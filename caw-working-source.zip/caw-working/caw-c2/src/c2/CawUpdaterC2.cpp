// CawUpdater.h for the ESP32-C2 clock. The check and the download are the
// ESP8266 updater's (GitHub's latest release, its SHA256SUMS.txt, the file
// installed only when its SHA-256 matches), over esp-tls. Rollback needs no
// copy here: the firmware that was running stays in the other app slot, and
// ESP-IDF's bootloader goes back to it when a new firmware restarts before
// it is confirmed (kCawRollbackConfirmMs).
#include <ArduinoJson.h>
#include <LittleFS.h>
#include <Updater.h>
#include <WiFiClientSecureBearSSL.h>

#include <memory>
#include <new>

#include "CawUpdater.h"
#include "../CawHttp.h"
#include "esp_ota_ops.h"
#include "mbedtls/sha256.h"

namespace {

constexpr char kNoticePath[] = "/fw-rollback.json";
constexpr char kInvalidSeenPath[] = "/fw-invalid-seen.txt";
constexpr uint32_t kReadTimeoutMs = 20000;

int readByteTimeout(BearSSL::WiFiClientSecure &client) {
  char c;
  return client.readBytes(&c, 1) == 1 ? static_cast<unsigned char>(c) : -1;
}

bool connectTo(std::unique_ptr<BearSSL::WiFiClientSecure> &client, const char *host, String &error) {
  client.reset(new (std::nothrow) BearSSL::WiFiClientSecure);
  if (!client) {
    error = F("Not enough memory");
    return false;
  }
  client->setTimeout(kReadTimeoutMs);
  if (client->connect(host, 443)) return true;
  error = String(F("Could not connect to ")) + host;
  if (client->getLastSSLError()) error += F(" (TLS error)");
  error += String(F("; free memory ")) + ESP.getFreeHeap() + F(", largest block ") + ESP.getMaxFreeBlockSize();
  return false;
}

// GET over HTTPS following GitHub's redirects (as the ESP8266 updater).
int httpsGetFollowing(const char *url, std::unique_ptr<BearSSL::WiFiClientSecure> &client, int32_t &length,
                      String &error) {
  constexpr size_t kUrlBytes = 1600;
  std::unique_ptr<char[]> buffer(new (std::nothrow) char[kUrlBytes]);
  if (!buffer) {
    error = F("Not enough memory");
    return 0;
  }
  char *current = buffer.get();
  strlcpy(current, url, kUrlBytes);
  for (uint8_t hop = 0; hop < 5; ++hop) {
    char host[96];
    const char *path = nullptr;
    if (!cawSplitHttpsUrl(current, host, sizeof(host), &path)) {
      error = F("Unexpected download address");
      return 0;
    }
    client.reset();
    if (!connectTo(client, host, error)) return 0;
    client->print(F("GET "));
    client->print(path);
    client->print(F(" HTTP/1.0\r\nHost: "));
    client->print(host);
    client->print(F("\r\nUser-Agent: CAW-Clock\r\nAccept: */*\r\nConnection: close\r\n\r\n"));
    BearSSL::WiFiClientSecure &stream = *client;
    const auto read = [&stream] { return readByteTimeout(stream); };
    const int status = readHttpStatus(read);
    if (!status || !cawReadHttpHeadersInPlace(read, current, kUrlBytes, length)) {
      error = String(F("No valid reply from ")) + host;
      return 0;
    }
    if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
      if (!current[0]) {
        error = F("Redirect without a usable address");
        return 0;
      }
      continue;
    }
    if (status != 200) error = String(F("GitHub answered HTTP ")) + status;
    return status;
  }
  error = F("Too many redirects");
  return 0;
}

void writeNotice(const char *failed, const char *restored) {
  DynamicJsonDocument document(256);
  document["failed"] = failed;
  document["restored"] = restored;
  File file = LittleFS.open(kNoticePath, "w");
  if (!file) return;
  serializeJson(document, file);
  file.close();
}

}  // namespace

CawRollbackSpace cawRollbackSpace() { return {1, 1}; }  // the other slot: always there

bool cawRollbackSave(const char *, void (*)(uint8_t)) { return true; }

// The new firmware ran long enough (or nothing was installed): keep it.
void cawRollbackDiscard() { esp_ota_mark_app_valid_cancel_rollback(); }

CawRollbackBoot cawRollbackBoot(const char *version, bool crashLoop, void (*message)(const char *line)) {
  const esp_partition_t *running = esp_ota_get_running_partition();
  esp_ota_img_states_t state = ESP_OTA_IMG_UNDEFINED;
  if (running && esp_ota_get_state_partition(running, &state) == ESP_OK && state == ESP_OTA_IMG_PENDING_VERIFY) {
    if (crashLoop) {  // safe mode on a new firmware: back to the previous one now
      const esp_partition_t *other = esp_ota_get_next_update_partition(nullptr);
      esp_app_desc_t previous = {};
      if (other && esp_ota_get_partition_description(other, &previous) == ESP_OK) {
        writeNotice(version, previous.version);
        if (message) message(previous.version);
        esp_ota_mark_app_invalid_rollback_and_reboot();
      }
    }
    return CawRollbackBoot::Pending;
  }
  // The bootloader went back from a new firmware that restarted before it was
  // confirmed: say so once on the System tab.
  const esp_partition_t *invalid = esp_ota_get_last_invalid_partition();
  esp_app_desc_t failed = {};
  if (!invalid || esp_ota_get_partition_description(invalid, &failed) != ESP_OK) return CawRollbackBoot::None;
  char key[48];
  snprintf(key, sizeof(key), "%lx %02x%02x%02x%02x", static_cast<unsigned long>(invalid->address),
           failed.app_elf_sha256[0], failed.app_elf_sha256[1], failed.app_elf_sha256[2], failed.app_elf_sha256[3]);
  char seen[48] = "";
  if (File file = LittleFS.open(kInvalidSeenPath, "r")) {
    const size_t got = file.read(reinterpret_cast<uint8_t *>(seen), sizeof(seen) - 1);
    seen[got] = '\0';
    file.close();
  }
  if (strcmp(seen, key) == 0) return CawRollbackBoot::None;
  if (File file = LittleFS.open(kInvalidSeenPath, "w")) {
    file.write(reinterpret_cast<const uint8_t *>(key), strlen(key));
    file.close();
  }
  writeNotice(failed.version, version);
  return CawRollbackBoot::RolledBack;
}

bool cawRollbackNotice(char *failed, size_t failedSize, char *restored, size_t restoredSize) {
  File file = LittleFS.open(kNoticePath, "r");
  if (!file) return false;
  DynamicJsonDocument document(256);
  const bool ok = document.capacity() && !deserializeJson(document, file);
  file.close();
  if (!ok) return false;
  strlcpy(failed, document["failed"] | "", failedSize);
  strlcpy(restored, document["restored"] | "", restoredSize);
  return failed[0] != '\0';
}

void cawRollbackClearNotice() { LittleFS.remove(kNoticePath); }

bool cawCheckLatestVersion(time_t, char *version, size_t versionSize, String &error, bool &lowMemory) {
  lowMemory = ESP.getFreeHeap() < 30000 || ESP.getMaxFreeBlockSize() < 18000;
  if (lowMemory) {
    error = F("Not enough free memory");
    return false;
  }
  std::unique_ptr<BearSSL::WiFiClientSecure> client;
  if (!connectTo(client, "github.com", error)) return false;
  client->print(F("GET /" CAW_RELEASE_REPOSITORY "/releases/latest HTTP/1.0\r\n"
                  "Host: github.com\r\nUser-Agent: CAW-Clock\r\nAccept: */*\r\n"
                  "Connection: close\r\n\r\n"));
  BearSSL::WiFiClientSecure &stream = *client;
  const auto read = [&stream] { return readByteTimeout(stream); };
  std::unique_ptr<char[]> buffers(new (std::nothrow) char[1024]);
  if (!buffers) {
    error = F("Not enough memory");
    return false;
  }
  char *line = buffers.get();
  char *location = line + 512;
  int32_t length = -1;
  const int status = readHttpStatus(read);
  const bool headers = status && cawReadHttpHeaders(read, line, 512, location, 512, length);
  client->stop();
  if (!headers) {
    error = F("No valid reply from github.com");
    return false;
  }
  if (status == 404) {
    error = F("No release published yet");
    return false;
  }
  if ((status != 302 && status != 301) ||
      !cawVersionFromTagUrl(location, CAW_RELEASE_REPOSITORY, version, versionSize)) {
    error = String(F("Unexpected reply from github.com (HTTP ")) + status + ')';
    return false;
  }
  return true;
}

bool cawFetchLatestRelease(time_t, CawReleaseInfo &out, String &error) {
  std::unique_ptr<BearSSL::WiFiClientSecure> client;
  int32_t length = -1;
  const int status = httpsGetFollowing(
      "https://github.com/" CAW_RELEASE_REPOSITORY "/releases/latest/download/SHA256SUMS.txt", client, length,
      error);
  if (status == 404) error = F("the release's files are still being uploaded; try again in a few minutes");
  else if (status && status != 200) error = String(F("Unexpected reply from GitHub (HTTP ")) + status + ')';
  if (status != 200) return false;
  constexpr size_t kMaxSums = 4096;
  if (length > static_cast<int32_t>(kMaxSums)) {
    error = F("Unexpected SHA256SUMS.txt");
    return false;
  }
  std::unique_ptr<char[]> text(new (std::nothrow) char[kMaxSums]);
  if (!text) {
    error = F("Not enough memory");
    return false;
  }
  size_t used = 0;
  for (int c; used < kMaxSums && (length < 0 || used < static_cast<size_t>(length)) &&
              (c = readByteTimeout(*client)) >= 0;)
    text[used++] = static_cast<char>(c);
  client->stop();
  if (!cawFindFirmwareInSums(text.get(), used, out)) {
    error = F("No firmware for this clock in the latest release");
    return false;
  }
  return true;
}

bool cawInstallRelease(time_t, const CawReleaseInfo &release, String &error,
                       void (*progress)(uint32_t done, uint32_t total)) {
  String url = F("https://github.com/" CAW_RELEASE_REPOSITORY "/releases/download/v");
  url += release.version;
  url += '/';
  url += release.file;
  std::unique_ptr<BearSSL::WiFiClientSecure> client;
  int32_t length = -1;
  if (httpsGetFollowing(url.c_str(), client, length, error) != 200) return false;
  if (length <= 0 || static_cast<uint32_t>(length) > ESP.getFreeSketchSpace()) {
    error = F("The firmware file has an unexpected size");
    return false;
  }
  std::unique_ptr<uint8_t[]> buffer(new (std::nothrow) uint8_t[1024]);
  if (!buffer || !Update.begin(length)) {
    error = F("Could not start the update");
    return false;
  }
  mbedtls_sha256_context sha;
  mbedtls_sha256_init(&sha);
  mbedtls_sha256_starts(&sha, 0);
  uint32_t done = 0;
  while (done < static_cast<uint32_t>(length)) {
    const size_t want = std::min<size_t>(1024, static_cast<size_t>(length) - done);
    const int got = client->read(buffer.get(), want);
    if (got <= 0) break;
    mbedtls_sha256_update(&sha, buffer.get(), got);
    if (Update.write(buffer.get(), got) != static_cast<size_t>(got)) break;
    done += got;
    if (progress) progress(done, length);
    yield();
  }
  client->stop();
  uint8_t digest[32];
  mbedtls_sha256_finish(&sha, digest);
  mbedtls_sha256_free(&sha);
  if (done != static_cast<uint32_t>(length)) {
    error = Update.hasError() ? F("Writing the firmware failed") : F("The download stopped");
    Update.abort();
    return false;
  }
  char hex[65];
  cawHex32(digest, hex);
  if (strcmp(hex, release.sha256) != 0) {
    Update.abort();  // nothing is activated: the current firmware keeps running
    error = F("Checksum mismatch: the download was not installed");
    return false;
  }
  if (!Update.end() || Update.hasError()) {
    error = F("Activating the firmware failed");
    return false;
  }
  return true;
}
