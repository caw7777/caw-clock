// CAW Clock for the ESP32-C2 SD PRO clock ("SDC2"): the ESP8266 firmware's
// app (firmware/src/CawStandalone/caw_standalone.cpp), unchanged but for a
// few CAW_C2 lines, on the stand-ins in src/port. Its setup and loop run in
// one task, as the ESP8266 core's loop.
#include <Arduino.h>

#include "CawApp.h"
#include "esp_attr.h"
#include "esp_ota_ops.h"
#include "esp_system.h"
#include "nvs_flash.h"

namespace {
// Last resort for a firmware that cannot start (the SDC2 has no serial port
// to fix it): starts that crash or hang before the app has run a minute are
// counted in RAM a restart leaves alone. After the app's own safe mode (3
// quick restarts) had its chance, the 4th switches to the firmware in the
// other slot, if there is one.
constexpr uint32_t kGuardMagic = 0xCA3C2F00;
constexpr uint32_t kFallbackAfter = 4;
constexpr uint32_t kRunningOkMs = 60000;
__NOINIT_ATTR uint32_t gGuard[2];  // magic, count

void countStart() {
  const esp_reset_reason_t reason = esp_reset_reason();
  const bool crash = reason == ESP_RST_PANIC || reason == ESP_RST_INT_WDT || reason == ESP_RST_TASK_WDT ||
                     reason == ESP_RST_WDT;
  if (gGuard[0] != kGuardMagic || !crash) {
    gGuard[0] = kGuardMagic;
    gGuard[1] = 0;
  }
  if (++gGuard[1] < kFallbackAfter) return;
  gGuard[1] = 0;
  const esp_partition_t *other = esp_ota_get_next_update_partition(nullptr);
  esp_app_desc_t description;
  if (other && esp_ota_get_partition_description(other, &description) == ESP_OK &&
      esp_ota_set_boot_partition(other) == ESP_OK)
    esp_restart();
}

void loopTask(void *) {
  cawAppSetup();
  const uint32_t started = millis();
  bool cleared = false;
  while (true) {
    cawAppLoop();
    if (!cleared && millis() - started >= kRunningOkMs) {
      cleared = true;
      gGuard[1] = 0;
    }
    // The ESP8266 loop yields to the system between passes; here every pass
    // sleeps a tick (1 ms) so the idle task (and its watchdog) always runs.
    cawSleepMs(1);
  }
}
}  // namespace

extern "C" void app_main(void) {
  countStart();
  esp_err_t err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    nvs_flash_erase();
    nvs_flash_init();
  }
  // 16 KB: the ESP8266's main stack is 4 KB plus BearSSL's own 6 KB; mbedTLS
  // and the page handlers run here.
  xTaskCreate(loopTask, "caw", 16 * 1024, nullptr, 5, nullptr);
}
