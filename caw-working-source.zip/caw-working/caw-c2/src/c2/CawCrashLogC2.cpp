// CawCrashLog.h for the ESP32-C2: after a crash or watchdog restart, the
// stage the app last marked (cawStage, kept in RAM a restart leaves alone)
// and the reset reason make the Status JSON's lastCrash record.
#include "CawCrashLog.h"

#include "esp_attr.h"
#include "esp_system.h"

volatile uint8_t gCawStage = 0;
volatile uint32_t gCawStageDetail = 0;
volatile uint32_t gCawStageHeap = 0;

namespace {
__NOINIT_ATTR uint32_t gLive[8];  // magic, stage, detail, heap, uptime
CawCrashRecord gCrash;
}  // namespace

volatile uint32_t *cawRtcLive() { return gLive; }

void cawCrashLogBegin() {
  const esp_reset_reason_t reason = esp_reset_reason();
  const bool crash = reason == ESP_RST_PANIC || reason == ESP_RST_INT_WDT || reason == ESP_RST_TASK_WDT ||
                     reason == ESP_RST_WDT;
  if (crash && gLive[0] == kCawRtcLiveMagic) {
    gCrash.valid = true;
    gCrash.fromResetInfo = true;
    gCrash.reason = reason == ESP_RST_PANIC ? 254 : reason;
    gCrash.stage = gLive[1];
    gCrash.detail = gLive[2];
    gCrash.heap = gLive[3];
    gCrash.uptime = gLive[4];
  }
  for (uint32_t &word : gLive) word = 0;
  gLive[0] = kCawRtcLiveMagic;
}

void cawCrashLogStore(bool, const char *version) {
  if (gCrash.valid) strlcpy(gCrash.version, version, sizeof(gCrash.version));
}

const CawCrashRecord &cawLastCrash() { return gCrash; }
