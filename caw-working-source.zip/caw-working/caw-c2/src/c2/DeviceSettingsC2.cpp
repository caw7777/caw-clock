// DeviceSettings.h for the ESP32-C2: the same DeviceConfig (Wi-Fi, clock
// password, user and host name) and checks as the ESP8266 firmware, kept as
// one NVS blob instead of EEPROM. On the first start of CAW Clock, the home
// network the factory firmware saved is taken over, so the clock joins it
// straight away (with no clock password yet: the panel asks for one).
#include "DeviceSettings.h"

#include <ESP8266WiFi.h>

#include <cctype>

#include "nvs.h"

namespace {
constexpr uint32_t kConfigMagic = 0x53445034;  // as DeviceSettings.cpp
constexpr char kNamespace[] = "cawdev";
constexpr char kKey[] = "config";

uint32_t checksum(const DeviceConfig &value) {
  const auto *bytes = reinterpret_cast<const uint8_t *>(&value);
  uint32_t hash = 2166136261UL;
  for (size_t index = 0; index < offsetof(DeviceConfig, checksum); ++index) {
    hash ^= bytes[index];
    hash *= 16777619UL;
  }
  return hash;
}
}  // namespace

bool deviceConfigValid(const DeviceConfig &config) {
  return config.magic == kConfigMagic && config.checksum == checksum(config);
}

bool wifiConfigured(const DeviceConfig &config) { return deviceConfigValid(config) && config.ssid[0] != '\0'; }

void saveDeviceConfig(DeviceConfig &config) {
  config.magic = kConfigMagic;
  config.checksum = checksum(config);
  nvs_handle_t handle;
  if (nvs_open(kNamespace, NVS_READWRITE, &handle) != ESP_OK) return;
  nvs_set_blob(handle, kKey, &config, sizeof(config));
  nvs_commit(handle);
  nvs_close(handle);
}

bool eraseDeviceConfig() {
  nvs_handle_t handle;
  if (nvs_open(kNamespace, NVS_READWRITE, &handle) != ESP_OK) return false;
  const esp_err_t err = nvs_erase_key(handle, kKey);
  nvs_commit(handle);
  nvs_close(handle);
  return err == ESP_OK || err == ESP_ERR_NVS_NOT_FOUND;
}

void loadDeviceConfig(DeviceConfig &config) {
  memset(&config, 0, sizeof(config));
  nvs_handle_t handle;
  size_t size = sizeof(config);
  bool found = false;
  if (nvs_open(kNamespace, NVS_READONLY, &handle) == ESP_OK) {
    found = nvs_get_blob(handle, kKey, &config, &size) == ESP_OK && size == sizeof(config);
    nvs_close(handle);
  }
  if (found && deviceConfigValid(config)) return;
  memset(&config, 0, sizeof(config));
  // First start (nothing stored, not a factory reset that erased it): the
  // factory firmware's home network.
  if (!found) {
    nvs_handle_t marker;
    uint8_t imported = 0;
    if (nvs_open(kNamespace, NVS_READWRITE, &marker) == ESP_OK) {
      nvs_get_u8(marker, "imported", &imported);
      if (!imported) nvs_set_u8(marker, "imported", 1), nvs_commit(marker);
      nvs_close(marker);
    }
    if (!imported && WiFi.factoryStation(config.ssid, sizeof(config.ssid), config.wifiPassword,
                                         sizeof(config.wifiPassword))) {
      strlcpy(config.username, "admin", sizeof(config.username));
      strlcpy(config.hostname, "caw-clock", sizeof(config.hostname));
      config.apiAuthEnabled = 1;
      config.wifiRetryLimit = kDefaultWifiRetryLimit;
      saveDeviceConfig(config);
      return;
    }
  }
  memset(&config, 0, sizeof(config));
}

bool timezoneValid(const char *value, size_t capacity) {
  const size_t length = strlen(value);
  if (length == 0 || length >= capacity) return false;
  for (size_t index = 0; index < length; ++index) {
    const unsigned char character = value[index];
    if (character < 0x20 || character > 0x7e) return false;
  }
  return true;
}

bool hostnameValid(const char *hostname) {
  const size_t length = strlen(hostname);
  if (length == 0 || length > 32 || hostname[0] == '-' || hostname[length - 1] == '-') return false;
  for (size_t index = 0; index < length; ++index) {
    const char character = hostname[index];
    if (!isalnum(static_cast<unsigned char>(character)) && character != '-') return false;
  }
  return true;
}

String deviceSuffix() {
  char suffix[7];
  snprintf(suffix, sizeof(suffix), "%06lX", static_cast<unsigned long>(ESP.getChipId()));
  return String(suffix);
}

String configuredHostname(const DeviceConfig &config) {
  if (config.hostname[0]) return String(config.hostname);
  return "caw-clock-" + deviceSuffix();
}

const char *configuredUsername(const DeviceConfig &config) { return config.username[0] ? config.username : "admin"; }
