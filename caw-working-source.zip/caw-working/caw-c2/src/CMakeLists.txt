# CAW Clock for the SDC2: the ESP8266 firmware's app compiled straight from
# its sources (one copy, ../../firmware/src), on the stand-ins in port/ for
# the Arduino core (String, WiFi, ESP8266WebServer, LittleFS, Update, BearSSL)
# and in c2/ for the parts that differ (updater, crash record, settings).
set(FW "${CMAKE_CURRENT_LIST_DIR}/../../firmware/src")
# The version the clock shows and compares updates with: the release tag
# (MINI_DISPLAY_BUILD_VERSION, as the ESP8266 build), else a development one.
if(DEFINED ENV{MINI_DISPLAY_BUILD_VERSION})
  set(CAW_VERSION "$ENV{MINI_DISPLAY_BUILD_VERSION}")
else()
  set(CAW_VERSION "0.7.0-dev")
endif()
idf_component_register(
  SRCS "c2/main_app.cpp" "c2/CawUpdaterC2.cpp" "c2/CawCrashLogC2.cpp" "c2/DeviceSettingsC2.cpp"
       "port/ArduinoCore.cpp" "port/TFT_eSPI.cpp" "port/LittleFS.cpp" "port/ESP8266WiFi.cpp"
       "port/ESP8266WebServer.cpp" "port/Updater.cpp" "port/WiFiClientSecureBearSSL.cpp"
       "${FW}/CawStandalone/caw_standalone.cpp" "${FW}/CawStandalone/CawFeedLite.cpp"
       "${FW}/CawStandalone/CawPictures.cpp" "${FW}/CawStandalone/CawScreen.cpp"
       "${FW}/CawFontAssets.cpp" "${FW}/DecimalParser.cpp"
  INCLUDE_DIRS "." "port" "c2" "${FW}" "${FW}/CawStandalone" "../generated"
               "${FW}/../.pio/libdeps/sdpro_caw_standalone/ArduinoJson/src"
  REQUIRES esp_driver_ledc esp_driver_gpio esp_driver_spi esp-tls mbedtls esp_netif esp_wifi esp_event
           nvs_flash esp_http_server app_update spi_flash esp_partition esp_timer esp_hw_support
           esp_app_format bootloader_support joltwallet__littlefs)
target_compile_definitions(${COMPONENT_LIB} PRIVATE
  CAW_STANDALONE=1 ESP8266=1 CAW_C2=1 MINI_DISPLAY_FEATURE_CAW=0
  "MINI_DISPLAY_VERSION=\"${CAW_VERSION}\""
  ARDUINOJSON_ENABLE_ARDUINO_STRING=1 ARDUINOJSON_ENABLE_ARDUINO_STREAM=1
  ARDUINOJSON_ENABLE_ARDUINO_PRINT=1 ARDUINOJSON_ENABLE_PROGMEM=0)
target_compile_options(${COMPONENT_LIB} PRIVATE -Wno-unused-function -Wno-missing-field-initializers
  -Wno-unused-variable -Wno-format-truncation)
