#pragma once
// The re-layout's new partition table, built from the factory one (pure:
// host-tested by test/relay_table_test.c). Same entries; app0 at 0x10000
// and app1 after it, 1.5 MB each; the spiffs data partition takes the rest
// of the 4 MB. Returns NULL, or why the table is not the expected layout.
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#ifndef RELAY_APP_SIZE
#define RELAY_APP_SIZE 0x180000u
#define RELAY_TABLE_BYTES 0xC00u
#endif

typedef void (*relay_md5_fn)(const uint8_t *data, size_t length, uint8_t digest[16]);

static inline const char *relay_build_table_md5(const uint8_t *old, uint8_t *table, relay_md5_fn md5_of) {
  const char *why = NULL;
  memset(table, 0xFF, RELAY_TABLE_BYTES);
  size_t n = 0;
  bool had_md5 = false;
  int apps = 0, data = 0;
  for (size_t off = 0; off + 32 <= RELAY_TABLE_BYTES; off += 32) {
    const uint8_t *e = old + off;
    if (e[0] == 0xEB && e[1] == 0xEB) { had_md5 = true; break; }
    if (!(e[0] == 0xAA && e[1] == 0x50)) break;
    uint8_t entry[32];
    memcpy(entry, e, 32);
    uint32_t addr, size;
    const uint8_t type = e[2], subtype = e[3];
    if (type == 0 && subtype == 0x10) { addr = 0x10000; size = RELAY_APP_SIZE; ++apps; }
    else if (type == 0 && subtype == 0x11) { addr = 0x10000 + RELAY_APP_SIZE; size = RELAY_APP_SIZE; ++apps; }
    else if (type == 1 && subtype == 0x82) { addr = 0x10000 + 2 * RELAY_APP_SIZE; size = 0x400000 - addr; ++data; }
    else { memcpy(&addr, e + 4, 4); memcpy(&size, e + 8, 4); if (addr + size > 0x10000) { why = "unexpected partition"; return why; } }
    memcpy(entry + 4, &addr, 4);
    memcpy(entry + 8, &size, 4);
    memcpy(table + n, entry, 32);
    n += 32;
  }
  if (apps != 2 || data != 1) { why = "the table is not the factory layout"; return why; }
  if (had_md5) {
    table[n] = 0xEB;
    table[n + 1] = 0xEB;
    md5_of(table, n, table + n + 16);
    n += 32;
  }
  (void)n;
  return why;
}
