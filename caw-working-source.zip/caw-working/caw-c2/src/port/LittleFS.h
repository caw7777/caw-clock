#pragma once
// LittleFS of the ESP8266 core, on ESP-IDF's LittleFS (joltwallet/littlefs)
// in the storage partition ("spiffs", 960 KB), mounted at /fs. Paths are the
// ESP8266 ones ("/caw-settings.json"); File is a Stream, so ArduinoJson reads
// and writes it directly.
#include <memory>

#include "Arduino.h"

struct CawFileHandle;

class File : public Stream {
 public:
  File() = default;
  explicit File(std::shared_ptr<CawFileHandle> h) : h_(std::move(h)) {}
  explicit operator bool() const;
  using Print::write;
  size_t write(uint8_t c) override;
  size_t write(const uint8_t *d, size_t n) override;
  int available() override;
  int read() override;
  int peek() override;
  size_t read(uint8_t *buf, size_t n);
  size_t readBytes(char *buf, size_t n) override { return read(reinterpret_cast<uint8_t *>(buf), n); }
  bool seek(uint32_t pos);
  size_t position() const;
  size_t size() const;
  void flush() override;
  void close();
  const char *name() const;

 private:
  std::shared_ptr<CawFileHandle> h_;
};

class Dir {
 public:
  bool next();
  String fileName() const { return name_; }
  size_t fileSize() const { return size_; }
  bool isDirectory() const { return directory_; }
  bool isFile() const { return !directory_; }

 private:
  friend class CawLittleFs;
  std::shared_ptr<void> dir_;  // DIR *
  std::string path_;           // real directory path
  String name_;
  size_t size_ = 0;
  bool directory_ = false;
};

struct FSInfo {
  size_t totalBytes = 0, usedBytes = 0, blockSize = 4096, pageSize = 256, maxOpenFiles = 5, maxPathLength = 64;
};

class CawLittleFs {
 public:
  bool begin();
  void end();
  bool format();
  File open(const char *path, const char *mode);
  File open(const String &path, const char *mode) { return open(path.c_str(), mode); }
  bool exists(const char *path);
  bool exists(const String &path) { return exists(path.c_str()); }
  bool remove(const char *path);
  bool remove(const String &path) { return remove(path.c_str()); }
  bool rename(const char *from, const char *to);
  bool rename(const String &from, const String &to) { return rename(from.c_str(), to.c_str()); }
  bool mkdir(const char *path);
  bool rmdir(const char *path);
  Dir openDir(const char *path);
  Dir openDir(const String &path) { return openDir(path.c_str()); }
  bool info(FSInfo &info);

 private:
  bool mounted_ = false;
};
extern CawLittleFs LittleFS;
