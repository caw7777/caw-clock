#pragma once
// BearSSL's separate stack (ESP8266 core); mbedTLS runs on the task's own stack here.
#include <cstdint>
inline uint32_t stack_thunk_get_max_usage() { return 0; }
