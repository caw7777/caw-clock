#pragma once
#include "Arduino.h"

class IPAddress {
 public:
  IPAddress() = default;
  IPAddress(uint32_t raw) : raw_(raw) {}  // network order, as lwIP stores it
  IPAddress(uint8_t a, uint8_t b, uint8_t c, uint8_t d) : raw_(a | b << 8 | c << 16 | uint32_t(d) << 24) {}
  operator uint32_t() const { return raw_; }
  uint8_t operator[](int i) const { return uint8_t(raw_ >> (8 * i)); }
  bool operator==(const IPAddress &o) const { return raw_ == o.raw_; }
  bool operator!=(const IPAddress &o) const { return raw_ != o.raw_; }
  bool isSet() const { return raw_ != 0; }
  String toString() const {
    char b[16];
    snprintf(b, sizeof(b), "%u.%u.%u.%u", (*this)[0], (*this)[1], (*this)[2], (*this)[3]);
    return String(b);
  }
  bool fromString(const char *text) {
    unsigned a, b, c, d;
    char end;
    if (sscanf(text, "%u.%u.%u.%u%c", &a, &b, &c, &d, &end) != 4 || a > 255 || b > 255 || c > 255 || d > 255)
      return false;
    *this = IPAddress(a, b, c, d);
    return true;
  }

 private:
  uint32_t raw_ = 0;
};
