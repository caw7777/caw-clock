#include "ESP8266WiFi.h"

#include "esp_event.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_wifi.h"

#include <mutex>
#include <new>

CawWiFi WiFi;

namespace {
esp_netif_t *gSta = nullptr, *gAp = nullptr;
char gFactorySsid[33], gFactoryPassword[65];
std::mutex gScanLock;  // the scan list: written by the driver's event, read by the setup page
bool gFactoryRead = false;

void handler(void *, esp_event_base_t base, int32_t id, void *data) { WiFi.onEvent(base, id, data); }

bool hasStation(WiFiMode_t m) { return m == WIFI_STA || m == WIFI_AP_STA; }
bool hasAp(WiFiMode_t m) { return m == WIFI_AP || m == WIFI_AP_STA; }
}  // namespace

void CawWiFi::init() {
  if (started_) return;
  started_ = true;
  esp_netif_init();
  esp_event_loop_create_default();
  gSta = esp_netif_create_default_wifi_sta();
  gAp = esp_netif_create_default_wifi_ap();
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&cfg);
  // The factory firmware kept its station network in the driver's storage:
  // read it once, then keep everything CAW Clock sets in RAM (its own copy
  // lives in DeviceConfig).
  wifi_config_t saved = {};
  if (esp_wifi_get_config(WIFI_IF_STA, &saved) == ESP_OK && saved.sta.ssid[0]) {
    snprintf(gFactorySsid, sizeof(gFactorySsid), "%s", reinterpret_cast<const char *>(saved.sta.ssid));
    snprintf(gFactoryPassword, sizeof(gFactoryPassword), "%s", reinterpret_cast<const char *>(saved.sta.password));
  }
  gFactoryRead = true;
  esp_wifi_set_storage(WIFI_STORAGE_RAM);
  esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, handler, nullptr);
  esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, handler, nullptr);
  esp_event_handler_register(IP_EVENT, IP_EVENT_STA_LOST_IP, handler, nullptr);
  esp_netif_set_hostname(gSta, hostname_);
}

bool CawWiFi::factoryStation(char *ssid, size_t ssidSize, char *password, size_t passwordSize) {
  init();
  if (!gFactorySsid[0]) return false;
  snprintf(ssid, ssidSize, "%s", gFactorySsid);
  snprintf(password, passwordSize, "%s", gFactoryPassword);
  return true;
}

bool CawWiFi::mode(WiFiMode_t mode) {
  init();
  mode_ = mode;
  // The driver scans only with a station interface: the access point always
  // comes with an (idle) station, as the ESP8266 allows scanning in AP mode.
  const wifi_mode_t m = mode == WIFI_OFF ? WIFI_MODE_NULL
                        : hasAp(mode)    ? WIFI_MODE_APSTA
                                         : WIFI_MODE_STA;
  if (m == WIFI_MODE_NULL) {
    esp_wifi_stop();
    status_ = WL_DISCONNECTED;
    return true;
  }
  const bool ok = esp_wifi_set_mode(m) == ESP_OK;
  esp_wifi_start();
  return ok;
}

bool CawWiFi::hostname(const char *name) {
  snprintf(hostname_, sizeof(hostname_), "%s", name);
  init();
  return esp_netif_set_hostname(gSta, hostname_) == ESP_OK;
}

wl_status_t CawWiFi::begin(const char *ssid, const char *password) {
  init();
  if (!hasStation(mode_)) mode(hasAp(mode_) ? WIFI_AP_STA : WIFI_STA);
  wifi_config_t config = {};
  snprintf(reinterpret_cast<char *>(config.sta.ssid), sizeof(config.sta.ssid), "%s", ssid);
  if (password) snprintf(reinterpret_cast<char *>(config.sta.password), sizeof(config.sta.password), "%s", password);
  config.sta.scan_method = WIFI_ALL_CHANNEL_SCAN;
  config.sta.sort_method = WIFI_CONNECT_AP_BY_SIGNAL;
  esp_wifi_set_config(WIFI_IF_STA, &config);
  wantStation_ = true;
  status_ = WL_DISCONNECTED;
  esp_wifi_disconnect();
  esp_wifi_connect();
  lastReconnect_ = millis();
  return status_;
}

bool CawWiFi::disconnect(bool) {
  wantStation_ = false;
  if (started_) esp_wifi_disconnect();
  status_ = WL_DISCONNECTED;
  return true;
}

IPAddress CawWiFi::localIP() const {
  esp_netif_ip_info_t info = {};
  if (!gSta || status_ != WL_CONNECTED || esp_netif_get_ip_info(gSta, &info) != ESP_OK) return IPAddress();
  return IPAddress(info.ip.addr);
}

IPAddress CawWiFi::softAPIP() const {
  esp_netif_ip_info_t info = {};
  if (!gAp || !hasAp(mode_) || esp_netif_get_ip_info(gAp, &info) != ESP_OK) return IPAddress();
  return IPAddress(info.ip.addr);
}

String CawWiFi::SSID() const {
  wifi_ap_record_t ap = {};
  if (status_ == WL_CONNECTED && esp_wifi_sta_get_ap_info(&ap) == ESP_OK)
    return String(reinterpret_cast<const char *>(ap.ssid));
  return String();
}

int32_t CawWiFi::RSSI() const {
  wifi_ap_record_t ap = {};
  return status_ == WL_CONNECTED && esp_wifi_sta_get_ap_info(&ap) == ESP_OK ? ap.rssi : 0;
}

bool CawWiFi::softAP(const char *ssid, const char *password, int channel) {
  init();
  if (!hasAp(mode_)) mode(hasStation(mode_) ? WIFI_AP_STA : WIFI_AP);
  wifi_config_t config = {};
  snprintf(reinterpret_cast<char *>(config.ap.ssid), sizeof(config.ap.ssid), "%s", ssid);
  config.ap.ssid_len = strlen(reinterpret_cast<const char *>(config.ap.ssid));
  const bool secured = password && strlen(password) >= 8;
  if (secured) snprintf(reinterpret_cast<char *>(config.ap.password), sizeof(config.ap.password), "%s", password);
  config.ap.authmode = secured ? WIFI_AUTH_WPA2_PSK : WIFI_AUTH_OPEN;
  config.ap.channel = channel;
  config.ap.max_connection = 4;
  config.ap.pmf_cfg.required = false;
  return esp_wifi_set_config(WIFI_IF_AP, &config) == ESP_OK;
}

bool CawWiFi::softAPdisconnect(bool) {
  if (!hasAp(mode_)) return true;
  return mode(hasStation(mode_) ? WIFI_STA : WIFI_OFF);
}

uint8_t CawWiFi::softAPgetStationNum() const {
  wifi_sta_list_t list = {};
  return hasAp(mode_) && esp_wifi_ap_get_sta_list(&list) == ESP_OK ? list.num : 0;
}

int8_t CawWiFi::scanNetworks(bool) {
  init();
  if (mode_ == WIFI_OFF) mode(WIFI_STA);
  scanDelete();
  if (esp_wifi_scan_start(nullptr, false) != ESP_OK) {
    scanState_ = WIFI_SCAN_FAILED;
    return WIFI_SCAN_FAILED;
  }
  scanState_ = WIFI_SCAN_RUNNING;
  return WIFI_SCAN_RUNNING;
}

void CawWiFi::scanDelete() {
  std::lock_guard<std::mutex> lock(gScanLock);
  delete[] networks_;
  networks_ = nullptr;
  networkCount_ = 0;
  if (scanState_ != WIFI_SCAN_RUNNING) scanState_ = WIFI_SCAN_FAILED;
}

String CawWiFi::SSID(uint8_t index) const {
  std::lock_guard<std::mutex> lock(gScanLock);
  return index < networkCount_ && networks_ ? String(networks_[index].ssid) : String();
}

int32_t CawWiFi::RSSI(uint8_t index) const {
  std::lock_guard<std::mutex> lock(gScanLock);
  return index < networkCount_ && networks_ ? networks_[index].rssi : 0;
}

String CawWiFi::macAddress() const {
  uint8_t mac[6] = {};
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  char text[18];
  snprintf(text, sizeof(text), "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(text);
}

void CawWiFi::onEvent(const char *base, int32_t id, void *data) {
  if (base == WIFI_EVENT) {
    if (id == WIFI_EVENT_STA_DISCONNECTED) {
      const auto *event = static_cast<const wifi_event_sta_disconnected_t *>(data);
      switch (event->reason) {
        case WIFI_REASON_NO_AP_FOUND:
          status_ = WL_NO_SSID_AVAIL;
          break;
        case WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT:
        case WIFI_REASON_AUTH_FAIL:
        case WIFI_REASON_HANDSHAKE_TIMEOUT:
        case WIFI_REASON_MIC_FAILURE:
          status_ = WL_WRONG_PASSWORD;
          break;
        case WIFI_REASON_ASSOC_FAIL:
        case WIFI_REASON_CONNECTION_FAIL:
          status_ = WL_CONNECT_FAILED;
          break;
        default:
          status_ = WL_DISCONNECTED;
      }
      // As the ESP8266's auto-reconnect: try again while the station is wanted.
      if (wantStation_ && autoReconnect_) esp_wifi_connect();
    } else if (id == WIFI_EVENT_SCAN_DONE) {
      uint16_t count = 0;
      esp_wifi_scan_get_ap_num(&count);
      if (count > 32) count = 32;
      auto *records = new (std::nothrow) wifi_ap_record_t[count ? count : 1];
      auto *networks = new (std::nothrow) Network[count ? count : 1];
      if (records && networks && esp_wifi_scan_get_ap_records(&count, records) == ESP_OK) {
        for (uint16_t i = 0; i < count; ++i) {
          snprintf(networks[i].ssid, sizeof(networks[i].ssid), "%s", reinterpret_cast<const char *>(records[i].ssid));
          networks[i].rssi = records[i].rssi;
        }
        std::lock_guard<std::mutex> lock(gScanLock);
        delete[] networks_;
        networks_ = networks;
        networkCount_ = count;
        networks = nullptr;
        scanState_ = int8_t(count);
      } else {
        esp_wifi_clear_ap_list();
        scanState_ = WIFI_SCAN_FAILED;
      }
      delete[] records;
      delete[] networks;
    }
  } else if (base == IP_EVENT) {
    if (id == IP_EVENT_STA_GOT_IP) status_ = WL_CONNECTED;
    else if (id == IP_EVENT_STA_LOST_IP && status_ == WL_CONNECTED) status_ = WL_DISCONNECTED;
  }
}
