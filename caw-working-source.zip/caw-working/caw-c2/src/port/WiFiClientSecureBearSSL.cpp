#include "WiFiClientSecureBearSSL.h"

#include "esp_crt_bundle.h"
#include "esp_tls.h"

namespace BearSSL {

int WiFiClientSecure::connect(const char *host, uint16_t port) {
  stop();
  lastError_ = 0;
  closed_ = false;
  bufferStart_ = bufferEnd_ = 0;
  esp_tls_cfg_t config = {};
  config.crt_bundle_attach = esp_crt_bundle_attach;  // CAW Clock's roots only
  config.timeout_ms = static_cast<int>(timeout_ < 3000 ? 10000 : timeout_);
  esp_tls_t *tls = esp_tls_init();
  if (!tls) {
    lastError_ = 0;
    return 0;
  }
  if (esp_tls_conn_new_sync(host, strlen(host), port, &config, tls) != 1) {
    int code = 0, flags = 0;
    esp_tls_error_handle_t handle = nullptr;
    if (esp_tls_get_error_handle(tls, &handle) == ESP_OK && handle)
      esp_tls_get_and_clear_last_error(handle, &code, &flags);
    // A TLS-level failure (certificate, handshake) is a "TLS error"; a
    // connection that never got that far is "no connection".
    lastError_ = (code || flags) ? kCawTlsError : 0;
    esp_tls_conn_destroy(tls);
    return 0;
  }
  tls_ = tls;
  return 1;
}

uint8_t WiFiClientSecure::connected() { return tls_ && (!closed_ || bufferStart_ < bufferEnd_); }

void WiFiClientSecure::stop() {
  if (tls_) esp_tls_conn_destroy(static_cast<esp_tls_t *>(tls_));
  tls_ = nullptr;
  bufferStart_ = bufferEnd_ = 0;
}

size_t WiFiClientSecure::write(const uint8_t *data, size_t length) {
  if (!tls_) return 0;
  size_t done = 0;
  while (done < length) {
    const ssize_t sent = esp_tls_conn_write(static_cast<esp_tls_t *>(tls_), data + done, length - done);
    if (sent == ESP_TLS_ERR_SSL_WANT_READ || sent == ESP_TLS_ERR_SSL_WANT_WRITE) continue;
    if (sent <= 0) break;
    done += sent;
  }
  return done;
}

// Blocking up to the connection timeout (set at connect).
bool WiFiClientSecure::fill() {
  if (!tls_ || closed_) return false;
  while (true) {
    const ssize_t got = esp_tls_conn_read(static_cast<esp_tls_t *>(tls_), buffer_, sizeof(buffer_));
    if (got == ESP_TLS_ERR_SSL_WANT_READ || got == ESP_TLS_ERR_SSL_WANT_WRITE) continue;
    if (got <= 0) {
      closed_ = true;
      return false;
    }
    bufferStart_ = 0;
    bufferEnd_ = size_t(got);
    return true;
  }
}

int WiFiClientSecure::available() {
  if (bufferStart_ < bufferEnd_) return int(bufferEnd_ - bufferStart_);
  if (!tls_ || closed_) return 0;
  const ssize_t pending = esp_tls_get_bytes_avail(static_cast<esp_tls_t *>(tls_));
  return pending > 0 ? int(pending) : 0;
}

int WiFiClientSecure::read() {
  if (bufferStart_ >= bufferEnd_ && !fill()) return -1;
  return buffer_[bufferStart_++];
}

int WiFiClientSecure::peek() {
  if (bufferStart_ >= bufferEnd_ && !fill()) return -1;
  return buffer_[bufferStart_];
}

int WiFiClientSecure::read(uint8_t *buffer, size_t length) {
  return int(readBytes(reinterpret_cast<char *>(buffer), length));
}

size_t WiFiClientSecure::readBytes(char *buffer, size_t length) {
  size_t done = 0;
  while (done < length) {
    if (bufferStart_ >= bufferEnd_ && !fill()) break;
    const size_t piece = std::min(length - done, bufferEnd_ - bufferStart_);
    memcpy(buffer + done, buffer_ + bufferStart_, piece);
    bufferStart_ += piece;
    done += piece;
  }
  return done;
}

int WiFiClientSecure::getLastSSLError(char *dest, size_t len) {
  if (dest && len) snprintf(dest, len, "%s", lastError_ ? "TLS error" : "");
  return lastError_;
}

}  // namespace BearSSL
