#include "WiFiClientSecureBearSSL.h"

#include "esp_crt_bundle.h"
#include "esp_tls.h"

namespace BearSSL {

void *Session::saved() const {
  void *session = nullptr;
  memcpy(&session, parameters_.master_secret, sizeof(session));
  return session;
}

void Session::keep(void *session, const uint8_t *id, size_t idLength) {
  clear();
  memcpy(parameters_.master_secret, &session, sizeof(session));
  parameters_.session_id_len = idLength > sizeof(parameters_.session_id) ? 0 : idLength;
  if (parameters_.session_id_len) memcpy(parameters_.session_id, id, parameters_.session_id_len);
}

void Session::clear() {
  if (void *session = saved())
    esp_tls_free_client_session(static_cast<esp_tls_client_session_t *>(session));
  memset(&parameters_, 0, sizeof(parameters_));
}

int WiFiClientSecure::connect(const char *host, uint16_t port) {
  stop();
  lastError_ = 0;
  closed_ = false;
  bufferStart_ = bufferEnd_ = 0;
  esp_tls_cfg_t config = {};
  config.crt_bundle_attach = esp_crt_bundle_attach;  // CAW Clock's roots only
  config.timeout_ms = static_cast<int>(timeout_ < 3000 ? 10000 : timeout_);
  // This host's last session, offered for resumption (the server may refuse
  // it; then the full handshake runs as usual).
  if (session_) config.client_session = static_cast<esp_tls_client_session_t *>(session_->saved());
  esp_tls_t *tls = esp_tls_init();
  if (!tls) {
    lastError_ = 0;
    return 0;
  }
  if (esp_tls_conn_new_sync(host, strlen(host), port, &config, tls) != 1) {
    int code = 0, flags = 0;
    esp_tls_error_handle_t handle = nullptr;
    if (esp_tls_get_error_handle(tls, &handle) == ESP_OK && handle)
      esp_tls_get_and_clear_last_error(handle, &code, &flags);
    // A TLS-level failure (certificate, handshake) is a "TLS error"; a
    // connection that never got that far is "no connection".
    lastError_ = (code || flags) ? kCawTlsError : 0;
    esp_tls_conn_destroy(tls);
    if (session_) session_->clear();  // not offered again after a failure
    return 0;
  }
  tls_ = tls;
  if (session_) {
    // This connection's session, for the next one. mbedTLS exports a
    // session only once per connection, so esp-tls takes it and the id is
    // read from that copy. The id: the master secret folded to 16 bytes,
    // unchanged when the server resumed the session (the TLS session id
    // itself is new with each ticket), so the shared code's "resumed" count
    // works as on the ESP8266.
    esp_tls_client_session_t *saved = esp_tls_get_client_session(tls);
    if (saved) {
      const unsigned char *master = saved->saved_session.MBEDTLS_PRIVATE(master);
      uint8_t id[16] = {};
      for (size_t index = 0; index < 48; ++index) id[index % sizeof(id)] ^= master[index];
      session_->keep(saved, id, sizeof(id));
    } else {
      session_->clear();
    }
  }
  return 1;
}

uint8_t WiFiClientSecure::connected() { return tls_ && (!closed_ || bufferStart_ < bufferEnd_); }

void WiFiClientSecure::stop() {
  if (tls_) esp_tls_conn_destroy(static_cast<esp_tls_t *>(tls_));
  tls_ = nullptr;
  bufferStart_ = bufferEnd_ = 0;
}

size_t WiFiClientSecure::write(const uint8_t *data, size_t length) {
  if (!tls_) return 0;
  size_t done = 0;
  while (done < length) {
    const ssize_t sent = esp_tls_conn_write(static_cast<esp_tls_t *>(tls_), data + done, length - done);
    if (sent == ESP_TLS_ERR_SSL_WANT_READ || sent == ESP_TLS_ERR_SSL_WANT_WRITE) continue;
    if (sent <= 0) break;
    done += sent;
  }
  return done;
}

// Blocking up to the connection timeout (set at connect).
bool WiFiClientSecure::fill() {
  if (!tls_ || closed_) return false;
  while (true) {
    const ssize_t got = esp_tls_conn_read(static_cast<esp_tls_t *>(tls_), buffer_, sizeof(buffer_));
    if (got == ESP_TLS_ERR_SSL_WANT_READ || got == ESP_TLS_ERR_SSL_WANT_WRITE) continue;
    if (got <= 0) {
      closed_ = true;
      return false;
    }
    bufferStart_ = 0;
    bufferEnd_ = size_t(got);
    return true;
  }
}

int WiFiClientSecure::available() {
  if (bufferStart_ < bufferEnd_) return int(bufferEnd_ - bufferStart_);
  if (!tls_ || closed_) return 0;
  const ssize_t pending = esp_tls_get_bytes_avail(static_cast<esp_tls_t *>(tls_));
  return pending > 0 ? int(pending) : 0;
}

int WiFiClientSecure::read() {
  if (bufferStart_ >= bufferEnd_ && !fill()) return -1;
  return buffer_[bufferStart_++];
}

int WiFiClientSecure::peek() {
  if (bufferStart_ >= bufferEnd_ && !fill()) return -1;
  return buffer_[bufferStart_];
}

int WiFiClientSecure::read(uint8_t *buffer, size_t length) {
  return int(readBytes(reinterpret_cast<char *>(buffer), length));
}

size_t WiFiClientSecure::readBytes(char *buffer, size_t length) {
  size_t done = 0;
  while (done < length) {
    if (bufferStart_ >= bufferEnd_ && !fill()) break;
    const size_t piece = std::min(length - done, bufferEnd_ - bufferStart_);
    memcpy(buffer + done, buffer_ + bufferStart_, piece);
    bufferStart_ += piece;
    done += piece;
  }
  return done;
}

int WiFiClientSecure::getLastSSLError(char *dest, size_t len) {
  if (dest && len) snprintf(dest, len, "%s", lastError_ ? "TLS error" : "");
  return lastError_;
}

}  // namespace BearSSL
