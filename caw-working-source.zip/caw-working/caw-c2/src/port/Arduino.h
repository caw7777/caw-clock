#pragma once
// The parts of the Arduino ESP8266 core that CAW Clock's code uses, on
// ESP-IDF for the ESP32-C2 (SDC2 clock). Flash data is memory-mapped on the
// ESP32-C2, so PROGMEM reads are plain reads and F("...") is a plain string
// with the Arduino type (so code that overloads on it still compiles).
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include "esp_random.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// ------------------------------------------------------------ flash strings
class __FlashStringHelper;
#define PROGMEM
#define PGM_P const char *
#define PSTR(s) (s)
#define F(s) (reinterpret_cast<const __FlashStringHelper *>(PSTR(s)))
#define FPSTR(s) (reinterpret_cast<const __FlashStringHelper *>(s))
inline const char *cawFlash(const __FlashStringHelper *s) { return reinterpret_cast<const char *>(s); }

inline uint8_t pgm_read_byte(const void *a) { return *static_cast<const uint8_t *>(a); }
inline uint16_t pgm_read_word(const void *a) { uint16_t v; memcpy(&v, a, 2); return v; }
inline uint32_t pgm_read_dword(const void *a) { uint32_t v; memcpy(&v, a, 4); return v; }
inline float pgm_read_float(const void *a) { float v; memcpy(&v, a, 4); return v; }
inline const void *pgm_read_ptr(const void *a) { const void *v; memcpy(&v, a, sizeof v); return v; }
#define memcpy_P memcpy
#define memcmp_P memcmp
#define strlen_P strlen
#define strcpy_P strcpy
#define strncpy_P strncpy
#define strcmp_P strcmp
#define strncmp_P strncmp
#define strcasecmp_P strcasecmp
#define strstr_P strstr
#define snprintf_P snprintf
#define sprintf_P sprintf
#define vsnprintf_P vsnprintf

// -------------------------------------------------------------------- time
inline uint32_t millis() { return static_cast<uint32_t>(esp_timer_get_time() / 1000); }
inline uint32_t micros() { return static_cast<uint32_t>(esp_timer_get_time()); }
// At least one tick: pdMS_TO_TICKS rounds below one tick (10 ms) to 0, which
// only yields, and a loop that never sleeps starves the idle task (the task
// watchdog then restarts the clock).
inline void cawSleepMs(uint32_t ms) {
  const TickType_t ticks = pdMS_TO_TICKS(ms);
  vTaskDelay(ticks ? ticks : 1);
}
inline void delay(uint32_t ms) { cawSleepMs(ms); }
inline void yield() { taskYIELD(); }
inline void optimistic_yield(uint32_t) {}

inline bool isDigit(int c) { return isdigit(c) != 0; }
inline bool isAlpha(int c) { return isalpha(c) != 0; }
inline bool isAlphaNumeric(int c) { return isalnum(c) != 0; }
inline bool isSpace(int c) { return isspace(c) != 0; }
inline bool isHexadecimalDigit(int c) { return isxdigit(c) != 0; }

// ------------------------------------------------------------------ String
class String {
 public:
  String() = default;
  String(const char *t) : s_(t ? t : "") {}
  String(const char *t, size_t n) : s_(t ? std::string(t, n) : std::string()) {}
  String(const __FlashStringHelper *t) : String(cawFlash(t)) {}
  explicit String(const std::string &t) : s_(t) {}
  explicit String(std::string &&t) : s_(std::move(t)) {}
  explicit String(char c) : s_(1, c) {}
  explicit String(unsigned char v) : s_(std::to_string(unsigned(v))) {}
  explicit String(int v) : s_(std::to_string(v)) {}
  explicit String(unsigned v) : s_(std::to_string(v)) {}
  explicit String(long v) : s_(std::to_string(v)) {}
  explicit String(unsigned long v) : s_(std::to_string(v)) {}
  explicit String(long long v) : s_(std::to_string(v)) {}
  explicit String(unsigned long long v) : s_(std::to_string(v)) {}
  explicit String(float v, unsigned char decimals = 2) { setFloat(v, decimals); }
  explicit String(double v, unsigned char decimals = 2) { setFloat(v, decimals); }

  const char *c_str() const { return s_.c_str(); }
  unsigned length() const { return s_.length(); }
  bool isEmpty() const { return s_.empty(); }
  bool reserve(unsigned n) { s_.reserve(n); return true; }
  const std::string &std() const { return s_; }

  char operator[](unsigned i) const { return i < s_.length() ? s_[i] : 0; }
  char &operator[](unsigned i) { return s_[i]; }
  char charAt(unsigned i) const { return (*this)[i]; }
  void setCharAt(unsigned i, char c) { if (i < s_.length()) s_[i] = c; }

  bool concat(const char *t) { s_ += t ? t : ""; return true; }
  bool concat(const char *t, size_t n) { s_.append(t, n); return true; }
  bool concat(const String &t) { s_ += t.s_; return true; }
  bool concat(char c) { s_ += c; return true; }
  // For ArduinoJson's Print writer.
  size_t write(uint8_t c) { s_ += char(c); return 1; }
  size_t write(const uint8_t *d, size_t n) { s_.append(reinterpret_cast<const char *>(d), n); return n; }

  String &operator+=(const String &t) { s_ += t.s_; return *this; }
  String &operator+=(const char *t) { s_ += t ? t : ""; return *this; }
  String &operator+=(const __FlashStringHelper *t) { return *this += cawFlash(t); }
  String &operator+=(const std::string &t) { s_ += t; return *this; }
  String &operator+=(char c) { s_ += c; return *this; }
  String &operator+=(unsigned char v) { s_ += std::to_string(unsigned(v)); return *this; }
  String &operator+=(short v) { s_ += std::to_string(v); return *this; }
  String &operator+=(unsigned short v) { s_ += std::to_string(v); return *this; }
  String &operator+=(int v) { s_ += std::to_string(v); return *this; }
  String &operator+=(unsigned v) { s_ += std::to_string(v); return *this; }
  String &operator+=(long v) { s_ += std::to_string(v); return *this; }
  String &operator+=(unsigned long v) { s_ += std::to_string(v); return *this; }
  String &operator+=(long long v) { s_ += std::to_string(v); return *this; }
  String &operator+=(unsigned long long v) { s_ += std::to_string(v); return *this; }
  String &operator+=(float v) { return *this += String(v); }
  String &operator+=(double v) { return *this += String(v); }

  bool operator==(const String &o) const { return s_ == o.s_; }
  bool operator==(const char *o) const { return s_ == (o ? o : ""); }
  bool operator==(const __FlashStringHelper *o) const { return *this == cawFlash(o); }
  bool operator!=(const String &o) const { return !(*this == o); }
  bool operator!=(const char *o) const { return !(*this == o); }
  bool operator!=(const __FlashStringHelper *o) const { return !(*this == o); }
  bool operator<(const String &o) const { return s_ < o.s_; }
  bool equals(const String &o) const { return *this == o; }
  bool equalsIgnoreCase(const String &o) const { return strcasecmp(c_str(), o.c_str()) == 0; }

  long toInt() const { return strtol(s_.c_str(), nullptr, 10); }
  float toFloat() const { return strtof(s_.c_str(), nullptr); }
  double toDouble() const { return strtod(s_.c_str(), nullptr); }
  void toLowerCase() { for (char &c : s_) c = char(tolower(static_cast<unsigned char>(c))); }
  void toUpperCase() { for (char &c : s_) c = char(toupper(static_cast<unsigned char>(c))); }
  void trim() {
    size_t a = 0, b = s_.size();
    while (a < b && isspace(static_cast<unsigned char>(s_[a]))) ++a;
    while (b > a && isspace(static_cast<unsigned char>(s_[b - 1]))) --b;
    s_ = s_.substr(a, b - a);
  }
  void remove(unsigned index) { if (index < s_.size()) s_.erase(index); }
  void remove(unsigned index, unsigned count) { if (index < s_.size()) s_.erase(index, count); }
  int indexOf(char c, unsigned from = 0) const { return found(s_.find(c, from)); }
  int indexOf(const char *t, unsigned from = 0) const { return found(s_.find(t, from)); }
  int indexOf(const String &t, unsigned from = 0) const { return found(s_.find(t.s_, from)); }
  int lastIndexOf(char c) const { return found(s_.rfind(c)); }
  int lastIndexOf(const char *t) const { return found(s_.rfind(t)); }
  String substring(unsigned from) const { return from < s_.size() ? String(s_.substr(from)) : String(); }
  String substring(unsigned from, unsigned to) const {
    if (to > s_.size()) to = s_.size();
    return from < to ? String(s_.substr(from, to - from)) : String();
  }
  bool startsWith(const String &p) const { return s_.compare(0, p.s_.size(), p.s_) == 0; }
  bool endsWith(const String &p) const {
    return p.s_.size() <= s_.size() && s_.compare(s_.size() - p.s_.size(), p.s_.size(), p.s_) == 0;
  }
  void replace(const String &from, const String &to) {
    if (from.s_.empty()) return;
    for (size_t at = 0; (at = s_.find(from.s_, at)) != std::string::npos; at += to.s_.size())
      s_.replace(at, from.s_.size(), to.s_);
  }
  void toCharArray(char *buf, unsigned size) const { if (size) { strncpy(buf, c_str(), size - 1); buf[size - 1] = 0; } }

 private:
  static int found(size_t at) { return at == std::string::npos ? -1 : int(at); }
  void setFloat(double v, unsigned char decimals) {
    char b[48];
    snprintf(b, sizeof(b), "%.*f", decimals, v);
    s_ = b;
  }
  std::string s_;
};

template <typename T>
inline String operator+(const String &a, const T &b) { String r(a); r += b; return r; }
inline String operator+(const char *a, const String &b) { String r(a); r += b; return r; }
inline String operator+(const __FlashStringHelper *a, const String &b) { String r(a); r += b; return r; }
inline bool operator==(const char *a, const String &b) { return b == a; }
inline const String emptyString;

// ------------------------------------------------------------ Print/Stream
class Print {
 public:
  virtual ~Print() = default;
  virtual size_t write(uint8_t c) = 0;
  virtual size_t write(const uint8_t *d, size_t n) {
    size_t done = 0;
    while (done < n && write(d[done])) ++done;
    return done;
  }
  size_t write(const char *t) { return t ? write(reinterpret_cast<const uint8_t *>(t), strlen(t)) : 0; }
  size_t write(const char *t, size_t n) { return write(reinterpret_cast<const uint8_t *>(t), n); }
  size_t print(const char *t) { return write(t); }
  size_t print(const String &t) { return write(t.c_str(), t.length()); }
  size_t print(const __FlashStringHelper *t) { return write(cawFlash(t)); }
  template <typename T> size_t print(T v) { return print(String(v)); }
  template <typename T> size_t println(T v) { return print(v) + write("\r\n"); }
  size_t println() { return write("\r\n"); }
  size_t printf(const char *format, ...) __attribute__((format(printf, 2, 3))) {
    char small[160];
    va_list args;
    va_start(args, format);
    const int n = vsnprintf(small, sizeof(small), format, args);
    va_end(args);
    if (n < 0) return 0;
    if (size_t(n) < sizeof(small)) return write(small, n);
    std::string big(n + 1, '\0');
    va_start(args, format);
    vsnprintf(&big[0], big.size(), format, args);
    va_end(args);
    return write(big.data(), n);
  }
  size_t printf_P(const char *format, ...) __attribute__((format(printf, 2, 3))) {
    va_list args;
    va_start(args, format);
    std::string out;
    char small[192];
    const int n = vsnprintf(small, sizeof(small), format, args);
    va_end(args);
    if (n < 0) return 0;
    if (size_t(n) < sizeof(small)) return write(small, n);
    out.resize(n + 1);
    va_start(args, format);
    vsnprintf(&out[0], out.size(), format, args);
    va_end(args);
    return write(out.data(), n);
  }
  virtual void flush() {}
  int getWriteError() const { return writeError_; }
  void clearWriteError() { writeError_ = 0; }

 protected:
  void setWriteError(int e = 1) { writeError_ = e; }

 private:
  int writeError_ = 0;
};

class Printable {
 public:
  virtual ~Printable() = default;
  virtual size_t printTo(Print &p) const = 0;
};

class Stream : public Print {
 public:
  virtual int available() = 0;
  virtual int read() = 0;
  virtual int peek() { return -1; }
  void setTimeout(uint32_t ms) { timeout_ = ms; }
  uint32_t getTimeout() const { return timeout_; }
  // Waits up to the timeout for each byte, as Arduino's Stream.
  virtual size_t readBytes(char *buffer, size_t length) {
    size_t count = 0;
    while (count < length) {
      const int c = timedRead();
      if (c < 0) break;
      buffer[count++] = char(c);
    }
    return count;
  }
  size_t readBytes(uint8_t *buffer, size_t length) { return readBytes(reinterpret_cast<char *>(buffer), length); }

 protected:
  int timedRead() {
    const uint32_t start = millis();
    do {
      const int c = read();
      if (c >= 0) return c;
      cawSleepMs(1);
    } while (millis() - start < timeout_);
    return -1;
  }
  uint32_t timeout_ = 1000;
};

struct CawSerial : public Print {
  void begin(unsigned long) {}
  size_t write(uint8_t) override { return 1; }
  size_t write(const uint8_t *, size_t n) override { return n; }
  explicit operator bool() const { return true; }
};
inline CawSerial Serial;

// ------------------------------------------------------- pins (unused here)
#define OUTPUT 1
#define INPUT 0
#define INPUT_PULLUP 2
#define LOW 0
#define HIGH 1
#define A0 0
inline void pinMode(int, int) {}
inline void digitalWrite(int, int) {}
inline int digitalRead(int) { return 0; }
inline void analogWrite(int, int) {}
inline void analogWriteRange(uint32_t) {}
inline int analogRead(int) { return 0; }

// ------------------------------------------------------------- reset info
// The ESP8266 core's rst_info (user_interface.h), filled from ESP-IDF's reset
// reason so the shared code's checks keep their meaning.
enum rst_reason {
  REASON_DEFAULT_RST = 0,
  REASON_WDT_RST = 1,
  REASON_EXCEPTION_RST = 2,
  REASON_SOFT_WDT_RST = 3,
  REASON_SOFT_RESTART = 4,
  REASON_DEEP_SLEEP_AWAKE = 5,
  REASON_EXT_SYS_RST = 6,
};
struct rst_info {
  uint32_t reason, exccause, epc1, epc2, epc3, excvaddr, depc;
};

class CawEsp {
 public:
  uint32_t random() { return esp_random(); }
  void restart();
  uint32_t getFreeHeap();
  uint32_t getMaxFreeBlockSize();
  uint8_t getHeapFragmentation();
  uint32_t getFreeContStack();
  void resetFreeContStack() {}
  String getResetReason();
  const rst_info *getResetInfoPtr();
  bool rtcUserMemoryRead(uint32_t offset, uint32_t *data, size_t size);
  bool rtcUserMemoryWrite(uint32_t offset, const uint32_t *data, size_t size);
  uint32_t getFreeSketchSpace();
  uint32_t getChipId();
  uint64_t getEfuseMac();
};
inline CawEsp ESP;

// configTime(tz, server1, server2) of the ESP8266 core: zone and SNTP.
void configTime(const char *tz, const char *server1, const char *server2 = nullptr);
