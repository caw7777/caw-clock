#pragma once
// The ESP8266 core's ESP8266WebServer, on ESP-IDF's HTTP server. The server
// task only queues each request (httpd's asynchronous requests); the CAW app
// answers it from its own loop in handleClient(), as on the ESP8266, so the
// shared handlers never run at the same time as the rest of the app.
// Arguments (query and form), multipart uploads streamed to the upload
// callback, chunked pages, Basic and Digest sign-in.
#include <functional>
#include <list>
#include <vector>

#include "Arduino.h"
#include "IPAddress.h"

// In a namespace: ESP-IDF's HTTP parser has its own HTTP_GET, HTTP_POST... The
// app (which never includes it) sees the Arduino names unqualified.
namespace cawweb {
enum HTTPMethod { HTTP_ANY, HTTP_GET, HTTP_HEAD, HTTP_POST, HTTP_PUT, HTTP_PATCH, HTTP_DELETE, HTTP_OPTIONS };
}
using HTTPMethod = cawweb::HTTPMethod;
#ifndef CAW_WEBSERVER_IMPL
using cawweb::HTTP_ANY;
using cawweb::HTTP_GET;
using cawweb::HTTP_POST;
#endif
enum HTTPUploadStatus { UPLOAD_FILE_START, UPLOAD_FILE_WRITE, UPLOAD_FILE_END, UPLOAD_FILE_ABORTED };
enum HTTPAuthMethod { BASIC_AUTH, DIGEST_AUTH };
constexpr size_t CONTENT_LENGTH_UNKNOWN = size_t(-1);
constexpr size_t HTTP_UPLOAD_BUFLEN = 2048;

struct HTTPUpload {
  HTTPUploadStatus status = UPLOAD_FILE_START;
  String filename, name, type;
  size_t totalSize = 0, currentSize = 0;
  uint8_t buf[HTTP_UPLOAD_BUFLEN];
};

struct CawRequestClient {
  IPAddress local, remote;
  IPAddress localIP() const { return local; }
  IPAddress remoteIP() const { return remote; }
};

class ESP8266WebServer {
 public:
  using Handler = std::function<void()>;
  explicit ESP8266WebServer(int port = 80) : port_(port) {}

  void on(const char *uri, HTTPMethod method, Handler fn) { routes_.push_back({uri, method, fn, nullptr}); }
  void on(const char *uri, HTTPMethod method, Handler fn, Handler upload) { routes_.push_back({uri, method, fn, upload}); }
  void on(const char *uri, Handler fn) { on(uri, cawweb::HTTP_ANY, fn); }
  void onNotFound(Handler fn) { notFound_ = fn; }
  void collectHeaders(const char *, ...) {}  // Host, Origin, Authorization are always kept
  void begin();
  void handleClient();

  String arg(const String &name) const;
  bool hasArg(const String &name) const;
  int args() const { return int(args_.size()); }
  String header(const String &name) const;
  bool hasHeader(const String &name) const;
  String hostHeader() const { return host_; }
  String uri() const { return path_; }
  HTTPMethod method() const { return method_; }
  HTTPUpload &upload() { return *upload_; }
  CawRequestClient client() const { return client_; }

  bool authenticate(const char *user, const char *password);
  void requestAuthentication(HTTPAuthMethod mode = BASIC_AUTH, const char *realm = nullptr,
                             const String &failMessage = String());

  void setContentLength(size_t length) { contentLength_ = length; }
  void sendHeader(const String &name, const String &value, bool first = false);
  void send(int code);
  void send(int code, const String &type, const String &content);
  void send(int code, const String &type, const uint8_t *data, size_t length);
  void send(int code, const char *type, const char *data, size_t length) {
    send(code, String(type), reinterpret_cast<const uint8_t *>(data), length);
  }
  void send_P(int code, PGM_P type, PGM_P content) { send(code, String(type), String(content)); }
  void send_P(int code, PGM_P type, PGM_P content, size_t length) { send(code, type, content, length); }
  void sendContent(const String &content) { sendContent(content.c_str(), content.length()); }
  void sendContent(const char *content) { sendContent(content, strlen(content)); }
  void sendContent(const char *content, size_t length);
  template <typename File>
  size_t streamFile(File &file, const String &type) {
    setContentLength(file.size());
    send(200, type, String());
    uint8_t chunk[1024];
    size_t total = 0;
    while (true) {
      const size_t got = file.read(chunk, sizeof(chunk));
      if (!got) break;
      sendContent(reinterpret_cast<const char *>(chunk), got);
      total += got;
    }
    return total;
  }

 private:
  struct Route {
    const char *uri;
    HTTPMethod method;
    Handler fn, upload;
  };
  struct Arg {
    String name, value;
  };
  void process(void *request);
  void readBody(const Route *route);
  void readMultipart(const Route *route, const String &boundary);
  int receive(char *buffer, size_t size);
  void beginResponse(int code, const String &type);
  void finishResponse();

  int port_;
  std::vector<Route> routes_;
  Handler notFound_;
  void *server_ = nullptr;  // httpd_handle_t
  void *queue_ = nullptr;   // QueueHandle_t of httpd_req_t *

  // The request being answered.
  void *request_ = nullptr;  // httpd_req_t *
  String path_, host_, origin_, authorization_, contentType_;
  HTTPMethod method_ = cawweb::HTTP_ANY;
  std::vector<Arg> args_;
  CawRequestClient client_;
  HTTPUpload *upload_ = nullptr;
  size_t bodyLeft_ = 0;
  bool bodyFailed_ = false;
  size_t contentLength_ = 0;
  bool headersSent_ = false, chunked_ = false, ended_ = false;
  std::list<std::string> headerStore_;  // httpd keeps pointers until the response is sent
  char status_[32];
  std::string type_;
};
