#pragma once
// The TFT_eSPI calls the shared CAW screen code makes, for the SDC2 clock's
// ST7789 240 x 240 panel (notes/pinout-juzipi-sdc2.md): SPI2 with SCLK GPIO1,
// MOSI GPIO2, DC GPIO0, reset GPIO3, no CS, mode 3; backlight GPIO5 active
// low. Drawing goes straight to the panel (no frame buffer: 115 KB is more
// than the free memory). Colours are RGB565 values; pushImage data follows
// TFT_eSPI's swap-bytes setting.
#include "Arduino.h"

typedef struct { uint16_t bitmapOffset; uint8_t width, height, xAdvance; int8_t xOffset, yOffset; } GFXglyph;
typedef struct { uint8_t *bitmap; GFXglyph *glyph; uint16_t first, last; uint8_t yAdvance; } GFXfont;
enum { TL_DATUM = 0, TC_DATUM, TR_DATUM, ML_DATUM, MC_DATUM, MR_DATUM, BL_DATUM, BC_DATUM, BR_DATUM,
       L_BASELINE, C_BASELINE, R_BASELINE };
#define TFT_BLACK 0x0000
#define TFT_WHITE 0xFFFF
#define TFT_RED 0xF800
#define TFT_BL 5              // backlight, active low (setBrightness drives it)
#define TFT_BACKLIGHT_ON LOW

class TFT_eSPI {
 public:
  static constexpr int W = 240, H = 240;
  void init();
  void setBacklight(bool on);
  // 0-100 %; PWM on the active-low backlight pin (the ESP8266 clock dims too).
  void setBrightness(uint8_t percent);
  // Moves the shown picture up by `rows` (hardware vertical scroll over the
  // panel's 320-row memory): the SDC2 glass hides the last rows we draw.
  void setVerticalOffset(uint8_t rows);
  int16_t width() const { return W; }
  int16_t height() const { return H; }
  void setRotation(int) {}

  void drawPixel(int32_t x, int32_t y, uint16_t c);
  void fillRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c);
  void fillScreen(uint16_t c) { fillRect(0, 0, W, H, c); }
  void drawFastHLine(int32_t x, int32_t y, int32_t w, uint16_t c) { fillRect(x, y, w, 1, c); }
  void drawFastVLine(int32_t x, int32_t y, int32_t h, uint16_t c) { fillRect(x, y, 1, h, c); }
  void drawRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c);
  void drawLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c);
  void drawRoundRect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c);
  void fillRoundRect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c);
  uint16_t alphaBlend(uint8_t a, uint16_t fg, uint16_t bg);

  void setSwapBytes(bool s) { swap_ = s; }
  bool getSwapBytes() const { return swap_; }
  void pushImage(int32_t x, int32_t y, int32_t w, int32_t h, const uint16_t *d);

  void startWrite() {}
  void endWrite() {}
  void writecommand(uint8_t c);
  void writedata(uint8_t d);
  void setWindow(int32_t x0, int32_t y0, int32_t x1, int32_t y1);
  void pushBlock(uint16_t c, uint32_t n);
  void pushPixels(const void *d, uint32_t n);

  void setTextDatum(uint8_t d) { datum_ = d; }
  uint8_t getTextDatum() const { return datum_; }
  void setFreeFont(const GFXfont *f) { font_ = f; }
  int16_t textWidth(const char *t);
  int16_t drawChar(uint16_t, int32_t, int32_t) { return 0; }
  void setTextColor(uint16_t, uint16_t) {}
  void setTextColor(uint16_t) {}
  void setTextWrap(bool, bool) {}

 private:
  void corner(int32_t x0, int32_t y0, int32_t r, uint8_t q, uint16_t c, bool fill, int32_t delta = 0);
  void flushCommand();
  bool swap_ = false;
  uint8_t datum_ = 0;
  const GFXfont *font_ = nullptr;
  int pendingCommand_ = -1;
  uint8_t pendingData_[16];
  uint8_t pendingCount_ = 0;
  bool ramStarted_ = false;
  uint8_t brightness_ = 64;
  bool backlightOn_ = true;
};
#include "LittleFS.h"  // File, as the Arduino core provides through TFT_eSPI
