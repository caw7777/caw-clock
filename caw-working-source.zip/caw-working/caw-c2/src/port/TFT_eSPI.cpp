#include "TFT_eSPI.h"

#include "driver/gpio.h"
#include "driver/ledc.h"
#include "driver/spi_master.h"
#include "esp_heap_caps.h"

namespace {
constexpr gpio_num_t kSclk = GPIO_NUM_1, kMosi = GPIO_NUM_2, kDc = GPIO_NUM_0, kReset = GPIO_NUM_3,
                     kBacklight = GPIO_NUM_5;
constexpr int kBufferPixels = 960;  // 1.9 KB DMA buffer: four rows of 240
spi_device_handle_t gSpi;
uint16_t *gBuffer;                  // big-endian pixels, as the panel takes them

void send(bool data, const void *bytes, size_t length) {
  if (!gSpi || !length) return;
  gpio_set_level(kDc, data ? 1 : 0);
  spi_transaction_t t = {};
  t.length = length * 8;
  t.tx_buffer = bytes;
  spi_device_polling_transmit(gSpi, &t);
}

void command(uint8_t c, const uint8_t *params = nullptr, size_t n = 0) {
  send(false, &c, 1);
  if (n) {
    // Small parameter blocks go through the DMA buffer too (stack data may
    // not be DMA-capable).
    uint8_t *b = reinterpret_cast<uint8_t *>(gBuffer);
    memcpy(b, params, n);
    send(true, b, n);
  }
}

// The panel keeps its column and row ranges until they change: only the
// changed ones are sent (a text run or picture row often keeps both).
int32_t gCols = -1, gRows = -1;  // last ranges sent, x0 << 16 | x1; -1 = unknown
void forgetWindow() { gCols = gRows = -1; }

void window(int32_t x0, int32_t y0, int32_t x1, int32_t y1) {
  const int32_t cols = x0 << 16 | x1, rows = y0 << 16 | y1;
  if (cols != gCols) {
    const uint8_t c[4] = {uint8_t(x0 >> 8), uint8_t(x0), uint8_t(x1 >> 8), uint8_t(x1)};
    command(0x2A, c, 4);
    gCols = cols;
  }
  if (rows != gRows) {
    const uint8_t r[4] = {uint8_t(y0 >> 8), uint8_t(y0), uint8_t(y1 >> 8), uint8_t(y1)};
    command(0x2B, r, 4);
    gRows = rows;
  }
  command(0x2C);
}

inline uint16_t bigEndian(uint16_t c) { return uint16_t((c >> 8) | (c << 8)); }

void solid(uint16_t c, uint32_t n) {
  const uint16_t be = bigEndian(c);
  const uint32_t fill = n < kBufferPixels ? n : kBufferPixels;
  for (uint32_t i = 0; i < fill; ++i) gBuffer[i] = be;
  while (n) {
    const uint32_t chunk = n < kBufferPixels ? n : kBufferPixels;
    send(true, gBuffer, chunk * 2);
    n -= chunk;
  }
}
}  // namespace

void TFT_eSPI::init() {
  if (gSpi) return;
  gBuffer = static_cast<uint16_t *>(heap_caps_malloc(kBufferPixels * 2, MALLOC_CAP_DMA));
  gpio_config_t out = {};
  out.pin_bit_mask = (1ULL << kDc) | (1ULL << kReset);
  out.mode = GPIO_MODE_OUTPUT;
  gpio_config(&out);
  // Backlight: LEDC PWM, output inverted (the LED is on while the pin is
  // low); duty 0 = off while the panel starts, as the factory firmware.
  ledc_timer_config_t timer = {};
  timer.speed_mode = LEDC_LOW_SPEED_MODE;
  timer.duty_resolution = LEDC_TIMER_10_BIT;
  timer.timer_num = LEDC_TIMER_0;
  timer.freq_hz = 5000;
  timer.clk_cfg = LEDC_AUTO_CLK;
  ledc_timer_config(&timer);
  ledc_channel_config_t channel = {};
  channel.gpio_num = kBacklight;
  channel.speed_mode = LEDC_LOW_SPEED_MODE;
  channel.channel = LEDC_CHANNEL_0;
  channel.timer_sel = LEDC_TIMER_0;
  channel.duty = 0;
  channel.flags.output_invert = 1;
  ledc_channel_config(&channel);
  spi_bus_config_t bus = {};
  bus.mosi_io_num = kMosi;
  bus.miso_io_num = -1;
  bus.sclk_io_num = kSclk;
  bus.quadwp_io_num = -1;
  bus.quadhd_io_num = -1;
  bus.max_transfer_sz = kBufferPixels * 2;
  spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO);
  spi_device_interface_config_t dev = {};
  dev.clock_speed_hz = 40 * 1000 * 1000;
  dev.mode = 3;
  dev.spics_io_num = -1;  // CS is tied low on this board
  dev.queue_size = 1;
  spi_bus_add_device(SPI2_HOST, &dev, &gSpi);
  // Reset as TFT_eSPI does: high, low 20 ms, high, 150 ms.
  gpio_set_level(kReset, 1);
  delay(5);
  gpio_set_level(kReset, 0);
  delay(20);
  gpio_set_level(kReset, 1);
  delay(150);
  // The minimal start-up that showed the right colours on the clock (stage
  // 1). TFT_eSPI's full ST7789 sequence (power, porch, VCOM, gamma) made the
  // colours wrong on this panel (stage 2, owner's report): not used.
  struct Step { uint8_t cmd, n; uint8_t data[4]; uint16_t wait; };
  static const Step kInit[] = {
      {0x11, 0, {}, 120},            // SLPOUT
      {0x3A, 1, {0x55}, 0},          // COLMOD: 16-bit
      {0x36, 1, {0x00}, 0},          // MADCTL: RGB, no rotation
      {0x21, 0, {}, 0},              // INVON: this panel shows true colours inverted
      {0x13, 0, {}, 0},              // NORON
      {0x29, 0, {}, 0},              // DISPON
  };
  for (const Step &step : kInit) {
    command(step.cmd, step.data, step.n);
    if (step.wait) delay(step.wait);
  }
  fillScreen(0);
  setBacklight(true);
}

void TFT_eSPI::setBacklight(bool on) {
  backlightOn_ = on;
  setBrightness(brightness_);
}

void TFT_eSPI::setVerticalOffset(uint8_t rows) {
  const uint8_t area[6] = {0, 0, 320 >> 8, 320 & 0xFF, 0, 0};  // VSCRDEF: 320 scroll rows
  command(0x33, area, 6);
  const uint8_t start[2] = {0, rows};                            // VSCRSADD
  command(0x37, start, 2);
}

void TFT_eSPI::setBrightness(uint8_t percent) {
  brightness_ = percent > 100 ? 100 : percent;
  // Perceived brightness is about the square of the duty: 64 % looks like
  // the ESP8266 clock's 64 % (also a squared curve there).
  const uint32_t duty = backlightOn_ ? (1023U * brightness_ * brightness_) / 10000U : 0;
  ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
  ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}

void TFT_eSPI::drawPixel(int32_t x, int32_t y, uint16_t c) {
  if (x < 0 || y < 0 || x >= W || y >= H) return;
  window(x, y, x, y);
  gBuffer[0] = bigEndian(c);
  send(true, gBuffer, 2);
  ramStarted_ = false;
}

void TFT_eSPI::fillRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c) {
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > W) w = W - x;
  if (y + h > H) h = H - y;
  if (w <= 0 || h <= 0) return;
  window(x, y, x + w - 1, y + h - 1);
  solid(c, uint32_t(w) * uint32_t(h));
  ramStarted_ = false;
}

void TFT_eSPI::drawRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c) {
  drawFastHLine(x, y, w, c);
  drawFastHLine(x, y + h - 1, w, c);
  drawFastVLine(x, y, h, c);
  drawFastVLine(x + w - 1, y, h, c);
}

void TFT_eSPI::drawLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c) {
  if (y0 == y1) { if (x1 < x0) std::swap(x0, x1); drawFastHLine(x0, y0, x1 - x0 + 1, c); return; }
  if (x0 == x1) { if (y1 < y0) std::swap(y0, y1); drawFastVLine(x0, y0, y1 - y0 + 1, c); return; }
  int32_t dx = std::abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -std::abs(y1 - y0), sy = y0 < y1 ? 1 : -1,
          e = dx + dy;
  for (;;) {
    drawPixel(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    const int32_t e2 = 2 * e;
    if (e2 >= dy) { e += dy; x0 += sx; }
    if (e2 <= dx) { e += dx; y0 += sy; }
  }
}

// Rounded corners as in Adafruit GFX (quarter circles, Bresenham).
void TFT_eSPI::corner(int32_t x0, int32_t y0, int32_t r, uint8_t q, uint16_t c, bool fill, int32_t delta) {
  int32_t f = 1 - r, ddx = 1, ddy = -2 * r, x = 0, y = r;
  while (x < y) {
    if (f >= 0) { --y; ddy += 2; f += ddy; }
    ++x; ddx += 2; f += ddx;
    if (!fill) {
      if (q & 4) { drawPixel(x0 + x, y0 + y, c); drawPixel(x0 + y, y0 + x, c); }
      if (q & 2) { drawPixel(x0 + x, y0 - y, c); drawPixel(x0 + y, y0 - x, c); }
      if (q & 8) { drawPixel(x0 - y, y0 + x, c); drawPixel(x0 - x, y0 + y, c); }
      if (q & 1) { drawPixel(x0 - y, y0 - x, c); drawPixel(x0 - x, y0 - y, c); }
    } else {
      if (q & 1) { drawFastVLine(x0 + x, y0 - y, 2 * y + 1 + delta, c); drawFastVLine(x0 + y, y0 - x, 2 * x + 1 + delta, c); }
      if (q & 2) { drawFastVLine(x0 - x, y0 - y, 2 * y + 1 + delta, c); drawFastVLine(x0 - y, y0 - x, 2 * x + 1 + delta, c); }
    }
  }
}

void TFT_eSPI::drawRoundRect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c) {
  drawFastHLine(x + r, y, w - 2 * r, c);
  drawFastHLine(x + r, y + h - 1, w - 2 * r, c);
  drawFastVLine(x, y + r, h - 2 * r, c);
  drawFastVLine(x + w - 1, y + r, h - 2 * r, c);
  corner(x + r, y + r, r, 1, c, false);
  corner(x + w - r - 1, y + r, r, 2, c, false);
  corner(x + w - r - 1, y + h - r - 1, r, 4, c, false);
  corner(x + r, y + h - r - 1, r, 8, c, false);
}

void TFT_eSPI::fillRoundRect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c) {
  fillRect(x + r, y, w - 2 * r, h, c);
  corner(x + w - r - 1, y + r, r, 1, c, true, h - 2 * r - 1);
  corner(x + r, y + r, r, 2, c, true, h - 2 * r - 1);
}

uint16_t TFT_eSPI::alphaBlend(uint8_t a, uint16_t fg, uint16_t bg) {
  const uint16_t fr = fg >> 11, fgg = (fg >> 5) & 63, fb = fg & 31, br = bg >> 11, bgg = (bg >> 5) & 63,
                 bb = bg & 31;
  const uint16_t r = (fr * a + br * (255 - a)) / 255, g = (fgg * a + bgg * (255 - a)) / 255,
                 b = (fb * a + bb * (255 - a)) / 255;
  return uint16_t((r << 11) | (g << 5) | b);
}

// Data in TFT_eSPI's convention: with swap off, each value is stored
// byte-swapped (as TFT_eSPI sends uint16_t words little-endian).
void TFT_eSPI::pushImage(int32_t x, int32_t y, int32_t w, int32_t h, const uint16_t *d) {
  if (w <= 0 || h <= 0 || x >= W || y >= H || x + w <= 0 || y + h <= 0) return;
  const int32_t cx0 = x < 0 ? -x : 0, cy0 = y < 0 ? -y : 0;
  const int32_t cw = (x + w > W ? W - x : w) - cx0, ch = (y + h > H ? H - y : h) - cy0;
  window(x + cx0, y + cy0, x + cx0 + cw - 1, y + cy0 + ch - 1);
  uint32_t used = 0;
  for (int32_t row = cy0; row < cy0 + ch; ++row) {
    for (int32_t col = cx0; col < cx0 + cw; ++col) {
      uint16_t v = d[row * w + col];
      if (!swap_) v = bigEndian(v);
      gBuffer[used++] = bigEndian(v);
      if (used == kBufferPixels) { send(true, gBuffer, used * 2); used = 0; }
    }
  }
  if (used) send(true, gBuffer, used * 2);
  ramStarted_ = false;
}

void TFT_eSPI::flushCommand() {
  if (pendingCommand_ < 0) return;
  forgetWindow();  // a raw command may set the ranges itself
  command(uint8_t(pendingCommand_), pendingData_, pendingCount_);
  pendingCommand_ = -1;
  pendingCount_ = 0;
}

void TFT_eSPI::writecommand(uint8_t c) {
  flushCommand();
  pendingCommand_ = c;
}

void TFT_eSPI::writedata(uint8_t d) {
  if (pendingCommand_ >= 0 && pendingCount_ < sizeof(pendingData_)) pendingData_[pendingCount_++] = d;
}

void TFT_eSPI::setWindow(int32_t x0, int32_t y0, int32_t x1, int32_t y1) {
  flushCommand();
  window(x0, y0, x1, y1);
  ramStarted_ = true;
}

void TFT_eSPI::pushBlock(uint16_t c, uint32_t n) {
  if (ramStarted_) solid(c, n);
}

void TFT_eSPI::pushPixels(const void *d, uint32_t n) {
  if (!ramStarted_) return;
  const uint16_t *p = static_cast<const uint16_t *>(d);
  while (n) {
    const uint32_t chunk = n < kBufferPixels ? n : kBufferPixels;
    for (uint32_t i = 0; i < chunk; ++i) {
      uint16_t v = p[i];
      if (!swap_) v = bigEndian(v);
      gBuffer[i] = bigEndian(v);
    }
    send(true, gBuffer, chunk * 2);
    p += chunk;
    n -= chunk;
  }
}

int16_t TFT_eSPI::textWidth(const char *t) {
  int16_t w = 0;
  for (const unsigned char *p = reinterpret_cast<const unsigned char *>(t); *p; ++p) {
    uint32_t c = *p;
    if (c >= 0x80) {
      int n = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : 1;
      c &= 0x3F >> n;
      while (n-- && p[1]) c = (c << 6) | (*++p & 0x3F);
      // The CAW fonts keep subscript digits and icons in the C1 slots.
      if (c >= 0x2080 && c <= 0x2089) c -= 0x2000;
      else if (c == 0xE000 || c == 0xE001) c -= 0xDF76;
      else if (c == 0x25B6) c = 0x8C;
    }
    if (font_ && c >= font_->first && c <= font_->last) w += font_->glyph[c - font_->first].xAdvance;
  }
  return w;
}
