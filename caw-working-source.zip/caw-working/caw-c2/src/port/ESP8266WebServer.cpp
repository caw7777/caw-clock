#include <sys/socket.h>

#include "esp_http_server.h"
#undef HTTP_ANY  // ESP-IDF's "any method" macro: the Arduino HTTP_ANY is cawweb::HTTP_ANY
#define CAW_WEBSERVER_IMPL 1
#include "ESP8266WebServer.h"
#include "freertos/queue.h"
#include "mbedtls/base64.h"
#include "mbedtls/md5.h"

namespace {
constexpr int kQueueLength = 6;
constexpr size_t kFormBodyMax = 8192;  // larger urlencoded bodies are read and dropped

int fromHex(char c) {
  return c >= '0' && c <= '9'   ? c - '0'
         : c >= 'a' && c <= 'f' ? c - 'a' + 10
         : c >= 'A' && c <= 'F' ? c - 'A' + 10
                                : -1;
}

String urlDecode(const char *text, size_t length) {
  std::string out;
  out.reserve(length);
  for (size_t i = 0; i < length; ++i) {
    const char c = text[i];
    if (c == '+') {
      out += ' ';
    } else if (c == '%' && i + 2 < length && fromHex(text[i + 1]) >= 0 && fromHex(text[i + 2]) >= 0) {
      out += char(fromHex(text[i + 1]) << 4 | fromHex(text[i + 2]));
      i += 2;
    } else {
      out += c;
    }
  }
  return String(std::move(out));
}

template <typename Add>
void parseForm(const char *text, size_t length, Add add) {
  size_t start = 0;
  while (start < length) {
    size_t end = start;
    while (end < length && text[end] != '&') ++end;
    size_t equals = start;
    while (equals < end && text[equals] != '=') ++equals;
    if (end > start)
      add(urlDecode(text + start, equals - start),
          equals < end ? urlDecode(text + equals + 1, end - equals - 1) : String());
    start = end + 1;
  }
}

String headerValue(httpd_req_t *r, const char *name) {
  const size_t length = httpd_req_get_hdr_value_len(r, name);
  if (!length) return String();
  std::string value(length + 1, '\0');
  if (httpd_req_get_hdr_value_str(r, name, &value[0], value.size()) != ESP_OK) return String();
  value.resize(length);
  return String(std::move(value));
}

const char *statusText(int code) {
  switch (code) {
    case 200: return "200 OK";
    case 204: return "204 No Content";
    case 301: return "301 Moved Permanently";
    case 302: return "302 Found";
    case 303: return "303 See Other";
    case 400: return "400 Bad Request";
    case 401: return "401 Unauthorized";
    case 403: return "403 Forbidden";
    case 404: return "404 Not Found";
    case 413: return "413 Payload Too Large";
    case 503: return "503 Service Unavailable";
    case 507: return "507 Insufficient Storage";
    default: return "500 Internal Server Error";
  }
}

void md5Hex(const std::string &text, char out[33]) {
  uint8_t digest[16];
  mbedtls_md5(reinterpret_cast<const unsigned char *>(text.data()), text.size(), digest);
  for (int i = 0; i < 16; ++i) snprintf(out + 2 * i, 3, "%02x", digest[i]);
}

// Parameter `name` of a Digest Authorization header (quoted or not).
std::string digestParam(const std::string &header, const char *name) {
  const std::string key = std::string(name) + "=";
  size_t at = 0;
  while ((at = header.find(key, at)) != std::string::npos) {
    if (at == 0 || header[at - 1] == ' ' || header[at - 1] == ',') break;
    at += key.size();
  }
  if (at == std::string::npos) return std::string();
  at += key.size();
  if (at < header.size() && header[at] == '"') {
    const size_t end = header.find('"', at + 1);
    return end == std::string::npos ? std::string() : header.substr(at + 1, end - at - 1);
  }
  size_t end = at;
  while (end < header.size() && header[end] != ',' && header[end] != ' ') ++end;
  return header.substr(at, end - at);
}

void randomHex(char out[33]) {
  for (int i = 0; i < 4; ++i) snprintf(out + 8 * i, 9, "%08lx", static_cast<unsigned long>(esp_random()));
}

// Nonces handed out recently: a Digest answer must use one of them.
constexpr int kNonces = 8;
char gNonces[kNonces][33];
int gNextNonce = 0;
char gOpaque[33];

QueueHandle_t gQueue = nullptr;

// Server task: hand the request to the app's loop (handleClient).
esp_err_t queueRequest(httpd_req_t *r) {
  httpd_req_t *copy = nullptr;
  if (httpd_req_async_handler_begin(r, &copy) != ESP_OK) return httpd_resp_send_500(r);
  if (xQueueSend(gQueue, &copy, 0) != pdTRUE) {
    httpd_resp_set_status(copy, "503 Service Unavailable");
    httpd_resp_send(copy, "Busy, try again", HTTPD_RESP_USE_STRLEN);
    httpd_req_async_handler_complete(copy);
  }
  return ESP_OK;
}
}  // namespace

void ESP8266WebServer::begin() {
  if (server_) return;
  randomHex(gOpaque);
  gQueue = xQueueCreate(kQueueLength, sizeof(httpd_req_t *));
  queue_ = gQueue;
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = port_;
  config.stack_size = 4096;
  config.max_open_sockets = 5;
  config.lru_purge_enable = true;
  config.recv_wait_timeout = 10;
  config.send_wait_timeout = 10;
  config.max_uri_handlers = 4;
  config.uri_match_fn = httpd_uri_match_wildcard;
  httpd_handle_t handle = nullptr;
  if (httpd_start(&handle, &config) != ESP_OK) return;
  server_ = handle;
  static const httpd_uri_t kGet = {"*", HTTP_GET, queueRequest, nullptr};
  static const httpd_uri_t kPost = {"*", HTTP_POST, queueRequest, nullptr};
  httpd_register_uri_handler(handle, &kGet);
  httpd_register_uri_handler(handle, &kPost);
}

void ESP8266WebServer::handleClient() {
  if (!gQueue) return;
  httpd_req_t *r = nullptr;
  if (xQueueReceive(gQueue, &r, 0) != pdTRUE || !r) return;
  process(r);
}

void ESP8266WebServer::process(void *request) {
  httpd_req_t *r = static_cast<httpd_req_t *>(request);
  request_ = r;
  args_.clear();
  headerStore_.clear();
  type_.clear();
  contentLength_ = 0;
  headersSent_ = chunked_ = ended_ = false;
  bodyFailed_ = false;
  bodyLeft_ = r->content_len;
  method_ = r->method == HTTP_POST ? cawweb::HTTP_POST : cawweb::HTTP_GET;

  const char *uri = r->uri;
  const char *query = strchr(uri, '?');
  path_ = query ? String(uri, size_t(query - uri)) : String(uri);
  if (query) parseForm(query + 1, strlen(query + 1), [this](const String &n, const String &v) { args_.push_back({n, v}); });
  host_ = headerValue(r, "Host");
  origin_ = headerValue(r, "Origin");
  authorization_ = headerValue(r, "Authorization");
  contentType_ = headerValue(r, "Content-Type");

  client_ = CawRequestClient{};
  const int fd = httpd_req_to_sockfd(r);
  sockaddr_storage address = {};
  socklen_t length = sizeof(address);
  if (fd >= 0 && getsockname(fd, reinterpret_cast<sockaddr *>(&address), &length) == 0 &&
      address.ss_family == AF_INET)
    client_.local = IPAddress(reinterpret_cast<sockaddr_in *>(&address)->sin_addr.s_addr);
  length = sizeof(address);
  if (fd >= 0 && getpeername(fd, reinterpret_cast<sockaddr *>(&address), &length) == 0 &&
      address.ss_family == AF_INET)
    client_.remote = IPAddress(reinterpret_cast<sockaddr_in *>(&address)->sin_addr.s_addr);

  const Route *route = nullptr;
  for (const Route &item : routes_)
    if (path_ == item.uri && (item.method == cawweb::HTTP_ANY || item.method == method_)) {
      route = &item;
      break;
    }
  readBody(route);
  if (route) route->fn();
  else if (notFound_) notFound_();
  finishResponse();
  httpd_req_async_handler_complete(r);
  request_ = nullptr;
  delete upload_;
  upload_ = nullptr;
  args_.clear();  // memory back before the app's next fetch
  headerStore_.clear();
  path_ = host_ = origin_ = authorization_ = contentType_ = String();
}

int ESP8266WebServer::receive(char *buffer, size_t size) {
  if (!bodyLeft_ || bodyFailed_) return 0;
  if (size > bodyLeft_) size = bodyLeft_;
  for (int attempt = 0; attempt < 3; ++attempt) {
    const int got = httpd_req_recv(static_cast<httpd_req_t *>(request_), buffer, size);
    if (got == HTTPD_SOCK_ERR_TIMEOUT) continue;
    if (got <= 0) break;
    bodyLeft_ -= got;
    return got;
  }
  bodyFailed_ = true;
  return -1;
}

void ESP8266WebServer::readBody(const Route *route) {
  if (!bodyLeft_) return;
  const int boundaryAt = contentType_.indexOf("boundary=");
  if (contentType_.startsWith("multipart/form-data") && boundaryAt >= 0) {
    String boundary = contentType_.substring(boundaryAt + 9);
    const int semicolon = boundary.indexOf(';');
    if (semicolon >= 0) boundary.remove(semicolon);
    boundary.trim();
    if (boundary.length() >= 2 && boundary[0] == '"') boundary = boundary.substring(1, boundary.length() - 1);
    readMultipart(route, boundary);
  } else if (bodyLeft_ <= kFormBodyMax) {
    std::string body(bodyLeft_, '\0');
    size_t have = 0;
    while (have < body.size()) {
      const int got = receive(&body[have], body.size() - have);
      if (got <= 0) break;
      have += got;
    }
    body.resize(have);
    if (contentType_.startsWith("application/x-www-form-urlencoded") || contentType_.isEmpty())
      parseForm(body.data(), body.size(), [this](const String &n, const String &v) { args_.push_back({n, v}); });
    else
      args_.push_back({String("plain"), String(std::move(body))});
  }
  char scratch[256];
  while (bodyLeft_ && receive(scratch, sizeof(scratch)) > 0) {
  }
}

// Streams a multipart/form-data body: file parts go to the route's upload
// callback in HTTP_UPLOAD_BUFLEN pieces (START, WRITE..., END or ABORTED);
// other fields become arguments.
void ESP8266WebServer::readMultipart(const Route *route, const String &boundary) {
  const std::string delimiter = std::string("\r\n--") + boundary.c_str();
  std::string buffer = "\r\n";  // so the first boundary matches the delimiter too
  buffer.reserve(4096);
  char chunk[1024];
  const auto fill = [&]() -> bool {
    const int got = receive(chunk, sizeof(chunk));
    if (got <= 0) return false;
    buffer.append(chunk, got);
    return true;
  };
  // Skip the preamble up to the first delimiter.
  size_t at;
  while ((at = buffer.find(delimiter)) == std::string::npos) {
    if (buffer.size() > delimiter.size()) buffer.erase(0, buffer.size() - delimiter.size());
    if (!fill()) return;
  }
  buffer.erase(0, at + delimiter.size());
  while (true) {
    while (buffer.size() < 2 && fill()) {
    }
    if (buffer.compare(0, 2, "--") == 0) return;  // the closing delimiter
    // Part headers.
    size_t end;
    while ((end = buffer.find("\r\n\r\n")) == std::string::npos) {
      if (buffer.size() > 4096 || !fill()) return;
    }
    const std::string headers = buffer.substr(0, end);
    buffer.erase(0, end + 4);
    const std::string name = digestParam(headers, "name");
    const size_t fileAt = headers.find("filename=");
    const bool isFile = fileAt != std::string::npos;
    std::string value;
    if (isFile) {
      if (!upload_) upload_ = new (std::nothrow) HTTPUpload;
      if (!upload_) return;
      upload_->status = UPLOAD_FILE_START;
      upload_->name = String(name);
      upload_->filename = String(digestParam(headers.substr(fileAt - 1), "filename"));
      const size_t typeAt = headers.find("Content-Type:");
      upload_->type = typeAt == std::string::npos ? String() : String(headers.substr(typeAt + 13));
      upload_->type.trim();
      upload_->totalSize = 0;
      upload_->currentSize = 0;
      if (route && route->upload) route->upload();
    }
    // Part data, up to the next delimiter.
    bool found = false;
    while (!found) {
      at = buffer.find(delimiter);
      found = at != std::string::npos;
      size_t emit = found ? at : buffer.size() > delimiter.size() ? buffer.size() - delimiter.size() : 0;
      size_t done = 0;
      while (done < emit) {
        const size_t piece = std::min(emit - done, isFile ? HTTP_UPLOAD_BUFLEN : emit - done);
        if (isFile) {
          memcpy(upload_->buf, buffer.data() + done, piece);
          upload_->status = UPLOAD_FILE_WRITE;
          upload_->currentSize = piece;
          upload_->totalSize += piece;
          if (route && route->upload) route->upload();
        } else if (value.size() < 2048) {
          value.append(buffer.data() + done, std::min(piece, 2048 - value.size()));
        }
        done += piece;
      }
      buffer.erase(0, emit);
      if (found) {
        buffer.erase(0, delimiter.size());
      } else if (!fill()) {
        if (isFile) {
          upload_->status = UPLOAD_FILE_ABORTED;
          upload_->currentSize = 0;
          if (route && route->upload) route->upload();
        }
        return;
      }
    }
    if (isFile) {
      upload_->status = UPLOAD_FILE_END;
      upload_->currentSize = 0;
      if (route && route->upload) route->upload();
    } else {
      args_.push_back({String(name), String(std::move(value))});
    }
    // After a delimiter: "--" ends the body, CRLF starts the next part.
    while (buffer.size() < 2 && fill()) {
    }
    if (buffer.compare(0, 2, "--") == 0) return;
    if (buffer.compare(0, 2, "\r\n") == 0) buffer.erase(0, 2);
  }
}

String ESP8266WebServer::arg(const String &name) const {
  for (const Arg &item : args_)
    if (item.name == name) return item.value;
  return String();
}

bool ESP8266WebServer::hasArg(const String &name) const {
  for (const Arg &item : args_)
    if (item.name == name) return true;
  return false;
}

String ESP8266WebServer::header(const String &name) const {
  if (name.equalsIgnoreCase("Origin")) return origin_;
  if (name.equalsIgnoreCase("Host")) return host_;
  if (name.equalsIgnoreCase("Authorization")) return authorization_;
  if (name.equalsIgnoreCase("Content-Type")) return contentType_;
  return request_ ? headerValue(static_cast<httpd_req_t *>(request_), name.c_str()) : String();
}

bool ESP8266WebServer::hasHeader(const String &name) const { return !header(name).isEmpty(); }

bool ESP8266WebServer::authenticate(const char *user, const char *password) {
  if (!user || !password) return false;
  const std::string header = authorization_.c_str();
  if (header.compare(0, 6, "Basic ") == 0) {
    unsigned char decoded[160];
    size_t length = 0;
    const std::string encoded = header.substr(6);
    if (mbedtls_base64_decode(decoded, sizeof(decoded) - 1, &length,
                              reinterpret_cast<const unsigned char *>(encoded.data()), encoded.size()) != 0)
      return false;
    const std::string expected = std::string(user) + ":" + password;
    return length == expected.size() && memcmp(decoded, expected.data(), length) == 0;
  }
  if (header.compare(0, 7, "Digest ") != 0) return false;
  const std::string username = digestParam(header, "username");
  const std::string realm = digestParam(header, "realm");
  const std::string nonce = digestParam(header, "nonce");
  const std::string uri = digestParam(header, "uri");
  const std::string response = digestParam(header, "response");
  const std::string qop = digestParam(header, "qop");
  const std::string nc = digestParam(header, "nc");
  const std::string cnonce = digestParam(header, "cnonce");
  if (username != user || nonce.empty() || response.size() != 32) return false;
  bool known = false;
  for (const char *item : gNonces)
    if (item[0] && nonce == item) known = true;
  if (!known) return false;
  char ha1[33], ha2[33], expected[33];
  md5Hex(username + ":" + realm + ":" + password, ha1);
  md5Hex(std::string(method_ == cawweb::HTTP_POST ? "POST" : "GET") + ":" + uri, ha2);
  if (qop.empty()) md5Hex(std::string(ha1) + ":" + nonce + ":" + ha2, expected);
  else md5Hex(std::string(ha1) + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + ha2, expected);
  return response == expected;
}

void ESP8266WebServer::requestAuthentication(HTTPAuthMethod mode, const char *realm, const String &failMessage) {
  const char *name = realm && realm[0] ? realm : "Login Required";
  char value[200];
  if (mode == DIGEST_AUTH) {
    char *nonce = gNonces[gNextNonce];
    gNextNonce = (gNextNonce + 1) % kNonces;
    randomHex(nonce);
    snprintf(value, sizeof(value), "Digest realm=\"%s\", qop=\"auth\", nonce=\"%s\", opaque=\"%s\"", name, nonce,
             gOpaque);
  } else {
    snprintf(value, sizeof(value), "Basic realm=\"%s\"", name);
  }
  sendHeader(String("WWW-Authenticate"), String(value));
  send(401, String("text/html"), failMessage.isEmpty() ? String("401 Unauthorized") : failMessage);
}

void ESP8266WebServer::sendHeader(const String &name, const String &value, bool) {
  if (!request_ || headersSent_) return;
  headerStore_.push_back(name.c_str());
  const char *field = headerStore_.back().c_str();
  headerStore_.push_back(value.c_str());
  httpd_resp_set_hdr(static_cast<httpd_req_t *>(request_), field, headerStore_.back().c_str());
}

void ESP8266WebServer::beginResponse(int code, const String &type) {
  httpd_req_t *r = static_cast<httpd_req_t *>(request_);
  snprintf(status_, sizeof(status_), "%s", statusText(code));
  httpd_resp_set_status(r, status_);
  type_ = type.isEmpty() ? "text/plain" : type.c_str();
  httpd_resp_set_type(r, type_.c_str());
  headersSent_ = true;
}

void ESP8266WebServer::send(int code) { send(code, String("text/plain"), String()); }

void ESP8266WebServer::send(int code, const String &type, const String &content) {
  send(code, type, reinterpret_cast<const uint8_t *>(content.c_str()), content.length());
}

void ESP8266WebServer::send(int code, const String &type, const uint8_t *data, size_t length) {
  if (!request_ || headersSent_) return;
  beginResponse(code, type);
  httpd_req_t *r = static_cast<httpd_req_t *>(request_);
  if (contentLength_) {
    // A page or file sent in pieces (setContentLength first): chunked.
    chunked_ = true;
    if (length) httpd_resp_send_chunk(r, reinterpret_cast<const char *>(data), length);
    return;
  }
  httpd_resp_send(r, reinterpret_cast<const char *>(data), length);
  ended_ = true;
}

void ESP8266WebServer::sendContent(const char *content, size_t length) {
  if (!request_ || !chunked_ || ended_) return;
  httpd_req_t *r = static_cast<httpd_req_t *>(request_);
  if (!length) {  // as the ESP8266: an empty piece ends the response
    httpd_resp_send_chunk(r, nullptr, 0);
    ended_ = true;
    return;
  }
  httpd_resp_send_chunk(r, content, length);
}

void ESP8266WebServer::finishResponse() {
  if (!request_) return;
  httpd_req_t *r = static_cast<httpd_req_t *>(request_);
  if (!headersSent_) {
    httpd_resp_set_status(r, "500 Internal Server Error");
    httpd_resp_send(r, "No response", HTTPD_RESP_USE_STRLEN);
  } else if (chunked_ && !ended_) {
    httpd_resp_send_chunk(r, nullptr, 0);
  }
  ended_ = true;
}
