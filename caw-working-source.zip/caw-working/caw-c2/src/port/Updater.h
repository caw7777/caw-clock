#pragma once
// The ESP8266 core's Update (firmware upload on the System tab), on ESP-IDF's
// OTA: the image goes into the other app slot and is checked (format and
// SHA-256 appended by the build) before the clock is told to start it.
#include "Arduino.h"

class CawUpdate {
 public:
  bool begin(size_t size);
  size_t write(const uint8_t *data, size_t length);
  bool end(bool evenIfRemaining = false);
  bool hasError() const { return error_; }
  bool isRunning() const { return running_; }
  size_t progress() const { return written_; }
  const char *errorText() const { return errorText_; }
  void abort();

 private:
  void fail(const char *text);
  uint32_t handle_ = 0;  // esp_ota_handle_t
  const void *partition_ = nullptr;
  bool running_ = false, error_ = false;
  size_t written_ = 0;
  const char *errorText_ = "";
};
extern CawUpdate Update;
