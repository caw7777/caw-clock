// ESP object and configTime of the Arduino stand-in (Arduino.h).
#include "Arduino.h"

#include "esp_attr.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_heap_caps.h"
#include "esp_mac.h"
#include "esp_netif_sntp.h"
#include "esp_ota_ops.h"
#include "esp_sntp.h"
#include "esp_system.h"

namespace {
// The ESP8266's RTC user memory: kept across restarts and crashes, lost on
// power-off. The ESP32-C2 has no RTC RAM; ordinary RAM left uninitialised at
// start behaves the same for software restarts (power-on is a cold start for
// every user of it: CawCrashLog and the boot guard check a magic value).
__NOINIT_ATTR uint32_t gRtcUser[128];
rst_info gResetInfo;
bool gResetInfoSet = false;
}  // namespace

void CawEsp::restart() { esp_restart(); }
uint32_t CawEsp::getFreeHeap() { return esp_get_free_heap_size(); }
uint32_t CawEsp::getMaxFreeBlockSize() { return heap_caps_get_largest_free_block(MALLOC_CAP_8BIT); }
uint8_t CawEsp::getHeapFragmentation() {
  const uint32_t free = getFreeHeap();
  return free ? uint8_t(100 - uint64_t(getMaxFreeBlockSize()) * 100 / free) : 0;
}
uint32_t CawEsp::getFreeContStack() { return uxTaskGetStackHighWaterMark(nullptr); }

String CawEsp::getResetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return String("Power On");
    case ESP_RST_EXT: return String("External System");
    case ESP_RST_SW: return String("Software/System restart");
    case ESP_RST_PANIC: return String("Exception");
    case ESP_RST_INT_WDT: case ESP_RST_WDT: return String("Hardware Watchdog");
    case ESP_RST_TASK_WDT: return String("Software Watchdog");
    case ESP_RST_BROWNOUT: return String("Brownout");
    case ESP_RST_DEEPSLEEP: return String("Deep-Sleep Wake");
    default: return String("Unknown");
  }
}

const rst_info *CawEsp::getResetInfoPtr() {
  if (!gResetInfoSet) {
    gResetInfoSet = true;
    switch (esp_reset_reason()) {
      case ESP_RST_EXT: gResetInfo.reason = REASON_EXT_SYS_RST; break;
      case ESP_RST_SW: gResetInfo.reason = REASON_SOFT_RESTART; break;
      case ESP_RST_PANIC: gResetInfo.reason = REASON_EXCEPTION_RST; break;
      case ESP_RST_INT_WDT: case ESP_RST_WDT: gResetInfo.reason = REASON_WDT_RST; break;
      case ESP_RST_TASK_WDT: gResetInfo.reason = REASON_SOFT_WDT_RST; break;
      case ESP_RST_DEEPSLEEP: gResetInfo.reason = REASON_DEEP_SLEEP_AWAKE; break;
      default: gResetInfo.reason = REASON_DEFAULT_RST;  // power-on, brown-out: a cold start
    }
  }
  return &gResetInfo;
}

bool CawEsp::rtcUserMemoryRead(uint32_t offset, uint32_t *data, size_t size) {
  if (offset * 4 + size > sizeof(gRtcUser)) return false;
  memcpy(data, reinterpret_cast<const uint8_t *>(gRtcUser) + offset * 4, size);
  return true;
}

bool CawEsp::rtcUserMemoryWrite(uint32_t offset, const uint32_t *data, size_t size) {
  if (offset * 4 + size > sizeof(gRtcUser)) return false;
  memcpy(reinterpret_cast<uint8_t *>(gRtcUser) + offset * 4, data, size);
  return true;
}

uint32_t CawEsp::getFreeSketchSpace() {
  const esp_partition_t *next = esp_ota_get_next_update_partition(nullptr);
  return next ? next->size : 0;
}

uint64_t CawEsp::getEfuseMac() {
  uint8_t mac[6] = {};
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  uint64_t value = 0;
  for (int i = 5; i >= 0; --i) value = value << 8 | mac[i];
  return value;
}

uint32_t CawEsp::getChipId() {
  // As the ESP8266: the last three bytes of the MAC address.
  uint8_t mac[6] = {};
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  return uint32_t(mac[3]) << 16 | uint32_t(mac[4]) << 8 | mac[5];
}

void configTime(const char *tz, const char *server1, const char *server2) {
  setenv("TZ", tz && tz[0] ? tz : "UTC0", 1);
  tzset();
  static bool started = false;
  if (started) return;
  started = true;
  // The app sets the zone before Wi-Fi starts: the network layer first (both
  // calls do nothing when WiFi has already made them).
  esp_netif_init();
  esp_event_loop_create_default();
  esp_sntp_config_t config = ESP_NETIF_SNTP_DEFAULT_CONFIG_MULTIPLE(
      2, ESP_SNTP_SERVER_LIST(server1 ? server1 : "pool.ntp.org", server2 ? server2 : "time.google.com"));
  esp_netif_sntp_init(&config);
}
