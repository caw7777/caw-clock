#pragma once
// The BearSSL::WiFiClientSecure of the ESP8266 core, on ESP-IDF's esp-tls
// (mbedTLS). Certificates are checked against CAW Clock's own roots (the
// custom bundle, certs/caw_roots.pem: the same six as the ESP8266 build), so
// the trust-anchor, session and buffer calls of the shared code have nothing
// to do here.
#include "Arduino.h"

// BearSSL names the shared code refers to.
struct br_ssl_session_parameters {
  uint8_t session_id[32];
  uint8_t session_id_len;
  uint16_t version, cipher_suite;
  uint8_t master_secret[48];
};
struct br_ssl_client_context { uint8_t opaque[2048]; };   // sizes only feed the heap probe
struct br_x509_minimal_context { uint8_t opaque[1024]; };
constexpr int BR_ERR_TOO_LARGE = 1001;           // never reported: mbedTLS sizes its buffers itself
constexpr int BR_ERR_X509_NOT_TRUSTED = 1002;    // every root is always loaded
constexpr int kCawTlsError = 1;                  // any other TLS failure

namespace BearSSL {

class X509List {
 public:
  X509List() = default;
  explicit X509List(const char *) {}
  bool append(const char *) { return true; }
  bool append(const uint8_t *, size_t) { return true; }
};

class Session {
 public:
  Session() { memset(&parameters_, 0, sizeof(parameters_)); }

 private:
  br_ssl_session_parameters parameters_;
};

class WiFiClientSecure : public Stream {
 public:
  WiFiClientSecure() = default;
  ~WiFiClientSecure() override { stop(); }
  WiFiClientSecure(const WiFiClientSecure &) = delete;
  WiFiClientSecure &operator=(const WiFiClientSecure &) = delete;

  int connect(const char *host, uint16_t port);
  int connect(const String &host, uint16_t port) { return connect(host.c_str(), port); }
  uint8_t connected();
  void stop();
  explicit operator bool() { return connected(); }

  using Print::write;
  size_t write(uint8_t c) override { return write(&c, 1); }
  size_t write(const uint8_t *data, size_t length) override;
  int available() override;
  int read() override;
  int peek() override;
  size_t readBytes(char *buffer, size_t length) override;
  int read(uint8_t *buffer, size_t length);

  void setBufferSizes(int, int) {}
  void setTrustAnchors(const X509List *) {}
  void setX509Time(time_t) {}
  void setSession(Session *) {}
  void setInsecure() {}
  int getLastSSLError(char *dest = nullptr, size_t len = 0);

 private:
  bool fill();
  void *tls_ = nullptr;  // esp_tls_t *
  uint8_t buffer_[512];
  size_t bufferStart_ = 0, bufferEnd_ = 0;
  bool closed_ = false;
  int lastError_ = 0;
};

}  // namespace BearSSL
