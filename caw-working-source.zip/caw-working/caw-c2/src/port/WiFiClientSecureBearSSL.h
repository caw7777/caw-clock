#pragma once
// The BearSSL::WiFiClientSecure of the ESP8266 core, on ESP-IDF's esp-tls
// (mbedTLS). Certificates are checked against CAW Clock's own roots (the
// custom bundle, certs/caw_roots.pem: the same six as the ESP8266 build), so
// the trust-anchor and buffer calls of the shared code have nothing to do
// here. Sessions are kept (esp-tls client sessions: a resumed connection
// skips the certificate check and key exchange, as on the ESP8266).
#include "Arduino.h"

// BearSSL names the shared code refers to.
struct br_ssl_session_parameters {
  uint8_t session_id[32];
  uint8_t session_id_len;
  uint16_t version, cipher_suite;
  uint8_t master_secret[48];
};
struct br_ssl_client_context { uint8_t opaque[2048]; };   // sizes only feed the heap probe
struct br_x509_minimal_context { uint8_t opaque[1024]; };
constexpr int BR_ERR_TOO_LARGE = 1001;           // never reported: mbedTLS sizes its buffers itself
constexpr int BR_ERR_X509_NOT_TRUSTED = 1002;    // every root is always loaded
constexpr int kCawTlsError = 1;                  // any other TLS failure

namespace BearSSL {

class X509List {
 public:
  X509List() = default;
  explicit X509List(const char *) {}
  bool append(const char *) { return true; }
  bool append(const uint8_t *, size_t) { return true; }
};

// The shared code reads session_id (same id after a connection = resumed),
// so the layout stays BearSSL's. The esp-tls session (heap) is kept in the
// otherwise unused master_secret bytes.
class Session {
 public:
  Session() { memset(&parameters_, 0, sizeof(parameters_)); }
  ~Session() { clear(); }
  Session(const Session &) = delete;
  Session &operator=(const Session &) = delete;

  void *saved() const;  // esp_tls_client_session_t *, or nullptr
  void keep(void *session, const uint8_t *id, size_t idLength);  // takes ownership
  void clear();

 private:
  br_ssl_session_parameters parameters_;
};

class WiFiClientSecure : public Stream {
 public:
  WiFiClientSecure() = default;
  ~WiFiClientSecure() override { stop(); }
  WiFiClientSecure(const WiFiClientSecure &) = delete;
  WiFiClientSecure &operator=(const WiFiClientSecure &) = delete;

  int connect(const char *host, uint16_t port);
  int connect(const String &host, uint16_t port) { return connect(host.c_str(), port); }
  uint8_t connected();
  void stop();
  explicit operator bool() { return connected(); }

  using Print::write;
  size_t write(uint8_t c) override { return write(&c, 1); }
  size_t write(const uint8_t *data, size_t length) override;
  int available() override;
  int read() override;
  int peek() override;
  size_t readBytes(char *buffer, size_t length) override;
  int read(uint8_t *buffer, size_t length);

  void setBufferSizes(int, int) {}
  void setTrustAnchors(const X509List *) {}
  void setX509Time(time_t) {}
  void setSession(Session *session) { session_ = session; }
  void setInsecure() {}
  int getLastSSLError(char *dest = nullptr, size_t len = 0);

 private:
  bool fill();
  void *tls_ = nullptr;  // esp_tls_t *
  uint8_t buffer_[512];
  size_t bufferStart_ = 0, bufferEnd_ = 0;
  bool closed_ = false;
  int lastError_ = 0;
  Session *session_ = nullptr;
};

}  // namespace BearSSL
