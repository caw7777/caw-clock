#pragma once
// The ESP8266 core's WiFi object, on ESP-IDF's Wi-Fi driver: one station and
// the setup access point, status from the driver's events, asynchronous scans.
#include "Arduino.h"
#include "IPAddress.h"

enum wl_status_t {
  WL_NO_SHIELD = 255,
  WL_IDLE_STATUS = 0,
  WL_NO_SSID_AVAIL = 1,
  WL_SCAN_COMPLETED = 2,
  WL_CONNECTED = 3,
  WL_CONNECT_FAILED = 4,
  WL_CONNECTION_LOST = 5,
  WL_WRONG_PASSWORD = 6,
  WL_DISCONNECTED = 7,
};
enum WiFiMode_t { WIFI_OFF = 0, WIFI_STA = 1, WIFI_AP = 2, WIFI_AP_STA = 3 };
constexpr int WIFI_SCAN_RUNNING = -1;
constexpr int WIFI_SCAN_FAILED = -2;

class CawWiFi {
 public:
  bool mode(WiFiMode_t mode);
  WiFiMode_t getMode() const { return mode_; }
  void persistent(bool) {}
  bool hostname(const String &name) { return hostname(name.c_str()); }
  bool hostname(const char *name);
  bool setAutoReconnect(bool on) { autoReconnect_ = on; return true; }
  wl_status_t begin(const char *ssid, const char *password = nullptr);
  bool disconnect(bool wifiOff = false);
  wl_status_t status() const { return status_; }
  bool isConnected() const { return status_ == WL_CONNECTED; }
  IPAddress localIP() const;
  IPAddress softAPIP() const;
  String SSID() const;
  int32_t RSSI() const;
  bool softAP(const char *ssid, const char *password = nullptr, int channel = 1);
  bool softAPdisconnect(bool wifiOff = false);
  uint8_t softAPgetStationNum() const;
  int8_t scanNetworks(bool async = false);
  int8_t scanComplete() const { return scanState_; }
  void scanDelete();
  String SSID(uint8_t index) const;
  int32_t RSSI(uint8_t index) const;
  String macAddress() const;
  // CAW C2: the station network the factory firmware saved (read before the
  // driver's storage is switched to RAM), for the first start of CAW Clock.
  bool factoryStation(char *ssid, size_t ssidSize, char *password, size_t passwordSize);

  // Driver events (port/ESP8266WiFi.cpp).
  void onEvent(const char *base, int32_t id, void *data);

 private:
  void init();
  bool started_ = false;
  WiFiMode_t mode_ = WIFI_OFF;
  volatile wl_status_t status_ = WL_IDLE_STATUS;
  bool autoReconnect_ = true;
  bool wantStation_ = false;
  char hostname_[33] = "caw-clock";
  volatile int8_t scanState_ = WIFI_SCAN_FAILED;
  struct Network { char ssid[33]; int8_t rssi; };
  Network *networks_ = nullptr;
  uint8_t networkCount_ = 0;
  uint32_t lastReconnect_ = 0;
};
extern CawWiFi WiFi;
