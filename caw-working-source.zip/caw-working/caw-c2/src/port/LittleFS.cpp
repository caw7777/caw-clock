#include "LittleFS.h"

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include "esp_littlefs.h"

namespace {
constexpr char kBase[] = "/fs";
constexpr char kLabel[] = "spiffs";  // the CAW layout's storage partition

std::string real(const char *path) {
  std::string out(kBase);
  if (!path || path[0] != '/') out += '/';
  if (path) out += path;
  while (out.size() > strlen(kBase) + 1 && out.back() == '/') out.pop_back();
  return out;
}
}  // namespace

struct CawFileHandle {
  FILE *file = nullptr;
  std::string name;
  ~CawFileHandle() {
    if (file) fclose(file);
  }
};

CawLittleFs LittleFS;

File::operator bool() const { return h_ && h_->file; }
size_t File::write(uint8_t c) { return write(&c, 1); }
size_t File::write(const uint8_t *d, size_t n) {
  if (!*this) return 0;
  const size_t done = fwrite(d, 1, n, h_->file);
  if (done != n) setWriteError();
  return done;
}
int File::available() {
  if (!*this) return 0;
  const long at = ftell(h_->file);
  const long total = long(size());
  return at < 0 || total <= at ? 0 : int(total - at);
}
int File::read() {
  if (!*this) return -1;
  const int c = fgetc(h_->file);
  return c == EOF ? -1 : c;
}
int File::peek() {
  if (!*this) return -1;
  const int c = fgetc(h_->file);
  if (c == EOF) return -1;
  ungetc(c, h_->file);
  return c;
}
size_t File::read(uint8_t *buf, size_t n) { return *this ? fread(buf, 1, n, h_->file) : 0; }
bool File::seek(uint32_t pos) { return *this && fseek(h_->file, long(pos), SEEK_SET) == 0; }
size_t File::position() const {
  if (!*this) return 0;
  const long at = ftell(h_->file);
  return at < 0 ? 0 : size_t(at);
}
size_t File::size() const {
  if (!*this) return 0;
  struct stat st {};
  if (fstat(fileno(h_->file), &st) == 0 && st.st_size > 0) return size_t(st.st_size);
  const long at = ftell(h_->file);  // written but not yet flushed: measure
  fseek(h_->file, 0, SEEK_END);
  const long end = ftell(h_->file);
  fseek(h_->file, at, SEEK_SET);
  return end < 0 ? 0 : size_t(end);
}
void File::flush() {
  if (*this) fflush(h_->file);
}
void File::close() { h_.reset(); }
const char *File::name() const { return h_ ? h_->name.c_str() : ""; }

bool Dir::next() {
  if (!dir_) return false;
  DIR *dir = static_cast<DIR *>(dir_.get());
  while (dirent *entry = readdir(dir)) {
    if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
    name_ = entry->d_name;
    const std::string full = path_ + "/" + entry->d_name;
    struct stat st {};
    directory_ = stat(full.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
    size_ = directory_ ? 0 : size_t(st.st_size);
    return true;
  }
  return false;
}

bool CawLittleFs::begin() {
  if (mounted_) return true;
  esp_vfs_littlefs_conf_t conf = {};
  conf.base_path = kBase;
  conf.partition_label = kLabel;
  conf.format_if_mount_failed = true;  // first start: the partition holds the factory's SPIFFS
  conf.dont_mount = false;
  mounted_ = esp_vfs_littlefs_register(&conf) == ESP_OK;
  return mounted_;
}

void CawLittleFs::end() {
  if (mounted_) esp_vfs_littlefs_unregister(kLabel);
  mounted_ = false;
}

bool CawLittleFs::format() {
  const bool was = mounted_;
  end();
  const bool ok = esp_littlefs_format(kLabel) == ESP_OK;
  if (was) begin();
  return ok;
}

File CawLittleFs::open(const char *path, const char *mode) {
  if (!mounted_) return File();
  const std::string full = real(path);
  // "w"/"a" create; "r+" and "w+" as stdio. Binary throughout.
  char m[4] = {mode && mode[0] ? mode[0] : 'r', 'b', 0, 0};
  if (mode && mode[0] && mode[1] == '+') m[2] = '+';
  FILE *file = fopen(full.c_str(), m);
  if (!file) return File();
  auto handle = std::make_shared<CawFileHandle>();
  handle->file = file;
  const char *slash = strrchr(path, '/');
  handle->name = slash ? slash + 1 : path;
  return File(handle);
}

bool CawLittleFs::exists(const char *path) {
  struct stat st {};
  return mounted_ && stat(real(path).c_str(), &st) == 0;
}
bool CawLittleFs::remove(const char *path) { return mounted_ && unlink(real(path).c_str()) == 0; }
bool CawLittleFs::rename(const char *from, const char *to) {
  return mounted_ && ::rename(real(from).c_str(), real(to).c_str()) == 0;
}
bool CawLittleFs::mkdir(const char *path) { return mounted_ && ::mkdir(real(path).c_str(), 0775) == 0; }
bool CawLittleFs::rmdir(const char *path) { return mounted_ && ::rmdir(real(path).c_str()) == 0; }

Dir CawLittleFs::openDir(const char *path) {
  Dir dir;
  if (!mounted_) return dir;
  dir.path_ = real(path);
  if (DIR *d = opendir(dir.path_.c_str())) dir.dir_ = std::shared_ptr<void>(d, [](void *p) { closedir(static_cast<DIR *>(p)); });
  return dir;
}

bool CawLittleFs::info(FSInfo &info) {
  if (!mounted_) return false;
  size_t total = 0, used = 0;
  if (esp_littlefs_info(kLabel, &total, &used) != ESP_OK) return false;
  info.totalBytes = total;
  info.usedBytes = used;
  return true;
}
