#pragma once
// The ESP8266 code stops all UDP (time sync) during an upload; nothing to do here.
struct WiFiUDP {
  static void stopAll() {}
};
