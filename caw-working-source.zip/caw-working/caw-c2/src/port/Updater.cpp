#include "Updater.h"

#include "esp_ota_ops.h"

CawUpdate Update;

void CawUpdate::fail(const char *text) {
  if (running_) esp_ota_abort(handle_);
  running_ = false;
  error_ = true;
  errorText_ = text;
}

bool CawUpdate::begin(size_t) {
  abort();
  error_ = false;
  errorText_ = "";
  written_ = 0;
  const esp_partition_t *next = esp_ota_get_next_update_partition(nullptr);
  if (!next) {
    error_ = true;
    errorText_ = "no slot to install into";
    return false;
  }
  esp_ota_handle_t handle = 0;
  if (esp_ota_begin(next, OTA_WITH_SEQUENTIAL_WRITES, &handle) != ESP_OK) {
    error_ = true;
    errorText_ = "could not prepare the slot";
    return false;
  }
  handle_ = handle;
  partition_ = next;
  running_ = true;
  return true;
}

size_t CawUpdate::write(const uint8_t *data, size_t length) {
  if (!running_) return 0;
  if (esp_ota_write(handle_, data, length) != ESP_OK) {
    fail("write failed (not a firmware for this clock?)");
    return 0;
  }
  written_ += length;
  return length;
}

bool CawUpdate::end(bool) {
  if (!running_) return false;
  running_ = false;
  if (esp_ota_end(handle_) != ESP_OK) {  // checks the image and its SHA-256
    error_ = true;
    errorText_ = "not a valid firmware for this clock";
    return false;
  }
  if (esp_ota_set_boot_partition(static_cast<const esp_partition_t *>(partition_)) != ESP_OK) {
    error_ = true;
    errorText_ = "could not select the new firmware";
    return false;
  }
  return true;
}

void CawUpdate::abort() {
  if (running_) esp_ota_abort(handle_);
  running_ = false;
}
