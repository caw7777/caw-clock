// Host test of port/ESP8266WebServer.cpp with a fake esp_http_server.h:
// arguments, form and multipart bodies (in odd-sized pieces), Basic and
// Digest sign-in, chunked and whole responses. Run: ./run.sh
#include <cassert>
#include <cstdio>
#include <openssl/md5.h>

#include "esp_http_server.h"
#undef HTTP_ANY
#define CAW_WEBSERVER_IMPL 1  // routes use cawweb:: names: the fake server has its own HTTP_GET
#include "ESP8266WebServer.h"

static int failures = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++failures; } } while (0)

static std::string md5hex(const std::string &s) {
  unsigned char d[16]; MD5((const unsigned char *)s.data(), s.size(), d);
  char h[33]; for (int i = 0; i < 16; ++i) sprintf(h + 2 * i, "%02x", d[i]); return h;
}

static httpd_req_t *request(int method, const char *uri, std::string body = "",
                            std::map<std::string, std::string> headers = {}) {
  auto *r = new httpd_req_t{};
  r->method = method; snprintf(r->uri, sizeof(r->uri), "%s", uri);
  r->body = body; r->content_len = body.size(); r->headers = headers;
  return r;
}

static void run(ESP8266WebServer &server, httpd_req_t *r) {
  gFakeHandler(r);
  server.handleClient();
  CHECK(r->completed);
  CHECK(r->sent);
}

int main() {
  ESP8266WebServer server(80);
  std::string seenArgs, uploaded, events;
  server.on("/form", cawweb::HTTP_POST, [&] {
    seenArgs = std::string(server.arg("a").c_str()) + "|" + server.arg("b").c_str() + "|" + (server.hasArg("c") ? "c" : "-");
    server.send(200, "text/plain", String("ok"));
  });
  server.on("/get", cawweb::HTTP_GET, [&] {
    seenArgs = std::string(server.arg("k").c_str()) + "|" + server.arg("x").c_str() + "|" + server.hostHeader().c_str();
    server.send(204);
  });
  server.on("/up", cawweb::HTTP_POST, [&] {
    seenArgs = server.arg("note").c_str();
    server.send(200, F("text/plain"), F("done"));
  }, [&] {
    HTTPUpload &u = server.upload();
    if (u.status == UPLOAD_FILE_START) { events += "S"; uploaded.clear(); CHECK(u.filename == "meme.cwp"); CHECK(u.name == "pic"); }
    else if (u.status == UPLOAD_FILE_WRITE) { events += "W"; uploaded.append((const char *)u.buf, u.currentSize); CHECK(u.currentSize <= HTTP_UPLOAD_BUFLEN); }
    else if (u.status == UPLOAD_FILE_END) { events += "E"; CHECK(u.totalSize == uploaded.size()); }
    else events += "A";
  });
  server.on("/page", cawweb::HTTP_GET, [&] {
    server.setContentLength(CONTENT_LENGTH_UNKNOWN);
    server.send(200, "text/html", emptyString);
    server.sendContent(String("<p>one"));
    server.sendContent("two");
    server.sendContent("");  // explicit end, as restartSoon()
  });
  server.on("/page2", cawweb::HTTP_GET, [&] {
    server.setContentLength(CONTENT_LENGTH_UNKNOWN);
    server.send(200, "text/html", emptyString);
    server.sendContent("abc");  // no explicit end: finishResponse ends it
  });
  server.on("/secret", cawweb::HTTP_GET, [&] {
    if (!server.authenticate("admin", "pass word!")) { server.requestAuthentication(DIGEST_AUTH, "CAW Clock"); return; }
    server.send(200, "text/plain", String("in"));
  });
  server.onNotFound([&] { server.send_P(404, "text/plain", PSTR("Not found")); });
  server.begin();

  // GET with query, %-escapes and +.
  auto *r = request(HTTP_GET, "/get?k=a%20b%2Bc&x=1+2", "", {{"Host", "192.168.1.50"}});
  run(server, r);
  CHECK(seenArgs == "a b+c|1 2|192.168.1.50");
  CHECK(r->status == "204 No Content");

  // urlencoded form body.
  r = request(HTTP_POST, "/form", "a=x%26y&b=&c", {{"Content-Type", "application/x-www-form-urlencoded"}});
  run(server, r);
  CHECK(seenArgs == "x&y||c");
  CHECK(r->out == "ok" && r->status == "200 OK");

  // Multipart: a field, then a binary file containing near-delimiters.
  std::string file;
  for (int i = 0; i < 9000; ++i) file += char((i * 131 + 7) & 0xFF);
  file.insert(100, "\r\n--XyZ");          // looks like the delimiter start
  file.insert(5000, "\r\n--XyZboundar");  // almost the whole delimiter
  const std::string boundary = "XyZboundary";
  std::string body = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"note\"\r\n\r\nhello there\r\n"
                     "--" + boundary + "\r\nContent-Disposition: form-data; name=\"pic\"; filename=\"meme.cwp\"\r\n"
                     "Content-Type: application/octet-stream\r\n\r\n" + file + "\r\n--" + boundary + "--\r\n";
  r = request(HTTP_POST, "/up?bytes=9000", body, {{"Content-Type", "multipart/form-data; boundary=" + boundary}});
  run(server, r);
  CHECK(uploaded == file);
  CHECK(events.front() == 'S' && events.back() == 'E' && events.find('A') == std::string::npos);
  CHECK(seenArgs == "hello there");
  CHECK(server.arg("bytes") == "");  // cleared after the request
  CHECK(r->out == "done");

  // Multipart cut off: ABORTED.
  events.clear();
  r = request(HTTP_POST, "/up", body.substr(0, 3000), {{"Content-Type", "multipart/form-data; boundary=" + boundary}});
  run(server, r);
  CHECK(events.back() == 'A');

  // Chunked pages.
  r = request(HTTP_GET, "/page");
  run(server, r);
  CHECK(r->out == "<p>onetwo" && r->ended && r->chunks == 2);
  r = request(HTTP_GET, "/page2");
  run(server, r);
  CHECK(r->out == "abc" && r->ended);

  // Not found.
  r = request(HTTP_GET, "/nope");
  run(server, r);
  CHECK(r->status == "404 Not Found" && r->out == "Not found");

  // RFC 2617's example, to pin the formula the test uses below.
  {
    const std::string ha1 = md5hex(std::string("Mufasa:testrealm") + "@host.com:Circle Of Life"), ha2 = md5hex("GET:/dir/index.html");
    CHECK(md5hex(ha1 + ":dcd98b7102dd2f0e8b11d0f600bfb0c093:00000001:0a4f113b:auth:" + ha2) ==
          "6629fae49393a05397450978507c4ef1");
  }
  // Digest: challenge, then an answer computed as a browser does.
  r = request(HTTP_GET, "/secret");
  run(server, r);
  CHECK(r->status == "401 Unauthorized");
  std::string challenge;
  for (auto &h : r->outHeaders) if (h.first == "WWW-Authenticate") challenge = h.second;
  CHECK(challenge.find("Digest realm=\"CAW Clock\"") == 0);
  const size_t n0 = challenge.find("nonce=\"") + 7;
  const std::string nonce = challenge.substr(n0, challenge.find('"', n0) - n0);
  CHECK(nonce.size() == 32);
  const auto answer = [&](const std::string &password, const std::string &useNonce) {
    const std::string ha1 = md5hex("admin:CAW Clock:" + password), ha2 = md5hex("GET:/secret");
    const std::string resp = md5hex(ha1 + ":" + useNonce + ":00000001:abcdef:auth:" + ha2);
    return "Digest username=\"admin\", realm=\"CAW Clock\", nonce=\"" + useNonce + "\", uri=\"/secret\", "
           "response=\"" + resp + "\", qop=auth, nc=00000001, cnonce=\"abcdef\", opaque=\"x\"";
  };
  r = request(HTTP_GET, "/secret", "", {{"Authorization", answer("pass word!", nonce)}});
  run(server, r);
  CHECK(r->out == "in");
  r = request(HTTP_GET, "/secret", "", {{"Authorization", answer("wrong", nonce)}});
  run(server, r);
  CHECK(r->status == "401 Unauthorized");
  r = request(HTTP_GET, "/secret", "", {{"Authorization", answer("pass word!", std::string(32, 'a'))}});
  run(server, r);
  CHECK(r->status == "401 Unauthorized");  // a nonce the clock never gave out
  // Basic.
  r = request(HTTP_GET, "/secret", "", {{"Authorization", "Basic YWRtaW46cGFzcyB3b3JkIQ=="}});  // admin:pass word!
  run(server, r);
  CHECK(r->out == "in");

  printf(failures ? "%d FAILED\n" : "all passed\n", failures);
  return failures != 0;
}
