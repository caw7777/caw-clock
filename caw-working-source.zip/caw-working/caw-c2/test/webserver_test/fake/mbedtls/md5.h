#pragma once
#include <openssl/md5.h>
inline int mbedtls_md5(const unsigned char *in, size_t n, unsigned char out[16]) { MD5(in, n, out); return 0; }
