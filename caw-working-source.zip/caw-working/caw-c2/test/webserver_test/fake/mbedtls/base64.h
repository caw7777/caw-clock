#pragma once
#include <openssl/evp.h>
#include <cstring>
inline int mbedtls_base64_decode(unsigned char *dst, size_t dlen, size_t *olen, const unsigned char *src, size_t slen) {
  unsigned char tmp[512]; if (slen > 600) return -1;
  int n = EVP_DecodeBlock(tmp, src, (int)slen); if (n < 0) return -1;
  while (slen && src[slen - 1] == '=') { --n; --slen; }
  if ((size_t)n > dlen) return -1; memcpy(dst, tmp, n); *olen = n; return 0; }
