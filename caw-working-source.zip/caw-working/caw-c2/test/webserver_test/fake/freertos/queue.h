#pragma once
#include <cstring>
#include <deque>
#include <vector>
#include "FreeRTOS.h"
struct FakeQueue { size_t item; std::deque<std::vector<char>> items; size_t max; };
typedef FakeQueue *QueueHandle_t;
inline QueueHandle_t xQueueCreate(int n, size_t item) { return new FakeQueue{item, {}, size_t(n)}; }
inline int xQueueSend(QueueHandle_t q, const void *p, TickType_t) {
  if (q->items.size() >= q->max) return pdFALSE;
  q->items.emplace_back((const char *)p, (const char *)p + q->item); return pdTRUE; }
inline int xQueueReceive(QueueHandle_t q, void *p, TickType_t) {
  if (q->items.empty()) return pdFALSE; memcpy(p, q->items.front().data(), q->item); q->items.pop_front(); return pdTRUE; }
