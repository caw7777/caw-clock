#pragma once
#include "FreeRTOS.h"
inline void vTaskDelay(TickType_t) {}
inline void taskYIELD() {}
inline uint32_t uxTaskGetStackHighWaterMark(void *) { return 0; }
