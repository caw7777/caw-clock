#pragma once
// Fake of the parts of ESP-IDF's HTTP server that port/ESP8266WebServer.cpp
// uses, driven by the test: one request at a time, body delivered in chunks.
#include <algorithm>
#include <climits>
#include <cstring>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>
typedef int esp_err_t;
#define ESP_OK 0
#define ESP_FAIL -1
enum http_method { HTTP_DELETE = 0, HTTP_GET = 1, HTTP_HEAD = 2, HTTP_POST = 3 };
#define HTTP_ANY INT_MAX
#define HTTPD_SOCK_ERR_TIMEOUT -3
#define HTTPD_RESP_USE_STRLEN -1
struct httpd_req_t {
  int method; char uri[512]; size_t content_len;
  std::map<std::string, std::string> headers;
  std::string body; size_t at = 0; size_t chunk = 7;
  // response
  std::string status, type; std::vector<std::pair<std::string, std::string>> outHeaders;
  std::string out; int chunks = 0; bool sent = false, ended = false, completed = false;
};
typedef void *httpd_handle_t;
struct httpd_uri_t { const char *uri; int method; esp_err_t (*handler)(httpd_req_t *); void *user_ctx; };
struct httpd_config_t { int server_port, stack_size, max_open_sockets; bool lru_purge_enable; int recv_wait_timeout, send_wait_timeout, max_uri_handlers; bool (*uri_match_fn)(const char *, const char *, size_t); };
#define HTTPD_DEFAULT_CONFIG() httpd_config_t{}
inline bool httpd_uri_match_wildcard(const char *, const char *, size_t) { return true; }
inline esp_err_t (*gFakeHandler)(httpd_req_t *) = nullptr;
inline esp_err_t httpd_start(httpd_handle_t *h, const httpd_config_t *) { *h = (void *)1; return ESP_OK; }
inline esp_err_t httpd_register_uri_handler(httpd_handle_t, const httpd_uri_t *u) { gFakeHandler = u->handler; return ESP_OK; }
inline esp_err_t httpd_req_async_handler_begin(httpd_req_t *r, httpd_req_t **out) { *out = r; return ESP_OK; }
inline esp_err_t httpd_req_async_handler_complete(httpd_req_t *r) { r->completed = true; return ESP_OK; }
inline esp_err_t httpd_resp_send_500(httpd_req_t *r) { r->status = "500"; r->sent = true; return ESP_OK; }
inline int httpd_req_to_sockfd(httpd_req_t *) { return -1; }
inline size_t httpd_req_get_hdr_value_len(httpd_req_t *r, const char *n) { auto i = r->headers.find(n); return i == r->headers.end() ? 0 : i->second.size(); }
inline esp_err_t httpd_req_get_hdr_value_str(httpd_req_t *r, const char *n, char *b, size_t s) {
  auto i = r->headers.find(n); if (i == r->headers.end() || i->second.size() + 1 > s) return ESP_FAIL;
  memcpy(b, i->second.c_str(), i->second.size() + 1); return ESP_OK; }
inline int httpd_req_recv(httpd_req_t *r, char *b, size_t n) {
  if (r->at >= r->body.size()) return 0; size_t k = std::min({n, r->chunk, r->body.size() - r->at});
  memcpy(b, r->body.data() + r->at, k); r->at += k; r->chunk = r->chunk % 97 + 13; return int(k); }
inline esp_err_t httpd_resp_set_status(httpd_req_t *r, const char *s) { r->status = s; return ESP_OK; }
inline esp_err_t httpd_resp_set_type(httpd_req_t *r, const char *t) { r->type = t; return ESP_OK; }
inline esp_err_t httpd_resp_set_hdr(httpd_req_t *r, const char *f, const char *v) { r->outHeaders.push_back({f, v}); return ESP_OK; }
inline esp_err_t httpd_resp_send(httpd_req_t *r, const char *b, long n) {
  if (r->sent) throw "sent twice"; r->sent = true; r->ended = true; r->out.assign(b ? b : "", n < 0 ? strlen(b) : size_t(n)); return ESP_OK; }
inline esp_err_t httpd_resp_send_chunk(httpd_req_t *r, const char *b, long n) {
  if (r->ended) throw "chunk after end"; r->sent = true;
  if (!b || n == 0) { r->ended = true; return ESP_OK; } r->out.append(b, n); ++r->chunks; return ESP_OK; }
