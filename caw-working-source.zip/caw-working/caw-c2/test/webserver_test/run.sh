#!/bin/sh
# Host test of the web server stand-in (needs g++ and OpenSSL's libcrypto).
set -e
cd "$(dirname "$0")"
g++ -std=gnu++17 -Wall -Wno-deprecated-declarations -Wno-misleading-indentation -include netinet/in.h -Ifake -I../../src/port \
  test.cpp ../../src/port/ESP8266WebServer.cpp -lcrypto -o /tmp/caw-webserver-test
/tmp/caw-webserver-test
