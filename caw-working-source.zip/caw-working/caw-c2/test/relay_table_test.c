// Host test of src/relay_table.h: reads a factory partition table binary
// (gen_esp32part.py output of ../partitions-factory.csv), writes the re-laid table.
// test/relay_table_test.sh checks the result with ESP-IDF's own parser.
#include <openssl/md5.h>
#include <stdio.h>
#include "../src/relay_table.h"

static void md5_of(const uint8_t *data, size_t length, uint8_t digest[16]) { MD5(data, length, digest); }

int main(int argc, char **argv) {
  if (argc != 3) return 2;
  uint8_t old[RELAY_TABLE_BYTES], table[RELAY_TABLE_BYTES];
  memset(old, 0xFF, sizeof old);
  FILE *f = fopen(argv[1], "rb");
  if (!f) return 2;
  fread(old, 1, sizeof old, f);
  fclose(f);
  const char *why = relay_build_table_md5(old, table, md5_of);
  if (why) { printf("refused: %s\n", why); return 1; }
  f = fopen(argv[2], "wb");
  fwrite(table, 1, sizeof table, f);
  fclose(f);
  // A table that is not the factory layout must be refused.
  uint8_t odd[RELAY_TABLE_BYTES];
  memcpy(odd, old, sizeof odd);
  odd[32 * 2 + 3] = 0x12;  // app0 -> ota_2: one app slot short
  if (!relay_build_table_md5(odd, table, md5_of)) { printf("FAIL: odd table accepted\n"); return 1; }
  printf("ok\n");
  return 0;
}
