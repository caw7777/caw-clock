#!/bin/sh
# Host test of the re-layout table (src/relay_table.h): builds the factory
# table from ../partitions.csv with ESP-IDF's gen_esp32part.py, re-lays it and
# parses the result with the same tool. Needs gcc, OpenSSL and IDF_PATH.
set -e
d=$(mktemp -d)
gcc -O1 -Wall -Wno-deprecated-declarations "$(dirname "$0")/relay_table_test.c" -lcrypto -o "$d/t"
python3 "$IDF_PATH/components/partition_table/gen_esp32part.py" "$(dirname "$0")/../partitions-factory.csv" "$d/old.bin" >/dev/null
"$d/t" "$d/old.bin" "$d/new.bin"
python3 "$IDF_PATH/components/partition_table/gen_esp32part.py" "$d/new.bin"
