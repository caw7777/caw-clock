// CAW Clock installer for the JUZIPi SD PRO with an ESP32-C2 ("SDC2").
//
// The clock's factory update page installs this image (a file named
// "SDC2...", at most 768 KB). It then:
//
//  1. joins the home Wi-Fi the factory firmware saved (or, when there is none
//     or it fails, opens a setup network whose key is on the screen, with a
//     page to enter it);
//  2. downloads the CAW Clock firmware of the release it was built for into
//     the part of the flash that becomes CAW Clock's second program slot
//     (the factory storage area, 0x190000), reads it back and checks its
//     SHA-256 against the one built in here;
//  3. only then rewrites the partition table to CAW Clock's layout
//     (relay_table.h: two 1.5 MB slots and 960 KB of storage) and starts the
//     downloaded firmware.
//
// Until step 3 nothing the factory firmware needs is touched: a failed
// download leaves it in place, and the clock starts it again. CAW Clock
// takes the saved Wi-Fi over on its first start.
//
// On a clock that already has CAW Clock's layout, the firmware is installed
// into the other program slot instead (as an update would).
#include <Arduino.h>
#include <TFT_eSPI.h>

#include "CawCrow.h"
#include "CawPictures.h"  // forEachMdiRow
#include "esp_crt_bundle.h"
#include "esp_event.h"
#include "esp_flash.h"
#include "esp_http_client.h"
#include "esp_http_server.h"
#include "esp_image_format.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_rom_crc.h"
#include "esp_rom_md5.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "mbedtls/sha256.h"
#include "nvs_flash.h"


#define RELAY_TABLE 0x8000u
#include "relay_table.h"

#ifndef CAW_INSTALLER_VERSION
#error "CAW_INSTALLER_VERSION is required"
#endif
#ifndef CAW_INSTALLER_SHA256
#error "CAW_INSTALLER_SHA256 is required"
#endif

namespace {

constexpr char kVersion[] = CAW_INSTALLER_VERSION;
constexpr char kSha256[] = CAW_INSTALLER_SHA256;
static_assert(sizeof(kSha256) == 65, "CAW_INSTALLER_SHA256 must be 64 hex characters");
#ifdef CAW_INSTALLER_URL
constexpr char kUrlOverride[] = CAW_INSTALLER_URL;  // test builds only
#else
constexpr char kUrlOverride[] = "";
#endif

constexpr uint32_t kNewSlot1 = 0x190000;   // CAW layout's app1 = the factory storage area
constexpr uint32_t kSlotBytes = 0x180000;  // 1.5 MB
constexpr uint32_t kJoinTimeoutMs = 30000;
constexpr int kDownloadAttempts = 3;

TFT_eSPI display;

// ------------------------------------------------------------------ screen
// 5 x 7 capitals and digits, column bytes, bit 0 = top.
struct Glyph {
  char c;
  uint8_t col[5];
};
const Glyph kFont[] = {
    {' ', {0, 0, 0, 0, 0}},          {'.', {0, 0x60, 0x60, 0, 0}},     {'-', {8, 8, 8, 8, 8}},
    {':', {0, 0x36, 0x36, 0, 0}},    {'/', {0x20, 0x10, 8, 4, 2}},     {'%', {0x23, 0x13, 8, 0x64, 0x62}},
    {'!', {0, 0, 0x5F, 0, 0}},       {',', {0, 0x50, 0x30, 0, 0}},     {'(', {0, 0x1C, 0x22, 0x41, 0}},
    {')', {0, 0x41, 0x22, 0x1C, 0}}, {'0', {0x3E, 0x51, 0x49, 0x45, 0x3E}}, {'1', {0, 0x42, 0x7F, 0x40, 0}},
    {'2', {0x42, 0x61, 0x51, 0x49, 0x46}}, {'3', {0x21, 0x41, 0x45, 0x4B, 0x31}}, {'4', {0x18, 0x14, 0x12, 0x7F, 0x10}},
    {'5', {0x27, 0x45, 0x45, 0x45, 0x39}}, {'6', {0x3C, 0x4A, 0x49, 0x49, 0x30}}, {'7', {1, 0x71, 9, 5, 3}},
    {'8', {0x36, 0x49, 0x49, 0x49, 0x36}}, {'9', {6, 0x49, 0x49, 0x29, 0x1E}}, {'A', {0x7E, 0x11, 0x11, 0x11, 0x7E}},
    {'B', {0x7F, 0x49, 0x49, 0x49, 0x36}}, {'C', {0x3E, 0x41, 0x41, 0x41, 0x22}}, {'D', {0x7F, 0x41, 0x41, 0x22, 0x1C}},
    {'E', {0x7F, 0x49, 0x49, 0x49, 0x41}}, {'F', {0x7F, 9, 9, 9, 1}},      {'G', {0x3E, 0x41, 0x49, 0x49, 0x7A}},
    {'H', {0x7F, 8, 8, 8, 0x7F}},     {'I', {0, 0x41, 0x7F, 0x41, 0}},  {'J', {0x20, 0x40, 0x41, 0x3F, 1}},
    {'K', {0x7F, 8, 0x14, 0x22, 0x41}}, {'L', {0x7F, 0x40, 0x40, 0x40, 0x40}}, {'M', {0x7F, 2, 0xC, 2, 0x7F}},
    {'N', {0x7F, 4, 8, 0x10, 0x7F}},  {'O', {0x3E, 0x41, 0x41, 0x41, 0x3E}}, {'P', {0x7F, 9, 9, 9, 6}},
    {'Q', {0x3E, 0x41, 0x51, 0x21, 0x5E}}, {'R', {0x7F, 9, 0x19, 0x29, 0x46}}, {'S', {0x46, 0x49, 0x49, 0x49, 0x31}},
    {'T', {1, 1, 0x7F, 1, 1}},        {'U', {0x3F, 0x40, 0x40, 0x40, 0x3F}}, {'V', {0x1F, 0x20, 0x40, 0x20, 0x1F}},
    {'W', {0x3F, 0x40, 0x38, 0x40, 0x3F}}, {'X', {0x63, 0x14, 8, 0x14, 0x63}}, {'Y', {7, 8, 0x70, 8, 7}},
    {'Z', {0x61, 0x51, 0x49, 0x45, 0x43}},
};

const uint8_t *glyph(char c) {
  if (c >= 'a' && c <= 'z') c = char(c - 32);
  for (const Glyph &g : kFont)
    if (g.c == c) return g.col;
  return kFont[0].col;
}

constexpr uint16_t kWhite = 0xFFFF, kGrey = 0x8410, kPurple = 0xB4FF, kOrange = 0xFD20, kRed = 0xF9A6,
                   kGreen = 0x47E8, kBlack = 0x0000;

// One line of text, centred, `scale` pixels per font pixel.
void text(int y, int scale, uint16_t color, const char *line) {
  const int width = int(strlen(line)) * 6 * scale - scale;
  int x = (240 - width) / 2;
  display.fillRect(0, y, 240, 7 * scale + 2, kBlack);
  for (const char *c = line; *c; ++c, x += 6 * scale) {
    const uint8_t *col = glyph(*c);
    for (int cx = 0; cx < 5; ++cx)
      for (int cy = 0; cy < 7; ++cy)
        if ((col[cx] >> cy) & 1) display.fillRect(x + cx * scale, y + cy * scale, scale, scale, color);
  }
}

void drawCrow() {
  const bool swapped = display.getSwapBytes();
  display.setSwapBytes(true);
  forEachMdiRow(kCawCrowMdi, [](uint16_t line, uint16_t *pixels, uint16_t width) {
    display.pushImage((240 - width) / 2, 14 + line, width, 1, pixels);
  });
  display.setSwapBytes(swapped);
}

// The title stays; the four lines below it are the current step.
void screen(const char *a, const char *b = "", const char *c = "", const char *d = "", uint16_t color = kWhite) {
  text(110, 2, color, a);
  text(136, 2, kWhite, b);
  text(162, 2, kGrey, c);
  text(188, 2, kGrey, d);
}

void screenStart() {
  display.init();
  display.setBrightness(64);
  display.fillScreen(kBlack);
  display.setVerticalOffset(3);  // the SDC2's glass hides the last 3 rows
  drawCrow();
  char title[32];
  snprintf(title, sizeof(title), "CAW CLOCK %s", kVersion);
  text(78, 2, kPurple, title);
  text(220, 1, kGrey, "INSTALLER - DO NOT UNPLUG");
}

// -------------------------------------------------------------------- wifi
esp_netif_t *gSta = nullptr;
volatile bool gGotIp = false;
volatile int gLastReason = 0;

void onEvent(void *, esp_event_base_t base, int32_t id, void *data) {
  if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
    gGotIp = false;
    gLastReason = static_cast<wifi_event_sta_disconnected_t *>(data)->reason;
    esp_wifi_connect();
  } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
    gGotIp = true;
  }
}

void wifiStart() {
  esp_netif_init();
  esp_event_loop_create_default();
  gSta = esp_netif_create_default_wifi_sta();
  esp_netif_create_default_wifi_ap();
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&cfg);
  esp_event_handler_register(WIFI_EVENT, WIFI_EVENT_STA_DISCONNECTED, onEvent, nullptr);
  esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, onEvent, nullptr);
  esp_netif_set_hostname(gSta, "caw-clock");
}

// Joins the saved station network (the driver's flash storage, where the
// factory firmware keeps it). False after kJoinTimeoutMs.
bool join(char *ssid, size_t ssidSize) {
  wifi_config_t config = {};
  if (esp_wifi_get_config(WIFI_IF_STA, &config) != ESP_OK || !config.sta.ssid[0]) return false;
  snprintf(ssid, ssidSize, "%s", reinterpret_cast<const char *>(config.sta.ssid));
  screen("JOINING WI-FI", ssid);
  esp_wifi_set_mode(WIFI_MODE_STA);
  esp_wifi_start();
  esp_wifi_connect();
  const uint32_t started = millis();
  while (!gGotIp && millis() - started < kJoinTimeoutMs) delay(100);
  return gGotIp;
}

// ------------------------------------------------- setup network (fallback)
char gSetupKey[13];
volatile bool gSetupDone = false;

const char kSetupPage[] =
    "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>CAW Clock</title>"
    "<style>body{margin:0;background:#0a0d12;color:#eef0f2;font:16px system-ui,sans-serif}main{max-width:420px;"
    "margin:auto;padding:16px}input,button{width:100%;box-sizing:border-box;padding:10px;margin:6px 0 12px;"
    "border-radius:8px;border:1px solid #3a444f;background:#0c1117;color:#fff;font-size:16px}button{background:"
    "#6a35d6;border:0;font-weight:700}</style><main><h2>Install CAW Clock</h2><p>The clock needs your home Wi-Fi "
    "(2.4 GHz) to download CAW Clock.</p><form method=post action=/wifi><label>Wi-Fi name</label><input "
    "name=ssid maxlength=32 required autocapitalize=none><label>Wi-Fi password</label><input name=pass "
    "type=password maxlength=64><button>Install</button></form></main>";

int hexValue(char c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

// Value of `name` in a urlencoded body, decoded.
bool formValue(const char *body, const char *name, char *out, size_t size) {
  const size_t length = strlen(name);
  for (const char *p = body; p && *p; p = strchr(p, '&') ? strchr(p, '&') + 1 : nullptr) {
    if (strncmp(p, name, length) != 0 || p[length] != '=') continue;
    size_t n = 0;
    for (const char *q = p + length + 1; *q && *q != '&' && n + 1 < size; ++q) {
      if (*q == '+') out[n++] = ' ';
      else if (*q == '%' && hexValue(q[1]) >= 0 && hexValue(q[2]) >= 0) {
        out[n++] = char(hexValue(q[1]) << 4 | hexValue(q[2]));
        q += 2;
      } else out[n++] = *q;
    }
    out[n] = '\0';
    return true;
  }
  return false;
}

esp_err_t getPage(httpd_req_t *r) {
  httpd_resp_set_type(r, "text/html");
  return httpd_resp_send(r, kSetupPage, HTTPD_RESP_USE_STRLEN);
}

esp_err_t postWifi(httpd_req_t *r) {
  char body[256] = {0};
  if (r->content_len >= sizeof(body)) return httpd_resp_send_err(r, HTTPD_400_BAD_REQUEST, "Too long");
  int got = 0;
  while (got < int(r->content_len)) {
    const int n = httpd_req_recv(r, body + got, r->content_len - got);
    if (n <= 0) return ESP_FAIL;
    got += n;
  }
  wifi_config_t config = {};
  char ssid[33] = "", pass[65] = "";
  if (!formValue(body, "ssid", ssid, sizeof(ssid)) || !ssid[0])
    return httpd_resp_send_err(r, HTTPD_400_BAD_REQUEST, "Wi-Fi name missing");
  formValue(body, "pass", pass, sizeof(pass));
  memcpy(config.sta.ssid, ssid, strlen(ssid));
  memcpy(config.sta.password, pass, strlen(pass));
  esp_wifi_set_storage(WIFI_STORAGE_FLASH);  // CAW Clock takes it over on its first start
  esp_wifi_set_config(WIFI_IF_STA, &config);
  httpd_resp_set_type(r, "text/html");
  httpd_resp_send(r,
                  "<meta name=viewport content='width=device-width'><body style='background:#0a0d12;color:#eee;"
                  "font:16px sans-serif;padding:20px'>Saved. The clock joins your Wi-Fi and installs CAW Clock: "
                  "watch its screen.</body>",
                  HTTPD_RESP_USE_STRLEN);
  gSetupDone = true;
  return ESP_OK;
}

void setupNetwork(const char *why) {
  for (size_t i = 0; i + 1 < sizeof(gSetupKey); ++i) gSetupKey[i] = char('0' + esp_random() % 10);
  gSetupKey[sizeof(gSetupKey) - 1] = '\0';
  uint8_t mac[6];
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  char name[24];
  snprintf(name, sizeof(name), "CAW-Clock-%02X%02X%02X", mac[3], mac[4], mac[5]);
  esp_wifi_stop();
  esp_wifi_set_mode(WIFI_MODE_APSTA);
  wifi_config_t ap = {};
  memcpy(ap.ap.ssid, name, strlen(name));
  ap.ap.ssid_len = strlen(name);
  memcpy(ap.ap.password, gSetupKey, strlen(gSetupKey));
  ap.ap.authmode = WIFI_AUTH_WPA2_PSK;
  ap.ap.channel = 1;
  ap.ap.max_connection = 2;
  esp_wifi_set_config(WIFI_IF_AP, &ap);
  esp_wifi_start();
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.max_uri_handlers = 3;
  httpd_handle_t server = nullptr;
  if (httpd_start(&server, &config) == ESP_OK) {
    static const httpd_uri_t kGet = {"/", HTTP_GET, getPage, nullptr};
    static const httpd_uri_t kPost = {"/wifi", HTTP_POST, postWifi, nullptr};
    httpd_register_uri_handler(server, &kGet);
    httpd_register_uri_handler(server, &kPost);
  }
  char key[24];
  snprintf(key, sizeof(key), "KEY %s", gSetupKey);
  screen(why, name, key, "OPEN 192.168.4.1", kOrange);
  while (!gSetupDone) delay(100);
  delay(1500);  // the reply reaches the phone first
  if (server) httpd_stop(server);
  esp_wifi_stop();
}

// ---------------------------------------------------------------- download
// Where the firmware goes: the factory storage area (factory layout), or the
// program slot that is not running (CAW layout).
struct Target {
  const esp_partition_t *partition = nullptr;
  uint32_t offset = 0;  // inside `partition`
  bool cawLayout = false;
};

bool cawLayout() {
  const esp_partition_t *app0 = esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_0, nullptr);
  return app0 && app0->size >= kSlotBytes;
}

bool findTarget(Target &target) {
  target = Target{};
  target.cawLayout = cawLayout();
  if (target.cawLayout) {
    target.partition = esp_ota_get_next_update_partition(nullptr);
    return target.partition && target.partition->size >= kSlotBytes;
  }
  // Factory layout: CAW Clock's app1 (0x190000, 1.5 MB) is the start of the
  // factory storage partition.
  target.partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, "spiffs");
  return target.partition && target.partition->address == kNewSlot1 && target.partition->size >= kSlotBytes;
}

bool sha256Of(const esp_partition_t *partition, uint32_t offset, uint32_t length, char hex[65]) {
  mbedtls_sha256_context sha;
  mbedtls_sha256_init(&sha);
  mbedtls_sha256_starts(&sha, 0);
  static uint8_t buffer[4096];
  bool ok = true;
  for (uint32_t done = 0; done < length && ok;) {
    const uint32_t piece = std::min<uint32_t>(sizeof(buffer), length - done);
    ok = esp_partition_read(partition, offset + done, buffer, piece) == ESP_OK;
    mbedtls_sha256_update(&sha, buffer, piece);
    done += piece;
  }
  uint8_t digest[32];
  mbedtls_sha256_finish(&sha, digest);
  mbedtls_sha256_free(&sha);
  for (int i = 0; i < 32; ++i) snprintf(hex + 2 * i, 3, "%02x", digest[i]);
  return ok;
}

// Downloads into the target and checks it; the length on success, 0 on failure
// (`why` says what failed).
uint32_t download(const Target &target, const char **why) {
  char url[160];
  if (kUrlOverride[0]) snprintf(url, sizeof(url), "%s", kUrlOverride);
  else
    snprintf(url, sizeof(url), "https://github.com/caw7777/caw-clock/releases/download/v%s/caw-clock-sdc2-%s.bin",
             kVersion, kVersion);
  esp_http_client_config_t config = {};
  config.url = url;
  config.crt_bundle_attach = esp_crt_bundle_attach;
  config.timeout_ms = 20000;
  config.buffer_size = 2048;     // GitHub's redirect: a ~1 KB Location header
  config.buffer_size_tx = 2048;  // and then a ~1 KB request line
  config.user_agent = "CAW-Clock-Installer";
  config.max_redirection_count = 5;
  esp_http_client_handle_t client = esp_http_client_init(&config);
  if (!client) {
    *why = "NO MEMORY";
    return 0;
  }
  uint32_t length = 0;
  *why = "NO CONNECTION";
  if (esp_http_client_open(client, 0) == ESP_OK) {
    int64_t size = esp_http_client_fetch_headers(client);
    int status = esp_http_client_get_status_code(client);
    // Redirects: esp_http_client_open() does not follow them by itself.
    for (int hop = 0; hop < 5 && (status == 301 || status == 302 || status == 303 || status == 307 || status == 308);
         ++hop) {
      if (esp_http_client_set_redirection(client) != ESP_OK) break;
      esp_http_client_close(client);
      if (esp_http_client_open(client, 0) != ESP_OK) break;
      size = esp_http_client_fetch_headers(client);
      status = esp_http_client_get_status_code(client);
    }
    if (status != 200) {
      *why = status == 404 ? "RELEASE NOT FOUND" : "DOWNLOAD REFUSED";
    } else if (size <= 0 || size > int64_t(kSlotBytes)) {
      *why = "UNEXPECTED SIZE";
    } else {
      static uint8_t buffer[4096];
      uint32_t done = 0, erased = 0;
      uint8_t shown = 255;
      bool ok = true;
      while (ok && done < uint32_t(size)) {
        const int got = esp_http_client_read(client, reinterpret_cast<char *>(buffer), sizeof(buffer));
        if (got <= 0) {
          ok = false;
          break;
        }
        // Erase ahead in 64 KB blocks, then write.
        while (erased < done + got) {
          ok = esp_partition_erase_range(target.partition, target.offset + erased, 0x10000) == ESP_OK;
          if (!ok) break;
          erased += 0x10000;
        }
        ok = ok && esp_partition_write(target.partition, target.offset + done, buffer, got) == ESP_OK;
        done += got;
        const uint8_t percent = uint8_t(uint64_t(done) * 100 / uint64_t(size));
        if (percent / 5 != shown) {
          shown = percent / 5;
          char line[24];
          snprintf(line, sizeof(line), "%u%%", percent);
          screen("DOWNLOADING", line, "", "");
        }
      }
      if (!ok || done != uint32_t(size)) *why = "DOWNLOAD STOPPED";
      else {
        length = done;
        *why = nullptr;
      }
    }
  }
  esp_http_client_close(client);
  esp_http_client_cleanup(client);
  if (!length) return 0;
  // Read back from the flash: what will run is what was checked.
  screen("CHECKING", "SHA-256");
  char hex[65];
  if (!sha256Of(target.partition, target.offset, length, hex) || strcmp(hex, kSha256) != 0) {
    *why = "CHECKSUM WRONG";
    return 0;
  }
  esp_image_header_t header;
  if (esp_partition_read(target.partition, target.offset, &header, sizeof(header)) != ESP_OK ||
      header.magic != ESP_IMAGE_HEADER_MAGIC || header.chip_id != ESP_CHIP_ID_ESP32C2) {
    *why = "NOT AN SDC2 FIRMWARE";
    return 0;
  }
  return length;
}

// --------------------------------------------------------------- re-layout
void installedMd5(const uint8_t *data, size_t length, uint8_t digest[16]) {
  md5_context_t context;
  esp_rom_md5_init(&context);
  esp_rom_md5_update(&context, data, length);
  esp_rom_md5_final(digest, &context);
}

// The boot choice, written the way the bootloader reads it: OTA slot `slot`.
bool selectSlot(uint32_t slot) {
  const esp_partition_t *otadata =
      esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, nullptr);
  if (!otadata || otadata->size < 0x2000) return false;
  esp_ota_select_entry_t entries[2];
  uint32_t newest = 0;
  int older = 0;
  for (int i = 0; i < 2; ++i) {
    esp_partition_read(otadata, i * 0x1000, &entries[i], sizeof(entries[i]));
    const bool valid = entries[i].ota_seq != 0xFFFFFFFF &&
                       entries[i].crc == esp_rom_crc32_le(UINT32_MAX, reinterpret_cast<const uint8_t *>(&entries[i].ota_seq), 4);
    if (valid && entries[i].ota_seq >= newest) {
      newest = entries[i].ota_seq;
      older = 1 - i;
    }
  }
  uint32_t seq = newest + 1;
  while ((seq - 1) % 2 != slot) ++seq;  // both layouts have two OTA slots
  esp_ota_select_entry_t entry;
  memset(&entry, 0xFF, sizeof(entry));
  entry.ota_seq = seq;
  entry.ota_state = ESP_OTA_IMG_VALID;
  entry.crc = esp_rom_crc32_le(UINT32_MAX, reinterpret_cast<const uint8_t *>(&entry.ota_seq), 4);
  if (esp_partition_erase_range(otadata, older * 0x1000, 0x1000) != ESP_OK) return false;
  if (esp_partition_write(otadata, older * 0x1000, &entry, sizeof(entry)) != ESP_OK) return false;
  esp_ota_select_entry_t check;
  return esp_partition_read(otadata, older * 0x1000, &check, sizeof(check)) == ESP_OK && check.ota_seq == seq;
}

// Factory layout -> CAW Clock's layout, with the downloaded firmware (already
// at 0x190000, its app1) started next. The boot choice first: under either
// table, OTA slot 1 then holds a firmware that starts (under the factory
// table the one in its app1), so a power cut between the two writes is safe.
const char *relayAndStart() {
  if (!selectSlot(1)) return "BOOT CHOICE FAILED";
  static uint8_t old[RELAY_TABLE_BYTES], table[RELAY_TABLE_BYTES];
  if (esp_flash_read(nullptr, old, RELAY_TABLE, RELAY_TABLE_BYTES) != ESP_OK) return "TABLE READ FAILED";
  if (const char *why = relay_build_table_md5(old, table, installedMd5)) return why;
  // The one write that must not be interrupted (a few milliseconds).
  if (esp_flash_erase_region(nullptr, RELAY_TABLE, 0x1000) != ESP_OK ||
      esp_flash_write(nullptr, table, RELAY_TABLE, RELAY_TABLE_BYTES) != ESP_OK)
    return "TABLE WRITE FAILED";
  if (esp_flash_read(nullptr, old, RELAY_TABLE, RELAY_TABLE_BYTES) != ESP_OK ||
      memcmp(old, table, RELAY_TABLE_BYTES) != 0)
    return "TABLE CHECK FAILED";
  return nullptr;
}

// Failed runs in a row (NVS). The installer tries again after a restart; the
// third failure in a row starts the factory firmware again instead (still in
// the other slot: nothing was changed), so the clock is never stuck here.
constexpr uint8_t kRunsBeforeFactory = 3;

uint8_t failedRuns(int change) {
  nvs_handle_t handle;
  uint8_t runs = 0;
  if (nvs_open("cawinst", NVS_READWRITE, &handle) != ESP_OK) return 0;
  nvs_get_u8(handle, "fails", &runs);
  if (change > 0) runs = runs < 255 ? runs + 1 : runs;
  if (change < 0) runs = 0;
  if (change) {
    nvs_set_u8(handle, "fails", runs);
    nvs_commit(handle);
  }
  nvs_close(handle);
  return runs;
}

void fail(const char *step, const char *why) {
  const bool toFactory = !cawLayout() && failedRuns(1) >= kRunsBeforeFactory;
  screen(step, why, toFactory ? "BACK TO FACTORY" : "TRYING AGAIN IN", toFactory ? "FIRMWARE IN 30 S" : "30 SECONDS", kRed);
  delay(30000);
  if (toFactory) {
    failedRuns(-1);
    const esp_partition_t *running = esp_ota_get_running_partition();
    const esp_partition_t *factory = esp_ota_get_next_update_partition(nullptr);  // the other slot
    if (running && factory && factory->subtype >= ESP_PARTITION_SUBTYPE_APP_OTA_MIN)
      selectSlot(factory->subtype - ESP_PARTITION_SUBTYPE_APP_OTA_MIN);
  }
  esp_restart();
}

void run() {
  screenStart();
  wifiStart();
  char ssid[33] = "";
  if (!join(ssid, sizeof(ssid))) {
    setupNetwork(ssid[0] ? "CAN'T JOIN WI-FI" : "WI-FI NEEDED");
    if (!join(ssid, sizeof(ssid))) fail("CAN'T JOIN WI-FI", ssid);
  }
  Target target;
  if (!findTarget(target)) fail("UNEXPECTED FLASH", "LAYOUT");
  uint32_t length = 0;
  const char *why = nullptr;
  for (int attempt = 0; attempt < kDownloadAttempts && !length; ++attempt) {
    if (attempt) {
      screen("TRYING AGAIN", why);
      delay(5000);
    }
    length = download(target, &why);
  }
  if (!length) fail("NOT INSTALLED", why);
  screen("INSTALLING", "", "", "", kGreen);
  if (target.cawLayout) {
    if (esp_ota_set_boot_partition(target.partition) != ESP_OK) fail("NOT INSTALLED", "BOOT CHOICE FAILED");
  } else if (const char *error = relayAndStart()) {
    fail("NOT INSTALLED", error);
  }
  failedRuns(-1);
  screen("DONE", "STARTING CAW CLOCK", "", "", kGreen);
  delay(1500);
  esp_restart();
}

}  // namespace

extern "C" void app_main(void) {
  esp_err_t err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    nvs_flash_erase();
    nvs_flash_init();
  }
  run();
}
