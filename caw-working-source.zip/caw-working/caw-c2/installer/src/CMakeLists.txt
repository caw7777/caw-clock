# CAW Clock installer for SDC2 clocks. The release workflow sets
# CAW_INSTALLER_VERSION and CAW_INSTALLER_SHA256 (of caw-clock-sdc2-VERSION.bin,
# which this image downloads and checks); CAW_INSTALLER_URL, for test builds
# only, downloads from another address instead.
set(C2 "${CMAKE_CURRENT_LIST_DIR}/../..")
set(FW "${C2}/../firmware/src")
if(NOT DEFINED ENV{CAW_INSTALLER_VERSION} OR NOT DEFINED ENV{CAW_INSTALLER_SHA256})
  message(FATAL_ERROR "set CAW_INSTALLER_VERSION and CAW_INSTALLER_SHA256")
endif()
idf_component_register(
  SRCS "installer.cpp" "${C2}/src/port/TFT_eSPI.cpp"
  INCLUDE_DIRS "." "${C2}/src/port" "${C2}/src" "${FW}" "${FW}/CawStandalone"
  REQUIRES esp_http_client esp-tls mbedtls esp_wifi esp_netif esp_event nvs_flash esp_http_server
           app_update spi_flash esp_partition esp_driver_ledc esp_driver_gpio esp_driver_spi esp_timer
           bootloader_support esp_app_format esp_rom)
target_compile_definitions(${COMPONENT_LIB} PRIVATE CAW_STANDALONE=1 CAW_C2=1
  "CAW_INSTALLER_VERSION=\"$ENV{CAW_INSTALLER_VERSION}\""
  "CAW_INSTALLER_SHA256=\"$ENV{CAW_INSTALLER_SHA256}\"")
if(DEFINED ENV{CAW_INSTALLER_URL})
  target_compile_definitions(${COMPONENT_LIB} PRIVATE "CAW_INSTALLER_URL=\"$ENV{CAW_INSTALLER_URL}\"")
endif()
target_compile_options(${COMPONENT_LIB} PRIVATE -Wno-missing-field-initializers)
