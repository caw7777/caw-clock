"""Copy the ESP8266 build's CAW fonts to caw-c2/generated, keeping only the
characters CAW Clock draws (about half the font data: the 768 KB app slot).

Kept: ASCII 32-126, the C1 slots 0x80-0x8C (subscript digits, Wi-Fi icons,
the ticker's play mark; see firmware/scripts/caw_font_assets.py) and U+00B7
(the burn line's middle dot). Other characters draw as the missing-glyph box.

Usage, from caw-working/ after building the ESP8266 firmware once:
  python3 caw-c2/scripts/trim_fonts.py \
      firmware/.pio/build/sdpro_caw_standalone/caw_generated/fonts_caw \
      caw-c2/generated/fonts_caw
"""

import importlib.util
import re
import struct
import sys
from pathlib import Path

KEEP = set(range(32, 127)) | set(range(0x80, 0x8D)) | {0xB7}
GFX_LAST = 0x8C  # GFX fonts cover a contiguous range: cut after the C1 slots
HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parents[1] / "firmware" / "scripts"


def hex_bytes(text):
    return bytes(int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", text))


def rows(data, width=16):
    return "\n".join("  " + ", ".join(f"0x{b:02X}" for b in data[i:i + width]) + ","
                     for i in range(0, len(data), width))


def parse_vlw(data):
    count, version, size, zero, ascent, descent = struct.unpack_from(">6I", data)
    assert version == 12, version
    glyphs, position = [], 24 + 7 * count
    for index in range(count):
        code, h, w, adv, dy, dx = struct.unpack_from(">HBBBbb", data, 24 + 7 * index)
        glyphs.append((code, h, w, adv, dy, dx, data[position:position + w * h]))
        position += w * h
    return (size, zero, ascent, descent), glyphs


def build_vlw(header, glyphs):
    out = bytearray(struct.pack(">6I", len(glyphs), 12, *header))
    for code, h, w, adv, dy, dx, _ in glyphs:
        out += struct.pack(">HBBBbb", code, h, w, adv, dy, dx)
    for glyph in glyphs:
        out += glyph[6]
    return bytes(out)


def trim_smooth(text):
    def one(match):
        name, body = match.group(1), match.group(2)
        header, glyphs = parse_vlw(hex_bytes(body))
        kept = [g for g in glyphs if g[0] in KEEP]
        return f"const uint8_t {name}[] PROGMEM = {{\n{rows(build_vlw(header, kept))}\n}};"
    return re.sub(r"const uint8_t (InterTightSmooth\d+)\[\] PROGMEM = \{(.*?)\};", one, text, flags=re.S)


def trim_coverage(text):
    for size in (36, 48):
        pixels_m = re.search(rf"const uint8_t coveragePixels{size}\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
        glyphs_m = re.search(rf"const CoverageGlyph coverageGlyphs{size}\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
        font_m = re.search(rf"const CoverageFont coverageFont{size} = \{{coveragePixels{size}, "
                           rf"coverageGlyphs{size}, (\d+), (-?\d+), (-?\d+)\}};", text)
        pixels = bytes(int(v, 16) for v in re.findall(r"0x([0-9a-fA-F]{2})", pixels_m.group(1)))
        records = [list(map(int, r.split(","))) for r in re.findall(r"\{([^{}]+)\}", glyphs_m.group(1))]
        # Each glyph's runs go from its offset to the next larger offset.
        offsets = sorted({r[0] for r in records} | {len(pixels)})
        end_of = {o: offsets[i + 1] for i, o in enumerate(offsets[:-1])}
        new_pixels, new_records = bytearray(), []
        for offset, code, w, h, adv, left, top in records:
            if code not in KEEP:
                continue
            start = len(new_pixels)
            if w and h:
                new_pixels += pixels[offset:end_of[offset]]
            new_records.append((start, code, w, h, adv, left, top))
        text = text.replace(pixels_m.group(0), f"const uint8_t coveragePixels{size}[] PROGMEM = {{\n"
                            + "\n".join("  " + ", ".join(f"0x{b:02x}" for b in new_pixels[i:i + 16]) + ","
                                        for i in range(0, len(new_pixels), 16)) + "\n};")
        text = text.replace(glyphs_m.group(0), f"const CoverageGlyph coverageGlyphs{size}[] PROGMEM = {{\n"
                            + "\n".join("  {" + ", ".join(map(str, r)) + "}," for r in new_records) + "\n};")
        text = text.replace(font_m.group(0), f"const CoverageFont coverageFont{size} = {{coveragePixels{size}, "
                            f"coverageGlyphs{size}, {len(new_records)}, {font_m.group(2)}, {font_m.group(3)}}};")
    return text


GLYPH = re.compile(r"\{\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(-?\d+),\s*(-?\d+)\s*\}, // U\+([0-9A-F]+)")


def trim_gfx(text, name):
    glyph_lines = [m for m in GLYPH.finditer(text)]
    kept = [m for m in glyph_lines if int(m.group(7), 16) <= GFX_LAST]
    last = kept[-1]
    end = int(last.group(1)) + (int(last.group(2)) * int(last.group(3)) + 7) // 8
    bitmaps_m = re.search(rf"const uint8_t {name}Bitmaps\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
    bitmap = hex_bytes(bitmaps_m.group(1))[:end]
    glyphs_m = re.search(rf"const GFXglyph {name}Glyphs\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
    text = text.replace(bitmaps_m.group(0), f"const uint8_t {name}Bitmaps[] PROGMEM = {{\n{rows(bitmap)}\n}};")
    text = text.replace(glyphs_m.group(0), f"const GFXglyph {name}Glyphs[] PROGMEM = {{\n"
                        + "\n".join("  " + m.group(0) for m in kept) + "\n};")
    return re.sub(r"0x0020, 0x017F,", f"0x0020, 0x{GFX_LAST:04X},", text)


def main(source, target):
    source, target = Path(source), Path(target)
    target.mkdir(parents=True, exist_ok=True)
    smooth = trim_smooth((source / "InterTightSmooth.h").read_text())
    (target / "InterTightSmooth.h").write_text(smooth)
    spec = importlib.util.spec_from_file_location("index_smooth_fonts", SCRIPTS / "index_smooth_fonts.py")
    index = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(index)
    (target / "StaticSmoothFonts.inc").write_text(index.render_index(smooth, guarded=False, sizes=(13, 18, 24)))
    (target / "CoverageFonts.inc").write_text(trim_coverage((source / "CoverageFonts.inc").read_text()))
    for header in source.glob("InterTight*.h"):
        if header.name == "InterTightSmooth.h":
            continue
        (target / header.name).write_text(trim_gfx(header.read_text(), header.stem))
    for path in sorted(target.iterdir()):
        print(f"{path.name}: {path.stat().st_size} bytes of source")


if __name__ == "__main__":
    main(*sys.argv[1:3])
