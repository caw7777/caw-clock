# CAW Clock for the SD PRO with an ESP32-C2 board ("SDC2")

Newer SD PRO clocks have an ESP32-C2 (ESP8684, 26 MHz crystal, 4 MB flash)
instead of the ESP8266; pinout in `../notes/pinout-juzipi-sdc2.md`. This
folder builds CAW Clock for them, and the installer that puts it on a clock
still running its factory firmware.

## The firmware (`pio run` here)

The ESP8266 firmware's app is compiled as it is, from its own sources:
`../firmware/src/CawStandalone/caw_standalone.cpp` (settings page, rotation,
alerts, updates, recovery and safe mode), `CawFeedLite.cpp`, `CawPictures.cpp`
and `CawScreen.cpp`. The few lines that differ are marked `CAW_C2`.

- `src/port/`: the ESP8266 Arduino core's interfaces on ESP-IDF 5.5:
  `Arduino.h` (String, Print/Stream, ESP), `ESP8266WiFi`, `ESP8266WebServer`
  (ESP-IDF's HTTP server; each request is answered from the app's loop, as on
  the ESP8266), `LittleFS` (on the storage partition), `Updater` (OTA into the
  other slot), `WiFiClientSecureBearSSL` (esp-tls with the roots in
  `certs/caw_roots.pem`) and `TFT_eSPI` (the ST7789 panel: SPI2, SCLK 1,
  MOSI 2, DC 0, reset 3, backlight 5 active low).
- `src/c2/`: what is different on this board: start-up (`main_app.cpp`, with
  a fallback to the other slot after repeated crashed starts), the updater
  (`caw-clock-sdc2-<version>.bin` from the release), the crash record and the
  Wi-Fi/password settings (NVS; the factory firmware's saved Wi-Fi is taken
  over on the first start).
- `generated/fonts_caw`: the ESP8266 build's fonts, trimmed to the characters
  CAW Clock draws (`scripts/trim_fonts.py`). Copy them again when the fonts
  change.

Flash layout (`partitions.csv`): two 1.5 MB program slots and 960 KB of
storage. The factory layout (`partitions-factory.csv`) has 768 KB slots; the
installer changes it once (`src/relay_table.h`).

## The installer (`installer/`, `pio run` there)

For clocks on their factory firmware: its update page takes a file named
`SDC2...` of at most 768 KB. The installer joins the Wi-Fi the factory
firmware saved (or opens a setup network), downloads
`caw-clock-sdc2-<version>.bin` of its release into the area that becomes the
second program slot, checks its SHA-256, and only then writes CAW Clock's
partition table and starts it. Build with `CAW_INSTALLER_VERSION` and
`CAW_INSTALLER_SHA256` set (the release workflow does).

## Build

pioarduino platform (ESP-IDF 5.5), which needs PlatformIO Core 6.2: see the
top-level README. Build the ESP8266 firmware first (its ArduinoJson is reused).
CMake reads the version (`MINI_DISPLAY_BUILD_VERSION`) when it configures:
delete `.pio/build` after changing it.

## Tests

- `test/webserver_test/run.sh`: the web server stand-in (arguments, uploads,
  sign-in, chunked pages) on a PC, with a fake ESP-IDF server.
- `test/relay_table_test.sh`: the re-layout table, checked with ESP-IDF's own
  partition tool (needs `IDF_PATH`).
