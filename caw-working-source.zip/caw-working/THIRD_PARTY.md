# Third-party software

Our code is MIT licensed. This does not replace dependency licenses.

| Component | License | Distributed notices |
| --- | --- | --- |
| Lit, lit-html, lit-element, reactive-element | BSD-3-Clause | `custom_components/mini_display/frontend/Lit-LICENSE.txt` |
| Inter Tight and generated font assets | SIL OFL 1.1 | `firmware/src/fonts/OFL.txt` and `custom_components/mini_display/frontend/InterTight-OFL.txt` |
| Bangers (screen title, drawn into `CawTitle.h`) | SIL OFL 1.1 | `assets/fonts/Bangers-OFL.txt` |
| Outfit (CAW firmware text, `firmware/caw_fonts`) | SIL OFL 1.1 | `assets/fonts/Outfit-OFL.txt` |
| ArduinoJson | MIT | Dependency source archive |
| TFT_eSPI and bundled Adafruit fonts | MIT / BSD, see individual files | Dependency source archive |
| Adafruit GFX, BusIO and Arduino_GFX | See individual component licenses | Dependency source archive |
| ESP8266 Arduino core | LGPL-2.1 and component-specific licenses | Dependency source archive |
| ESP32 Arduino core, ESP-IDF and SDK libraries | Component-specific licenses | Dependency source archive |

CAW Clock releases attach, next to `caw-clock-<version>.bin`:

- `caw-clock-<version>-source.tar.gz`: the project sources used for the build;
- `caw-clock-<version>-relink.tar.gz`: the installed PlatformIO platform and
  frameworks exactly as built (ESP8266 Arduino core and SDK, with their
  licences and our patch below), the library sources, and the compiled
  objects/archives of the `sdpro_caw_standalone` build;
- `LICENSE` and this file.

SDK packages may include vendor-provided binary components; their own terms
still apply. This is not a claim that every SDK component is MIT.

## Rebuilding and relinking

Extract the source and relink archives into the same folder, then follow
`RELINKING.md` from the relink archive: install Python 3.12 and PlatformIO
6.1.19, set `PLATFORMIO_CORE_DIR` to the archive's `.platformio`, change the
framework or library sources, and run `pio run -e sdpro_caw_standalone` from
`firmware/`. The archive records toolchain versions in their package metadata,
without bundling compiler executables. Existing objects and static archives
are retained for relinking. Install the resulting image from the clock's
settings page (System, Firmware). No vendor signing key is required.

Our ESP8266 HTTP parser modification transfers the request body with move
semantics rather than copying it. It is applied by
`firmware/scripts/patch_esp8266_http.py`; the relink archive contains the patched source.
The affected core remains under its original license. Reverse engineering for
debugging modifications to LGPL-covered components is not restricted by this
project.

When redistributing firmware, include the matching source archive and preserve
its license/copyright files. When distributing the HA integration, retain both
license files in its `frontend` directory. User-uploaded fonts and images are not
relicensed by this project.

## Chain logos (CAW firmware)

`assets/chain-icons/*.png` (Cronos, Solana, Base, Robinhood) are DexScreener's
chain icons (`dd.dexscreener.com/ds-data/chains/<chain>.png`). The logos are
trademarks of their respective owners and are shown only to identify which
chain's CAW market is on screen. `firmware/scripts/caw_chain_icons.py` turns
them into `firmware/src/CawStandalone/CawChainIcons.h`.
