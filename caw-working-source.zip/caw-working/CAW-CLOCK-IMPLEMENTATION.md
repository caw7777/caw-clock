# CAW Clock – standalone firmware variant

This is a separate experimental firmware profile for the JUZIPi SD PRO (ESP8266 ESP-12F, 4 MB flash, 240 × 240 ST7789). The normal `sdpro` profile remains separate.

## Intended user experience

1. On first boot, the clock starts a protected Wi-Fi network named `CAW-Clock-Setup-XXXXXX`.
2. The setup password is shown on the clock screen.
3. Connect a phone to that Wi-Fi network and open `http://192.168.4.1`.
4. Enter the home Wi-Fi details, choose the display mode and set a clock password (8-32 characters). The clock saves the settings and restarts.
5. In CAW mode the clock obtains CAW market data itself and renders the CAW dashboard. It does not require Home Assistant, a local server, an app, or a user account.

Sign in to `http://caw-clock.local` (or `https://` once HTTPS is enabled under Security) as `admin` with the clock password to change settings later. Home Assistant uses the same credentials. Direct OTA updates are disabled in this product profile; panel updates require the clock password. Recovery setup remains available through the setup Wi-Fi page.

## Display modes

- **CAW market clock** (default): `/caw-dashboard.json`, DexScreener feed running.
- **Home Assistant dashboard**: `/dashboard.json`, pushed by the Home Assistant integration; the DexScreener feed does not run.

The mode is stored as `displayMode` in the display settings and can be changed on the panel's Display page or with `PUT /api/v1/display {"displayMode": "caw" | "homeassistant"}`. Each mode keeps its own dashboard, so switching never overwrites the other. `GET`/`PUT /api/v1/dashboard` always address the Home Assistant dashboard (`/dashboard.json`); in CAW mode `PUT` returns 409 and changes nothing, because validating an upload would replace the CAW page metadata and chart history. The CAW layout is built in. Recovery never disables API authentication in this profile. In CAW mode `PATCH /api/v1/data` and `PUT /api/v1/dashboard` are answered with 409 before their body is read, so a still-paired Home Assistant integration costs no heap; disable or remove the integration while the clock is in CAW mode.

## Memory

The ESP8266 has about 33 KB of heap after static data. The CAW page needs about 7 KB for its JSON plus the compiled scene and drawing buffers, and the DexScreener TLS fetch needs 24 KB (36 KB if the server does not accept small TLS fragments). Before each fetch the feed releases the renderer's caches; the screen is rebuilt afterwards. `/api/v1/status` reports `cawFeed` (`ok`, `low_memory`, `tls_or_connection`, `http_status`, `json`, ...), `cawFeedFreeHeapBytes`, `cawFeedMaxFreeBlockBytes` and `cawFeedSmallTlsFragments` from the last attempt. A change restarts the clock. The built-in CAW layout is reinstalled only when `kCawLayoutVersion` changes.

## Market feed

The firmware requests the Cronos CAW/WCRO pair directly from DexScreener:

`https://api.dexscreener.com/latest/dex/pairs/cronos/0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c`

- Polling interval: 5 minutes.
- Retry after a failed request: 1 minute.
- Display fields: USD price, 1-hour and 24-hour percentage change, liquidity, 24-hour volume, FDV (retained internally as the market-cap fallback), and market cap.
- USD price is expanded to ordinary decimal notation without floating-point formatting, then shown in DexScreener's compact form: `$0.0₈5191` means 0.000000005191 (the subscript counts every zero after the decimal point; four significant digits, truncated). Prices with fewer than two leading zeros keep four significant digits (`$0.01234`).
- Market cap falls back to FDV if DexScreener omits the market-cap field.
- Last successful values are cached in LittleFS; the status label changes to `STALE` when the API/Wi-Fi is unavailable.
- The ticker shows `▶ caw  $0.0₈5191` and the 1H/24H changes. Percentages, the chart and the ticker ring are green on up days and red on down days (24-hour change); the ring is grey while data is stale.
- The dashboard includes a 48-point line graph with 30-minute buckets. It samples the fetched price every five minutes locally, without Home Assistant or another server. The graph starts filling on first startup and needs 24 hours of successful polling for a complete day of data. Graph history is currently RAM-only and resets after a reboot; persistence is a remaining improvement.

HTTPS uses BearSSL certificate validation with NTP-synchronized time. The current source includes the GTS Root R4 trust anchor because the parent DexScreener domain has been observed using a WE1 → GTS Root R4 chain. The `api.dexscreener.com` hostname and ESP8266 handshake still require direct target-device verification before production use.

## Screen

`scripts/caw_dashboard.py` generates the layout embedded in `main.cpp` (18 cards, the per-page maximum; page JSON under the 6 KiB loader limit). `scripts/preview_caw_layout.py` renders an approximate preview from the generated fonts.

Subscript digits (U+2080-U+2089), the Wi-Fi icons (U+E000/U+E001) and the play marker (U+25B6) are drawn from the unused C1 slots of the built-in fonts. `scripts/caw_font_assets.py` adds them to CAW-only copies of the fonts in the build directory and maps the code points in both UTF-8 decoders. Those copies also drop Latin Extended-A letters that the anti-aliased fonts never contained.

## Size and security

The OTA slot is 1,044,464 bytes and the whole `firmware.bin` (including eboot) must fit. The CAW image was 1,046,624 bytes; it now builds at about 1,016,000 bytes. The savings come from:

- the on-device HTTPS server: TLS 1.2 only with ECDHE-ECDSA ChaCha20-Poly1305 / AES-128-GCM (`scripts/patch_bearssl_server.py`). TLS 1.0/1.1, 3DES, CBC-SHA1, static ECDH and CCM are no longer offered;
- one constant-time P-256 implementation (`br_ec_prime_i15`) for TLS, certificate generation and the OTA signature verifier instead of two;
- the 48 px crow badge stored at its display size, the glyph subsets above, one instance of the text drawing template, and the DecimalParser instead of newlib `strtod`.

The DexScreener client profile, certificate validation, the OTA limit and the partition layout are unchanged.

## Firmware update security

- Signed OTA is **not** enabled (`ARDUINO_SIGNING` 0, no `public.key`). The signature verifier is linked but never called. `Update.end()` checks only the image header (magic byte 0xE9 and flash configuration); no MD5 or signature is checked.
- What stops an unauthorised image is HTTP authentication:
  - `POST /api/v1/firmware` (the panel's Firmware page) requires the clock password (Digest, or Bearer for the API). In setup or recovery mode it returns 403.
  - `POST /update` (direct OTA) is disabled by the CAW setup (`directOtaEnabled: false`) and returns 403. It is open only on an unconfigured clock in setup mode, whose access point is WPA2-protected with the password shown on the screen.
  - The CAW build never clears the clock password in recovery mode, so a Wi-Fi outage cannot leave the panel unauthenticated.
- Credentials and firmware travel over plain HTTP unless HTTPS is enabled on the Security page. Anyone who knows the clock password, or captures a Bearer token on an unencrypted LAN, can install any image.

## Installing and rolling back

The CAW image (~1 MB) does not fit the stock updater (`/update_ota`); see the README warning. Supported routes:

1. **Stock firmware -> CAW:** install the upstream bootstrap (`SDP-HomeAssistant-MiniDisplay-Bootstrap-<VERSION>.bin`) through the stock update page. It installs a pinned, SHA-256-verified `sdpro` release. Finish its setup, then upload the CAW `firmware.bin` on its Firmware page. Alternatively, write the image at offset 0x0 over UART.
2. **CAW -> previous firmware (clock still on the LAN):** sign in to the panel, open Firmware and upload the previous `firmware.bin` (an `sdpro` release or an earlier CAW build). Any image up to 1,044,464 bytes fits: running CAW leaves 1,077,248 bytes of OTA space.
3. **Clock cannot join Wi-Fi:** after the configured retries it opens `CAW-Clock-Setup-XXXXXX` (WPA2 password on the screen). The setup page can change Wi-Fi and the clock password. Then use route 2. Firmware upload is refused in recovery mode.
4. **Clock crashes or never reaches Wi-Fi or recovery:** there is no automatic rollback or crash-loop fallback. Recover over UART with esptool: hold GPIO0 low at reset (GPIO0 is also the display DC line) and write a known-good image. The UART pads are not documented in `notes/`. Take a full flash backup first (`esptool.py read_flash 0 0x400000 backup.bin`).

When an upload is interrupted or rejected, the running firmware keeps working ("Update failed"). After a successful upload the bootloader copies the new image on restart; the copy command is kept in RTC memory, so **do not cut power during that restart**.

## Files changed or added

- `firmware/platformio.ini`: adds the separate `sdpro_caw` environment.
- `Makefile`: adds `make build-caw`.
- `firmware/src/FeatureFlags.h`: adds the CAW feature flag, off by default.
- `firmware/src/DashboardValues.h`: expands value storage only for the CAW build to hold the ticker.
- `firmware/src/CawMarketFeed.h/.cpp`: direct HTTPS feed, formatting, cache, 24-hour change, and ticker.
- `firmware/src/CawClockAssets.h`: embedded compact crow-with-knife image.
- `firmware/src/main.cpp`: first-run provisioning page, local dashboard installation, setup-network branding, and feed lifecycle.
- `firmware/src/StartupScreens.cpp`: CAW Clock boot and setup branding.
- `assets/`: original supplied photo and compact MDI image.

The CAW layout is installed into its own file (`/caw-dashboard.json`); an existing Home Assistant dashboard is left in place and is used in Home Assistant mode.

## Build

`make build-caw` builds the web panel with `MINI_DISPLAY_FEATURE_TLS=1` and `MINI_DISPLAY_FEATURE_CAW=1` so the HTTPS and display-mode controls are present.

Requires the repository's documented toolchain: Python 3, Node.js 24, npm, Make, PlatformIO Core 6.1.19, and `zopfli==0.4.1`.

```sh
make build-caw
```

Expected OTA image:

`firmware/.pio/build/sdpro_caw/firmware.bin`

## Validation status

The embedded dashboard JSON has been checked against `dashboard/dashboard.schema.json`. The chart renderer is wired to the local CAW price sampler, and the graph colour follows the 24-hour change (red for negative, green for positive). The Wi-Fi indicator is driven by the live Wi-Fi connection state. The bottom accent line follows the same 24-hour colour state. The crow asset has been checked as a valid MDI2 72 × 72 RGB565/RLE file and its FNV-1a asset ID has been verified. The image-codec tests pass.

**Superseded:** the CAW firmware now compiles with PlatformIO 6.1.19 (`sdpro_caw` and `sdpro` both build without warnings; the native tests pass). The paragraph below is the earlier status. It has still **not** been tested on hardware: verify the DexScreener HTTPS request, the screen layout, HTTPS to the panel and both display modes on the clock before relying on it.

Earlier: a complete firmware compile and an ESP8266 hardware test had **not** been completed in that environment: PlatformIO is not installed, and the uploaded web dependencies are incomplete (the Prettier and TypeScript type packages are unavailable). The new source has passed dashboard-schema validation, the image-codec tests, embedded-asset verification, and static wiring/conditional checks. Therefore this is a source implementation, not a verified flashable `.bin` yet. Do not flash it to a working clock until the full build succeeds and the HTTPS request has been tested on the JUZIPi SD PRO.
