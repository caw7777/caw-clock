#pragma once

// Release checking for the CAW app's "Check for updates": the version rules,
// the release's SHA256SUMS.txt, and the HTTP headers of GitHub's download
// redirects. Kept free of hardware calls so the native tests cover them.

#include <cstddef>
#include <cstdint>
#include <cstring>

#include "CawHttp.h"

// "0.4.0" or "v0.4.0" -> {0, 4, 0}. Anything after the third number (for
// example "-rc1") is ignored. False when there are not three numbers.
inline bool cawParseVersion(const char *text, uint16_t out[3]) {
  if (!text) return false;
  if (*text == 'v' || *text == 'V') ++text;
  for (uint8_t part = 0; part < 3; ++part) {
    if (*text < '0' || *text > '9') return false;
    uint32_t value = 0;
    while (*text >= '0' && *text <= '9') {
      value = value * 10 + static_cast<uint32_t>(*text - '0');
      if (value > 65535) return false;
      ++text;
    }
    out[part] = static_cast<uint16_t>(value);
    if (part < 2) {
      if (*text != '.') return false;
      ++text;
    }
  }
  return true;
}

enum class CawVersionOrder : uint8_t { Older, Same, Newer, Unknown };

// True when the version has something after its three numbers ("0.7.0-rc2").
inline bool cawVersionHasSuffix(const char *text) {
  if (!text) return false;
  if (*text == 'v' || *text == 'V') ++text;
  while ((*text >= '0' && *text <= '9') || *text == '.') ++text;
  return *text != '\0';
}

// How `latest` compares with the installed `current`. Unknown when either is
// not a release version (test builds are "caw-test-<commit>"). A test build
// of a version ("0.7.0-rc2") is older than the release itself ("0.7.0"), so
// clocks on a release candidate are offered the release (0.7.0-rc clocks,
// built before this rule, were not).
inline CawVersionOrder cawCompareVersions(const char *latest, const char *current) {
  uint16_t a[3], b[3];
  if (!cawParseVersion(latest, a) || !cawParseVersion(current, b)) return CawVersionOrder::Unknown;
  for (uint8_t part = 0; part < 3; ++part) {
    if (a[part] > b[part]) return CawVersionOrder::Newer;
    if (a[part] < b[part]) return CawVersionOrder::Older;
  }
  const bool latestTest = cawVersionHasSuffix(latest), currentTest = cawVersionHasSuffix(current);
  if (currentTest && !latestTest) return CawVersionOrder::Newer;
  if (latestTest && !currentTest) return CawVersionOrder::Older;
  return CawVersionOrder::Same;
}

struct CawReleaseInfo {
  char version[16];   // "0.4.1"
  char file[48];      // "caw-clock-0.4.1.bin"
  char sha256[65];    // lowercase hex
};

namespace caw_release_detail {
inline bool isHex(char c) {
  return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
}
inline char lower(char c) { return (c >= 'A' && c <= 'Z') ? static_cast<char>(c + 32) : c; }
}  // namespace caw_release_detail

// Finds the firmware line of SHA256SUMS.txt ("<64 hex>  caw-clock-X.Y.Z.bin";
// sha256sum may mark binary mode with '*') and reads its version from the
// file name. The source and relink archives are skipped. False when there is
// no such line or the version is not X.Y.Z.
// `kPrefix`: "caw-clock-" for the ESP8266 clocks ("caw-clock-0.6.0.bin"),
// "caw-clock-sdc2-" for the ESP32-C2 ones; each skips the other's files (a
// version must be plain digits and dots).
#if CAW_C2
#define CAW_FIRMWARE_PREFIX "caw-clock-sdc2-"
#else
#define CAW_FIRMWARE_PREFIX "caw-clock-"
#endif
inline bool cawFindFirmwareInSums(const char *text, size_t length, CawReleaseInfo &out) {
  using namespace caw_release_detail;
  static const char kPrefix[] = CAW_FIRMWARE_PREFIX;
  static const char kSuffix[] = ".bin";
  size_t line = 0;
  while (line < length) {
    size_t end = line;
    while (end < length && text[end] != '\n') ++end;
    size_t lineEnd = end;
    if (lineEnd > line && text[lineEnd - 1] == '\r') --lineEnd;
    const size_t lineLength = lineEnd - line;
    const char *row = text + line;
    bool hashOk = lineLength > 66;
    for (size_t index = 0; hashOk && index < 64; ++index) hashOk = isHex(row[index]);
    if (hashOk && row[64] == ' ') {
      size_t name = 65;
      while (name < lineLength && (row[name] == ' ' || row[name] == '*')) ++name;
      const size_t nameLength = lineLength - name;
      const size_t prefix = sizeof(kPrefix) - 1, suffix = sizeof(kSuffix) - 1;
      if (nameLength > prefix + suffix && nameLength < sizeof(out.file) &&
          std::strncmp(row + name, kPrefix, prefix) == 0 &&
          std::strncmp(row + name + nameLength - suffix, kSuffix, suffix) == 0) {
        const size_t versionLength = nameLength - prefix - suffix;
        if (versionLength < sizeof(out.version)) {
          CawReleaseInfo info{};
          std::memcpy(info.version, row + name + prefix, versionLength);
          info.version[versionLength] = '\0';
          uint16_t parts[3];
          bool plain = cawParseVersion(info.version, parts);
          // Only "X.Y.Z" itself: "caw-clock-0.4.1-source.tar.gz" never ends in
          // .bin, but be strict anyway.
          for (size_t index = 0; plain && index < versionLength; ++index)
            plain = (info.version[index] >= '0' && info.version[index] <= '9') ||
                    info.version[index] == '.';
          if (plain) {
            std::memcpy(info.file, row + name, nameLength);
            info.file[nameLength] = '\0';
            for (size_t index = 0; index < 64; ++index) info.sha256[index] = lower(row[index]);
            info.sha256[64] = '\0';
            out = info;
            return true;
          }
        }
      }
    }
    line = end + 1;
  }
  return false;
}

// Splits "https://host/path?query" into host and path ("/path?query").
// False for anything that is not an https URL with a host.
inline bool cawSplitHttpsUrl(const char *url, char *host, size_t hostSize, const char **path) {
  static const char kScheme[] = "https://";
  if (!url || std::strncmp(url, kScheme, sizeof(kScheme) - 1) != 0) return false;
  const char *start = url + sizeof(kScheme) - 1;
  const char *end = start;
  while (*end && *end != '/' && *end != '?' && *end != ':') ++end;
  const size_t length = static_cast<size_t>(end - start);
  if (length == 0 || length >= hostSize || *end == ':') return false;  // no ports
  std::memcpy(host, start, length);
  host[length] = '\0';
  *path = *end ? end : "/";
  return true;
}

namespace caw_release_detail {
// Case-insensitive "name:" at the start of a header line.
inline bool headerIs(const char *line, size_t length, const char *name) {
  size_t index = 0;
  for (; name[index]; ++index) {
    if (index >= length || lower(line[index]) != name[index]) return false;
  }
  return index < length && line[index] == ':';
}
inline const char *headerValue(const char *line, size_t length, size_t nameLength,
                               size_t &valueLength) {
  size_t start = nameLength + 1;
  while (start < length && (line[start] == ' ' || line[start] == '\t')) ++start;
  valueLength = length - start;
  return line + start;
}
}  // namespace caw_release_detail

// Consumes the header lines up to and including the blank line, keeping the
// Location header (redirects; GitHub's asset URLs are ~1 KB) and
// Content-Length. `location` is empty when there is none or it does not fit;
// `contentLength` is -1 when absent. False when the stream ends first or the
// headers are implausibly long. `line` is scratch space for one header line
// (on the device a heap buffer: the main stack is only 4 KB); longer lines
// (cookies, policies) are skipped, not kept.
template <typename Read>
bool cawReadHttpHeaders(Read read, char *line, size_t lineSize, char *location,
                        size_t locationSize, int32_t &contentLength) {
  using namespace caw_release_detail;
  if (locationSize) location[0] = '\0';
  contentLength = -1;
  size_t length = 0;
  bool overflow = false;
  for (size_t count = 0; count < kCawHttpMaxHeaderBytes; ++count) {
    const int c = read();
    if (c < 0) return false;
    if (c == '\r') continue;
    if (c != '\n') {
      if (length < lineSize) line[length++] = static_cast<char>(c);
      else overflow = true;
      continue;
    }
    if (length == 0) return true;  // blank line: end of headers
    size_t valueLength = 0;
    if (!overflow && headerIs(line, length, "location")) {
      const char *value = headerValue(line, length, 8, valueLength);
      if (valueLength < locationSize) {
        std::memcpy(location, value, valueLength);
        location[valueLength] = '\0';
      }
    } else if (!overflow && headerIs(line, length, "content-length")) {
      const char *value = headerValue(line, length, 14, valueLength);
      int64_t number = 0;
      bool ok = valueLength > 0 && valueLength <= 10;
      for (size_t index = 0; ok && index < valueLength; ++index) {
        ok = value[index] >= '0' && value[index] <= '9';
        number = number * 10 + (value[index] - '0');
      }
      contentLength = ok && number <= 0x7FFFFFFF ? static_cast<int32_t>(number) : -1;
    }
    length = 0;
    overflow = false;
  }
  return false;
}

// As cawReadHttpHeaders, but with one buffer: the Location value is kept at
// its start and the rest is scratch space for the following header lines
// (one buffer instead of two saves memory while the TLS buffers are held).
// `buffer` holds the Location (or "") afterwards. Lines that do not fit are
// skipped; a Location that does not fit is dropped.
template <typename Read>
bool cawReadHttpHeadersInPlace(Read read, char *buffer, size_t size, int32_t &contentLength) {
  using namespace caw_release_detail;
  contentLength = -1;
  if (size < 2) return false;
  size_t keep = 0;  // bytes at the start holding the Location and its NUL
  size_t length = 0;
  bool overflow = false;
  for (size_t count = 0; count < kCawHttpMaxHeaderBytes; ++count) {
    const int c = read();
    if (c < 0) return false;
    if (c == '\r') continue;
    char *line = buffer + keep;
    const size_t room = size - keep;
    if (c != '\n') {
      if (length < room) line[length++] = static_cast<char>(c);
      else overflow = true;
      continue;
    }
    if (length == 0) {  // blank line: end of headers
      if (keep == 0) buffer[0] = '\0';
      return true;
    }
    size_t valueLength = 0;
    if (!overflow && headerIs(line, length, "location")) {
      const char *value = headerValue(line, length, 8, valueLength);
      std::memmove(buffer, value, valueLength);  // to the start (may overlap)
      buffer[valueLength] = '\0';
      keep = valueLength + 1;
    } else if (!overflow && headerIs(line, length, "content-length")) {
      const char *value = headerValue(line, length, 14, valueLength);
      int64_t number = 0;
      bool ok = valueLength > 0 && valueLength <= 10;
      for (size_t index = 0; ok && index < valueLength; ++index) {
        ok = value[index] >= '0' && value[index] <= '9';
        number = number * 10 + (value[index] - '0');
      }
      contentLength = ok && number <= 0x7FFFFFFF ? static_cast<int32_t>(number) : -1;
    }
    length = 0;
    overflow = false;
  }
  return false;
}

// GitHub answers ".../releases/latest" with a redirect to the latest
// release's page, "https://github.com/<repository>/releases/tag/v0.4.1".
// Reads the version from that address; false when it is anything else (other
// host or repository, not X.Y.Z).
inline bool cawVersionFromTagUrl(const char *url, const char *repository, char *version,
                                 size_t versionSize) {
  static const char kHost[] = "https://github.com/";
  static const char kTag[] = "/releases/tag/v";
  if (!url || std::strncmp(url, kHost, sizeof(kHost) - 1) != 0) return false;
  url += sizeof(kHost) - 1;
  const size_t repositoryLength = std::strlen(repository);
  if (std::strncmp(url, repository, repositoryLength) != 0) return false;
  url += repositoryLength;
  if (std::strncmp(url, kTag, sizeof(kTag) - 1) != 0) return false;
  url += sizeof(kTag) - 1;
  size_t length = 0;
  while (url[length] && url[length] != '/' && url[length] != '?' && url[length] != '#') {
    const char c = url[length];
    if (!((c >= '0' && c <= '9') || c == '.')) return false;  // X.Y.Z only
    ++length;
  }
  if (length == 0 || length >= versionSize || url[length]) return false;
  std::memcpy(version, url, length);
  version[length] = '\0';
  uint16_t parts[3];
  return cawParseVersion(version, parts);
}

// Lowercase hex of a 32-byte digest, for comparing with SHA256SUMS.
inline void cawHex32(const uint8_t digest[32], char out[65]) {
  static const char kDigits[] = "0123456789abcdef";
  for (uint8_t index = 0; index < 32; ++index) {
    out[index * 2] = kDigits[digest[index] >> 4];
    out[index * 2 + 1] = kDigits[digest[index] & 0x0F];
  }
  out[64] = '\0';
}
