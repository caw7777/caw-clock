#pragma once

// Sends a web page in pieces while it is being built, instead of building it
// whole in one String first. The CAW settings and memes pages are 13-15 KB:
// as one String that needs a block of that size in the heap, and while the
// String grows past what was reserved, briefly the old and the new block
// together. Here at most about one piece (~1.4 KB) is held. The bytes the
// browser receives are the same.
//
// `Sink` sends: begin() starts a response of unknown length (HTTP/1.1
// chunked transfer), chunk() sends a piece, whole() sends a page that never
// grew past one piece as a normal response. Adding works exactly as on a
// String (numbers become decimal text, a char is a character): every += is
// passed to one.

#include <stddef.h>

template <typename Sink, typename Text>
class CawPageWriter {
 public:
  explicit CawPageWriter(Sink &sink, size_t pieceBytes = 1400) : sink_(sink), piece_(pieceBytes) {
    buffer_.reserve(piece_ + 160);
  }
  CawPageWriter(const CawPageWriter &) = delete;
  CawPageWriter &operator=(const CawPageWriter &) = delete;

  template <typename Value>
  CawPageWriter &operator+=(const Value &value) {
    buffer_ += value;
    if (buffer_.length() >= piece_) flush();
    return *this;
  }

  // Sends what is left. Call once, after the last +=.
  void finish() {
    if (finished_) return;
    finished_ = true;
    if (!started_) {
      sink_.whole(buffer_);
      return;
    }
    if (buffer_.length()) sink_.chunk(buffer_);
  }

  bool started() const { return started_; }

 private:
  void flush() {
    if (!started_) {
      sink_.begin();
      started_ = true;
    }
    sink_.chunk(buffer_);
    buffer_.remove(0);  // keeps the reserved space
  }

  Sink &sink_;
  const size_t piece_;
  Text buffer_;
  bool started_ = false;
  bool finished_ = false;
};
