#pragma once

// Small scheduling rules of the CAW app, kept free of hardware calls so the
// native tests cover them.

#include <cstdint>

// True when `minute` (minutes after local midnight) is inside the window
// [start, end). The window may span midnight; start == end is "never".
inline bool nightWindowContains(uint16_t start, uint16_t end, uint16_t minute) {
  if (start == end) return false;
  return start < end ? minute >= start && minute < end : minute >= start || minute < end;
}

// Delay before the next attempt after `failures` consecutive failed fetches:
// base, 2x, 4x, ... capped at `maximum`, so an offline clock spends little
// time blocked in connection timeouts.
inline uint32_t retryDelayMs(uint8_t failures, uint32_t base, uint32_t maximum) {
  uint32_t delay = base;
  for (uint8_t step = 0; step < failures && delay < maximum; ++step) delay *= 2;
  return delay < maximum ? delay : maximum;
}

// True when `deadline`, a millis() value that is only ever set up to
// `maxAheadMs` into the future, has passed. Unlike a signed difference this
// stays true however long the deadline is overdue: a deadline that seems to
// lie further ahead than it can ever be set must have passed long ago (once
// in 49.7 days, for at most `maxAheadMs`, it reads as not passed yet).
inline bool deadlinePassed(uint32_t deadline, uint32_t nowMs, uint32_t maxAheadMs) {
  const uint32_t ahead = deadline - nowMs;  // wraps like millis()
  return ahead == 0 || ahead > maxAheadMs;
}

// The first price source gets another chance every this many successful fetches.
constexpr uint8_t kCawFirstSourceEvery = 6;

// The successful-fetch count kept for sourceOrder(): 0, 1, ... 5, 0, 1, ...
// It wraps instead of stopping at 255, which would have ended the retries of
// the first source after ~21 hours of running.
inline uint8_t nextFetchCount(uint8_t fetches) {
  return static_cast<uint8_t>((fetches + 1) % kCawFirstSourceEvery);
}

// Order in which a chain's price sources are tried. Normally the list order
// (DexScreener, DexScreener full-size, GeckoTerminal); once a later source is
// the one that works (e.g. a pool DexScreener no longer serves), it goes first,
// except on every sixth fetch when the first source gets another chance.
// Writes `count` indexes into `order`; returns count.
inline uint8_t sourceOrder(uint8_t preferred, uint8_t fetches, uint8_t count, uint8_t *order) {
  const bool preferredFirst =
      preferred != 0 && preferred < count && fetches % kCawFirstSourceEvery != 0;
  uint8_t position = 0;
  if (preferredFirst) order[position++] = preferred;
  for (uint8_t index = 0; index < count; ++index)
    if (!preferredFirst || index != preferred) order[position++] = index;
  return position;
}

