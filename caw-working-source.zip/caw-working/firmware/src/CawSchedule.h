#pragma once

// Small scheduling rules of the CAW app, kept free of hardware calls so the
// native tests cover them.

#include <cstdint>

// True when `minute` (minutes after local midnight) is inside the window
// [start, end). The window may span midnight; start == end is "never".
inline bool nightWindowContains(uint16_t start, uint16_t end, uint16_t minute) {
  if (start == end) return false;
  return start < end ? minute >= start && minute < end : minute >= start || minute < end;
}

// Delay before the next attempt after `failures` consecutive failed fetches:
// base, 2x, 4x, ... capped at `maximum`, so an offline clock spends little
// time blocked in connection timeouts.
inline uint32_t retryDelayMs(uint8_t failures, uint32_t base, uint32_t maximum) {
  uint32_t delay = base;
  for (uint8_t step = 0; step < failures && delay < maximum; ++step) delay *= 2;
  return delay < maximum ? delay : maximum;
}

// Order in which a chain's price sources are tried. Normally the list order
// (DexScreener, DexScreener full-size, GeckoTerminal); once a later source is
// the one that works (e.g. a pool DexScreener no longer serves), it goes first,
// except on every sixth fetch when the first source gets another chance.
// Writes `count` indexes into `order`; returns count.
inline uint8_t sourceOrder(uint8_t preferred, uint8_t fetches, uint8_t count, uint8_t *order) {
  const bool preferredFirst = preferred != 0 && preferred < count && fetches % 6 != 0;
  uint8_t position = 0;
  if (preferredFirst) order[position++] = preferred;
  for (uint8_t index = 0; index < count; ++index)
    if (!preferredFirst || index != preferred) order[position++] = index;
  return position;
}

