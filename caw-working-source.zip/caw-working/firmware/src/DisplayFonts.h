#pragma once

#include "StaticSmoothFont.h"
#include "UserFonts.h"

const GFXfont *builtInFontFor(const char *family, uint8_t size);
RenderFont renderFontFor(const char *family, uint8_t size);
RenderFont compactCardTitleFont();
bool isBuiltInCardTitleFamily(const char *family);
StaticSmoothFont notificationTitleFont();
StaticSmoothFont notificationBodyFont();

#if CAW_DUAL
// The CAW app's fonts, served from this file so the CAW + Home Assistant
// firmware links one copy (the font headers define the data per file).
const uint8_t *cawSmoothFontData(uint8_t size);  // 13, 18 or 24 px
const GFXfont *cawBoldFont36();
#endif
