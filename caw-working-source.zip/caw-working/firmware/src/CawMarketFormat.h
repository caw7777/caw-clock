#pragma once

// Market-value formatting shared by the CAW firmware builds. Host-testable:
// no Arduino dependencies beyond ArduinoJson and the decimal parser.
#include <ArduinoJson.h>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include "DecimalParser.h"

#ifndef ARDUINO
#include <string.h>
inline size_t cawStrlcpy(char *destination, const char *source, size_t capacity) {
  const size_t length = std::strlen(source);
  if (capacity) {
    const size_t count = length < capacity - 1 ? length : capacity - 1;
    std::memcpy(destination, source, count);
    destination[count] = '\0';
  }
  return length;
}
#define strlcpy cawStrlcpy
#endif

// DexScreener sends numbers; GeckoTerminal sends them as decimal strings.
// Accept both without newlib's strtod (see AGENTS.md).
inline bool cawNumber(JsonVariantConst source, double &value) {
  if (source.is<double>()) { value = source.as<double>(); return true; }
  if (source.is<const char *>()) {
    float parsed = 0.0F;
    if (!parseDecimalFloat(source.as<const char *>(), parsed)) return false;
    value = parsed;
    return true;
  }
  return false;
}

// DexScreener normally returns priceUsd as a decimal string, but very small
// values may be represented in exponent notation. Expand that notation to a
// plain decimal string so the clock never rounds away leading zeroes.
inline bool copyPrice(const char *source, char *destination, size_t capacity) {
  if (!source || !source[0] || capacity < 4) return false;
  char digits[40]{};
  size_t digitCount = 0;
  int decimalPosition = 0;
  bool decimalSeen = false;
  bool digitSeen = false;
  const char *cursor = source;
  if (*cursor == '+') ++cursor;
  if (*cursor == '-') return false;
  while (*cursor && *cursor != 'e' && *cursor != 'E') {
    if (*cursor >= '0' && *cursor <= '9') {
      if (digitCount >= sizeof(digits) - 1) {
        // GeckoTerminal sends up to ~70 decimals (e.g. Solana pools); digits
        // past the 39th are far below display precision, so drop them. Too
        // many integer digits is still an error.
        if (!decimalSeen) return false;
        ++cursor;
        continue;
      }
      digits[digitCount++] = *cursor;
      if (!decimalSeen) ++decimalPosition;
      digitSeen = true;
    } else if (*cursor == '.' && !decimalSeen) {
      decimalSeen = true;
    } else {
      return false;
    }
    ++cursor;
  }
  if (!digitSeen) return false;
  int exponent = 0;
  if (*cursor == 'e' || *cursor == 'E') {
    ++cursor;
    bool negativeExponent = false;
    if (*cursor == '+' || *cursor == '-') {
      negativeExponent = *cursor == '-';
      ++cursor;
    }
    if (!*cursor) return false;
    while (*cursor) {
      if (*cursor < '0' || *cursor > '9' || exponent > 30) return false;
      exponent = exponent * 10 + (*cursor - '0');
      ++cursor;
    }
    if (exponent > 30) return false;
    if (negativeExponent) exponent = -exponent;
  }
  decimalPosition += exponent;

  char plain[64]{};
  size_t output = 0;
  if (decimalPosition <= 0) {
    plain[output++] = '0';
    plain[output++] = '.';
    for (int zeros = 0; zeros < -decimalPosition; ++zeros) {
      if (output >= sizeof(plain) - 1) return false;
      plain[output++] = '0';
    }
    for (size_t index = 0; index < digitCount; ++index) {
      if (output >= sizeof(plain) - 1) return false;
      plain[output++] = digits[index];
    }
  } else if (static_cast<size_t>(decimalPosition) >= digitCount) {
    for (size_t index = 0; index < digitCount; ++index) {
      if (output >= sizeof(plain) - 1) return false;
      plain[output++] = digits[index];
    }
    for (int zeros = 0; zeros < decimalPosition -
                                      static_cast<int>(digitCount); ++zeros) {
      if (output >= sizeof(plain) - 1) return false;
      plain[output++] = '0';
    }
  } else {
    for (int index = 0; index < decimalPosition; ++index)
      plain[output++] = digits[index];
    plain[output++] = '.';
    for (size_t index = decimalPosition; index < digitCount; ++index)
      plain[output++] = digits[index];
  }
  plain[output] = '\0';
  if (strchr(plain, '.') != nullptr) {
    while (output > 0 && plain[output - 1] == '0') plain[--output] = '\0';
    if (output > 0 && plain[output - 1] == '.') plain[--output] = '\0';
  }
  if (output + 2 > capacity) return false;
  destination[0] = '$';
  memcpy(destination + 1, plain, output + 1);
  return true;
}

// "+0.9%" / "-12.4%" from a percentage. False when out of range.
inline bool formatChangePercent(double value, char *destination, size_t capacity) {
  if (!std::isfinite(value) || std::fabs(value) > 999999.0) return false;
  // Integer formatting only: the firmware links newlib without float printf
  // (scripts/optimize_esp8266_link.py), where "%f" prints nothing.
  long long tenths = static_cast<long long>(std::llround(value * 10.0));
  const char sign = tenths < 0 ? '-' : '+';
  if (tenths < 0) tenths = -tenths;
  snprintf(destination, capacity, "%c%lld.%lld%%", sign, tenths / 10, tenths % 10);
  return destination[0] != '\0';
}

// A change field from the API (number or numeric string). Absent, it shows
// "+0.0%": DexScreener leaves out the 1-hour change of a pool with no trades
// in that hour (BSC), and no trades means no change (owner's choice, instead
// of "N/A"). The price alert reads it as no move.
inline bool format24hChange(JsonVariantConst source, char *destination,
                     size_t capacity) {
  double value = 0.0;
  if (!cawNumber(source, value)) {
    strlcpy(destination, "+0.0%", capacity);
    return true;
  }
  return formatChangePercent(value, destination, capacity);
}

inline bool compactUsd(JsonVariantConst source, char *destination,
                size_t capacity) {
  // Some DexScreener fields are nullable. A missing statistic should not
  // discard a valid price and the other market fields.
  if (source.isNull()) {
    strlcpy(destination, "N/A", capacity);
    return true;
  }
  double value = 0.0;
  if (!cawNumber(source, value)) return false;
  if (!std::isfinite(value) || value < 0.0 || value > 1.0e15) return false;

  if (value >= 1000000.0) {
    const uint64_t tenths =
        static_cast<uint64_t>((value + 50000.0) / 100000.0);
    snprintf(destination, capacity, "$%llu.%lluM",
             static_cast<unsigned long long>(tenths / 10),
             static_cast<unsigned long long>(tenths % 10));
  } else if (value >= 1000.0) {
    const uint64_t thousands =
        static_cast<uint64_t>((value + 500.0) / 1000.0);
    snprintf(destination, capacity, "$%lluK",
             static_cast<unsigned long long>(thousands));
  } else {
    const uint64_t dollars = static_cast<uint64_t>(value + 0.5);
    snprintf(destination, capacity, "$%llu",
             static_cast<unsigned long long>(dollars));
  }
  return destination[0] == '$';
}
