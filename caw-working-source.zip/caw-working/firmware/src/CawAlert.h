#pragma once

// Price alert of the CAW app: the price flashes when a chain's 1-hour change
// passes a threshold. Kept free of hardware calls so the native tests cover
// it.

#include <cmath>
#include <cstdint>

// The 1-hour change as the feeds format it ("+12.3%", "-0.4%", "0.0%"), as a
// number of percent; NaN for "--" or anything else that is not a number.
// Parsed by hand: strtof would pull ~10 KB of the C library into the image.
inline float cawParsePercent(const char *text) {
  if (!text) return NAN;
  bool negative = false;
  if (*text == '+' || *text == '-') negative = *text++ == '-';
  float value = 0.0F;
  bool digits = false;
  for (; *text >= '0' && *text <= '9'; ++text) {
    if (value < 1e6F) value = value * 10.0F + static_cast<float>(*text - '0');
    digits = true;
  }
  if (*text == '.') {
    float scale = 0.1F;
    for (++text; *text >= '0' && *text <= '9'; ++text, scale *= 0.1F) {
      value += scale * static_cast<float>(*text - '0');
      digits = true;
    }
  }
  if (!digits || (*text != '\0' && *text != '%')) return NAN;
  return negative ? -value : value;
}

struct CawMoveAlert {
  bool armed = true;     // false after an alert until the move settles
  bool up = false;       // direction of the last alert
  uint32_t until = 0;    // millis() when the flashing stops; 0 = not flashing
};

// Re-arms below this share of the threshold, so a change that hovers around
// the threshold (9.8%, 10.1%, 9.9%...) alerts once, not on every fetch.
constexpr float kCawAlertRearmShare = 0.7F;

// Feeds one fetched 1-hour change into the alert. Returns true when it starts
// a new alert (the caller then shows that chain). `durationMs` is how long the
// price flashes; `threshold` in percent, 0 or less turns alerts off.
inline bool cawMoveAlertUpdate(CawMoveAlert &alert, float change, float threshold,
                               uint32_t nowMs, uint32_t durationMs) {
  if (!(threshold > 0.0F) || std::isnan(change)) return false;
  const float size = std::fabs(change);
  if (size < threshold * kCawAlertRearmShare) {
    alert.armed = true;
    return false;
  }
  if (!alert.armed || size < threshold) return false;
  alert.armed = false;
  alert.up = change > 0.0F;
  alert.until = nowMs + durationMs;
  if (alert.until == 0) alert.until = 1;  // 0 means "not flashing"
  return true;
}

// True while the price should flash (wraps safely with millis()).
inline bool cawMoveAlertActive(const CawMoveAlert &alert, uint32_t nowMs) {
  return alert.until != 0 && static_cast<int32_t>(alert.until - nowMs) > 0;
}

// Clears an alert once its flashing time is over. The main loop calls it for
// every chain on every pass: left set, the end time (compared as a signed
// difference) would read as "flashing" again about 24.9 days later.
inline void cawMoveAlertExpire(CawMoveAlert &alert, uint32_t nowMs) {
  if (alert.until != 0 && !cawMoveAlertActive(alert, nowMs)) alert.until = 0;
}
