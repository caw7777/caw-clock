#pragma once

// Streaming reader for GeckoTerminal OHLCV responses:
//   {"data":{"attributes":{"ohlcv_list":[[ts,open,high,low,close,volume],...]}},...}
// Reads one character at a time, so a day of candles needs no JSON document
// (ArduinoJson needs ~6 KB for 25 candles). Numbers may be quoted. Prices use
// the project's DecimalParser (newlib's strtod would add ~7 KB of flash);
// timestamps are parsed as integers, since a float is off by up to two
// minutes at current Unix times.

#include <cstdint>

#include "DecimalParser.h"

inline bool parseOhlcvTimestamp(const char *text, uint32_t &result) {
  uint32_t value = 0;
  if (!*text) return false;
  for (; *text; ++text) {
    if (*text < '0' || *text > '9' || value > 429496728U) return false;
    value = value * 10 + static_cast<uint32_t>(*text - '0');
  }
  result = value;
  return value != 0;
}

// `read()` returns the next character, or a negative value at the end.
// `candle(timestamp, open, close)` (uint32_t, float, float) is called for
// each complete candle.
// Returns the number of candles delivered.
template <typename Read, typename Candle>
uint16_t parseOhlcvList(Read read, Candle candle) {
  static const char kKey[] = "\"ohlcv_list\"";
  uint8_t matched = 0;
  int c = 0;
  while (kKey[matched]) {
    c = read();
    if (c < 0) return 0;
    matched = c == kKey[matched] ? matched + 1 : (c == kKey[0] ? 1 : 0);
  }
  do {
    c = read();
    if (c < 0 || c == '{' || c == '}') return 0;
  } while (c != '[');

  uint16_t count = 0;
  for (;;) {
    do {
      c = read();
      if (c < 0) return count;
    } while (c == ' ' || c == ',' || c == '\n' || c == '\r' || c == '\t');
    if (c != '[') return count;  // ']' ends the list

    uint32_t timestamp = 0;
    float open = 0.0F, close = 0.0F;
    uint8_t found = 0;
    char token[32];
    uint8_t length = 0;
    bool bad = false;
    for (;;) {
      c = read();
      if (c < 0) return count;
      if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' ||
          c == 'E') {
        if (length < sizeof(token) - 1) token[length++] = static_cast<char>(c);
        else bad = true;
        continue;
      }
      if (c == '"' || c == ' ') continue;
      if (length) {
        token[length] = '\0';
        float value = 0.0F;
        if (found == 0) bad = bad || !parseOhlcvTimestamp(token, timestamp);
        else if (!parseDecimalFloat(token, value)) bad = true;
        if (found == 1) open = value;
        if (found == 4) close = value;
        ++found;
        length = 0;
      }
      if (c == ']') break;
      if (c != ',') bad = true;
    }
    if (!bad && found >= 5) {
      candle(timestamp, open, close);
      ++count;
    }
  }
}
