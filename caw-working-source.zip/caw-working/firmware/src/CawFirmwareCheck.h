#pragma once
// Which board a firmware image is for, from its first 16 bytes, so a clock
// refuses the other board's file before writing anything: the ESP8266 core's
// updater only checks the first byte (0xE9, the same on both) and the flash
// size (4 MB on both), so an ESP32-C2 image would be installed and the clock
// would not start again. (ESP-IDF's updater on the SDC2 checks the chip
// itself; this check is the same on both for a clear message.)
//
//  ESP8266 (SD PRO "SDP"): E9, segments, mode, size, entry (4 bytes), then
//    the first segment's load address: 0x3FFxxxxx or 0x40xxxxxx (byte 11).
//  ESP32 family (SD PRO "SDC2" = ESP32-C2): E9, ..., entry, then the extended
//    header: wp pin 0xEE (byte 8), ..., chip id LE16 at byte 12 (C2: 0x000C).
// Checked 2026-11-23 against CAW 0.7.0-rc1, both installers, the stock SD PRO
// firmware V1.0.6 and the factory SDC2 firmware.
#include <stddef.h>
#include <stdint.h>

enum class CawFirmwareKind : uint8_t { Unknown, Esp8266, Esp32C2, OtherEsp32 };

inline CawFirmwareKind cawFirmwareKind(const uint8_t *header, size_t length) {
  if (!header || length < 16 || header[0] != 0xE9) return CawFirmwareKind::Unknown;
  if (header[8] == 0xEE)
    return header[12] == 0x0C && header[13] == 0x00 ? CawFirmwareKind::Esp32C2 : CawFirmwareKind::OtherEsp32;
  if (header[11] == 0x40 || header[11] == 0x3F) return CawFirmwareKind::Esp8266;
  return CawFirmwareKind::Unknown;
}

// True when the image is for the board this firmware runs on.
inline bool cawFirmwareForThisClock(const uint8_t *header, size_t length) {
#if CAW_C2
  return cawFirmwareKind(header, length) == CawFirmwareKind::Esp32C2;
#else
  return cawFirmwareKind(header, length) == CawFirmwareKind::Esp8266;
#endif
}

// The first 16 bytes of a file that arrives in pieces (a piece can be shorter
// than 16 bytes). feed() each piece in order: false once the file is known not
// to be firmware for this clock. accepted(): the 16 bytes arrived and passed.
struct CawFirmwareHead {
  uint8_t bytes[16]{};
  uint8_t have = 0;
  bool decided = false, ok = false;

  bool feed(const uint8_t *data, size_t length) {
    while (!decided && length && have < sizeof(bytes)) {
      bytes[have++] = *data++;
      --length;
    }
    if (!decided && have == sizeof(bytes)) {
      decided = true;
      ok = cawFirmwareForThisClock(bytes, sizeof(bytes));
    }
    return !decided || ok;
  }
  bool accepted() const { return decided && ok; }
};
