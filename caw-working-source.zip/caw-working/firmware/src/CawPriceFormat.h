#pragma once

#include <algorithm>
#include <cstdio>
#include <cstring>

// DexScreener-style compact price: $0.0\u20885191 means 0.000000005191, the
// subscript counting every zero after the decimal point. Prices with fewer
// than two leading zeros keep four significant digits ($0.01234, $1.234).
// Digits are truncated from the exact decimal string; no float is used.
// Returns a static buffer (single-threaded firmware). Host-tested by
// tests/caw_price_format_test.cpp.
inline const char *compactDisplayPrice(const char *price) {
  static char output[48];
  if (!price || !price[0]) return "--";
  if (price[0] == '$') ++price;
  if (strcmp(price, "N/A") == 0) return "N/A";
  const char *dot = strchr(price, '.');
  size_t integerDigits = dot ? static_cast<size_t>(dot - price) : strlen(price);
  if (integerDigits == 0 || integerDigits > 12) return "--";
  size_t used = 0;
  output[used++] = '$';
  memcpy(output + used, price, integerDigits);
  used += integerDigits;
  output[used] = '\0';
  if (!dot) return output;

  const char *fraction = dot + 1;
  const char *first = fraction;
  while (*first == '0') ++first;
  const size_t zeroCount = static_cast<size_t>(first - fraction);
  const bool integerZero = integerDigits == 1 && price[0] == '0';
  if (integerZero && !*first) return output;  // "$0"
  if (integerZero && zeroCount >= 2) {
    // "$0.0" + subscript zero count + four significant digits.
    used += snprintf(output + used, sizeof(output) - used, ".0");
    char count[4]{};
    snprintf(count, sizeof(count), "%u", static_cast<unsigned>(std::min<size_t>(zeroCount, 99)));
    for (const char *digit = count; *digit; ++digit) {
      // U+2080 + d in UTF-8 is E2 82 (80 + d).
      if (used + 4 >= sizeof(output)) break;
      output[used++] = '\xE2';
      output[used++] = '\x82';
      output[used++] = static_cast<char>(0x80 + (*digit - '0'));
    }
    for (size_t index = 0; index < 4 && first[index] >= '0' && first[index] <= '9' &&
                           used + 1 < sizeof(output); ++index)
      output[used++] = first[index];
    output[used] = '\0';
    return output;
  }
  // Four significant digits in total, or the whole integer part if longer.
  const size_t significantInteger = integerZero ? 0 : integerDigits;
  size_t decimals = significantInteger >= 4 ? 0 : 4 - significantInteger;
  if (integerZero) decimals += zeroCount;
  size_t available = 0;
  while (fraction[available] >= '0' && fraction[available] <= '9') ++available;
  decimals = std::min(decimals, available);
  if (decimals && used + decimals + 2 < sizeof(output)) {
    output[used++] = '.';
    memcpy(output + used, fraction, decimals);
    used += decimals;
  }
  output[used] = '\0';
  return output;
}
