#pragma once

// HTTP response helpers for the CAW feeds. They read one character at a time
// and allocate nothing, so reading Cloudflare's ~25 header lines (some over
// 400 bytes) causes no heap churn while the TLS buffers are allocated.
//
// `read()` returns the next character, or a negative value on end / timeout.

#include <cstddef>
#include <cstdint>

// Longest header block accepted; a response that exceeds it is malformed.
constexpr size_t kCawHttpMaxHeaderBytes = 8192;

// Consumes the status line ("HTTP/1.1 200 OK\r\n") and returns the status
// code, or 0 when the line is not an HTTP/1.x status line.
template <typename Read>
int readHttpStatus(Read read) {
  static const char kPrefix[] = "HTTP/1.";
  char line[12];  // "HTTP/1.x NNN"
  size_t length = 0;
  for (size_t count = 0; count < kCawHttpMaxHeaderBytes; ++count) {
    const int c = read();
    if (c < 0) return 0;
    if (c == '\n') break;
    if (length < sizeof(line)) line[length++] = static_cast<char>(c);
  }
  if (length < sizeof(line)) return 0;
  for (size_t index = 0; index < sizeof(kPrefix) - 1; ++index)
    if (line[index] != kPrefix[index]) return 0;
  if (line[8] != ' ') return 0;
  int status = 0;
  for (size_t index = 9; index < 12; ++index) {
    if (line[index] < '0' || line[index] > '9') return 0;
    status = status * 10 + (line[index] - '0');
  }
  return status;
}

// Consumes the header lines up to and including the blank line. False when
// the stream ends first or the headers are implausibly long.
template <typename Read>
bool skipHttpHeaders(Read read) {
  size_t lineLength = 0;
  for (size_t count = 0; count < kCawHttpMaxHeaderBytes; ++count) {
    const int c = read();
    if (c < 0) return false;
    if (c == '\r') continue;
    if (c == '\n') {
      if (lineLength == 0) return true;
      lineLength = 0;
    } else {
      ++lineLength;
    }
  }
  return false;
}
