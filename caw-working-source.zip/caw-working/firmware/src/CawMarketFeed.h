#pragma once

#include <cstdint>

#include "DashboardValues.h"

// Fetches the fixed CAW/WCRO market pair directly from DexScreener.
// This module is intentionally independent of Home Assistant and the
// dashboard transport API. Values are written into the same data model that
// the renderer already consumes.
class CawMarketFeed {
 public:
  // Restores the last successful snapshot from LittleFS, if one exists.
  // changedMask contains the dashboard value slots restored from the cache.
  void begin(DashboardValues &values, uint32_t &changedMask,
             bool filesystemReady);

  // Returns true when a fresh market snapshot was received. changedMask
  // contains the dashboard value slots that actually changed.
  // releaseRenderCaches runs just before a fetch is attempted, so the TLS
  // handshake can use the heap the renderer would otherwise hold.
  bool tick(DashboardValues &values, uint32_t &changedMask,
            void (*releaseRenderCaches)() = nullptr);

  // Diagnostics for /api/v1/status.
  const char *lastResult() const { return lastResult_; }
  uint32_t lastFreeHeap() const { return lastFreeHeap_; }
  uint32_t lastMaxFreeBlock() const { return lastMaxFreeBlock_; }
  bool smallTlsFragments() const { return smallTlsFragments_; }

 private:
  uint32_t nextAttemptAt_ = 0;
  uint32_t lastCacheSavedAt_ = 0;
  bool cacheExists_ = false;
  bool cacheLoaded_ = false;
  bool filesystemReady_ = false;
  const char *lastResult_ = "not_started";
  uint32_t lastFreeHeap_ = 0;
  uint32_t lastMaxFreeBlock_ = 0;
  bool smallTlsFragments_ = false;
};
