#pragma once

// Written by scripts/patch_bearssl_client.py. Do not edit by hand.
#define CAW_BEARSSL_TRIM 7
#define CAW_LINK_BOLD48 0
