// CAW TLS probe: a minimal firmware that measures whether HTTPS price fetches
// fit in the ESP8266 heap when the Home Assistant dashboard engine is absent.
//
// It reuses the Wi-Fi credentials, hostname and panel password stored by the
// Mini Display / CAW firmware (read only: nothing is written to EEPROM or
// LittleFS), fetches DexScreener and GeckoTerminal over HTTPS with certificate
// validation using full and reduced TLS receive buffers, and reports the
// results on the screen and at /status. /update accepts a firmware upload
// protected by the panel password, so the next firmware can be installed
// without a serial cable.
#if CAW_PROBE

#include <Arduino.h>
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <TFT_eSPI.h>
#include <Updater.h>
#include <WiFiClientSecureBearSSL.h>
#include <WiFiUdp.h>
#include <time.h>

#include "../DeviceSettings.h"
#include "ProbeTrustAnchors.h"

namespace {

constexpr char kProbeVersion[] = "caw-probe-1";
constexpr uint32_t kRepeatMs = 10UL * 60UL * 1000UL;
constexpr uint32_t kReadTimeoutMs = 12000;
constexpr time_t kMinimumValidEpoch = 1704067200;  // 2024-01-01

struct ProbeCase {
  const char *name;
  const char *host;
  const char *path;
  const char *accept;
  const char *priceKey;
  uint16_t receiveBytes;  // 0 = BearSSL default (16 KiB + overhead)
};

const ProbeCase kCases[] = {
    {"dex-full", "api.dexscreener.com",
     "/latest/dex/pairs/cronos/0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c",
     "application/json", "\"priceUsd\":\"", 0},
    {"dex-4k", "api.dexscreener.com",
     "/latest/dex/pairs/cronos/0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c",
     "application/json", "\"priceUsd\":\"", 4096},
    {"dex-2k", "api.dexscreener.com",
     "/latest/dex/pairs/cronos/0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c",
     "application/json", "\"priceUsd\":\"", 2048},
    {"gecko-full", "api.geckoterminal.com",
     "/api/v2/networks/cro/pools/0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c",
     "application/json;version=20230302", "\"base_token_price_usd\":\"", 0},
    {"gecko-4k", "api.geckoterminal.com",
     "/api/v2/networks/cro/pools/0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c",
     "application/json;version=20230302", "\"base_token_price_usd\":\"", 4096},
};
constexpr size_t kCaseCount = sizeof(kCases) / sizeof(kCases[0]);

struct ProbeResult {
  bool ran = false;
  bool connected = false;
  int httpStatus = 0;
  uint32_t bodyBytes = 0;
  uint32_t heapBefore = 0, blockBefore = 0;
  uint32_t heapConnected = 0, blockConnected = 0;
  uint32_t heapMinimum = 0;
  uint32_t durationMs = 0;
  int sslError = 0;
  char sslErrorText[64]{};
  char price[24]{};
};

DeviceConfig config{};
ESP8266WebServer server(80);
TFT_eSPI display;
ProbeResult results[kCaseCount];
BearSSL::X509List *anchors = nullptr;
uint32_t anchorsHeapBytes = 0;
uint32_t idleHeap = 0, idleBlock = 0, idleMinimumHeap = 0xFFFFFFFF;
uint32_t lastRunAt = 0;
uint32_t runCount = 0;
bool runRequested = true;
bool fallbackAp = false;
char fallbackPassword[33]{};

void sampleHeap(uint32_t &minimum) {
  const uint32_t heap = ESP.getFreeHeap();
  if (heap < minimum) minimum = heap;
}

bool authorised() {
  if (!config.apiPassword[0]) return true;
  const char *user = configuredUsername(config);
  if (server.authenticate(user, config.apiPassword)) return true;
  server.requestAuthentication(DIGEST_AUTH, "CAW probe");
  return false;
}

void runCase(size_t index) {
  const ProbeCase &probe = kCases[index];
  ProbeResult &result = results[index];
  result = ProbeResult{};
  result.ran = true;
  result.heapBefore = ESP.getFreeHeap();
  result.blockBefore = ESP.getMaxFreeBlockSize();
  result.heapMinimum = result.heapBefore;
  const uint32_t started = millis();
  {
    BearSSL::WiFiClientSecure client;
    if (probe.receiveBytes) client.setBufferSizes(probe.receiveBytes, 512);
    client.setTrustAnchors(anchors);
    client.setX509Time(time(nullptr));
    client.setTimeout(kReadTimeoutMs);
    result.connected = client.connect(probe.host, 443);
    result.heapConnected = ESP.getFreeHeap();
    result.blockConnected = ESP.getMaxFreeBlockSize();
    sampleHeap(result.heapMinimum);
    if (result.connected) {
      client.printf_P(PSTR("GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: CAW-Clock-Probe/1\r\n"
                           "Accept: %s\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n"),
                      probe.path, probe.host, probe.accept);
      // Status line, then the body: count bytes and pick out the price.
      const String status = client.readStringUntil('\n');
      if (status.startsWith("HTTP/1.")) result.httpStatus = status.substring(9, 12).toInt();
      bool body = false;
      const size_t keyLength = strlen(probe.priceKey);
      size_t keyMatched = 0;
      bool capturing = false;
      size_t captured = 0;
      char previous = 0;
      const uint32_t readStarted = millis();
      while ((client.connected() || client.available()) &&
             millis() - readStarted < kReadTimeoutMs) {
        const int value = client.read();
        if (value < 0) {
          sampleHeap(result.heapMinimum);
          delay(5);
          continue;
        }
        const char character = static_cast<char>(value);
        if (!body) {
          if (character == '\n' && previous == '\r') {
            const int next = client.peek();
            if (next == '\r') { client.read(); client.read(); body = true; }
          }
          previous = character;
          continue;
        }
        ++result.bodyBytes;
        if (capturing) {
          if (character == '"' || captured + 1 >= sizeof(result.price)) {
            capturing = false;
          } else {
            result.price[captured++] = character;
          }
        } else if (!result.price[0]) {
          keyMatched = character == probe.priceKey[keyMatched]
                           ? keyMatched + 1
                           : (character == probe.priceKey[0] ? 1 : 0);
          if (keyMatched == keyLength) capturing = true;
        }
        if ((result.bodyBytes & 255) == 0) sampleHeap(result.heapMinimum);
      }
    }
    result.sslError = client.getLastSSLError(result.sslErrorText,
                                             sizeof(result.sslErrorText));
    client.stop();
  }
  result.durationMs = millis() - started;
}

void drawResults() {
  display.fillScreen(TFT_BLACK);
  display.setTextFont(1);
  display.setTextSize(1);
  display.setTextDatum(TL_DATUM);
  display.setTextColor(TFT_YELLOW, TFT_BLACK);
  display.drawString("CAW TLS probe  " + String(kProbeVersion), 4, 4);
  display.setTextColor(TFT_WHITE, TFT_BLACK);
  display.drawString(WiFi.localIP().toString() + "  run " + String(runCount), 4, 16);
  display.drawString("idle heap " + String(idleHeap) + " blk " + String(idleBlock), 4, 28);
  int16_t y = 46;
  for (size_t index = 0; index < kCaseCount; ++index) {
    const ProbeResult &result = results[index];
    const bool ok = result.httpStatus == 200 && result.price[0];
    display.setTextColor(!result.ran ? TFT_DARKGREY : ok ? TFT_GREEN : TFT_RED, TFT_BLACK);
    display.drawString(String(kCases[index].name) + (ok ? " OK " : " FAIL ") +
                           String(result.httpStatus) + " " + String(result.bodyBytes) + "B",
                       4, y);
    display.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    display.drawString(" min " + String(result.heapMinimum) + " conn blk " +
                           String(result.blockConnected), 4, y + 10);
    if (!ok && result.sslError) {
      display.drawString(" ssl " + String(result.sslError), 4, y + 20);
      y += 10;
    }
    y += 26;
  }
  display.setTextColor(TFT_CYAN, TFT_BLACK);
  display.drawString("http://" + WiFi.localIP().toString() + "/status", 4, 228);
}

void runAll() {
  ++runCount;
  for (size_t index = 0; index < kCaseCount; ++index) {
    runCase(index);
    drawResults();
    yield();
  }
  lastRunAt = millis();
}

void sendStatus() {
  if (!authorised()) return;
  String body;
  body.reserve(2600);
  body += F("{\"probe\":\"");
  body += kProbeVersion;
  body += F("\",\"uptimeSeconds\":");
  body += millis() / 1000;
  body += F(",\"runs\":");
  body += runCount;
  body += F(",\"idleFreeHeap\":");
  body += idleHeap;
  body += F(",\"idleMaxFreeBlock\":");
  body += idleBlock;
  body += F(",\"idleMinimumFreeHeap\":");
  body += idleMinimumHeap;
  body += F(",\"trustAnchorsHeapBytes\":");
  body += anchorsHeapBytes;
  body += F(",\"freeHeap\":");
  body += ESP.getFreeHeap();
  body += F(",\"maxFreeBlock\":");
  body += ESP.getMaxFreeBlockSize();
  body += F(",\"results\":[");
  for (size_t index = 0; index < kCaseCount; ++index) {
    const ProbeResult &result = results[index];
    if (index) body += ',';
    body += F("{\"case\":\"");
    body += kCases[index].name;
    body += F("\",\"receiveBufferBytes\":");
    body += kCases[index].receiveBytes;
    body += F(",\"ran\":");
    body += result.ran ? F("true") : F("false");
    body += F(",\"connected\":");
    body += result.connected ? F("true") : F("false");
    body += F(",\"httpStatus\":");
    body += result.httpStatus;
    body += F(",\"bodyBytes\":");
    body += result.bodyBytes;
    body += F(",\"price\":\"");
    body += result.price;
    body += F("\",\"heapBefore\":");
    body += result.heapBefore;
    body += F(",\"maxBlockBefore\":");
    body += result.blockBefore;
    body += F(",\"heapConnected\":");
    body += result.heapConnected;
    body += F(",\"maxBlockConnected\":");
    body += result.blockConnected;
    body += F(",\"heapMinimum\":");
    body += result.heapMinimum;
    body += F(",\"durationMs\":");
    body += result.durationMs;
    body += F(",\"sslError\":");
    body += result.sslError;
    body += F(",\"sslErrorText\":\"");
    for (const char *c = result.sslErrorText; *c; ++c)
      if (*c != '"' && *c != '\\') body += *c;
    body += F("\"}");
  }
  body += F("]}");
  server.send(200, "application/json", body);
}

void sendIndex() {
  if (!authorised()) return;
  server.send_P(200, PSTR("text/html"), PSTR(
      "<!doctype html><meta name=viewport content='width=device-width'>"
      "<title>CAW TLS probe</title><body style='font:16px system-ui;padding:16px'>"
      "<h2>CAW TLS probe</h2><p><a href=/status>Results (JSON)</a> &middot; "
      "<a href=/run>Run again</a></p><h3>Install firmware</h3>"
      "<form method=post action=/update enctype=multipart/form-data>"
      "<input type=file name=firmware accept=.bin> <button>Upload</button></form>"));
}

void receiveUpdate() {
  if (!authorised()) return;
  HTTPUpload &upload = server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    WiFiUDP::stopAll();
    display.fillScreen(TFT_BLACK);
    display.setTextColor(TFT_YELLOW, TFT_BLACK);
    display.drawString("Updating... do not power off", 4, 110);
    Update.begin(ESP.getFreeSketchSpace() & 0xFFFFF000);
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    Update.write(upload.buf, upload.currentSize);
  } else if (upload.status == UPLOAD_FILE_END) {
    Update.end(true);
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    Update.end();
  }
  yield();
}

void finishUpdate() {
  if (!authorised()) return;
  const bool success = !Update.hasError();
  server.send(success ? 200 : 500, "text/plain",
              success ? "Update complete. Restarting..." : "Update failed");
  if (success) {
    delay(300);
    ESP.restart();
  }
  drawResults();
}

// Keeps the upload page reachable if the clock cannot join Wi-Fi: a WPA2
// access point using the clock password (or a random one shown on screen).
void startFallbackAp() {
  if (fallbackAp) return;
  fallbackAp = true;
  if (strlen(config.apiPassword) >= 8) {
    strlcpy(fallbackPassword, config.apiPassword, sizeof(fallbackPassword));
  } else {
    snprintf(fallbackPassword, sizeof(fallbackPassword), "%08lx",
             static_cast<unsigned long>(ESP.random()));
  }
  const String ssid = "CAW-Probe-" + deviceSuffix();
  WiFi.mode(config.ssid[0] ? WIFI_AP_STA : WIFI_AP);
  WiFi.softAP(ssid.c_str(), fallbackPassword);
  display.fillRect(0, 150, 240, 90, TFT_BLACK);
  display.setTextColor(TFT_YELLOW, TFT_BLACK);
  display.drawString("Wi-Fi failed. Join " + ssid, 4, 160);
  display.drawString(strlen(config.apiPassword) >= 8
                         ? String("Key: your clock password")
                         : String("Key: ") + fallbackPassword,
                     4, 172);
  display.drawString("Then open http://192.168.4.1", 4, 184);
}

}  // namespace

void setup() {
  Serial.begin(115200);
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, TFT_BACKLIGHT_ON);
  display.init();
  display.fillScreen(TFT_BLACK);
  display.setTextColor(TFT_WHITE, TFT_BLACK);
  display.drawString("CAW TLS probe: connecting", 4, 4);

  loadDeviceConfig(config);  // read only for a current-format configuration
  WiFi.persistent(false);
  if (wifiConfigured(config)) {
    WiFi.mode(WIFI_STA);
    WiFi.hostname(configuredHostname(config));
    WiFi.begin(config.ssid, config.wifiPassword);
    const uint32_t started = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - started < 45000) delay(100);
  }
  if (WiFi.status() != WL_CONNECTED) startFallbackAp();
  configTime(0, 0, "pool.ntp.org", "time.google.com");

  const uint32_t heapBeforeAnchors = ESP.getFreeHeap();
  anchors = new BearSSL::X509List(kGtsRootR1);
  anchors->append(kGtsRootR4);
  anchors->append(kIsrgRootX1);
  anchors->append(kIsrgRootX2);
  anchorsHeapBytes = heapBeforeAnchors - ESP.getFreeHeap();

  server.on("/", HTTP_GET, sendIndex);
  server.on("/status", HTTP_GET, sendStatus);
  server.on("/run", HTTP_GET, [] {
    if (!authorised()) return;
    runRequested = true;
    server.sendHeader("Location", "/status");
    server.send(303);
  });
  server.on("/update", HTTP_POST, finishUpdate, receiveUpdate);
  server.begin();
}

void loop() {
  server.handleClient();
  if (WiFi.status() != WL_CONNECTED) {
    delay(10);
    return;
  }
  sampleHeap(idleMinimumHeap);
  if (!idleHeap) {
    idleHeap = ESP.getFreeHeap();
    idleBlock = ESP.getMaxFreeBlockSize();
  }
  if (time(nullptr) < kMinimumValidEpoch) {
    delay(50);
    return;
  }
  if (runRequested || millis() - lastRunAt >= kRepeatMs) {
    runRequested = false;
    idleHeap = ESP.getFreeHeap();
    idleBlock = ESP.getMaxFreeBlockSize();
    runAll();
  }
  delay(2);
}

#endif  // CAW_PROBE
