#include "CawMarketFeed.h"
#include "FeatureFlags.h"
#include "CawMarketFormat.h"
#include "CawPriceFormat.h"
#include "DecimalParser.h"
#include "GraphHistory.h"

#if defined(ESP8266) && MINI_DISPLAY_FEATURE_CAW

#include <Arduino.h>
#include <ArduinoJson.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WiFi.h>
#include <LittleFS.h>
#include <WiFiClientSecureBearSSL.h>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace {

constexpr char kDexScreenerUrl[] =
    "https://api.dexscreener.com/latest/dex/pairs/cronos/"
    "0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c";
constexpr uint32_t kRefreshIntervalMs = 5UL * 60UL * 1000UL;
constexpr uint32_t kRetryIntervalMs = 60UL * 1000UL;
constexpr uint32_t kClockRetryIntervalMs = 30UL * 1000UL;
constexpr uint32_t kConnectTimeoutMs = 10000;
constexpr uint32_t kMinimumValidEpoch = 1704067200UL;  // 2024-01-01 UTC
constexpr char kDexScreenerHost[] = "api.dexscreener.com";
constexpr size_t kMaximumResponseBytes = 8192;
constexpr uint32_t kCacheWriteIntervalMs = 15UL * 60UL * 1000UL;
constexpr char kCachePath[] = "/caw-cache.json";
constexpr char kCacheTempPath[] = "/caw-cache.tmp";
constexpr char kCacheBackupPath[] = "/caw-cache.bak";
constexpr char kCacheInvalidPath[] = "/caw-cache.invalid";

// Trust the long-lived GTS Root R4 CA rather than a short-lived leaf or
// intermediate certificate. Current public certificate observations for
// dexscreener.com show the WE1 -> GTS Root R4 chain; verify the API hostname
// itself during hardware testing before treating the CA choice as final.
// The firmware checks certificate validity against NTP-synchronized time.
static const char kGtsRootR4[] PROGMEM =
    "-----BEGIN CERTIFICATE-----\n"
    "MIICCTCCAY6gAwIBAgINAgPlwGjvYxqccpBQUjAKBggqhkjOPQQDAzBHMQswCQYD\n"
    "VQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExMQzEUMBIG\n"
    "A1UEAxMLR1RTIFJvb3QgUjQwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIyMDAwMDAw\n"
    "WjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2Vz\n"
    "IExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjQwdjAQBgcqhkjOPQIBBgUrgQQAIgNi\n"
    "AATzdHOnaItgrkO4NcWBMHtLSZ37wWHO5t5GvWvVYRg1rkDdc/eJkTBa6zzuhXyi\n"
    "QHY7qca4R9gq55KRanPpsXI5nymfopjTX15YhmUPoYRlBtHci8nHc8iMai/lxKvR\n"
    "HYqjQjBAMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQW\n"
    "BBSATNbrdP9JNqPV2Py1PsVq8JQdjDAKBggqhkjOPQQDAwNpADBmAjEA6ED/g94D\n"
    "9J+uHXqnLrmvT/aDHQ4thQEd0dlq7A/Cr8deVl5c1RxYIigL9zC2L7F8AjEA8GE8\n"
    "p/SgguMh1YQdc4acLa/KNJvxn7kjNuK8YAOdgLOaVsjh4rsUecrNIdSUtUlD\n"
    "-----END CERTIFICATE-----\n";

struct MarketSnapshot {
  char priceUsd[49]{};
  char priceChange1h[25]{};
  char priceChange24h[25]{};
  char liquidity[49]{};
  char volume24h[49]{};
  char fdv[49]{};
  char marketCap[49]{};
  // Derived display strings, rebuilt from the fields above (not cached).
  char ticker[64]{};         // "\u25B6 caw  $0.0\u20885191"
  char tickerChanges[56]{};  // "+0.9%  +2.4%"
};

// Display icons stored in the C1 slots of the CAW fonts
// (scripts/caw_font_assets.py). Private-use code points keep them apart
// from real text.
constexpr char kWifiOnIcon[] = "\uE000";
constexpr char kWifiOffIcon[] = "\uE001";


void buildTicker(MarketSnapshot &snapshot) {
  // Two strings so the percentages can follow their own red/green mapping.
  snprintf(snapshot.ticker, sizeof(snapshot.ticker), "\u25B6 caw  %s",
           compactDisplayPrice(snapshot.priceUsd));
  snprintf(snapshot.tickerChanges, sizeof(snapshot.tickerChanges), "%s  %s",
           snapshot.priceChange1h, snapshot.priceChange24h);
}

// "up", "down" or "stale" for the ticker ring; follows the 24-hour change.
const char *trendState(const MarketSnapshot &snapshot, bool live) {
  if (!live) return "stale";
  return snapshot.priceChange24h[0] == '-' ? "down" : "up";
}

bool dexScreenerSupportsSmallTlsFragments() {
  static bool checked = false;
  static bool supported = false;
  if (!checked) {
    supported = BearSSL::WiFiClientSecure::probeMaxFragmentLength(
        kDexScreenerHost, 443, 512);
    checked = true;
  }
  return supported;
}

const char *gFetchFailure = "none";

bool readSnapshot(MarketSnapshot &snapshot, time_t now) {
  gFetchFailure = "connect";
  // Construct the trust anchor once. Its memory remains allocated for the
  // lifetime of the firmware and is reused across five-minute polls.
  static BearSSL::X509List trustAnchor(kGtsRootR4);
  if (trustAnchor.getCount() == 0) return false;

  BearSSL::WiFiClientSecure client;
  // Only reduce BearSSL's receive buffer when the API host negotiates the
  // TLS maximum-fragment-length extension. Otherwise retain BearSSL's safe
  // default 16 KiB receive buffer.
  if (dexScreenerSupportsSmallTlsFragments()) {
    client.setBufferSizes(512, 512);
  }
  client.setX509Time(now);
  client.setTrustAnchors(&trustAnchor);
  client.setTimeout(kConnectTimeoutMs);

  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(kConnectTimeoutMs);
  http.setUserAgent(String("CAW-Clock/0.1"));
  http.setReuse(false);
  if (!http.begin(client, kDexScreenerUrl)) return false;
  http.addHeader(String("Accept"), String("application/json"));
  http.addHeader(String("Accept-Encoding"), String("identity"));
  http.addHeader(String("Connection"), String("close"));
  const int status = http.GET();
  if (status != HTTP_CODE_OK) {
    // Negative values are transport errors (TLS handshake, timeout).
    gFetchFailure = status < 0 ? "tls_or_connection" : "http_status";
    http.end();
    return false;
  }

  const int responseBytes = http.getSize();
  if (responseBytes <= 0 ||
      static_cast<size_t>(responseBytes) > kMaximumResponseBytes) {
    gFetchFailure = "response_size";
    http.end();
    return false;
  }

  StaticJsonDocument<256> filter;
  filter["pairs"][0]["priceUsd"] = true;
  filter["pairs"][0]["priceChange"]["h1"] = true;
  filter["pairs"][0]["priceChange"]["h24"] = true;
  filter["pairs"][0]["liquidity"]["usd"] = true;
  filter["pairs"][0]["volume"]["h24"] = true;
  filter["pairs"][0]["fdv"] = true;
  filter["pairs"][0]["marketCap"] = true;
  filter["pairs"][0]["liquidity"]["usd"] = true;
  filter["pairs"][0]["volume"]["h24"] = true;
  filter["pairs"][0]["fdv"] = true;
  filter["pairs"][0]["marketCap"] = true;
  if (filter.overflowed()) {
    http.end();
    return false;
  }

  // Parse from the HTTP stream with a field filter; the full DexScreener
  // response is never copied into a large temporary String.
  StaticJsonDocument<768> document;
  WiFiClient *responseStream = http.getStreamPtr();
  if (!responseStream) {
    http.end();
    return false;
  }
  const DeserializationError error = deserializeJson(
      document, *responseStream, DeserializationOption::Filter(filter),
      DeserializationOption::NestingLimit(5));
  if (error || !document["pairs"].is<JsonArray>() ||
      document["pairs"].size() == 0) {
    gFetchFailure = "json";
    http.end();
    return false;
  }

  JsonObjectConst pair = document["pairs"][0].as<JsonObjectConst>();
  const char *price = pair["priceUsd"] | "";
  const bool priceValid = copyPrice(price, snapshot.priceUsd,
                                    sizeof(snapshot.priceUsd));
  const bool change1hValid = format24hChange(
      pair["priceChange"]["h1"], snapshot.priceChange1h,
      sizeof(snapshot.priceChange1h));
  const bool changeValid = format24hChange(
      pair["priceChange"]["h24"], snapshot.priceChange24h,
      sizeof(snapshot.priceChange24h));
  const bool liquidityValid = compactUsd(
      pair["liquidity"]["usd"], snapshot.liquidity,
      sizeof(snapshot.liquidity));
  const bool volumeValid = compactUsd(pair["volume"]["h24"], snapshot.volume24h,
                                      sizeof(snapshot.volume24h));
  const bool fdvValid = compactUsd(pair["fdv"], snapshot.fdv,
                                   sizeof(snapshot.fdv));

  // DexScreener can omit marketCap for some pairs. Match the existing HA
  // template's fallback to FDV when that field is absent or null.
  bool marketCapValid = compactUsd(pair["marketCap"], snapshot.marketCap,
                                   sizeof(snapshot.marketCap));
  if (!marketCapValid && fdvValid) {
    strlcpy(snapshot.marketCap, snapshot.fdv, sizeof(snapshot.marketCap));
    marketCapValid = true;
  }

  http.end();
  if (!(priceValid && change1hValid && changeValid && liquidityValid &&
        volumeValid && fdvValid && marketCapValid)) {
    gFetchFailure = "invalid_fields";
    return false;
  }
  buildTicker(snapshot);
  return true;
}

bool cachedString(JsonVariantConst value, char *destination,
                  size_t capacity) {
  const char *text = value | "";
  if (!text[0] || strlen(text) >= capacity) return false;
  for (const unsigned char *cursor =
           reinterpret_cast<const unsigned char *>(text);
       *cursor; ++cursor) {
    if (*cursor < 0x20 || *cursor > 0x7e) return false;
  }
  strlcpy(destination, text, capacity);
  return true;
}

bool readCache(MarketSnapshot &snapshot) {
  if (!LittleFS.exists(kCachePath)) return false;
  File file = LittleFS.open(kCachePath, "r");
  if (!file) return false;

  StaticJsonDocument<768> document;
  const DeserializationError error = deserializeJson(document, file);
  file.close();
  const int schemaVersion = document["schemaVersion"] | 0;
  const bool valid = !error && schemaVersion >= 2 && schemaVersion <= 4 &&
      cachedString(document["priceUsd"], snapshot.priceUsd,
                 sizeof(snapshot.priceUsd)) &&
      cachedString(document["liquidity"], snapshot.liquidity,
                 sizeof(snapshot.liquidity)) &&
      cachedString(document["fdv"], snapshot.fdv, sizeof(snapshot.fdv)) &&
      cachedString(document["marketCap"], snapshot.marketCap,
                 sizeof(snapshot.marketCap)) &&
      cachedString(document["priceChange24h"], snapshot.priceChange24h,
                 sizeof(snapshot.priceChange24h)) &&
      (schemaVersion == 2 || cachedString(document["priceChange1h"], snapshot.priceChange1h,
                 sizeof(snapshot.priceChange1h))) &&
      (schemaVersion == 2 || cachedString(document["volume24h"], snapshot.volume24h,
                 sizeof(snapshot.volume24h)));
  if (valid && schemaVersion == 2) {
    strlcpy(snapshot.priceChange1h, "N/A", sizeof(snapshot.priceChange1h));
    strlcpy(snapshot.volume24h, "N/A", sizeof(snapshot.volume24h));
  }
  // Schema 2/3 stored a ticker string; it is now derived, not cached.
  if (valid) buildTicker(snapshot);
  if (!valid) {
    LittleFS.remove(kCacheInvalidPath);
    LittleFS.rename(kCachePath, kCacheInvalidPath);
  }
  return valid;
}

bool writeCache(const MarketSnapshot &snapshot) {
  StaticJsonDocument<768> document;
  document["schemaVersion"] = 4;
  document["priceUsd"] = snapshot.priceUsd;
  document["priceChange1h"] = snapshot.priceChange1h;
  document["priceChange24h"] = snapshot.priceChange24h;
  document["liquidity"] = snapshot.liquidity;
  document["volume24h"] = snapshot.volume24h;
  document["fdv"] = snapshot.fdv;
  document["marketCap"] = snapshot.marketCap;

  LittleFS.remove(kCacheTempPath);
  File file = LittleFS.open(kCacheTempPath, "w");
  if (!file) return false;
  const size_t written = serializeJson(document, file);
  file.flush();
  const bool writeOk = written > 0 && !file.getWriteError();
  file.close();
  if (!writeOk) {
    LittleFS.remove(kCacheTempPath);
    return false;
  }

  LittleFS.remove(kCacheBackupPath);
  const bool hadCache = LittleFS.exists(kCachePath);
  if (hadCache && !LittleFS.rename(kCachePath, kCacheBackupPath)) {
    LittleFS.remove(kCacheTempPath);
    return false;
  }
  if (!LittleFS.rename(kCacheTempPath, kCachePath)) {
    if (hadCache) LittleFS.rename(kCacheBackupPath, kCachePath);
    LittleFS.remove(kCacheTempPath);
    return false;
  }
  LittleFS.remove(kCacheBackupPath);
  return true;
}



bool updateValue(DashboardValues &values, const char *source,
                 const char *state, uint32_t &changedMask) {
  DashboardValue *slot = values.find(source, true);
  if (!slot) return false;
  if (slot->available && strcmp(slot->state, state) == 0) return true;
  strlcpy(slot->state, state, sizeof(slot->state));
  slot->available = true;
  const uint8_t index = values.indexOf(slot);
  if (index < 32) changedMask |= (1UL << index);
  return true;
}

}  // namespace

void CawMarketFeed::begin(DashboardValues &values, uint32_t &changedMask,
                          bool filesystemReady) {
  changedMask = 0;
  if (cacheLoaded_) return;
  cacheLoaded_ = true;
  filesystemReady_ = filesystemReady;
  MarketSnapshot snapshot;
  if (!filesystemReady_ || !readCache(snapshot)) {
    cacheExists_ = filesystemReady_ && LittleFS.exists(kCachePath);
    // Register every dashboard source before its first scene compilation.
    // Without these placeholders the renderer would not know that it needs
    // to watch the market values that arrive after the first HTTPS request.
    updateValue(values, "sensor.caw_usd_price_display", "--", changedMask);
    updateValue(values, "sensor.caw_change_1h_display", "--", changedMask);
    updateValue(values, "sensor.caw_change_24h_display", "--", changedMask);
    updateValue(values, "sensor.caw_ticker_display", "\u25B6 caw  --",
                changedMask);
    updateValue(values, "sensor.caw_ticker_changes_display", "--",
                changedMask);
    updateValue(values, "sensor.caw_trend_display", "stale", changedMask);
    updateValue(values, "sensor.caw_liquidity_display", "--", changedMask);
    updateValue(values, "sensor.caw_volume_24h_display", "--", changedMask);
    updateValue(values, "sensor.caw_fdv_display", "--", changedMask);
    updateValue(values, "sensor.caw_market_cap_display", "--", changedMask);
    updateValue(values, "sensor.caw_data_status_display",
                "CONNECTING", changedMask);
    updateValue(values, "sensor.caw_wifi_status_display",
                WiFi.status() == WL_CONNECTED ? kWifiOnIcon : kWifiOffIcon,
                changedMask);
    return;
  }
  cacheExists_ = true;

  updateValue(values, "sensor.caw_usd_price_display", compactDisplayPrice(snapshot.priceUsd),
              changedMask);
  updateValue(values, "sensor.caw_change_1h_display",
              snapshot.priceChange1h, changedMask);
  updateValue(values, "sensor.caw_change_24h_display",
              snapshot.priceChange24h, changedMask);
  updateValue(values, "sensor.caw_ticker_display", snapshot.ticker,
              changedMask);
  updateValue(values, "sensor.caw_ticker_changes_display",
              snapshot.tickerChanges, changedMask);
  updateValue(values, "sensor.caw_trend_display", trendState(snapshot, false),
              changedMask);
  updateValue(values, "sensor.caw_liquidity_display", snapshot.liquidity,
              changedMask);
  updateValue(values, "sensor.caw_volume_24h_display", snapshot.volume24h,
              changedMask);
  updateValue(values, "sensor.caw_fdv_display", snapshot.fdv, changedMask);
  updateValue(values, "sensor.caw_market_cap_display", snapshot.marketCap,
              changedMask);
  updateValue(values, "sensor.caw_data_status_display", "STALE", changedMask);
  updateValue(values, "sensor.caw_wifi_status_display",
              WiFi.status() == WL_CONNECTED ? kWifiOnIcon : kWifiOffIcon,
                changedMask);
  lastCacheSavedAt_ = millis();
}

bool CawMarketFeed::tick(DashboardValues &values, uint32_t &changedMask,
                         void (*releaseRenderCaches)()) {
  changedMask = 0;
  const bool wifiConnected = WiFi.status() == WL_CONNECTED;
  updateValue(values, "sensor.caw_wifi_status_display",
              wifiConnected ? kWifiOnIcon : kWifiOffIcon, changedMask);
  const char *failureState = cacheExists_ ? "STALE" : "OFFLINE";
  if (!wifiConnected) {
    lastResult_ = "waiting_for_wifi";
    updateValue(values, "sensor.caw_data_status_display", failureState,
                changedMask);
    updateValue(values, "sensor.caw_trend_display", "stale", changedMask);
    return changedMask != 0;
  }

  const uint32_t nowMs = millis();
  if (nextAttemptAt_ != 0 &&
      static_cast<int32_t>(nowMs - nextAttemptAt_) < 0) return changedMask != 0;

  const time_t now = time(nullptr);
  if (now < static_cast<time_t>(kMinimumValidEpoch)) {
    lastResult_ = "waiting_for_time";
    nextAttemptAt_ = nowMs + kClockRetryIntervalMs;
    return updateValue(values, "sensor.caw_data_status_display",
                       cacheExists_ ? "STALE" : "WAITING FOR TIME",
                       changedMask) && changedMask != 0;
  }

  // Avoid starting a TLS handshake when the dashboard has left too little
  // contiguous heap for BearSSL's buffers and certificate validation.
  // Release the renderer's caches first (page JSON, scene, font tables); the
  // screen is rebuilt after the attempt. Without this the heap check below
  // cannot pass while the CAW page is displayed.
  if (releaseRenderCaches) releaseRenderCaches();
  const bool mflnSupported = dexScreenerSupportsSmallTlsFragments();
  smallTlsFragments_ = mflnSupported;
  const uint32_t requiredFreeHeap = mflnSupported ? 24000 : 36000;
  const uint32_t requiredFreeBlock = mflnSupported ? 12000 : 20000;
  lastFreeHeap_ = ESP.getFreeHeap();
  lastMaxFreeBlock_ = ESP.getMaxFreeBlockSize();
  if (lastFreeHeap_ < requiredFreeHeap ||
      lastMaxFreeBlock_ < requiredFreeBlock) {
    lastResult_ = "low_memory";
    nextAttemptAt_ = nowMs + kRetryIntervalMs;
    return updateValue(values, "sensor.caw_data_status_display", failureState,
                       changedMask) && changedMask != 0;
  }

  MarketSnapshot snapshot;
  if (!readSnapshot(snapshot, now)) {
    lastResult_ = gFetchFailure;
    nextAttemptAt_ = nowMs + kRetryIntervalMs;
    updateValue(values, "sensor.caw_trend_display", "stale", changedMask);
    return updateValue(values, "sensor.caw_data_status_display", failureState,
                       changedMask) && changedMask != 0;
  }

  lastResult_ = "ok";
  // Record the actual fetched USD price in the chart series. The graph is
  // sampled locally every five minutes and uses 48 half-hour buckets for a
  // rolling 24-hour view. It starts filling on first boot; no history is
  // fabricated when the device has not yet been online for a full day.
  // parseDecimalFloat avoids linking newlib's strtod (see AGENTS.md).
  float chartPrice = 0.0F;
  if (parseDecimalFloat(snapshot.priceUsd[0] == '$' ? snapshot.priceUsd + 1
                                                     : snapshot.priceUsd,
                        chartPrice) &&
      std::isfinite(chartPrice) && chartPrice > 0.0F) {
    graphHistory.recordSample("sensor.caw_usd_price_display", chartPrice,
                              static_cast<uint32_t>(now));
  }

  bool updated = updateValue(values, "sensor.caw_usd_price_display",
                             compactDisplayPrice(snapshot.priceUsd),
                             changedMask);
  updated = updateValue(values, "sensor.caw_change_1h_display",
                        snapshot.priceChange1h, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_change_24h_display",
                        snapshot.priceChange24h, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_ticker_display",
                        snapshot.ticker, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_ticker_changes_display",
                        snapshot.tickerChanges, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_trend_display",
                        trendState(snapshot, true), changedMask) && updated;
  updated = updateValue(values, "sensor.caw_liquidity_display",
                        snapshot.liquidity, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_volume_24h_display",
                        snapshot.volume24h, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_fdv_display", snapshot.fdv,
                        changedMask) && updated;
  updated = updateValue(values, "sensor.caw_market_cap_display",
                        snapshot.marketCap, changedMask) && updated;
  updated = updateValue(values, "sensor.caw_data_status_display", "LIVE",
                        changedMask) && updated;

  if (filesystemReady_ &&
      (!cacheExists_ || millis() - lastCacheSavedAt_ >= kCacheWriteIntervalMs)) {
    if (writeCache(snapshot)) {
      cacheExists_ = true;
      lastCacheSavedAt_ = millis();
    }
  }
  nextAttemptAt_ = nowMs + kRefreshIntervalMs;
  return updated || changedMask != 0;
}

#else

void CawMarketFeed::begin(DashboardValues &, uint32_t &changedMask, bool) {
  changedMask = 0;
}

bool CawMarketFeed::tick(DashboardValues &, uint32_t &changedMask, void (*)()) {
  changedMask = 0;
  return false;
}

#endif
