#pragma once

// Burn alert. The CAW bridge (cawbridge, a LayerZero OFT bridge) burns 0.5%
// of every bridge, on the chain the bridge starts from, and its contract
// there emits
//   CawExportBurnEvent(address indexed sender, uint256 totalAmount,
//                      uint256 burnedAmount, uint32 dstChain)
// (dstChain: the LayerZero endpoint id of the destination). A bridge from
// Solana burns nothing on Solana (its OFT program sends the whole amount);
// the burn happens when it arrives, and the contract on the arriving chain
// emits
//   CawImportBurnEvent(address indexed target, uint256 totalAmount,
//                      uint256 burnedAmount)
// (seen on chain: Solana -> Cronos, 2026-11-13, 58.40B bridged, 291.99M
// burned; EVM -> EVM bridges emit only the export event). The clock asks a
// public JSON-RPC server of each chain for these events (eth_getLogs) a few
// minutes apart, in one batched request together with eth_blockNumber, and
// reads the answer with CawBurnReader: a small streaming JSON reader that
// keeps only the block number and each event's block and data, so its
// memory use is fixed however long the answer is.
//
// Plain C++: tested on the PC (tests/caw_burn_test.cpp) and fuzzed
// (tools/fuzz in the private repository).

#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

// The texts below (names, servers, addresses, request templates) stay in
// flash on the clock, where RAM is short; read them with the _P functions
// (which also read RAM). Plain on a PC.
#if defined(ARDUINO)
#include <pgmspace.h>
#define CAW_BURN_FLASH PROGMEM
#define CAW_BURN_TEXT(text) PSTR(text)
#define CAW_BURN_STRLEN strlen_P
#define CAW_BURN_MEMCPY memcpy_P
#define CAW_BURN_STRNCPY strncpy_P
#else
#define CAW_BURN_FLASH
#define CAW_BURN_TEXT(text) (text)
#define CAW_BURN_STRLEN strlen
#define CAW_BURN_MEMCPY memcpy
#define CAW_BURN_STRNCPY strncpy
#endif

// Copies a text of the tables (in flash on the clock) into out.
// Returns out as char *: ArduinoJson copies a char * but only points at a
// const char *.
inline char *cawBurnText(const char *text, char *out, size_t size) {
  if (!size) return out;
  CAW_BURN_STRNCPY(out, text, size - 1);
  out[size - 1] = '\0';
  return out;
}

// Appends texts (flash or RAM) to a buffer; ok turns false if one doesn't fit.
struct CawBurnWriter {
  char *out;
  size_t size;
  size_t used = 0;
  bool ok = true;
  CawBurnWriter(char *buffer, size_t bytes) : out(buffer), size(bytes) {
    if (size) out[0] = '\0';
    else ok = false;
  }
  CawBurnWriter &operator<<(const char *text) {
    const size_t length = CAW_BURN_STRLEN(text);
    if (!ok || used + length >= size) {
      ok = false;
      return *this;
    }
    CAW_BURN_MEMCPY(out + used, text, length);
    used += length;
    out[used] = '\0';
    return *this;
  }
};

enum class CawBurnRoot : uint8_t { Usual, SslCom, UserTrust };

struct CawBurnChain {
  const char *name;      // shown on the screen, e.g. "cronos"
  const char *host;      // JSON-RPC over HTTPS
  const char *path;
  const char *contract;  // the bridge's OFT contract (Solana: the CAW mint)
  const char *token;     // the CAW token (supply, dead wallet)
  uint32_t eid;          // LayerZero endpoint id
  uint8_t decimals;      // of the token: amounts are divided by 10^decimals
  bool home;             // Cronos: the original token, the bridge holds the rest
  bool solana;           // not EVM: only the token supply is asked
  CawBurnRoot root;      // certificate root beyond the usual four
};

// From bridge.crowwithknife.com. Servers checked 2026-11-19 with the
// requests the clock sends: PublicNode (Cronos: at most 10,000 blocks per
// request, BSC and Base 50,000) and the chains' own servers for Arbitrum
// (PublicNode refuses its log requests), Robinhood and Solana (PublicNode
// wants a key for token supply). Certificates: GTS Root R4 (PublicNode),
// ISRG Root X2 (Arbitrum), SSL.com TLS ECC Root CA 2022 (Robinhood),
// USERTrust ECC (Solana). Arbitrum's CAW has 0 decimals.
static const char kCawBurnOft[] CAW_BURN_FLASH = "0x74897ef1b152E5a733D797CAb5Cee383fe052C56";
static const char kCawBurnBaseBsc[] CAW_BURN_FLASH = "0xdfbea88c4842d30c26669602888d746d30f9d60d";
static const char kCawBurnSlash[] CAW_BURN_FLASH = "/";
static const char kCawBurnCronos[] CAW_BURN_FLASH = "cronos";
static const char kCawBurnCronosHost[] CAW_BURN_FLASH = "cronos-evm-rpc.publicnode.com";
static const char kCawBurnCronosToken[] CAW_BURN_FLASH = "0xcCcCcCcCdbEC186DC426F8B5628AF94737dF0E60";
static const char kCawBurnBsc[] CAW_BURN_FLASH = "bsc";
static const char kCawBurnBscHost[] CAW_BURN_FLASH = "bsc-rpc.publicnode.com";
static const char kCawBurnBase[] CAW_BURN_FLASH = "base";
static const char kCawBurnBaseHost[] CAW_BURN_FLASH = "base-rpc.publicnode.com";
static const char kCawBurnPolygon[] CAW_BURN_FLASH = "polygon";
static const char kCawBurnPolygonHost[] CAW_BURN_FLASH = "polygon-bor-rpc.publicnode.com";
static const char kCawBurnPolygonToken[] CAW_BURN_FLASH = "0xbbBBbBbBB7949dcC7d1539c91b81A5BF09E37bDB";
static const char kCawBurnArbitrum[] CAW_BURN_FLASH = "arbitrum";
static const char kCawBurnArbitrumHost[] CAW_BURN_FLASH = "arb1.arbitrum.io";
static const char kCawBurnArbitrumPath[] CAW_BURN_FLASH = "/rpc";
static const char kCawBurnArbitrumToken[] CAW_BURN_FLASH = "0x16f1967565aaD72DD77588a332CE445e7cEF752b";
static const char kCawBurnRobinhood[] CAW_BURN_FLASH = "robinhood";
static const char kCawBurnRobinhoodHost[] CAW_BURN_FLASH = "rpc.mainnet.chain.robinhood.com";
static const char kCawBurnRobinhoodOft[] CAW_BURN_FLASH = "0x0Ef0330255579725B0a5f7F3890af6c0FC857D2A";
static const char kCawBurnRobinhoodToken[] CAW_BURN_FLASH = "0x777777783478dAdf54678d1D92DaD3fB5Bd42Eb2";
static const char kCawBurnSolana[] CAW_BURN_FLASH = "solana";
static const char kCawBurnSolanaHost[] CAW_BURN_FLASH = "api.mainnet-beta.solana.com";
static const char kCawBurnSolanaMint[] CAW_BURN_FLASH = "CAW777xcHVTQZ4CRwVQGB8CV1BVKPm5bNVxFJHWFKiH8";
static const char kCawBurnAnother[] CAW_BURN_FLASH = "another chain";

// name, host, path, contract, token, eid, decimals, home, solana, root
constexpr CawBurnChain kCawBurnChains[] = {
    {kCawBurnCronos, kCawBurnCronosHost, kCawBurnSlash, kCawBurnOft, kCawBurnCronosToken, 30359, 18,
     true, false, CawBurnRoot::Usual},
    {kCawBurnBsc, kCawBurnBscHost, kCawBurnSlash, kCawBurnOft, kCawBurnBaseBsc, 30102, 18, false,
     false, CawBurnRoot::Usual},
    {kCawBurnBase, kCawBurnBaseHost, kCawBurnSlash, kCawBurnOft, kCawBurnBaseBsc, 30184, 18, false,
     false, CawBurnRoot::Usual},
    {kCawBurnPolygon, kCawBurnPolygonHost, kCawBurnSlash, kCawBurnOft, kCawBurnPolygonToken, 30109,
     18, false, false, CawBurnRoot::Usual},
    {kCawBurnArbitrum, kCawBurnArbitrumHost, kCawBurnArbitrumPath, kCawBurnOft,
     kCawBurnArbitrumToken, 30110, 0, false, false, CawBurnRoot::Usual},
    {kCawBurnRobinhood, kCawBurnRobinhoodHost, kCawBurnSlash, kCawBurnRobinhoodOft,
     kCawBurnRobinhoodToken, 30416, 18, false, false, CawBurnRoot::SslCom},
    {kCawBurnSolana, kCawBurnSolanaHost, kCawBurnSlash, kCawBurnSolanaMint, kCawBurnSolanaMint, 30168,
     2, false, true, CawBurnRoot::UserTrust},
};
constexpr uint8_t kCawBurnChainCount = sizeof(kCawBurnChains) / sizeof(kCawBurnChains[0]);

// keccak256("CawExportBurnEvent(address,uint256,uint256,uint32)") and
// keccak256("CawImportBurnEvent(address,uint256,uint256)")
static const char kCawExportBurnTopic[] CAW_BURN_FLASH =
    "0x63c3e78bc4e2d8174461ececdeef203ef623f259bbb24514c3eb5dacc89e0e33";
static const char kCawImportBurnTopic[] CAW_BURN_FLASH =
    "0x9e179a6f930feb2737bb5ec3c2c395675aca53d058aa68d4d042aba58184c942";

// Name of a LayerZero endpoint id, as the Discord bot writes it (a table
// text: copy it with cawBurnText).
inline const char *cawBurnChainName(uint32_t eid) {
  for (const CawBurnChain &chain : kCawBurnChains)
    if (chain.eid == eid) return chain.name;
  return kCawBurnAnother;
}

// "0x" + lowercase hex of value, into out. Returns false if it doesn't fit.
inline bool cawHex(uint64_t value, char *out, size_t size) {
  char digits[17];
  size_t count = 0;
  do {
    digits[count++] = "0123456789abcdef"[value & 15];
    value >>= 4;
  } while (value && count < sizeof(digits));
  if (size < count + 3) return false;
  out[0] = '0';
  out[1] = 'x';
  for (size_t index = 0; index < count; ++index) out[2 + index] = digits[count - 1 - index];
  out[2 + count] = '\0';
  return true;
}

// Ids of the answers in a chain's batch.
enum : uint8_t {
  kCawBurnIdBlock = 1,   // eth_blockNumber
  kCawBurnIdLogs = 2,    // eth_getLogs: the burn events
  kCawBurnIdSupply = 3,  // the token's totalSupply()
  kCawBurnIdDead = 4,    // Cronos: balanceOf(0x...dEaD)
  kCawBurnIdLocked = 5,  // Cronos: balanceOf(bridge), CAW bridged to other chains
};

// The JSON-RPC body. EVM chains: a batch of eth_blockNumber, the supply calls
// and from fromBlock on (0: not known yet) the burn events up to the newest
// block. Solana: getTokenSupply. Returns its length, or 0 if it doesn't fit.
inline size_t cawBurnRequest(const CawBurnChain &chain, uint64_t fromBlock, char *out,
                             size_t size) {
  CawBurnWriter body(out, size);
  if (chain.solana) {
    body << CAW_BURN_TEXT("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"getTokenSupply\",\"params\":[\"")
         << chain.token << CAW_BURN_TEXT("\"]}");
    return body.ok ? body.used : 0;
  }
#define CAW_BURN_CALL(id) ",{\"jsonrpc\":\"2.0\",\"id\":" #id ",\"method\":\"eth_call\",\"params\":[{\"to\":\""
#define CAW_BURN_BALANCE "\",\"data\":\"0x70a08231000000000000000000000000"
#define CAW_BURN_LATEST "\"},\"latest\"]}"
  body << CAW_BURN_TEXT("[{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"eth_blockNumber\",\"params\":[]}"
                        CAW_BURN_CALL(3))
       << chain.token << CAW_BURN_TEXT("\",\"data\":\"0x18160ddd" CAW_BURN_LATEST);
  if (chain.home) {
    body << CAW_BURN_TEXT(CAW_BURN_CALL(4)) << chain.token
         << CAW_BURN_TEXT(CAW_BURN_BALANCE "000000000000000000000000000000000000dEaD" CAW_BURN_LATEST
                          CAW_BURN_CALL(5))
         << chain.token << CAW_BURN_TEXT(CAW_BURN_BALANCE) << chain.contract + 2
         << CAW_BURN_TEXT(CAW_BURN_LATEST);
  }
  if (fromBlock) {
    char from[20];
    if (!cawHex(fromBlock, from, sizeof(from))) return 0;
    body << CAW_BURN_TEXT(",{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"eth_getLogs\",\"params\":[{"
                          "\"fromBlock\":\"")
         << from << CAW_BURN_TEXT("\",\"toBlock\":\"latest\",\"address\":\"") << chain.contract
         << CAW_BURN_TEXT("\",\"topics\":[[\"") << kCawExportBurnTopic << CAW_BURN_TEXT("\",\"")
         << kCawImportBurnTopic << CAW_BURN_TEXT("\"]]}]}");
  }
#undef CAW_BURN_CALL
#undef CAW_BURN_BALANCE
#undef CAW_BURN_LATEST
  body << CAW_BURN_TEXT("]");
  return body.ok ? body.used : 0;
}

inline int cawHexDigit(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

// "0x1a2b" (1 to 16 digits) -> value. False for anything else.
inline bool cawParseHexQuantity(const char *text, uint64_t &value) {
  if (!text || text[0] != '0' || (text[1] != 'x' && text[1] != 'X') || !text[2]) return false;
  value = 0;
  size_t count = 0;
  for (const char *p = text + 2; *p; ++p) {
    const int digit = cawHexDigit(*p);
    if (digit < 0 || ++count > 16) return false;
    value = value << 4 | static_cast<uint64_t>(digit);
  }
  return true;
}

// One 32-byte word (64 hex digits) as a number; tokens have 18 decimals, so
// the caller divides by 1e18. A double keeps the first 15-16 digits, plenty
// for "67.11M". -1 if a digit is not hex.
inline double cawHexWord(const char *digits) {
  double value = 0;
  for (size_t index = 0; index < 64; ++index) {
    const int digit = cawHexDigit(digits[index]);
    if (digit < 0) return -1;
    value = value * 16 + digit;
  }
  return value;
}

// 67116015.3 -> "67.11M", 13423203007 -> "13.42B" (cut, not rounded, like
// the Discord bot), 950 -> "950".
inline void cawFormatCawAmount(double amount, char *out, size_t size, int decimals = 2) {
  static const struct { double scale; char unit; } kUnits[] = {
      {1e12, 'T'}, {1e9, 'B'}, {1e6, 'M'}, {1e3, 'K'}};
  if (!(amount >= 0) || amount > 1e18) {
    snprintf(out, size, "?");
    return;
  }
  // Whole numbers only: the clock's printf has no %f (it prints nothing).
  for (const auto &unit : kUnits) {
    if (amount >= unit.scale) {
      const unsigned long factor = decimals == 3 ? 1000 : 100;
      // At most 1e18 / 1e12 * 1000 = 1e9: fits 32 bits.
      const unsigned long cut =
          static_cast<unsigned long>(floor(amount / unit.scale * factor + 1e-6));
      snprintf(out, size, decimals == 3 ? "%lu.%03lu%c" : "%lu.%02lu%c", cut / factor,
               cut % factor, unit.unit);
      return;
    }
  }
  snprintf(out, size, "%lu", static_cast<unsigned long>(floor(amount)));
}

struct CawBurnLog {
  uint64_t block = 0;
  double total = 0;   // CAW bridged (whole tokens)
  double burned = 0;  // CAW burned
  uint32_t dstEid = 0;   // export: the destination's LayerZero id
  bool arrived = false;  // import event: a bridge from Solana arriving here
};

// Streaming reader of the JSON-RPC answer (a batch: an array of two
// objects; or one object, when a server answers a batch with one error).
// feed() each byte of the body; it returns false once the text is not
// JSON, nests too deep or a byte is missing (-1). done() is true when the
// whole document was read.
class CawBurnReader {
 public:
  static constexpr uint8_t kMaxLogs = 4;

  bool haveLatest = false;    // eth_blockNumber answered
  uint64_t latest = 0;
  bool logsAnswered = false;  // eth_getLogs answered with a list
  bool rpcError = false;      // an answer carried "error" (e.g. range too wide)
  uint8_t count = 0;          // events in logs[]
  uint16_t extra = 0;         // events beyond kMaxLogs (dropped)
  uint16_t invalid = 0;       // events whose fields could not be read
  uint64_t maxLogBlock = 0;   // of the new events
  CawBurnLog logs[kMaxLogs];
  // Events beyond kMaxLogs, added up (not dropped): CAW burned and bridged.
  double extraBurned = 0, extraTotal = 0;
  // Set before feeding: only events in later blocks are new (polls overlap,
  // see cawBurnNextCursor); older ones are skipped.
  uint64_t newerThan = 0;
  // Set before feeding: amounts are divided by this (10^decimals of the
  // chain's token).
  double scale = 1e18;
  // The eth_call answers, by id - kCawBurnIdSupply: supply, dead, locked.
  bool haveCall[3] = {false, false, false};
  double call[3] = {0, 0, 0};
  // Solana's getTokenSupply: "amount" (whole units) / 10^"decimals".
  bool haveAmount = false;
  double amount = 0;

  bool done() const { return done_ && !failed_; }

  bool feed(int c) {
    if (failed_) return false;
    if (c < 0 || c > 255) return fail();
    const char ch = static_cast<char>(c);
    if (state_ == State::String) return stringChar(ch);
    if (state_ == State::Literal) {
      if ((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
          ch == '.' || ch == '+' || ch == '-') {
        if (literalLength_ + 1u < sizeof(literal_)) literal_[literalLength_++] = ch;
        return true;
      }
      literal_[literalLength_] = '\0';
      scalar(false);
      state_ = State::AfterValue;
    }
    if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t') return true;
    switch (state_) {
      case State::Value:
        return startValue(ch);
      case State::KeyOrEnd:
        if (ch == '"') return startString(true);
        if (ch == '}') return close('{');
        return fail();
      case State::Colon:
        if (ch != ':') return fail();
        state_ = State::Value;
        return true;
      case State::AfterValue:
        if (depth_ == 0) return fail();  // text after the document
        if (ch == ',') {
          state_ = kind_[depth_ - 1] == '{' ? State::KeyOrEnd : State::Value;
          return true;
        }
        if (ch == '}' || ch == ']') return close(ch == '}' ? '{' : '[');
        return fail();
      default:
        return fail();
    }
  }

 private:
  enum class State : uint8_t { Value, KeyOrEnd, Colon, AfterValue, String, Literal };
  static constexpr uint8_t kMaxDepth = 8;

  bool fail() {
    failed_ = true;
    return false;
  }

  const char *key(uint8_t index) const { return kind_[index] == '{' ? key_[index] : ""; }
  bool logsArray(uint8_t index) const {
    return index == elementLevel_ + 1 && kind_[index] == '[' &&
           strcmp(key(elementLevel_), "result") == 0;
  }

  bool startValue(char ch) {
    if (ch == '{' || ch == '[') return open(ch);
    if (depth_ == 0) return fail();  // the document must be an object or array
    if (ch == ']' && kind_[depth_ - 1] == '[') return close('[');
    if (ch == '"') return startString(false);
    if ((ch >= '0' && ch <= '9') || ch == '-' || ch == 't' || ch == 'f' || ch == 'n') {
      state_ = State::Literal;
      literalLength_ = 0;
      literal_[literalLength_++] = ch;
      return true;
    }
    return fail();
  }

  bool open(char kind) {
    if (done_ || depth_ >= kMaxDepth) return fail();
    const uint8_t index = depth_++;
    kind_[index] = kind;
    key_[index][0] = '\0';
    if (index == 0) elementLevel_ = kind == '[' ? 1 : 0;
    if (index == elementLevel_ && kind == '{') {
      elementError_ = false;
      elementHex_ = false;
      elementId_ = -1;
      elementWord_ = -1;
    } else if (index == elementLevel_ + 1 && index > 0 && kind_[elementLevel_] == '{') {
      if (strcmp(key(elementLevel_), "error") == 0) elementError_ = true;
      if (logsArray(index)) logsAnswered = true;
    } else if (index == elementLevel_ + 2 && kind == '{' && logsArray(index - 1)) {
      logBlock_ = false;
      logData_ = false;
      logRemoved_ = false;
    }
    state_ = kind == '{' ? State::KeyOrEnd : State::Value;
    return true;
  }

  bool close(char kind) {
    if (depth_ == 0 || kind_[depth_ - 1] != kind) return fail();
    const uint8_t index = --depth_;
    if (index == elementLevel_ + 2 && kind == '{' && logsArray(index - 1)) {
      if (logBlock_ && logData_ && !logRemoved_) addLog();
      else if (!logRemoved_) ++invalid;
    } else if (index == elementLevel_ && kind == '{') {
      if (elementError_) {
        rpcError = true;
      } else if (elementId_ >= kCawBurnIdSupply && elementId_ <= kCawBurnIdLocked) {
        if (elementWord_ >= 0) {
          haveCall[elementId_ - kCawBurnIdSupply] = true;
          call[elementId_ - kCawBurnIdSupply] = elementWord_ / scale;
        }
      } else if (elementHex_ && (elementId_ == kCawBurnIdBlock || elementId_ < 0)) {
        haveLatest = true;
        latest = elementValue_;
      }
    }
    if (index == 0) done_ = true;
    state_ = State::AfterValue;
    return true;
  }

  bool startString(bool isKey) {
    if (!isKey && depth_ == 0) return fail();
    stringIsKey_ = isKey;
    stringLength_ = 0;
    stringOverflow_ = false;
    escape_ = false;
    state_ = State::String;
    return true;
  }

  bool stringChar(char ch) {
    if (escape_) {
      escape_ = false;
      ch = '?';  // the strings read here are hex: an escape makes them invalid
    } else if (ch == '\\') {
      escape_ = true;
      return true;
    } else if (ch == '"') {
      string_[stringLength_] = '\0';
      if (stringIsKey_) {
        strncpy(key_[depth_ - 1], string_, sizeof(key_[0]) - 1);
        key_[depth_ - 1][sizeof(key_[0]) - 1] = '\0';
        state_ = State::Colon;
      } else {
        scalar(true);
        state_ = State::AfterValue;
      }
      return true;
    }
    if (stringLength_ + 1u < sizeof(string_)) string_[stringLength_++] = ch;
    else stringOverflow_ = true;
    return true;
  }

  // A string or literal value just ended, inside container depth_ - 1.
  void scalar(bool isString) {
    const uint8_t index = depth_ - 1;
    if (kind_[index] != '{') return;
    const char *name = key_[index];
    if (isString && strcmp(name, "amount") == 0) {  // Solana's token supply
      haveAmount = readDigits(amountRaw_);
    } else if (!isString && strcmp(name, "decimals") == 0) {
      double decimals = 0;
      if (readDigits(decimals, literal_) && decimals <= 30) amountDecimals_ = decimals;
      else haveAmount = false;
    }
    if (haveAmount && amountDecimals_ >= 0) amount = amountRaw_ / pow(10.0, amountDecimals_);
    if (index == elementLevel_) {
      if (strcmp(name, "error") == 0) {
        elementError_ = true;
      } else if (!isString && strcmp(name, "id") == 0) {
        double id = 0;
        elementId_ = readDigits(id, literal_) && id < 100 ? static_cast<int8_t>(id) : -1;
      } else if (isString && strcmp(name, "result") == 0) {
        elementHex_ = !stringOverflow_ && cawParseHexQuantity(string_, elementValue_);
        // eth_call: "0x" + one 32-byte word.
        elementWord_ = !stringOverflow_ && stringLength_ == 66 ? cawHexWord(string_ + 2) : -1;
      }
    } else if (index == elementLevel_ + 2 && index >= 2 && logsArray(index - 1)) {
      if (isString && strcmp(name, "blockNumber") == 0) {
        logBlock_ = !stringOverflow_ && cawParseHexQuantity(string_, log_.block);
      } else if (isString && strcmp(name, "data") == 0) {
        logData_ = readData();
      } else if (!isString && strcmp(name, "removed") == 0) {
        logRemoved_ = strcmp(literal_, "true") == 0;
      }
    }
  }

  // Export: "0x" + three 32-byte words: totalAmount, burnedAmount, dstChain.
  // Import: two words: totalAmount, burnedAmount.
  bool readData() {
    const bool exported = stringLength_ == 2 + 3 * 64;
    if (stringOverflow_ || (!exported && stringLength_ != 2 + 2 * 64) || string_[0] != '0' ||
        (string_[1] != 'x' && string_[1] != 'X'))
      return false;
    const double total = cawHexWord(string_ + 2), burned = cawHexWord(string_ + 66);
    if (total < 0 || burned < 0) return false;
    log_.total = total / scale;
    log_.burned = burned / scale;
    log_.arrived = !exported;
    log_.dstEid = 0;
    if (!exported) return true;
    uint64_t eid = 0;
    for (size_t index = 130; index < 194; ++index) {
      const int digit = cawHexDigit(string_[index]);
      if (digit < 0) return false;
      if (index < 194 - 8) {
        if (digit) return false;  // a uint32 has only its last 8 digits set
      } else {
        eid = eid << 4 | static_cast<uint64_t>(digit);
      }
    }
    log_.dstEid = static_cast<uint32_t>(eid);
    return true;
  }

  // Decimal digits only (1 to 30): string_ or the given text.
  bool readDigits(double &value, const char *text = nullptr) const {
    if (!text) {
      if (stringOverflow_) return false;
      text = string_;
    }
    value = 0;
    size_t count = 0;
    for (const char *p = text; *p; ++p) {
      if (*p < '0' || *p > '9' || ++count > 30) return false;
      value = value * 10 + (*p - '0');
    }
    return count > 0;
  }

  void addLog() {
    if (log_.block <= newerThan) return;  // seen in an earlier poll
    if (log_.block > maxLogBlock) maxLogBlock = log_.block;
    if (count < kMaxLogs) {
      logs[count++] = log_;
    } else {
      if (extra < 0xFFFF) ++extra;
      extraBurned += log_.burned;
      extraTotal += log_.total;
    }
  }

  State state_ = State::Value;
  bool failed_ = false, done_ = false;
  uint8_t depth_ = 0, elementLevel_ = 1;
  char kind_[kMaxDepth]{};
  char key_[kMaxDepth][14]{};
  char string_[2 + 3 * 64 + 2]{};
  uint16_t stringLength_ = 0;
  bool stringIsKey_ = false, stringOverflow_ = false, escape_ = false;
  char literal_[8]{};
  uint8_t literalLength_ = 0;
  bool elementError_ = false, elementHex_ = false;
  int8_t elementId_ = -1;
  double elementWord_ = -1;
  double amountRaw_ = 0, amountDecimals_ = -1;
  uint64_t elementValue_ = 0;
  bool logBlock_ = false, logData_ = false, logRemoved_ = false;
  CawBurnLog log_;
};

// Where the next poll starts. Before the first answer (cursor 0) only the
// block number is asked: burns from before the clock started aren't shown.
// Then each poll asks from cursor + 1 up to the newest block. Afterwards the
// cursor moves to kCawBurnOverlapBlocks below the newest block the batch
// reported: a load-balanced server can answer eth_blockNumber from a node a
// few blocks ahead of the one that answers eth_getLogs, so the last blocks
// are asked again (events already seen are skipped: CawBurnReader::newerThan,
// the highest block with an event seen). When eth_getLogs was not answered
// (an error, a range too wide), the same range is asked again; the caller
// starts over (cursor 0) after a few failures in a row.
constexpr uint64_t kCawBurnOverlapBlocks = 64;

inline uint64_t cawBurnNextCursor(uint64_t cursor, const CawBurnReader &reader) {
  if (!reader.done() || !reader.haveLatest) return cursor;
  if (cursor == 0) return reader.latest;
  if (!reader.logsAnswered) return cursor;
  const uint64_t next =
      reader.latest > kCawBurnOverlapBlocks ? reader.latest - kCawBurnOverlapBlocks : 0;
  return next > cursor ? next : cursor;
}

// The highest block with an event seen, after this answer. On the first
// answer (cursor 0) it starts at the newest block: older burns are not new.
inline uint64_t cawBurnSeenAfter(uint64_t seen, uint64_t cursor, const CawBurnReader &reader) {
  if (!reader.done()) return seen;
  if (cursor == 0 && reader.haveLatest && reader.latest > seen) seen = reader.latest;
  return reader.maxLogBlock > seen ? reader.maxLogBlock : seen;
}

// Total burned, as the CAW Discord's supply chart counts it: Cronos's
// original supply minus the CAW on every chain. Cronos: supply - held by the
// bridge (bridged to other chains) - dead wallet; other EVM chains: supply;
// Solana: token supply. Checked 2026-11-19: 11.521T, as the Discord bot
// (the small dead wallets on BSC and Base are not counted as burned, as
// there). Each chain's figures come with its burn poll.
struct CawBurnSupply {
  bool known = false;
  double circulating = 0;
  double homeSupply = 0;  // Cronos only
  uint32_t at = 0;        // millis() of the figures
};

// From one chain's answer; false if a figure is missing.
inline bool cawBurnSupplyFrom(const CawBurnChain &chain, const CawBurnReader &reader,
                              uint32_t nowMs, CawBurnSupply &out) {
  if (!reader.done()) return false;
  double circulating;
  if (chain.solana) {
    if (!reader.haveAmount) return false;
    circulating = reader.amount;
  } else {
    const int supply = kCawBurnIdSupply - kCawBurnIdSupply, dead = kCawBurnIdDead - kCawBurnIdSupply,
              locked = kCawBurnIdLocked - kCawBurnIdSupply;
    if (!reader.haveCall[supply]) return false;
    if (chain.home && (!reader.haveCall[dead] || !reader.haveCall[locked])) return false;
    circulating = reader.call[supply] - (chain.home ? reader.call[dead] + reader.call[locked] : 0);
    out.homeSupply = chain.home ? reader.call[supply] : 0;
  }
  if (!(circulating >= 0)) return false;
  out.circulating = circulating;
  out.known = true;
  out.at = nowMs;
  return true;
}

// The total, when every chain's figures are known and at most maxAgeMs old.
inline bool cawBurnTotal(const CawBurnSupply *supplies, uint8_t count, uint32_t nowMs,
                         uint32_t maxAgeMs, double &burned) {
  double home = 0, circulating = 0;
  for (uint8_t index = 0; index < count; ++index) {
    const CawBurnSupply &supply = supplies[index];
    if (!supply.known || nowMs - supply.at > maxAgeMs) return false;
    circulating += supply.circulating;
    if (supply.homeSupply > 0) home = supply.homeSupply;
  }
  burned = home - circulating;
  return home > 0 && burned >= 0;
}

// Cool-down: at most one burn screen per cooldown; burns in between are
// added up and shown together when it ends.
struct CawBurnGate {
  bool pending = false;
  double burned = 0, bridged = 0;
  uint16_t count = 0;
  char from[12]{}, to[16]{};  // route of the last burn added
  bool cooling = false;
  uint32_t shownAt = 0;
};

inline void cawBurnAdd(CawBurnGate &gate, double burned, double bridged, const char *from,
                       const char *to, uint16_t count = 1) {
  gate.pending = true;
  gate.burned += burned;
  gate.bridged += bridged;
  const uint32_t sum = static_cast<uint32_t>(gate.count) + count;
  gate.count = sum > 0xFFFF ? 0xFFFF : static_cast<uint16_t>(sum);
  cawBurnText(from, gate.from, sizeof(gate.from));  // names may be in flash
  cawBurnText(to, gate.to, sizeof(gate.to));
}

// Call often: ends the cool-down when it is over (so millis() wrapping can
// never stretch it), then says whether a burn screen should start now.
inline bool cawBurnDue(CawBurnGate &gate, uint32_t nowMs, uint32_t cooldownMs) {
  if (gate.cooling && nowMs - gate.shownAt >= cooldownMs) gate.cooling = false;
  return gate.pending && !gate.cooling;
}

inline void cawBurnShown(CawBurnGate &gate, uint32_t nowMs) {
  gate.pending = false;
  gate.burned = gate.bridged = 0;
  gate.count = 0;
  gate.cooling = true;
  gate.shownAt = nowMs;
}
