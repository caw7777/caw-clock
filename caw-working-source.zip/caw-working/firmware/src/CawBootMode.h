#pragma once

// Boot mode of the CAW + Home Assistant firmware: which app runs after the
// next start. Read once at boot; switching modes writes it and restarts, so
// only one app's memory is ever in use. Missing or unreadable: CAW.
#include <LittleFS.h>

constexpr char kCawBootModePath[] = "/boot-mode";

inline bool cawBootModeIsCaw() {
  File file = LittleFS.open(kCawBootModePath, "r");
  if (!file) return true;
  const String mode = file.readStringUntil('\n');
  file.close();
  return mode != "homeassistant";
}

inline bool cawSetBootMode(bool caw) {
  File file = LittleFS.open(kCawBootModePath, "w");
  if (!file) return false;
  const size_t written = file.print(caw ? "caw" : "homeassistant");
  file.close();
  return written > 0;
}
