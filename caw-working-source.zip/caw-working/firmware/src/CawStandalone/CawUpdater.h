#pragma once

// Firmware safety and updates of the standalone CAW app:
//
//  * Automatic rollback. Before an update is installed, the running firmware
//    is copied into the file system (~1 MB, when there is room). The new
//    firmware restores that copy if it keeps restarting before it has run
//    for kCawRollbackConfirmMs; after that the copy is deleted. It needs the
//    new firmware to get as far as the start of cawAppSetup().
//  * "Check for updates": the latest release's SHA256SUMS.txt from GitHub,
//    and installing its firmware, verified against that SHA-256 before it is
//    activated. Both run with certificate-validated HTTPS.

#if CAW_STANDALONE

#include <Arduino.h>
#include <time.h>

#include "../CawRelease.h"

// Public repository whose releases the clock checks.
#define CAW_RELEASE_REPOSITORY "caw7777/caw-clock"

// How long a new firmware must run before its rollback copy is deleted.
#if CAW_C2
// ESP32-C2: the bootloader rolls back on any restart before the new firmware
// is confirmed (ESP-IDF app rollback), so confirm once it has run 2 minutes.
constexpr uint32_t kCawRollbackConfirmMs = 2UL * 60UL * 1000UL;
#else
constexpr uint32_t kCawRollbackConfirmMs = 10UL * 60UL * 1000UL;
#endif

struct CawRollbackSpace {
  uint32_t needed;     // bytes the copy needs (firmware + working space)
  uint32_t available;  // free bytes (an existing copy counts as free)
};
CawRollbackSpace cawRollbackSpace();
inline bool cawRollbackFits(const CawRollbackSpace &space) {
  return space.available >= space.needed;
}

// Copies the running firmware (`version`) to the file system. Blocks for
// ~15-30 s, yielding. False when there is no room or a write failed (then no
// copy is left behind). `progress` gets 0-100 and may be null.
bool cawRollbackSave(const char *version, void (*progress)(uint8_t percent));

// Deletes the copy (update abandoned or confirmed).
void cawRollbackDiscard();

enum class CawRollbackBoot : uint8_t {
  None,          // no copy, or nothing to do
  Pending,       // this is a new firmware on trial; the copy is kept
  RestoreReady,  // the copy was written back: restart now to run it
  RolledBack,    // this firmware was just restored (see cawRollbackNotice)
};

// Called once at start-up with the running version. `crashLoop`: the boot
// guard counted enough quick restarts. `message` shows a line on screen and
// may be null.
CawRollbackBoot cawRollbackBoot(const char *version, bool crashLoop,
                                 void (*message)(const char *line));

// The last automatic rollback: the version that kept restarting and the one
// that was restored. False when none happened since the last update.
bool cawRollbackNotice(char *failed, size_t failedSize, char *restored, size_t restoredSize);
void cawRollbackClearNotice();

// Asks github.com for the latest release's version (one small request: the
// redirect of ".../releases/latest" names it). Runs during normal operation,
// like a price fetch. `lowMemory` is set when it did not try because free
// memory was short; the caller can then check in update mode instead.
bool cawCheckLatestVersion(time_t now, char *version, size_t versionSize, String &error,
                           bool &lowMemory);

// Reads the latest release's firmware line from GitHub. `now` must be the
// real time (certificates are checked). `error` gets a short reason.
bool cawFetchLatestRelease(time_t now, CawReleaseInfo &out, String &error);

// Downloads `release`, checks its SHA-256 and, only when it matches, makes it
// the firmware that runs after the next restart. `progress` gets bytes done
// and total, and may be null.
bool cawInstallRelease(time_t now, const CawReleaseInfo &release, String &error,
                       void (*progress)(uint32_t done, uint32_t total));

#endif  // CAW_STANDALONE
