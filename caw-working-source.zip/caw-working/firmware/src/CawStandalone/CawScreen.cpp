#if CAW_STANDALONE

#include "CawScreen.h"

#include <cmath>
#include <cstring>

#include <LittleFS.h>

#include "CawPictures.h"
#include "CawChainIcons.h"
#include "../CoverageFont.h"
#include "../StaticSmoothFont.h"
#if CAW_DUAL
#include "../DisplayFonts.h"  // shared font data (one copy in the image)
#else
#include <fonts_caw/InterTightBold36.h>
#include <fonts_caw/InterTightSmooth.h>
#endif

namespace {

// Colours of the CAW design (RGB565).
constexpr uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}
constexpr uint16_t kBackground = rgb(0x00, 0x00, 0x00);
constexpr uint16_t kWhite = rgb(0xF5, 0xF5, 0xF5);
constexpr uint16_t kGrey = rgb(0x9A, 0xA0, 0xA6);
constexpr uint16_t kGreen = rgb(0x2F, 0xD6, 0x55);
constexpr uint16_t kRed = rgb(0xFF, 0x4D, 0x4D);
constexpr uint16_t kDivider = rgb(0x3A, 0x3F, 0x47);
constexpr uint16_t kBoxBorder = rgb(0xD0, 0xD0, 0xD0);

// Layout in pixels. The 56 x 56 picture sits at (5, 5); the header text
// starts to its right (kTextX) and the divider is below it.
constexpr int16_t kPictureX = 5, kPictureY = 5;
constexpr int16_t kTextX = kPictureX + kCawPictureSize + 4;
constexpr int16_t kTitleY = 20, kPairY = 48, kDividerY = 66;
// Price: the smaller built-in coverage font (see drawPrice), bottom datum at
// y 107; the cleared band is tall enough for either size.
constexpr int16_t kPriceTop = 67, kPriceHeight = 48, kPriceTextY = 112;
constexpr int16_t kChangeY = 126;
constexpr int16_t kChartX = 2, kChartY = 140, kChartW = 236, kChartH = 31;
constexpr int16_t kBoxY = 173, kBoxH = 42, kBoxW = 77;
constexpr int16_t kBoxX[3] = {2, 82, 161};
constexpr int16_t kTickerY = 216;

StaticSmoothFont smoothFont(uint8_t size) {
#if CAW_DUAL
  return indexedSmoothFont(cawSmoothFontData(size));
#else
  return indexedSmoothFont(size == 13   ? InterTightSmooth13
                           : size == 24 ? InterTightSmooth24
                                        : InterTightSmooth18);
#endif
}

uint16_t changeColor(const char *value) {
  return value[0] == '-' ? kRed : value[0] == '+' ? kGreen : kGrey;
}

}  // namespace

void CawScreen::begin() {
#if defined(ESP8266)
  // The Home Assistant firmware scrolls the panel through its 320-row memory.
  // Reset the scroll area and offset so row 0 is the top of the screen.
  display_.startWrite();
  display_.writecommand(0x33);  // VSCRDEF: no fixed areas, 320 scroll rows
  for (const uint16_t value : {uint16_t{0}, uint16_t{320}, uint16_t{0}}) {
    display_.writedata(value >> 8);
    display_.writedata(value & 0xFF);
  }
  display_.writecommand(0x37);  // VSCRSADD: offset 0
  display_.writedata(0);
  display_.writedata(0);
  // Blank all 320 rows of panel memory, not just the 240 we draw: the panel
  // shows a few rows below 240, which otherwise keep old firmware's pixels
  // (the ghost line under the ticker).
  display_.setWindow(0, 0, 239, 319);
  display_.pushBlock(kBackground, 240UL * 320UL);
  display_.endWrite();
#endif
  display_.fillScreen(kBackground);
  invalidate();
}

void CawScreen::invalidate() {
  staticDrawn_ = false;
  for (Cache *cache : {&chain_, &clock_, &wifi_, &price_, &h1_, &h24_, &liq_, &vol_,
                       &mcap_, &ticker_, &moves_, &ring_}) {
    cache->valid = false;
  }
  chartVersion_ = 0xFFFFFFFF;
  pictureValid_ = false;
}

bool CawScreen::changed(Cache &cache, const char *text, uint16_t color) {
  if (cache.valid && cache.color == color &&
      strncmp(cache.text, text, sizeof(cache.text) - 1) == 0) {
    return false;
  }
  strlcpy(cache.text, text, sizeof(cache.text));
  cache.color = color;
  cache.valid = true;
  return true;
}

void CawScreen::drawSmooth(uint8_t size, const char *text, int16_t x,
                           int16_t y, uint8_t datum, uint16_t color) {
  const StaticSmoothFont font = smoothFont(size);
  if (!font.data) return;
  display_.setTextDatum(datum);
  paintStaticSmoothText(display_, font, text, x, y, color,
                        [](int16_t, int16_t) { return kBackground; });
}

bool CawScreen::drawPaletteFrame(int16_t x, int16_t y, const uint8_t *data, uint16_t frame) {
  if (!cawIsPaletteAnimation(data) || frame >= cawPaletteFrames(data)) return false;
  const bool swapped = display_.getSwapBytes();
  display_.setSwapBytes(true);
  forEachPaletteRow(data, frame, [&](uint16_t line, uint16_t *pixels, uint16_t width) {
    display_.pushImage(x, y + line, width, 1, pixels);
  });
  display_.setSwapBytes(swapped);
  return true;
}

void CawScreen::drawPicture(int16_t x, int16_t y, const uint8_t *mdi) {
  if (cawIsPaletteAnimation(mdi)) {  // a built-in animation: its first frame
    drawPaletteFrame(x, y, mdi, 0);
    return;
  }
  // The ESP8266 sends 16-bit pixels little-endian; the panel wants them
  // big-endian, so pushImage must swap (this was the "noisy" logo).
  const bool swapped = display_.getSwapBytes();
  display_.setSwapBytes(true);
  forEachMdiRow(mdi ? mdi : CawPictures::crow(), [&](uint16_t line, uint16_t *pixels, uint16_t width) {
    display_.pushImage(x, y + line, width, 1, pixels);
  });
  display_.setSwapBytes(swapped);
}

// Uploaded picture (CawPictures file: "CWP1", 56, 56, then RGB565 LE rows).
// False (nothing drawn) when the file is missing or malformed.
// Reads one 56 x 56 frame from the current position of `file` and draws it.
bool CawScreen::drawFileFrame(int16_t x, int16_t y, File &file) {
  uint16_t row[kCawPictureSize];
  const bool swapped = display_.getSwapBytes();
  display_.setSwapBytes(true);  // stored little-endian, like the MDI2 pixels
  bool ok = true;
  for (int16_t line = 0; line < kCawPictureSize && ok; ++line) {
    ok = file.read(reinterpret_cast<uint8_t *>(row), sizeof(row)) == sizeof(row);
    if (ok) display_.pushImage(x, y + line, kCawPictureSize, 1, row);
  }
  display_.setSwapBytes(swapped);
  return ok;
}

// A static picture ("CWP1") or the first frame of an animation ("CWA1").
bool CawScreen::drawPictureFile(int16_t x, int16_t y, const char *path) {
  File file = LittleFS.open(path, "r");
  if (!file) return false;
  uint8_t header[kCawAnimHeaderBytes + 2 * kCawMaxFrames];
  const size_t size = file.size();
  const size_t length = file.read(header, size < sizeof(header) ? size : sizeof(header));
  size_t pixels = 0;
  if (size == kCawPictureFileBytes && length >= kCawPictureHeaderBytes &&
      memcmp(header, "CWP1", 4) == 0) {
    pixels = kCawPictureHeaderBytes;
  } else {
    CawAnimation animation;
    if (cawParseAnimation(header, length, size, animation)) pixels = animation.dataOffset;
  }
  bool ok = pixels != 0 && file.seek(pixels);
  if (ok) ok = drawFileFrame(x, y, file);
  file.close();
  return ok;
}

bool CawScreen::drawPaletteAnimationFrame(const uint8_t *data, uint16_t frame) {
  return pictureReady() && drawPaletteFrame(kPictureX, kPictureY, data, frame);
}

bool CawScreen::drawAnimationFrame(const char *path, uint32_t dataOffset, uint16_t frame) {
  if (!pictureReady()) return false;
  File file = LittleFS.open(path, "r");
  if (!file) return false;
  const bool ok = file.seek(dataOffset + static_cast<uint32_t>(frame) * kCawPicturePixelBytes) &&
                  drawFileFrame(kPictureX, kPictureY, file);
  file.close();
  return ok;
}

void CawScreen::drawStatic() {
  display_.fillScreen(kBackground);
  drawSmooth(18, "crow with", kTextX, kTitleY, ML_DATUM, kWhite);
  drawSmooth(18, "knife", kTextX + 87, kTitleY, ML_DATUM, kRed);
  display_.drawFastHLine(5, kDividerY, 230, kDivider);
  drawSmooth(13, "1H", 6, kChangeY, ML_DATUM, kGrey);
  drawSmooth(13, "24H", 105, kChangeY, ML_DATUM, kGrey);
  display_.drawFastHLine(5, 172, 230, kDivider);
  static const char *const titles[3] = {"liq", "vol", "mcap"};
  for (uint8_t index = 0; index < 3; ++index) {
    display_.drawRoundRect(kBoxX[index], kBoxY, kBoxW, kBoxH, 8, kBoxBorder);
    drawSmooth(13, titles[index], kBoxX[index] + kBoxW / 2, kBoxY + 10,
               MC_DATUM, kGrey);
  }
  staticDrawn_ = true;
}

void CawScreen::drawPrice(const char *text, uint16_t color) {
  display_.fillRect(2, kPriceTop, 236, kPriceHeight, kBackground);
  // One size for every price. Choosing the larger font whenever it fitted
  // made prices with a narrow "1" (e.g. $0.0\u20884715) jump to a bigger size
  // that touched the divider; this is the size prices normally show at.
  const CoverageFont *font = builtInCoverageFont(2);
  if (!font) return;
#if CAW_DUAL
  display_.setFreeFont(cawBoldFont36());  // width and missing-glyph fallback
#else
  display_.setFreeFont(&InterTightBold36);  // width and missing-glyph fallback
#endif
  display_.setTextDatum(BL_DATUM);
  paintCoverageText(display_, *font, text, 6, kPriceTextY, color,
                    [](int16_t, int16_t) { return kBackground; });
}

void CawScreen::drawChart(const CawScreenData &data, uint16_t color) {
  display_.fillRect(kChartX, kChartY, kChartW, kChartH, kBackground);
  if (!data.history || data.historyCount < 2) return;
  float low = INFINITY, high = -INFINITY;
  uint8_t valid = 0;
  for (uint8_t index = 0; index < data.historyCount; ++index) {
    const float value = data.history[index];
    if (std::isnan(value)) continue;
    low = std::min(low, value);
    high = std::max(high, value);
    ++valid;
  }
  if (valid < 2) {
    drawSmooth(13, "chart fills in over 24 hours", 120, kChartY + kChartH / 2,
               MC_DATUM, kDivider);
    return;
  }
  float range = high - low;
  if (range <= 0) range = std::fabs(high) * 0.02F + 1e-12F;
  low -= range * 0.08F;
  high += range * 0.08F;
  const int16_t left = kChartX + 4, right = kChartX + kChartW - 4;
  const int16_t top = kChartY + 3, bottom = kChartY + kChartH - 2;
  const uint16_t fill = display_.alphaBlend(32, color, kBackground);
  int16_t previousX = -1, previousY = 0;
  for (uint8_t index = 0; index < data.historyCount; ++index) {
    const float value = data.history[index];
    if (std::isnan(value)) continue;
    const int16_t x =
        left + static_cast<int32_t>(right - left) * index / (data.historyCount - 1);
    const int16_t y = bottom - static_cast<int16_t>(
                                   (value - low) / (high - low) * (bottom - top));
    if (previousX >= 0) {
      for (int16_t column = previousX; column <= x; ++column) {
        const int16_t lineY =
            previousY + (y - previousY) * (column - previousX) / std::max<int16_t>(1, x - previousX);
        display_.drawFastVLine(column, lineY + 1, bottom - lineY, fill);
      }
      display_.drawLine(previousX, previousY, x, y, color);
      display_.drawLine(previousX, previousY + 1, x, y + 1, color);
    }
    previousX = x;
    previousY = y;
  }
}

void CawScreen::drawTicker(const CawScreenData &data, uint16_t ring,
                           uint16_t moves) {
  display_.fillRoundRect(2, kTickerY, 236, 24, 8, ring);
  display_.fillRoundRect(4, kTickerY + 2, 232, 20, 7, kBackground);
  char ticker[48];
  snprintf(ticker, sizeof(ticker), "▶ caw  %s", data.price);
  drawSmooth(13, ticker, 9, kTickerY + 12, ML_DATUM, kWhite);
  char changes[40];
  snprintf(changes, sizeof(changes), "%s  %s", data.change1h, data.change24h);
  drawSmooth(13, changes, 230, kTickerY + 12, MR_DATUM, moves);
}

void CawScreen::update(const CawScreenData &data) {
  if (!staticDrawn_) drawStatic();

  char clock[8] = "--:--";
  const time_t now = time(nullptr);
  if (now > 1700000000) {
    struct tm local {};
    localtime_r(&now, &local);
    if (data.clock24) {
      snprintf(clock, sizeof(clock), "%02d:%02d", local.tm_hour, local.tm_min);
    } else {  // 12-hour, no AM/PM: "7:05" (the row has no room for more)
      const int hour = local.tm_hour % 12 == 0 ? 12 : local.tm_hour % 12;
      snprintf(clock, sizeof(clock), "%d:%02d", hour, local.tm_min);
    }
  }
  // Top-left picture: the crow, a built-in meme or an uploaded one. An
  // unreadable upload falls back to the crow.
  if (!pictureValid_ || pictureKey_ != data.pictureKey) {
    pictureKey_ = data.pictureKey;
    pictureValid_ = true;
    if (!data.picturePath || !drawPictureFile(kPictureX, kPictureY, data.picturePath))
      drawPicture(kPictureX, kPictureY, data.picturePath ? nullptr : data.picture);
  }

  // Chain logo and name on the second row (rotates through the chains).
  if (changed(chain_, data.chain, kWhite)) {
    display_.fillRect(kTextX - 1, kPairY - 12, 175 - kTextX, 25, kBackground);
    int16_t textX = kTextX;
    if (const uint16_t *icon = cawChainIcon(data.chainId)) {
      const bool swapped = display_.getSwapBytes();
      display_.setSwapBytes(true);  // RGB565 stored little-endian, as the logo
      display_.pushImage(kTextX, kPairY - kChainIconSize / 2, kChainIconSize, kChainIconSize, icon);
      display_.setSwapBytes(swapped);
      textX += kChainIconSize + 5;
    }
    drawSmooth(18, data.chain, textX, kPairY, ML_DATUM, kWhite);
  }

  // Wi-Fi icon top right; clock under it, right-aligned on the second row.
  if (changed(clock_, clock, kWhite)) {
    display_.fillRect(176, kPairY - 12, 62, 25, kBackground);
    drawSmooth(18, clock, 235, kPairY, MR_DATUM, kWhite);
  }

  const uint16_t wifiColor = data.wifiConnected ? kWhite : kRed;
  const char *wifiIcon = data.wifiConnected ? "" : "";
  if (changed(wifi_, wifiIcon, wifiColor)) {
    display_.fillRect(210, kTitleY - 13, 28, 25, kBackground);
    drawSmooth(18, wifiIcon, 235, kTitleY, MR_DATUM, wifiColor);
  }

  const uint16_t priceColor =
      data.priceFlash > 0 ? kGreen : data.priceFlash < 0 ? kRed : kWhite;
  if (changed(price_, data.price, priceColor)) drawPrice(data.price, priceColor);

  const uint16_t h1Color = changeColor(data.change1h);
  if (changed(h1_, data.change1h, h1Color)) {
    display_.fillRect(24, kChangeY - 12, 76, 25, kBackground);
    drawSmooth(18, data.change1h, 28, kChangeY, ML_DATUM, h1Color);
  }
  const uint16_t h24Color = changeColor(data.change24h);
  if (changed(h24_, data.change24h, h24Color)) {
    display_.fillRect(134, kChangeY - 12, 76, 25, kBackground);
    drawSmooth(18, data.change24h, 138, kChangeY, ML_DATUM, h24Color);
  }

  Cache *boxes[3] = {&liq_, &vol_, &mcap_};
  const char *values[3] = {data.liquidity, data.volume, data.marketCap};
  for (uint8_t index = 0; index < 3; ++index) {
    if (!changed(*boxes[index], values[index], kWhite)) continue;
    display_.fillRect(kBoxX[index] + 3, kBoxY + 19, kBoxW - 6, kBoxH - 21, kBackground);
    drawSmooth(18, values[index], kBoxX[index] + kBoxW / 2, kBoxY + 30,
               MC_DATUM, kWhite);
  }

  // Red on down days (24-hour change); the ring alone turns grey when stale.
  const bool down = data.change24h[0] == '-';
  const uint16_t chartColor = down ? kRed : kGreen;
  const uint16_t trend = data.live ? chartColor : kGrey;
  if (chartVersion_ != data.historyVersion || chartColor_ != chartColor) {
    chartVersion_ = data.historyVersion;
    chartColor_ = chartColor;
    drawChart(data, chartColor);
  }

  char movesKey[40];
  snprintf(movesKey, sizeof(movesKey), "%s %s", data.change1h, data.change24h);
  const bool ringChanged = changed(ring_, data.live ? "live" : "stale", trend);
  const bool tickerChanged = changed(ticker_, data.price, kWhite);
  const bool movesChanged = changed(moves_, movesKey, h1Color);
  if (ringChanged || tickerChanged || movesChanged) drawTicker(data, trend, h1Color);
}

void CawScreen::showMessageLine(uint8_t line, const char *text) {
  if (line > 4) return;
  const int16_t y = 121 + 23 * line;  // as in showMessage
  display_.fillRect(0, y - 11, 240, 23, kBackground);
  if (text && text[0]) drawSmooth(18, text, 120, y, MC_DATUM, kGrey);
}

void CawScreen::showMessage(const char *title, const char *line1,
                            const char *line2, const char *line3,
                            const char *line4, const char *line5) {
  display_.fillScreen(kBackground);
  drawPicture(120 - kCawPictureSize / 2, 8, nullptr);
  drawSmooth(24, title, 120, 88, MC_DATUM, kWhite);
  const char *lines[5] = {line1, line2, line3, line4, line5};
  int16_t y = 121;
  for (const char *line : lines) {
    if (line && line[0]) {
      // Long lines (e.g. the setup network name) drop to 13 px to stay on screen.
      const StaticSmoothFont medium = smoothFont(18);
      const uint8_t size = medium.width(line) > 232 ? 13 : 18;
      drawSmooth(size, line, 120, y, MC_DATUM, kGrey);
    }
    y += 23;
  }
  invalidate();
}

#endif  // CAW_STANDALONE
