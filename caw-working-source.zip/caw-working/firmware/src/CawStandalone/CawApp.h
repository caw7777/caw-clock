#pragma once

// Entry points of the CAW app (the standalone CAW screen, feeds and panel).
// The CAW-only firmware calls them from setup()/loop(); the CAW + Home
// Assistant firmware calls them instead of its own when it boots in CAW mode.
#if CAW_STANDALONE
void cawAppSetup();
void cawAppLoop();
#endif
