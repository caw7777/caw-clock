#if CAW_STANDALONE

#include "CawFeedLite.h"

#include <ArduinoJson.h>
#include <LittleFS.h>
#include <StackThunk.h>
#include <WiFiClientSecureBearSSL.h>

#include <cmath>
#include <memory>
#include <new>

#include "../CawHttp.h"
#include "../CawMarketFormat.h"
#include "../CawOhlcv.h"
#include "../CawPriceFormat.h"
#include "../CawProbe/ProbeTrustAnchors.h"
#include "../CawSchedule.h"
#include "CawCrashLog.h"
#include "../DecimalParser.h"

namespace {

constexpr uint32_t kRefreshMs = 5UL * 60UL * 1000UL;
constexpr uint32_t kRetryMs = 60UL * 1000UL;
constexpr uint32_t kMaximumRetryMs = 15UL * 60UL * 1000UL;
constexpr uint32_t kLiveForMs = 15UL * 60UL * 1000UL;
constexpr uint32_t kTimeoutMs = 10000;
constexpr uint32_t kBucketSeconds = 1800;
// The full-size (16 KiB) receive buffer needs ~28 KB in all.
constexpr uint32_t kFullBufferMinimumHeap = 30000;
constexpr uint32_t kFullBufferMinimumBlock = 20000;
// HTTPS needs, besides the trust anchors: BearSSL's 6,200-byte stack (the
// core calls abort() when it cannot allocate it, which restarts the clock),
// the 4 KiB + 512 B record buffers and the engine. Measured on the device: a
// 4 KiB fetch takes ~21 KB of heap with four anchors. Below these limits the
// fetch is skipped ("low_memory") instead of risking that abort.
constexpr uint32_t kTlsMinimumFreeHeap = 20000;
constexpr uint32_t kTlsMinimumBlock = 6200 + 1024;
// Back-fill when fewer buckets than this hold data; at most hourly.
constexpr uint8_t kBackfillBelowPoints = 40;
constexpr uint32_t kBackfillIntervalMs = 60UL * 60UL * 1000UL;
constexpr char kCacheTempPath[] = "/caw-market.tmp";

enum class Kind : uint8_t { DexScreener, GeckoTerminal };

// Most of BearSSL's separate 6 KB stack used by any connection so far. The
// stack exists only while a secure client exists, so it is read just before
// each client is destroyed (TlsStackNote); reading it later always gave 0.
uint32_t gTlsStackMax = 0;

struct TlsStackNote {
  ~TlsStackNote() {
    const uint32_t used = stack_thunk_get_max_usage();
    if (used > gTlsStackMax) gTlsStackMax = used;
  }
};

}  // namespace

// The deepest CAW pool on each chain (DexScreener search, 2026-11-15):
// Cronos VVS CAW/WCRO ($715K liquidity), Solana Raydium CAW/SOL ($23K),
// Base Uniswap CAW/WETH ($23K), Robinhood Uniswap CAW/WETH ($10K).
const CawChain kCawChains[kCawChainCount] = {
    {"cronos", "cronos", "wcro", "cronos", "cro",
     "0xc7a139c804a3bbdfe90d32c100dffeca1a2f735c"},
    {"solana", "solana", "sol", "solana", "solana",
     "4feuGCH11HoEjK19dZJFmotAKAYd1ZEG77aKz9gLWYuH"},
    {"base", "base", "weth", "base", "base",
     "0x110751cbf035862f59a10528dd54b9ac2b048906"},
    {"robinhood", "robinhood", "weth", "robinhood", "robinhood",
     "0xf1dea610bcd74419924f511f0ab324e5c591074d"},
};

struct CawFeedLite::Source {
  const char *name;
  const char *host;
  const char *pathFormat;  // chain id, pair address
  const char *accept;
  uint16_t receiveBytes;  // 0 = BearSSL default (16 KiB + overhead)
  Kind kind;
};

namespace {

constexpr char kDexHost[] = "api.dexscreener.com";
constexpr char kDexPath[] = "/latest/dex/pairs/%s/%s";
const CawFeedLite::Source kSources[] = {
    {"dexscreener", kDexHost, kDexPath, "application/json", 4096, Kind::DexScreener},
    {"dexscreener-full", kDexHost, kDexPath, "application/json", 0, Kind::DexScreener},
    {"geckoterminal", "api.geckoterminal.com", "/api/v2/networks/%s/pools/%s",
     "application/json;version=20230302", 4096, Kind::GeckoTerminal},
};
constexpr uint8_t kSourceCount = sizeof(kSources) / sizeof(kSources[0]);

// `receiveBytes` 0 = BearSSL's default full-size buffers.
bool tlsMemoryAvailable(uint16_t receiveBytes = 4096) {
  const bool full = receiveBytes == 0;
  return ESP.getFreeHeap() >= (full ? kFullBufferMinimumHeap : kTlsMinimumFreeHeap) &&
         ESP.getMaxFreeBlockSize() >= (full ? kFullBufferMinimumBlock : kTlsMinimumBlock);
}

// Whether the secure connection can get all its memory at once. The core
// calls abort() when one of BearSSL's allocations fails, and the free-heap
// figure doesn't show fragmentation: a crash on the clock came from a 3,080-byte
// request that failed with plenty of memory free in total. So ask the allocator
// for the same set of blocks the connection will need (BearSSL's 6,200-byte
// stack, the two record buffers, the client and X.509 contexts, and some
// slack for the small allocations around them), then give them back. Cheap,
// and a failure here is a "low_memory" result instead of a restart.
bool tlsHeapProbe(uint16_t receiveBytes) {
  constexpr size_t kStackBytes = 6200;      // BearSSL stack (StackThunk.cpp)
  constexpr size_t kFullReceive = 16709;    // BR_SSL_BUFSIZE_INPUT
  constexpr size_t kSendBytes = 512;
  constexpr size_t kSlack = 2048;           // shared_ptr blocks, session, strings
  constexpr size_t kMargin = 48;            // allocator headers and rounding
  const size_t sizes[] = {kStackBytes,
                          receiveBytes ? receiveBytes : kFullReceive,
                          kSendBytes,
                          sizeof(br_ssl_client_context),
                          sizeof(br_x509_minimal_context),
                          kSlack};
  void *blocks[sizeof(sizes) / sizeof(sizes[0])]{};
  bool ok = true;
  for (size_t index = 0; index < sizeof(sizes) / sizeof(sizes[0]) && ok; ++index) {
    blocks[index] = malloc(sizes[index] + kMargin);
    ok = blocks[index] != nullptr;
  }
  for (void *block : blocks) free(block);
  return ok;
}

// readBytes honours the client timeout; read() would return -1 whenever the
// next TLS record has not arrived yet.
int readByte(BearSSL::WiFiClientSecure &client) {
  char c;
  return client.readBytes(&c, 1) == 1 ? static_cast<unsigned char>(c) : -1;
}

constexpr int kHttpNoConnection = -1;

// TLS sessions, one per host. After one full handshake (certificate chain
// checked against the trust anchors, ECDHE key exchange) later connections
// to the same host resume the session: a short handshake with no signature
// checks or key exchange, so the CPU is busy for a fraction of the time. The
// long crypto steps of a full handshake do not yield to the Wi-Fi stack; both
// crashes seen in testing hit during a fetch (one inside the Wi-Fi driver,
// one a watchdog reset), so fewer full handshakes means fewer of those
// windows. Security is unchanged: a session only exists after a fully
// verified handshake, and the server can always refuse it (then the client
// does the full handshake again).
BearSSL::Session gDexSession;
BearSSL::Session gGeckoSession;

BearSSL::Session &sessionFor(const char *host) {
  return strcmp(host, "api.geckoterminal.com") == 0 ? gGeckoSession : gDexSession;
}

// Session id offered before the connection. The core copies the negotiated
// session into the Session object in stop(); the same non-empty id then
// means the server accepted the resumption.
struct SessionId {
  uint8_t bytes[32];
  uint8_t length;
};
SessionId sessionId(BearSSL::Session &session) {
  SessionId id{};
  // BearSSL::Session holds exactly one br_ssl_session_parameters (its
  // accessor is private); the class is standard-layout, so its address is
  // the member's.
  static_assert(sizeof(BearSSL::Session) == sizeof(br_ssl_session_parameters), "Session layout");
  const auto *parameters = reinterpret_cast<const br_ssl_session_parameters *>(&session);
  id.length = parameters->session_id_len > sizeof(id.bytes) ? sizeof(id.bytes)
                                                            : parameters->session_id_len;
  memcpy(id.bytes, parameters->session_id, id.length);
  return id;
}
bool sameSession(const SessionId &a, const SessionId &b) {
  return a.length && a.length == b.length && memcmp(a.bytes, b.bytes, a.length) == 0;
}

// Connects, sends the GET and consumes the status line and headers, leaving
// the client at the start of the body. Returns the HTTP status, 0 when the
// response is not HTTP, or kHttpNoConnection. HTTP/1.0: no chunked encoding,
// so the body can be parsed straight from the stream.
int httpsGet(BearSSL::WiFiClientSecure &client, const char *host, const char *path,
             const char *accept, uint32_t *connectMs = nullptr) {
  const uint32_t started = millis();
  const bool connected = client.connect(host, 443);
  if (connectMs) *connectMs = millis() - started;
  if (!connected) return kHttpNoConnection;
  client.printf_P(PSTR("GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: CAW-Clock/1.0\r\n"
                       "Accept: %s\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n"),
                  path, host, accept);
  const auto read = [&client] { return readByte(client); };
  const int status = readHttpStatus(read);
  if (status != 200) return status;
  return skipHttpHeaders(read) ? 200 : 0;
}

constexpr char kGeckoHost[] = "api.geckoterminal.com";
constexpr char kGeckoAccept[] = "application/json;version=20230302";

// Builds with the CAW BearSSL client profile (MINI_DISPLAY_FEATURE_CAW, i.e.
// the CAW + Home Assistant firmware) verify ECDSA only, so the RSA roots could
// never complete a chain there; leaving them out saves ~4 KB per fetch. Both
// APIs (Cloudflare) serve ECDSA chains to GTS Root R4 or ISRG Root X2.
void loadTrustAnchors(BearSSL::X509List &anchors) {
  anchors.append(kGtsRootR4);
  anchors.append(kIsrgRootX2);
#if !MINI_DISPLAY_FEATURE_CAW
  anchors.append(kGtsRootR1);
  anchors.append(kIsrgRootX1);
#endif
}

bool parseDex(JsonObjectConst pair, CawMarket &out) {
  char fdv[24]{};
  const bool ok =
      copyPrice(pair["priceUsd"] | "", out.price, sizeof(out.price)) &&
      format24hChange(pair["priceChange"]["h1"], out.change1h, sizeof(out.change1h)) &&
      format24hChange(pair["priceChange"]["h24"], out.change24h, sizeof(out.change24h)) &&
      compactUsd(pair["liquidity"]["usd"], out.liquidity, sizeof(out.liquidity)) &&
      compactUsd(pair["volume"]["h24"], out.volume, sizeof(out.volume)) &&
      compactUsd(pair["fdv"], fdv, sizeof(fdv));
  if (!ok) return false;
  if (!compactUsd(pair["marketCap"], out.marketCap, sizeof(out.marketCap)) ||
      strcmp(out.marketCap, "N/A") == 0) {
    strlcpy(out.marketCap, fdv, sizeof(out.marketCap));
  }
  return true;
}

bool parseGecko(JsonObjectConst attributes, CawMarket &out) {
  char fdv[24]{};
  const bool ok =
      copyPrice(attributes["base_token_price_usd"] | "", out.price, sizeof(out.price)) &&
      format24hChange(attributes["price_change_percentage"]["h1"], out.change1h,
                      sizeof(out.change1h)) &&
      format24hChange(attributes["price_change_percentage"]["h24"], out.change24h,
                      sizeof(out.change24h)) &&
      compactUsd(attributes["reserve_in_usd"], out.liquidity, sizeof(out.liquidity)) &&
      compactUsd(attributes["volume_usd"]["h24"], out.volume, sizeof(out.volume)) &&
      compactUsd(attributes["fdv_usd"], fdv, sizeof(fdv));
  if (!ok) return false;
  if (!compactUsd(attributes["market_cap_usd"], out.marketCap, sizeof(out.marketCap)) ||
      strcmp(out.marketCap, "N/A") == 0) {
    strlcpy(out.marketCap, fdv, sizeof(out.marketCap));
  }
  return true;
}

}  // namespace

void CawFeedLite::begin(bool filesystemReady) {
  filesystemReady_ = filesystemReady;
  // Cronos keeps the original file name, so its cache survives the upgrade.
  if (&chain_ == &kCawChains[0]) strlcpy(cachePath_, "/caw-market.json", sizeof(cachePath_));
  else snprintf(cachePath_, sizeof(cachePath_), "/caw-market-%s.json", chain_.id);
  for (float &value : history_) value = NAN;
  loadCache();
}

bool CawFeedLite::due() const {
  return nextAttemptAt_ == 0 ||
         static_cast<int32_t>(millis() - nextAttemptAt_) >= 0;
}

const char *CawFeedLite::displayPrice() const { return market_.valid ? display_ : "--"; }

void CawFeedLite::setMarket(const CawMarket &market) {
  market_ = market;
  strlcpy(display_, compactDisplayPrice(market_.price), sizeof(display_));
}

bool CawFeedLite::live() const {
  return market_.valid && lastSuccessAt_ != 0 &&
         millis() - lastSuccessAt_ < kLiveForMs;
}

int32_t CawFeedLite::secondsSinceSuccess() const {
  return lastSuccessAt_ ? static_cast<int32_t>((millis() - lastSuccessAt_) / 1000) : -1;
}

void CawFeedLite::noteConnect(uint32_t milliseconds, bool resumed) {
  lastConnectMs_ = milliseconds;
  if (milliseconds > maxConnectMs_) maxConnectMs_ = milliseconds;
  ++connections_;
  if (resumed) ++resumed_;
}

bool CawFeedLite::fetchFrom(const Source &source, time_t now, CawMarket &out) {
  lastSource_ = source.name;
  lastHttpStatus_ = 0;
  lastSslError_ = 0;
  lastFetchFreeHeap_ = ESP.getFreeHeap();
  lastFetchMaxBlock_ = ESP.getMaxFreeBlockSize();
  lastFetchMinimumHeap_ = lastFetchFreeHeap_;
  if (!tlsMemoryAvailable(source.receiveBytes)) {
    lastResult_ = "low_memory";
    return false;
  }
  cawStage(21, chain_.id[0]);
  BearSSL::X509List anchors;
  loadTrustAnchors(anchors);
  cawStage(22, chain_.id[0]);
  // With the anchors loaded, check that the connection's memory is really
  // there as separate blocks (see tlsHeapProbe).
  if (!tlsMemoryAvailable(source.receiveBytes) || !tlsHeapProbe(source.receiveBytes)) {
    lastResult_ = "low_memory";
    return false;
  }
  cawStage(23, chain_.id[0]);
  // The client lives on the heap, not the 4 KB main stack, which also has to
  // hold the lwIP calls and Wi-Fi interrupts during the connect.
  std::unique_ptr<BearSSL::WiFiClientSecure> owned(new (std::nothrow) BearSSL::WiFiClientSecure);
  if (!owned) {
    lastResult_ = "low_memory";
    return false;
  }
  BearSSL::WiFiClientSecure &client = *owned;
  const TlsStackNote tlsStackNote;  // destroyed before the client
  cawStage(24, chain_.id[0]);
  if (source.receiveBytes) client.setBufferSizes(source.receiveBytes, 512);
  client.setTrustAnchors(&anchors);
  client.setX509Time(now);
  client.setTimeout(kTimeoutMs);
  BearSSL::Session &session = sessionFor(source.host);
  client.setSession(&session);
  const SessionId before = sessionId(session);
  static char path[112];  // static: one fetch at a time, keeps the stack small
  snprintf(path, sizeof(path), source.pathFormat,
           source.kind == Kind::DexScreener ? chain_.dexChain : chain_.geckoNetwork,
           chain_.pair);
  cawStage(25, chain_.id[0]);
  uint32_t connectMs = 0;
  const int status = httpsGet(client, source.host, path, source.accept, &connectMs);
  cawStage(26, chain_.id[0]);
  lastFetchMinimumHeap_ = std::min<uint32_t>(lastFetchMinimumHeap_, ESP.getFreeHeap());
  if (status == kHttpNoConnection) {
    // No SSL error means the TCP connection itself failed (no route, DNS).
    lastSslError_ = client.getLastSSLError();
    lastResult_ = lastSslError_ ? "tls_error" : "no_connection";
    return false;
  }
  lastHttpStatus_ = status;
  if (status != 200) {
    lastResult_ = status ? "http_status" : "no_response";
    client.stop();
    noteConnect(connectMs, sameSession(before, sessionId(session)));
    return false;
  }

  // Both documents are static, not on the stack: the main loop's stack is
  // 4 KB and Wi-Fi interrupts run on it too. During a TLS connect it held
  // fetchFrom's 1.5 KB frame, the WiFiClientSecure/lwIP calls and the
  // interrupt frames, and overflowed (reset 253 "stack smash", and before
  // that crashes inside the Wi-Fi driver). One fetch runs at a time.
  static StaticJsonDocument<256> filter;
  filter.clear();
  if (source.kind == Kind::DexScreener) {
    JsonObject pair = filter["pairs"].createNestedObject();
    pair["priceUsd"] = true;
    pair["priceChange"]["h1"] = true;
    pair["priceChange"]["h24"] = true;
    pair["liquidity"]["usd"] = true;
    pair["volume"]["h24"] = true;
    pair["fdv"] = true;
    pair["marketCap"] = true;
  } else {
    JsonObject attributes = filter.createNestedObject("data").createNestedObject("attributes");
    attributes["base_token_price_usd"] = true;
    attributes["price_change_percentage"]["h1"] = true;
    attributes["price_change_percentage"]["h24"] = true;
    attributes["reserve_in_usd"] = true;
    attributes["volume_usd"]["h24"] = true;
    attributes["fdv_usd"] = true;
    attributes["market_cap_usd"] = true;
  }
  cawStage(27);
  static StaticJsonDocument<768> document;
  document.clear();
  const DeserializationError error =
      deserializeJson(document, client, DeserializationOption::Filter(filter),
                      DeserializationOption::NestingLimit(8));
  lastFetchMinimumHeap_ = std::min<uint32_t>(lastFetchMinimumHeap_, ESP.getFreeHeap());
  client.stop();  // also saves the TLS session for the next connection
  noteConnect(connectMs, sameSession(before, sessionId(session)));
  if (error) {
    lastResult_ = "json";
    return false;
  }
  cawStage(28);
  out = CawMarket{};
  const bool parsed =
      source.kind == Kind::DexScreener
          ? parseDex(document["pairs"][0].as<JsonObjectConst>(), out)
          : parseGecko(document["data"]["attributes"].as<JsonObjectConst>(), out);
  if (!parsed) {
    lastResult_ = "invalid_fields";
    return false;
  }
  out.valid = true;
  lastResult_ = "ok";
  return true;
}

bool CawFeedLite::fetch(time_t now) {
  const char *unreachable = nullptr;  // host that refused the connection
  // Try the source that worked last time first, so a pool one source no
  // longer serves (DexScreener dropped the Robinhood pair) costs one request,
  // not two. The first source is tried first again every sixth fetch.
  uint8_t order[kSourceCount];
  sourceOrder(preferred_, fetches_, kSourceCount, order);
  // The full-size (16 KiB buffer) DexScreener request needs ~36 KB and the
  // clock has ~38 KB free, so it can abort the clock when the heap is not
  // laid out well. It only helps when the first request failed inside TLS
  // (a record bigger than the 4 KiB buffer); a wrong or empty answer comes
  // back the same whatever the buffer size.
  bool fullBufferUseful = false;
  for (const uint8_t sourceIndex : order) {
    const Source &source = kSources[sourceIndex];
    const bool primary = sourceIndex == 0;
    if (sourceIndex == 1 && !fullBufferUseful) continue;
    // The same host was unreachable a moment ago: don't wait out a second
    // connection timeout on it.
    if (unreachable && strcmp(unreachable, source.host) == 0) continue;
    CawMarket next;
    const bool fetched = fetchFrom(source, now, next);
    if (primary) {
      primaryResult_ = lastResult_;
      fullBufferUseful = !fetched && (strcmp(lastResult_, "tls_error") == 0 ||
                                      strcmp(lastResult_, "no_response") == 0);
    }
    if (!fetched) {
      if (strcmp(lastResult_, "no_connection") == 0) unreachable = source.host;
      yield();
      continue;
    }
    cawStage(29);
    setMarket(next);
    preferred_ = sourceIndex == 2 ? 2 : 0;  // DexScreener (either size) or GeckoTerminal
    if (fetches_ < 255) ++fetches_;
    const bool first = lastSuccessAt_ == 0;
    lastSuccessAt_ = millis();
    if (lastSuccessAt_ == 0) lastSuccessAt_ = 1;
    failures_ = 0;
    nextAttemptAt_ = millis() + kRefreshMs + (first ? staggerMs_ : 0);
    if (nextAttemptAt_ == 0) nextAttemptAt_ = 1;  // 0 means "never fetched"

    float price = 0.0F;
    if (parseDecimalFloat(market_.price[0] == '$' ? market_.price + 1 : market_.price,
                          price) &&
        std::isfinite(price) && price > 0.0F) {
      record(price, now);
      // DexScreener leaves out priceChange.h1 when the pair had no trades in
      // the last hour. Use the chart's price from about an hour ago instead
      // (buckets 30-90 minutes old), which is ~0% in that case.
      if (strcmp(market_.change1h, "N/A") == 0) {
        const float a = history_[kHistoryPoints - 3], b = history_[kHistoryPoints - 2];
        const float earlier = std::isnan(a) ? b : std::isnan(b) ? a : (a + b) / 2.0F;
        if (std::isfinite(earlier) && earlier > 0.0F) {
          formatChangePercent((static_cast<double>(price) / earlier - 1.0) * 100.0,
                              market_.change1h, sizeof(market_.change1h));
        }
      }
    }
    bool backfilled = false;
    if (historyPoints() < kBackfillBelowPoints &&
        (lastBackfillAt_ == 0 || millis() - lastBackfillAt_ >= kBackfillIntervalMs)) {
      lastBackfillAt_ = millis();
      if (lastBackfillAt_ == 0) lastBackfillAt_ = 1;
      cawStage(30);
      backfilled = backfill(now);
    }
    cawStage(31);
    // One flash write per 30-minute bucket (and after a back-fill): the chart
    // is what a restart needs; the figures are refreshed minutes later anyway.
    if (filesystemReady_ &&
        (lastCacheSavedAt_ == 0 || historyBucket_ != savedBucket_ || backfilled)) {
      saveCache();
    }
    return true;
  }
  nextAttemptAt_ = millis() + retryDelayMs(failures_, kRetryMs, kMaximumRetryMs);
  if (nextAttemptAt_ == 0) nextAttemptAt_ = 1;
  if (failures_ < 255) ++failures_;
  return false;
}

uint8_t CawFeedLite::historyPoints() const {
  uint8_t count = 0;
  for (float value : history_) count += std::isnan(value) ? 0 : 1;
  return count;
}

// Make `bucket` the newest slot, shifting older values left.
void CawFeedLite::advanceTo(uint32_t bucket) {
  if (historyBucket_ == 0 || bucket >= historyBucket_ + kHistoryPoints) {
    for (float &value : history_) value = NAN;
  } else if (bucket > historyBucket_) {
    const uint32_t shift = bucket - historyBucket_;
    for (uint8_t index = 0; index < kHistoryPoints; ++index)
      history_[index] = index + shift < kHistoryPoints ? history_[index + shift] : NAN;
  } else {
    return;
  }
  historyBucket_ = bucket;
  bucketSamples_ = 0;
}

void CawFeedLite::record(float price, time_t now) {
  const uint32_t bucket = static_cast<uint32_t>(now) / kBucketSeconds;
  if (historyBucket_ != 0 && bucket < historyBucket_) return;  // clock moved back
  advanceTo(bucket);
  float &newest = history_[kHistoryPoints - 1];
  // Mean of the samples in the current 30-minute bucket.
  newest = bucketSamples_ == 0 || std::isnan(newest)
               ? price
               : newest + (price - newest) / static_cast<float>(bucketSamples_ + 1);
  ++bucketSamples_;
  ++historyVersion_;
}

// GeckoTerminal hourly candles for the last 24 h, read as a stream (CawOhlcv.h).
// Each candle fills its two 30-minute buckets (open, then close). Only empty
// buckets are written, and never the newest (live) one. Same TLS settings and
// certificate validation as the price fetch.
bool CawFeedLite::backfill(time_t now) {
  if (!tlsMemoryAvailable()) {
    backfillResult_ = "low_memory";
    return false;
  }
  BearSSL::X509List anchors;
  loadTrustAnchors(anchors);
  if (!tlsMemoryAvailable() || !tlsHeapProbe(4096)) {
    backfillResult_ = "low_memory";
    return false;
  }
  std::unique_ptr<BearSSL::WiFiClientSecure> owned(new (std::nothrow) BearSSL::WiFiClientSecure);
  if (!owned) {
    backfillResult_ = "low_memory";
    return false;
  }
  BearSSL::WiFiClientSecure &client = *owned;
  const TlsStackNote tlsStackNote;  // destroyed before the client
  client.setBufferSizes(4096, 512);
  client.setTrustAnchors(&anchors);
  client.setX509Time(now);
  client.setTimeout(kTimeoutMs);
  client.setSession(&gGeckoSession);
  static char path[160];  // static: one fetch at a time
  snprintf(path, sizeof(path),
           "/api/v2/networks/%s/pools/%s/ohlcv/hour?aggregate=1&limit=25&currency=usd",
           chain_.geckoNetwork, chain_.pair);
  const int status = httpsGet(client, kGeckoHost, path, kGeckoAccept);
  if (status != 200) {
    backfillResult_ = status == kHttpNoConnection
                          ? (client.getLastSSLError() ? "tls_error" : "no_connection")
                          : "http_status";
    client.stop();
    return false;
  }
  const uint32_t current = static_cast<uint32_t>(now) / kBucketSeconds;
  if (historyBucket_ == 0 || current > historyBucket_) advanceTo(current);
  uint8_t filled = 0;
  uint32_t carryStart = 0;
  float carry = NAN;
  const auto put = [&](uint32_t bucket, float price) {
    if (!(price > 0.0F) || !std::isfinite(price) || bucket >= historyBucket_) return;
    const uint32_t age = historyBucket_ - bucket;
    if (age >= kHistoryPoints) return;
    float &slot = history_[kHistoryPoints - 1 - age];
    if (!std::isnan(slot)) return;
    slot = price;
    ++filled;
  };
  const uint16_t candles = parseOhlcvList(
      [&client] { return readByte(client); },
      [&](uint32_t start, float open, float close) {
        const uint32_t bucket = start / kBucketSeconds;
        // Newest candle that ends before the window: its close is the price
        // at the window's start.
        if (bucket + 1 + kHistoryPoints <= historyBucket_) {
          if (start > carryStart && close > 0.0F && std::isfinite(close)) {
            carryStart = start;
            carry = close;
          }
          return;
        }
        put(bucket, open);
        put(bucket + 1, close);
      });
  client.stop();
  if (candles == 0) {
    backfillResult_ = "no_candles";
    return false;
  }
  // GeckoTerminal leaves out hours without trades, i.e. hours where the price
  // did not move: carry the last price forward through those gaps (but not
  // into the newest bucket, which only live samples fill).
  float last = carry;
  for (uint8_t index = 0; index + 1 < kHistoryPoints; ++index) {
    if (!std::isnan(history_[index])) {
      last = history_[index];
    } else if (!std::isnan(last)) {
      history_[index] = last;
      ++filled;
    }
  }
  if (filled) ++historyVersion_;
  backfillResult_ = filled ? "ok" : "nothing_to_fill";
  return filled != 0;
}

void CawFeedLite::loadCache() {
  if (!filesystemReady_ || !LittleFS.exists(cachePath_)) return;
  File file = LittleFS.open(cachePath_, "r");
  if (!file) return;
  DynamicJsonDocument document(2048);
  const DeserializationError error = deserializeJson(document, file);
  file.close();
  if (error || (document["schemaVersion"] | 0) != 1) return;
  CawMarket cached;
  const auto copy = [](JsonVariantConst value, char *destination, size_t capacity) {
    const char *text = value | "";
    if (!text[0] || strlen(text) >= capacity) return false;
    strlcpy(destination, text, capacity);
    return true;
  };
  if (copy(document["price"], cached.price, sizeof(cached.price)) &&
      copy(document["change1h"], cached.change1h, sizeof(cached.change1h)) &&
      copy(document["change24h"], cached.change24h, sizeof(cached.change24h)) &&
      copy(document["liquidity"], cached.liquidity, sizeof(cached.liquidity)) &&
      copy(document["volume"], cached.volume, sizeof(cached.volume)) &&
      copy(document["marketCap"], cached.marketCap, sizeof(cached.marketCap))) {
    cached.valid = true;
    setMarket(cached);  // shown as stale until the first fetch succeeds
  }
  JsonArrayConst points = document["history"];
  const uint32_t bucket = document["historyBucket"] | 0;
  if (bucket && points.size() == kHistoryPoints) {
    uint8_t index = 0;
    for (JsonVariantConst point : points)
      history_[index++] = point.is<float>() ? point.as<float>() : NAN;
    historyBucket_ = bucket;
    savedBucket_ = bucket;
    bucketSamples_ = 1;
    ++historyVersion_;
  }
}

void CawFeedLite::saveCache() {
  DynamicJsonDocument document(2048);
  document["schemaVersion"] = 1;
  document["price"] = market_.price;
  document["change1h"] = market_.change1h;
  document["change24h"] = market_.change24h;
  document["liquidity"] = market_.liquidity;
  document["volume"] = market_.volume;
  document["marketCap"] = market_.marketCap;
  document["historyBucket"] = historyBucket_;
  JsonArray points = document.createNestedArray("history");
  for (float value : history_) {
    if (std::isnan(value)) points.add(nullptr);
    else points.add(value);
  }
  File file = LittleFS.open(kCacheTempPath, "w");
  if (!file) return;
  const bool written = serializeJson(document, file) > 0 && !file.getWriteError();
  file.close();
  if (!written) {
    LittleFS.remove(kCacheTempPath);
    return;
  }
  LittleFS.remove(cachePath_);
  if (LittleFS.rename(kCacheTempPath, cachePath_)) {
    lastCacheSavedAt_ = millis();
    savedBucket_ = historyBucket_;
  }
}

uint32_t cawTlsStackMax() { return gTlsStackMax; }

#endif  // CAW_STANDALONE
