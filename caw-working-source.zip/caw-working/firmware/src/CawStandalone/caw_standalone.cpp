// Standalone CAW Clock firmware for the JUZIPi SD PRO.
//
// One fixed screen of CAW market data, rotating through the CAW pools on
// Cronos, Solana, Base and Robinhood (chosen in the panel), fetched directly over HTTPS
// (certificate-validated), no Home Assistant and no dashboard engine. That
// keeps enough heap free for the TLS fetch on the ESP8266 (measured with the
// CAW TLS probe: ~41 KB idle heap, ~15 KB used by a 4 KiB-buffer fetch).
//
// Access:
//  * Unconfigured clock: WPA2 setup network "CAW-Clock-XXXXXX" with the
//    key shown on screen; http://192.168.4.1 sets Wi-Fi, clock password and
//    time zone.
//  * Configured clock: panel at http://<clock IP>/ with HTTP Digest auth
//    (user "admin" or the stored user, clock password): status, display, Wi-Fi,
//    password, firmware update, restart, factory reset.
//  * Wi-Fi lost for 2 minutes: the same setup network opens again (recovery);
//    API authentication is never disabled. It closes when Wi-Fi returns.
#if CAW_STANDALONE

#include <Arduino.h>
#include <ArduinoJson.h>
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <LittleFS.h>
#include <TFT_eSPI.h>
#include <Updater.h>
#include <WiFiUdp.h>
#include <time.h>

#include <memory>
#include <new>
#include <user_interface.h>  // rst_info

#include "../DeviceSettings.h"
#include "CawFeedLite.h"
#include "CawTimeZones.h"
#include "CawPictures.h"
#include <StackThunk.h>
#include "CawApp.h"
#include "CawCrashLog.h"
#include "CawScreen.h"
#include "../CawSchedule.h"
#if CAW_DUAL
#include "../CawBootMode.h"
#endif

namespace {

constexpr char kVersion[] = MINI_DISPLAY_VERSION;
constexpr char kSettingsPath[] = "/caw-settings.json";
constexpr char kSettingsTempPath[] = "/caw-settings.tmp";
// Setup / recovery network: "CAW-Clock-" + the last 6 MAC digits. Short
// enough to show at full size on the setup screen.
constexpr char kSetupNetworkPrefix[] = "CAW-Clock-";
constexpr uint32_t kRecoveryAfterMs = 2UL * 60UL * 1000UL;
constexpr time_t kMinimumValidEpoch = 1704067200;  // 2024-01-01

struct Settings {
  uint8_t brightness = 100;
  // Night mode: dim to nightBrightness (0 = backlight off) between nightStart
  // and nightEnd, in minutes after local midnight; may span midnight.
  bool nightEnabled = false;
  uint16_t nightStart = 22 * 60;
  uint16_t nightEnd = 7 * 60;
  uint8_t nightBrightness = 10;
  // UTC until the owner picks a zone; the setup page preselects the phone's
  // zone. Nothing location-specific is built into the firmware.
  char timezone[64] = "UTC0";
  char setupKey[17]{};           // WPA2 key of the setup/recovery network
  uint8_t chainMask = 0x0F;      // bit i: show kCawChains[i]
  uint16_t rotateSeconds = 15;   // time on each chain
  // Top-left picture: 0 = crow only, 1 = new picture with each chain change,
  // otherwise seconds per picture. Pictures: CawPictures (crow, built-in
  // memes, uploads).
  uint16_t pictureSeconds = 60;
  bool pictureRandom = true;
  bool pictureCrow = true;   // keep the original crow in the rotation
  uint32_t builtinOff = 0;   // bit n: built-in meme n hidden
};

constexpr uint16_t kPictureOff = 0, kPictureWithChain = 1;
const uint16_t kPictureChoices[] = {kPictureOff, kPictureWithChain, 30, 60, 300, 900, 3600};

bool validPictureSeconds(int seconds) {
  for (uint16_t choice : kPictureChoices)
    if (seconds == choice) return true;
  return false;
}

const uint16_t kRotateChoices[] = {5, 10, 15, 30, 60, 120, 300};

bool validRotate(int seconds) {
  for (uint16_t choice : kRotateChoices)
    if (seconds == choice) return true;
  return false;
}


// Everything sizeable lives in one heap object created at start-up. In the
// CAW + Home Assistant firmware this costs no RAM while Home Assistant mode
// runs (only one of the two apps is started per boot).
struct App {
  DeviceConfig config{};
  Settings settings;
  TFT_eSPI display;
  CawScreen screen{display};
  // Cronos is always fetched: its market cap is CAW's total (the other
  // chains' pools report only the supply on their own chain).
  CawFeedLite feeds[kCawChainCount]{CawFeedLite(kCawChains[0]), CawFeedLite(kCawChains[1]),
                                    CawFeedLite(kCawChains[2]), CawFeedLite(kCawChains[3])};
  ESP8266WebServer server{80};
  CawPictures pictures;
};
App *app = nullptr;
uint8_t activeChain = 0;
uint32_t pictureKey = CawPictures::kCrowKey;  // picture on screen
// Animated picture on screen (an uploaded GIF): frames play from the file.
CawAnimation animation;
bool animationActive = false;
uint32_t animationKey = 0xFFFFFFFF;  // picture the fields above belong to
uint16_t animationFrame = 0;
uint32_t animationAt = 0;  // millis() when the current frame was drawn
char animationPath[24];
uint32_t lastPictureChange = 0;
bool pictureUploadAllowed = false;  // the meme upload in progress passed the checks
const char *pictureUploadError = nullptr;
uint32_t lastRotation = 0;
bool filesystemReady = false;
bool accessPointRunning = false;
bool wasConnected = false;
uint32_t disconnectedSince = 0;
uint32_t lastScreenUpdate = 0;
bool updateInProgress = false;
// Why the clock last failed to join the configured network (shown on the
// setup screen and page), or nullptr.
const char *wifiFailure = nullptr;
bool everConnected = false;
uint32_t connectedNoticeUntil = 0;  // millis(); 0 = normal screen
uint32_t lastStationAttempt = 0;
constexpr uint32_t kConnectedNoticeMs = 10000;
constexpr uint32_t kRecoveryRetryMs = 60UL * 1000UL;

// ---------------------------------------------------------------- boot guard
// Counts starts that follow each other within kStableAfterMs, in RTC memory
// (kept across restarts and crashes, cleared by power loss). After
// kSafeModeAfter quick restarts in a row the clock starts in safe mode: no
// HTTPS fetches, the panel and firmware upload stay available, so a crash in
// the price feed can never lock the owner out. Block 64 is clear of the
// eboot command at the start of RTC user memory.
constexpr uint32_t kBootGuardBlock = 64;
constexpr uint32_t kBootGuardMagic = 0xCA3B0071;
constexpr uint32_t kSafeModeAfter = 3;
constexpr uint32_t kStableAfterMs = 2UL * 60UL * 1000UL;

struct BootGuard {
  uint32_t magic;
  uint32_t count;
};

uint32_t quickRestarts = 0;
bool safeMode = false;
bool bootGuardCleared = false;
String safeModeAddress;

void checkBootGuard() {
  BootGuard guard{};
  ESP.rtcUserMemoryRead(kBootGuardBlock, reinterpret_cast<uint32_t *>(&guard), sizeof(guard));
  const rst_info *info = ESP.getResetInfoPtr();
  const bool coldStart = guard.magic != kBootGuardMagic || info->reason == REASON_DEFAULT_RST ||
                         info->reason == REASON_EXT_SYS_RST;
  guard.magic = kBootGuardMagic;
  guard.count = coldStart ? 1 : guard.count + 1;
  ESP.rtcUserMemoryWrite(kBootGuardBlock, reinterpret_cast<uint32_t *>(&guard), sizeof(guard));
  quickRestarts = guard.count - 1;
  safeMode = quickRestarts >= kSafeModeAfter;
}

void clearBootGuard() {
  BootGuard guard{kBootGuardMagic, 0};
  ESP.rtcUserMemoryWrite(kBootGuardBlock, reinterpret_cast<uint32_t *>(&guard), sizeof(guard));
}

uint32_t lastUploadActivity = 0;  // millis() of the last upload chunk
bool uploadAllowed = false;       // the upload in progress passed the checks
// After a fetch where every source failed, wait before trying the next chain:
// each attempt can block for several seconds while the network is down, and
// the settings page must stay usable in between.
constexpr uint32_t kFetchCooldownMs = 20000;
uint32_t fetchCooldownUntil = 0;  // millis(); 0 = none
// Refresh times of the chains are spread this far apart.
constexpr uint32_t kFetchStaggerMs = 75000;

// ------------------------------------------------------------------ settings

void loadSettings() {
  if (!filesystemReady || !LittleFS.exists(kSettingsPath)) return;
  File file = LittleFS.open(kSettingsPath, "r");
  if (!file) return;
  StaticJsonDocument<512> document;
  if (deserializeJson(document, file) || (document["schemaVersion"] | 0) != 1) {
    file.close();
    return;
  }
  file.close();
  const int brightness = document["brightness"] | 100;
  if (brightness >= 0 && brightness <= 100) app->settings.brightness = brightness;
  app->settings.nightEnabled = document["nightEnabled"] | false;
  const int nightStart = document["nightStart"] | 22 * 60;
  const int nightEnd = document["nightEnd"] | 7 * 60;
  const int nightBrightness = document["nightBrightness"] | 10;
  if (nightStart >= 0 && nightStart < 24 * 60) app->settings.nightStart = nightStart;
  if (nightEnd >= 0 && nightEnd < 24 * 60) app->settings.nightEnd = nightEnd;
  if (nightBrightness >= 0 && nightBrightness <= 100) app->settings.nightBrightness = nightBrightness;
  const char *zone = document["timezone"] | "";
  if (timezoneValid(zone, sizeof(app->settings.timezone)))
    strlcpy(app->settings.timezone, zone, sizeof(app->settings.timezone));
  const int mask = document["chains"] | 0x0F;
  if (mask > 0 && mask <= 0x0F) app->settings.chainMask = mask;
  const int rotate = document["rotateSeconds"] | 15;
  if (validRotate(rotate)) app->settings.rotateSeconds = rotate;
  const int picture = document["pictureSeconds"] | 60;
  if (validPictureSeconds(picture)) app->settings.pictureSeconds = picture;
  app->settings.pictureRandom = document["pictureRandom"] | true;
  app->settings.pictureCrow = document["pictureCrow"] | true;
  app->settings.builtinOff = document["builtinOff"] | 0UL;
  const char *key = document["setupKey"] | "";
  if (strlen(key) >= 8 && strlen(key) < sizeof(app->settings.setupKey))
    strlcpy(app->settings.setupKey, key, sizeof(app->settings.setupKey));
}

bool saveSettings() {
  if (!filesystemReady) return false;
  StaticJsonDocument<512> document;
  document["schemaVersion"] = 1;
  document["brightness"] = app->settings.brightness;
  document["nightEnabled"] = app->settings.nightEnabled;
  document["nightStart"] = app->settings.nightStart;
  document["nightEnd"] = app->settings.nightEnd;
  document["nightBrightness"] = app->settings.nightBrightness;
  document["timezone"] = app->settings.timezone;
  document["setupKey"] = app->settings.setupKey;
  document["chains"] = app->settings.chainMask;
  document["rotateSeconds"] = app->settings.rotateSeconds;
  document["pictureSeconds"] = app->settings.pictureSeconds;
  document["pictureRandom"] = app->settings.pictureRandom;
  document["pictureCrow"] = app->settings.pictureCrow;
  document["builtinOff"] = app->settings.builtinOff;
  File file = LittleFS.open(kSettingsTempPath, "w");
  if (!file) return false;
  const bool written = serializeJson(document, file) > 0 && !file.getWriteError();
  file.close();
  if (!written) return false;
  LittleFS.remove(kSettingsPath);
  return LittleFS.rename(kSettingsTempPath, kSettingsPath);
}

// WPA2 key of the setup network: 10 characters from 31 unambiguous symbols
// (~50 bits), so a captured handshake cannot be brute-forced in practical
// time. Earlier firmware used 8 hex digits (32 bits); those are replaced.
constexpr uint8_t kSetupKeyLength = 10;

void ensureSetupKey() {
  static const char kAlphabet[] PROGMEM = "abcdefghjkmnpqrstuvwxyz23456789";
  if (strlen(app->settings.setupKey) >= kSetupKeyLength) return;
  for (uint8_t index = 0; index < kSetupKeyLength; ++index) {
    app->settings.setupKey[index] =
        pgm_read_byte(kAlphabet + ESP.random() % (sizeof(kAlphabet) - 1));
  }
  app->settings.setupKey[kSetupKeyLength] = '\0';
  saveSettings();
}

uint8_t appliedBrightness = 255;  // what the backlight is set to now

// True while the local time is inside the night window.
bool nightActive() {
  const Settings &settings = app->settings;
  if (!settings.nightEnabled) return false;
  const time_t now = time(nullptr);
  if (now < kMinimumValidEpoch) return false;  // clock not set yet
  struct tm local {};
  localtime_r(&now, &local);
  return nightWindowContains(settings.nightStart, settings.nightEnd,
                             local.tm_hour * 60 + local.tm_min);
}

// Sets the backlight for the current time (day or night brightness). Cheap
// when nothing changed, so the loop calls it regularly.
void applyBacklight(bool force = false) {
  const uint8_t level = nightActive() ? app->settings.nightBrightness : app->settings.brightness;
  if (!force && level == appliedBrightness) return;
  appliedBrightness = level;
  pinMode(TFT_BL, OUTPUT);
  if (level == 0) {
    digitalWrite(TFT_BL, !TFT_BACKLIGHT_ON);
    return;
  }
  analogWriteRange(100);
  analogWrite(TFT_BL, TFT_BACKLIGHT_ON == LOW ? 100 - level : level);
}

String minutesText(uint16_t minutes) {
  char text[8];
  snprintf(text, sizeof(text), "%02u:%02u", static_cast<unsigned>(minutes / 60 % 24),
           static_cast<unsigned>(minutes % 60));
  return text;
}

// "HH:MM" from an <input type=time>; false when malformed.
bool parseMinutes(const String &text, uint16_t &minutes) {
  if (text.length() != 5 || text[2] != ':') return false;
  const int hours = text.substring(0, 2).toInt(), mins = text.substring(3).toInt();
  if (!isDigit(text[0]) || !isDigit(text[1]) || !isDigit(text[3]) || !isDigit(text[4]) ||
      hours > 23 || mins > 59)
    return false;
  minutes = hours * 60 + mins;
  return true;
}

void applyTimeZone() {
  configTime(app->settings.timezone, "pool.ntp.org", "time.google.com");
}

// --------------------------------------------------------------------- html

String escape(const char *text) {
  String out;
  for (const char *c = text; *c; ++c) {
    switch (*c) {
      case '&': out += F("&amp;"); break;
      case '<': out += F("&lt;"); break;
      case '>': out += F("&gt;"); break;
      case '"': out += F("&quot;"); break;
      case '\'': out += F("&#39;"); break;
      default: out += *c;
    }
  }
  return out;
}

const char kStyle[] PROGMEM =
    "<meta name=viewport content='width=device-width,initial-scale=1'>"
    "<meta charset=utf-8><style>:root{color-scheme:dark}body{margin:0;background:#0a0d12;"
    "color:#eef0f2;font:15px system-ui,sans-serif}main{max-width:460px;margin:auto;padding:16px}"
    "h1{font-size:22px;margin:4px 0 12px}h2{font-size:16px;margin:0 0 10px}"
    "section{background:#161b22;border:1px solid #2b333d;border-radius:12px;padding:14px;margin:12px 0}"
    "label{display:block;margin:10px 0 4px;color:#aab4c1;font-size:13px}"
    "input,select,button{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;"
    "border:1px solid #3a444f;background:#0c1117;color:#fff;font-size:15px}"
    "button{margin-top:12px;background:#6a35d6;color:#fff;font-weight:700;border:0}"
    "button.ghost{background:#2b333d;color:#fff}table{width:100%;border-collapse:collapse}"
    "td{padding:4px 0;border-bottom:1px solid #222a33}td:last-child{text-align:right}"
    "[hidden]{display:none!important}.tabs{display:flex;gap:6px;margin:0 0 4px}"
    ".tabs button{margin:0;padding:9px 4px;background:#161b22;color:#aab4c1;border:1px solid #2b333d}"
    ".tabs button.on{background:#6a35d6;color:#fff;border-color:#6a35d6}"
    "small{color:#8d97a3}.brand{color:#b79cff;font-weight:800;letter-spacing:.12em;font-size:12px}"
    "</style>";

// `reserve`: the pages with the time zone list are ~11 KB; messages are small.
void beginPage(String &page, const char *title, size_t reserve = 12288) {
  page.reserve(reserve);
  page = F("<!doctype html><html lang=en><title>");
  page += title;
  page += F("</title>");
  page += FPSTR(kStyle);
  page += F("<main><div class=brand>CAW CLOCK</div><h1>");
  page += title;
  page += F("</h1>");
}

// Time zones grouped by region (CawTimeZones.h, from the IANA database), in
// flash. data-z carries the IANA name for the setup page's detection.
void timeZoneOptions(String &page) {
  bool matched = false;
  const char *region = nullptr;
  for (uint8_t index = 0; index < kCawTimeZoneCount; ++index) {
    const CawTimeZone zone = cawTimeZone(index);
    if (zone.region != region) {
      if (region) page += F("</optgroup>");
      region = zone.region;
      page += F("<optgroup label='");
      page += FPSTR(zone.region);
      page += F("'>");
    }
    const bool selected = strcmp_P(app->settings.timezone, zone.rule) == 0 && !matched;
    matched = matched || selected;
    page += F("<option value='");
    page += FPSTR(zone.rule);
    page += F("' data-z='");
    page += FPSTR(zone.iana);
    page += selected ? F("' selected>") : F("'>");
    page += FPSTR(zone.label);
    page += F("</option>");
  }
  if (region) page += F("</optgroup>");
  if (!matched) {
    page += F("<option selected value='");
    page += escape(app->settings.timezone);
    page += F("'>Custom: ");
    page += escape(app->settings.timezone);
    page += F("</option>");
  }
}

// Setup page: preselect the phone's time zone while the clock is still on
// UTC. Exact IANA name first, else a zone with the same UTC offsets in
// January and July (covers aliases such as Asia/Calcutta).
const char kDetectZoneScript[] PROGMEM =
    "<script>(function(){var s=document.querySelector('select[name=timezone]');"
    "if(!s||s.value!=='UTC0')return;var z;try{z=Intl.DateTimeFormat().resolvedOptions().timeZone}"
    "catch(e){return}if(!z)return;function o(t,m){var d=new Date(Date.UTC(2026,m,15,12));"
    "try{return Math.round((new Date(d.toLocaleString('en-US',{timeZone:t}))-"
    "new Date(d.toLocaleString('en-US',{timeZone:'UTC'})))/6e4)}catch(e){return NaN}}"
    "var a=o(z,0),b=o(z,6),best=null;for(var i=0;i<s.options.length;i++){var p=s.options[i],"
    "q=p.getAttribute('data-z');if(!q)continue;if(q===z){best=p;break}"
    "if(!best&&q!=='Etc/UTC'&&o(q,0)===a&&o(q,6)===b)best=p}if(best)best.selected=true})()</script>";

void firmwareForm(String &page) {
  page += F("<section data-tab=system><h2>Firmware</h2><form method=post action=/update "
            "enctype=multipart/form-data><input type=file name=firmware accept=.bin required>"
            "<button>Install firmware</button></form><small>Do not power off while the "
            "clock restarts.</small></section>");
}

// ------------------------------------------------------------------ access

bool fromSetupNetwork() {
  return accessPointRunning && app->server.client().localIP() == WiFi.softAPIP();
}

bool passwordSet() { return app->config.apiPassword[0] != '\0'; }

// True when the request may use the panel. Sends nothing.
bool permitted() {
  if (fromSetupNetwork()) return true;  // WPA2 key is shown on the clock
  if (!passwordSet()) return true;      // only until a password is set (panel warns)
  return app->server.authenticate(configuredUsername(app->config), app->config.apiPassword);
}

bool authorised() {
  if (permitted()) return true;
  app->server.requestAuthentication(DIGEST_AUTH, "CAW Clock");
  return false;
}

// Browsers attach the saved sign-in to requests any web page makes to the
// clock, so another site could submit these forms (even a firmware upload).
// They also send that site's Origin; accept a form only from our own pages.
// Tools without an Origin header (curl) still have to authenticate.
bool sameOrigin() {
  const String &origin = app->server.header(F("Origin"));
  return origin.isEmpty() || origin == String(F("http://")) + app->server.hostHeader();
}

// Gate for every state-changing request.
bool postAllowed() {
  if (!sameOrigin()) {
    app->server.send(403, F("text/plain"),
                     F("Open the clock's settings page directly and try again."));
    return false;
  }
  return authorised();
}

void redirectHome(const char *message = nullptr, const char *tab = "") {
  String page;
  beginPage(page, "CAW Clock", 2048);
  page += F("<section><p>");
  page += message ? message : "Saved.";
  // The result of a POST is shown at "/" so that refreshing the page never
  // resubmits the form (e.g. a firmware upload).
  page += F("</p><p><a style='color:#b79cff' href='/?back#");  // the query makes it a real page load, not a hash jump
  page += tab;
  page += F("'>Back</a></p></section></main><script>history.replaceState(null,'','/')</script>");
  app->server.send(200, "text/html", page);
}

void restartSoon(const char *message) {
  clearBootGuard();  // deliberate restarts never count towards safe mode
  redirectHome(message);
  delay(500);
  ESP.restart();
}

// ------------------------------------------------------------------- pages

void sendSetupPage() {
  String page;
  beginPage(page, "Set up CAW Clock");
  if (wifiFailure && app->config.ssid[0]) {
    page += F("<section style='border-color:#ff4d4d'><h2>Couldn't join your Wi-Fi</h2><p>");
    page += escape(app->config.ssid);
    page += F(": ");
    page += wifiFailure;
    page += F(". Names are case-sensitive and the clock needs a 2.4 GHz network.</p></section>");
  }
  page += F("<section><form method=post action=/setup><label>Wi-Fi network</label>");
  // Networks the clock can see (2.4 GHz only), strongest first, so the name
  // never has to be typed. "Other" covers hidden networks.
  const int scanned = WiFi.scanComplete();
  const int found = scanned > 32 ? 32 : scanned;  // strongest of the first 32 seen
  bool listed = false;
  if (found > 0) {
    page += F("<select name=network id=network onchange=\"other.hidden=this.value!==''\">");
    bool used[32]{};
    for (int pick = 0; pick < found; ++pick) {
      int best = -1;
      for (int index = 0; index < found; ++index) {
        if (used[index] || WiFi.SSID(index).isEmpty()) continue;
        if (best < 0 || WiFi.RSSI(index) > WiFi.RSSI(best)) best = index;
      }
      if (best < 0) break;
      used[best] = true;
      const String name = WiFi.SSID(best);
      bool duplicate = false;
      for (int index = 0; index < found; ++index)
        if (used[index] && index != best && WiFi.SSID(index) == name) duplicate = true;
      if (duplicate) continue;  // same name on several access points
      page += F("<option value='");
      page += escape(name.c_str());
      page += name == app->config.ssid || (!listed && !app->config.ssid[0]) ? F("' selected>") : F("'>");
      page += escape(name.c_str());
      const int32_t rssi = WiFi.RSSI(best);
      page += rssi > -60 ? F(" (strong)") : rssi > -75 ? F(" (good)") : F(" (weak)");
      page += F("</option>");
      listed = true;
    }
    page += F("<option value=''>Other network...</option></select>");
  }
  page += listed ? F("<div id=other hidden>") : F("<div id=other>");
  page += F("<label>Network name</label><input name=ssid maxlength=32 autocapitalize=none "
            "autocorrect=off spellcheck=false value='");
  page += escape(app->config.ssid);
  page += F("'></div>");
  if (scanned == WIFI_SCAN_RUNNING) page += F("<small>Looking for networks... reload in a few seconds.</small>");
  page += F("<small><a style='color:#b79cff' href=/scan>Scan again</a></small>"
            "<label>Wi-Fi password</label><input name=wifi type=password maxlength=64>"
            "<label>Clock password (8-32 characters)");
  if (app->config.apiPassword[0]) page += F(", leave blank to keep");
  page += F("</label><input name=password type=password minlength=8 maxlength=32");
  if (!app->config.apiPassword[0]) page += F(" required");
  page += F("><label>Time zone</label><select name=timezone>");
  timeZoneOptions(page);
  page += F("</select><button>Save and connect</button></form><small>Sign in to the "
            "clock later as <b>");
  page += escape(configuredUsername(app->config));
  page += F("</b> with this password.</small></section>");
  page += FPSTR(kDetectZoneScript);
  firmwareForm(page);
  page += F("</main>");
  app->server.send(200, "text/html", page);
}

// Next top-left picture: random (never the same twice in a row) or in order.
// "Original crow only" shows the crow whatever else is enabled.
void nextPicture() {
  CawPictures &pictures = app->pictures;
  pictures.configure(app->settings.pictureCrow, app->settings.builtinOff);
  pictureKey = app->settings.pictureSeconds == kPictureOff
                   ? CawPictures::kCrowKey
                   : pictures.next(pictureKey, app->settings.pictureRandom);
}

bool chainShown(uint8_t index) { return app->settings.chainMask & (1U << index); }

void sendPanel() {
  if (!authorised()) return;
  String page;
  beginPage(page, "CAW Clock");
  if (safeMode) {
    page += F("<section style='border-color:#ff4d4d'><h2>Safe mode</h2><p>The clock restarted ");
    page += quickRestarts;
    page += F(" times in a row (last: ");
    page += escape(ESP.getResetReason().c_str());
    page += F("), so price updates are paused. Install other firmware below, or "
              "try a normal start.</p><form method=post action=/restart>"
              "<button>Restart normally</button></form></section>");
  }
  if (!passwordSet() && !fromSetupNetwork()) {
    page += F("<section style='border-color:#ff4d4d'><h2>No clock password</h2><p>Anyone on "
              "your network can change these settings or install firmware. Set a password "
              "under <b>Clock password</b> below.</p></section>");
  }
  page += F("<nav class=tabs hidden><button data-go=status>Status</button>"
            "<button data-go=display>Display</button><button data-go=memes>Memes</button>"
            "<button data-go=system>System</button></nav>"
            "<section data-tab=status><h2>Markets</h2><table>");
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    const CawFeedLite &feed = app->feeds[index];
    if (!chainShown(index) && index != 0) continue;
    const CawMarket &market = feed.market();
    page += F("<tr><td>");
    page += feed.chain().label;
    page += F("<br><small>");
    const int32_t age = feed.secondsSinceSuccess();
    if (age < 0) page += F("no data yet");
    else { page += age / 60; page += F(" min ago"); }
    page += F(" · ");
    page += feed.lastResult();
    page += F("</small></td><td>");
    page += escape(feed.displayPrice());
    page += F("<br><small>");
    page += market.valid ? escape(market.change1h) : String("--");
    page += F(" / ");
    page += market.valid ? escape(market.change24h) : String("--");
    page += F("</small></td></tr>");
  }
  page += F("</table></section><section data-tab=status><h2>Clock</h2><table><tr><td>Wi-Fi</td><td>");
  page += escape(app->config.ssid);
  page += F(" · ");
  page += WiFi.RSSI();
  page += F(" dBm</td></tr><tr><td>Address</td><td>");
  page += WiFi.localIP().toString();
  page += F("</td></tr><tr><td>Firmware</td><td>");
  page += kVersion;
  page += F("</td></tr><tr><td>Memory free</td><td>");
  page += ESP.getFreeHeap();
  page += F(" B (block ");
  page += ESP.getMaxFreeBlockSize();
  page += F(")</td></tr></table></section>");

  page += F("<section data-tab='display memes'><form method=post action=/settings>"
            "<div data-tab=display><h2>Display</h2><label>Brightness</label><input type=range name=brightness min=0 max=100 value=");
  page += app->settings.brightness;
  page += F("><label style='color:#eef0f2'><input type=checkbox style='width:auto' name=night");
  page += app->settings.nightEnabled ? F(" checked") : F("");
  page += F("> Night mode: dim the screen</label><div style='display:flex;gap:10px'>"
            "<div style='flex:1'><label>From</label><input type=time name=nightStart value=");
  page += minutesText(app->settings.nightStart);
  page += F("></div><div style='flex:1'><label>Until</label><input type=time name=nightEnd value=");
  page += minutesText(app->settings.nightEnd);
  page += F("></div></div><label>Night brightness (0 turns the screen off)</label>"
            "<input type=range name=nightBrightness min=0 max=100 value=");
  page += app->settings.nightBrightness;
  page += F("><label>Chains to show</label>");
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    page += F("<label style='display:inline-block;margin-right:14px;color:#eef0f2'>"
              "<input type=checkbox style='width:auto' name=chain");
    page += index;
    page += chainShown(index) ? F(" checked> ") : F("> ");
    page += kCawChains[index].label;
    page += F("</label>");
  }
  page += F("<label>Time on each chain</label><select name=rotate>");
  for (uint16_t choice : kRotateChoices) {
    page += F("<option value=");
    page += choice;
    page += choice == app->settings.rotateSeconds ? F(" selected>") : F(">");
    if (choice < 60) { page += choice; page += F(" seconds"); }
    else { page += choice / 60; page += choice == 60 ? F(" minute") : F(" minutes"); }
    page += F("</option>");
  }
  page += F("</select><label>Time zone</label><select name=timezone>");
  timeZoneOptions(page);
  page += F("</select></div><div data-tab=memes><h2>Memes</h2><label>Meme (top left): ");
  page += app->pictures.builtinCount();
  page += F(" built-in + ");
  page += app->pictures.uploadCount();
  page += F(" uploaded memes</label><select name=picture>");
  for (uint16_t choice : kPictureChoices) {
    page += F("<option value=");
    page += choice;
    page += choice == app->settings.pictureSeconds ? F(" selected>") : F(">");
    if (choice == kPictureOff) page += F("Original crow only");
    else if (choice == kPictureWithChain) page += F("New meme with each chain");
    else if (choice < 60) { page += F("Every "); page += choice; page += F(" seconds"); }
    else if (choice == 60) page += F("Every minute");
    else if (choice < 3600) { page += F("Every "); page += choice / 60; page += F(" minutes"); }
    else page += F("Every hour");
    page += F("</option>");
  }
  page += F("</select><label>Meme order</label><select name=pictureOrder><option value=random");
  page += app->settings.pictureRandom ? F(" selected") : F("");
  page += F(">Random</option><option value=sequence");
  page += app->settings.pictureRandom ? F("") : F(" selected");
  page += F(">In order</option></select><label style='color:#eef0f2'><input type=checkbox "
            "style='width:auto' name=pictureCrow");
  page += app->settings.pictureCrow ? F(" checked") : F("");
  page += F("> Include the original crow</label></div><button>Save</button></form></section>"
            "<section data-tab=memes style='padding:0;border:0;background:none'>"
            "<iframe title=memes data-src='/memes?embed=1' scrolling=no "
            "style='width:100%;height:700px;border:0'></iframe></section>");

  page += F("<section data-tab=system><h2>Wi-Fi</h2><form method=post action=/wifi>"
            "<label>Network name (case-sensitive, 2.4 GHz)</label><input name=ssid maxlength=32 "
            "required autocapitalize=none autocorrect=off spellcheck=false value='");
  page += escape(app->config.ssid);
  page += F("'><label>Password</label><input name=wifi type=password maxlength=64>"
            "<button>Save and restart</button></form></section>");

  page += F("<section data-tab=system><h2>Clock password</h2><form method=post action=/password>"
            "<label>New password (8-32 characters)</label>"
            "<input name=password type=password minlength=8 maxlength=32 required>"
            "<label>Repeat</label><input name=confirm type=password minlength=8 maxlength=32 required>"
            "<button>Change password</button></form></section>");
  firmwareForm(page);
#if CAW_DUAL
  page += F("<section><h2>Screen mode</h2><p>Showing the CAW screen. Home Assistant "
            "mode shows the dashboards Home Assistant sends to the clock.</p>"
            "<form method=post action=/mode><button>Restart in Home Assistant mode</button>"
            "</form></section>");
#endif
  page += F("<section data-tab=system><h2>Maintenance</h2><form method=post action=/restart>"
            "<button class=ghost>Restart</button></form>"
            "<form method=post action=/factory-reset onsubmit=\"return confirm('Erase Wi-Fi, "
            "password and settings?')\"><button class=ghost>Factory reset</button></form>"
            "</section>");
  page += F("</main><script>(function(){var t=document.querySelectorAll('[data-tab]'),"
            "b=document.querySelectorAll('.tabs button'),n=document.querySelector('.tabs');"
            "var f=document.querySelector('iframe');function fit(){try{var d=f.contentDocument;"
            "if(d&&d.body)f.style.height=d.documentElement.scrollHeight+'px'}catch(e){}}"
            "setInterval(fit,400);"
            "function go(k){if(k=='memes'&&!f.src)f.src=f.dataset.src;for(var i=0;i<t.length;i++)t[i].hidden=(' '+t[i].dataset.tab+' ')"
            ".indexOf(' '+k+' ')<0;for(i=0;i<b.length;i++)b[i].className=b[i].dataset.go==k?'on':'';"
            "try{history.replaceState(null,'','#'+k)}catch(e){}}"
            "for(var i=0;i<b.length;i++)b[i].onclick=function(){go(this.dataset.go)};"
            "n.hidden=false;var h=location.hash.slice(1);"
            "go(['status','display','memes','system'].indexOf(h)<0?'status':h)})()</script>");
  app->server.send(200, "text/html", page);
}

void sendStatusJson() {
  if (!authorised()) return;
  DynamicJsonDocument document(4096);
  document["firmware"] = kVersion;
#if CAW_DUAL
  document["edition"] = "caw+homeassistant";
  document["mode"] = "caw";
#else
  document["edition"] = "caw";
#endif
  document["uptimeSeconds"] = millis() / 1000;
  // Why the clock last started: power-on, software restart (update or panel),
  // or an exception / watchdog reset, which would point to a crash.
  document["resetReason"] = ESP.getResetReason();
  document["safeMode"] = safeMode;
  document["quickRestarts"] = quickRestarts;
  {
    const rst_info *info = ESP.getResetInfoPtr();
    char hex[11];
    JsonObject reset = document.createNestedObject("lastReset");
    reset["reason"] = info->reason;
    reset["exception"] = info->exccause;
    snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(info->epc1));
    reset["epc1"] = hex;
    snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(info->excvaddr));
    reset["excvaddr"] = hex;
  }
  document["ip"] = WiFi.localIP().toString();
  document["rssi"] = WiFi.RSSI();
  document["freeHeap"] = ESP.getFreeHeap();
  document["maxFreeBlock"] = ESP.getMaxFreeBlockSize();
  document["timezone"] = app->settings.timezone;
  document["brightness"] = app->settings.brightness;
  {
    JsonObject night = document.createNestedObject("nightMode");
    night["enabled"] = app->settings.nightEnabled;
    night["active"] = nightActive();
    night["from"] = minutesText(app->settings.nightStart);
    night["until"] = minutesText(app->settings.nightEnd);
    night["brightness"] = app->settings.nightBrightness;
  }
  document["backlight"] = appliedBrightness;
  // Raw ADC (0-1023). If this changes when the clock is covered, the board
  // has a light sensor that automatic dimming could use.
  document["lightSensorRaw"] = analogRead(A0);
  document["shownChain"] = kCawChains[activeChain].id;
  document["rotateSeconds"] = app->settings.rotateSeconds;
  {
    JsonObject memes = document.createNestedObject("memes");
    uint32_t total = 0, used = 0;
    app->pictures.space(total, used);
    memes["showing"] = pictureKey;  // 0 crow, 256+n built-in n, 16777216+id upload
    memes["builtin"] = app->pictures.builtinCount();
    memes["uploaded"] = app->pictures.uploadCount();
    memes["animated"] = app->pictures.animatedCount();
    memes["playing"] = animationActive;
    memes["inRotation"] = app->pictures.shownCount();
    memes["uploadsLeft"] = app->pictures.uploadsLeft();
    memes["maxUploads"] = CawPictures::kMaxUploads;
    memes["storageBytes"] = total;
    memes["storageUsedBytes"] = used;
  }
  document["passwordSet"] = passwordSet();
  // Stack high-water marks: bytes of the 4 KB main stack never used since
  // start (painted-stack scan), and the most the 6 KB TLS stack has used.
  document["freeContStack"] = ESP.getFreeContStack();
  document["tlsStackMax"] = stack_thunk_get_max_usage();
  {
    // The last crash or watchdog reset: where it happened, the size and
    // caller of the allocation that failed, and a stack trail to decode.
    const CawCrashRecord &crash = cawLastCrash();
    if (crash.valid) {
      char hex[11];
      JsonObject item = document.createNestedObject("lastCrash");
      item["firmware"] = crash.version;
      item["uptimeSeconds"] = crash.uptime;
      item["stage"] = crash.stage;
      item["detail"] = crash.detail;
      item["freeHeapAtStage"] = crash.heap;
      item["reason"] = crash.reason;
      item["exception"] = crash.exception;
      snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.epc1));
      item["epc1"] = hex;
      snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.excvaddr));
      item["excvaddr"] = hex;
      item["source"] = crash.fromResetInfo ? "reset_info" : "crash_handler";
      item["storedEarlier"] = crash.fromFile;
      item["failedAllocBytes"] = crash.failSize;
      snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.failAddr));
      item["failedAllocCaller"] = hex;
      JsonArray stack = item.createNestedArray("stack");
      for (uint8_t index = 0; index < crash.stackCount; ++index) {
        snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.stack[index]));
        stack.add(hex);
      }
    }
  }
  JsonArray chains = document.createNestedArray("chains");
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    const CawFeedLite &feed = app->feeds[index];
    const CawMarket &market = feed.market();
    JsonObject item = chains.createNestedObject();
    item["chain"] = feed.chain().id;
    item["shown"] = chainShown(index);
    item["pair"] = feed.chain().pair;
    item["price"] = market.price;
    item["display"] = feed.displayPrice();
    item["change1h"] = market.change1h;
    item["change24h"] = market.change24h;
    item["liquidity"] = market.liquidity;
    item["volume"] = market.volume;
    item["marketCap"] = market.marketCap;
    item["live"] = feed.live();
    JsonObject fetch = item.createNestedObject("feed");
    fetch["result"] = feed.lastResult();
    fetch["source"] = feed.lastSource();
    fetch["primaryResult"] = feed.primaryResult();
    fetch["failures"] = feed.failures();
    fetch["httpStatus"] = feed.lastHttpStatus();
    fetch["sslError"] = feed.lastSslError();
    fetch["secondsSinceSuccess"] = feed.secondsSinceSuccess();
    fetch["freeHeapBefore"] = feed.lastFetchFreeHeap();
    fetch["minimumHeap"] = feed.lastFetchMinimumHeap();
    fetch["connectMs"] = feed.lastConnectMs();
    fetch["maxConnectMs"] = feed.maxConnectMs();
    fetch["resumed"] = feed.resumedConnections();
    fetch["connections"] = feed.connections();
    JsonObject chart = item.createNestedObject("chart");
    chart["points"] = feed.historyPoints();
    chart["backfill"] = feed.backfillResult();
  }
  String body;
  serializeJson(document, body);
  app->server.send(200, "application/json", body);
}

// ------------------------------------------------------------------ actions

bool validPassword(const String &password) {
  return password.length() >= 8 && password.length() <= 32;
}

void receiveSetup() {
  if (!fromSetupNetwork() || !sameOrigin()) {
    app->server.send(403, "text/plain", "Setup is only available on the clock's setup network");
    return;
  }
  const String picked = app->server.arg("network");
  const String ssid = picked.isEmpty() ? app->server.arg("ssid") : picked;
  const String wifi = app->server.arg("wifi");
  const String password = app->server.arg("password");
  const String zone = app->server.arg("timezone");
  if (ssid.isEmpty() || ssid.length() > 32 || wifi.length() > 64 ||
      (!password.isEmpty() && !validPassword(password)) ||
      (password.isEmpty() && !app->config.apiPassword[0])) {
    redirectHome("Check the Wi-Fi name and use a clock password of 8-32 characters.");
    return;
  }
  const bool configured = deviceConfigValid(app->config);
  DeviceConfig next = configured ? app->config : DeviceConfig{};
  strlcpy(next.ssid, ssid.c_str(), sizeof(next.ssid));
  if (!wifi.isEmpty() || !configured) strlcpy(next.wifiPassword, wifi.c_str(), sizeof(next.wifiPassword));
  if (!password.isEmpty()) strlcpy(next.apiPassword, password.c_str(), sizeof(next.apiPassword));
  if (!next.username[0]) strlcpy(next.username, "admin", sizeof(next.username));
  if (!next.hostname[0]) strlcpy(next.hostname, "caw-clock", sizeof(next.hostname));
  next.apiAuthEnabled = 1;
  next.otaAuthEnabled = 0;
  next.directOtaEnabled = 0;
  next.resetApiAuthOnRecovery = 0;
  if (!next.wifiRetryLimit) next.wifiRetryLimit = kDefaultWifiRetryLimit;
  app->config = next;
  saveDeviceConfig(app->config);
  if (timezoneValid(zone.c_str(), sizeof(app->settings.timezone)))
    strlcpy(app->settings.timezone, zone.c_str(), sizeof(app->settings.timezone));
  saveSettings();
  restartSoon("Saved. The clock is restarting and joining your Wi-Fi.");
}

void receiveSettings() {
  if (!postAllowed()) return;
  // Every group is applied only when its fields were sent, so a partial
  // request can't, say, read a missing brightness as 0 and blank the screen.
  if (app->server.hasArg("brightness")) {
    const int brightness = app->server.arg("brightness").toInt();
    if (brightness >= 0 && brightness <= 100) app->settings.brightness = brightness;
  }
  if (app->server.hasArg("nightBrightness")) {
    app->settings.nightEnabled = app->server.hasArg("night");
    parseMinutes(app->server.arg("nightStart"), app->settings.nightStart);
    parseMinutes(app->server.arg("nightEnd"), app->settings.nightEnd);
    const int nightBrightness = app->server.arg("nightBrightness").toInt();
    if (nightBrightness >= 0 && nightBrightness <= 100)
      app->settings.nightBrightness = nightBrightness;
  }
  const String zone = app->server.arg("timezone");
  if (timezoneValid(zone.c_str(), sizeof(app->settings.timezone)))
    strlcpy(app->settings.timezone, zone.c_str(), sizeof(app->settings.timezone));
  if (app->server.hasArg("rotate")) {  // sent with the chain checkboxes
    uint8_t mask = 0;
    for (uint8_t index = 0; index < kCawChainCount; ++index)
      if (app->server.hasArg(String("chain") + index)) mask |= 1U << index;
    app->settings.chainMask = mask ? mask : 0x01;  // at least Cronos
    const int rotate = app->server.arg("rotate").toInt();
    if (validRotate(rotate)) app->settings.rotateSeconds = rotate;
  }
  if (app->server.hasArg("picture")) {
    const int picture = app->server.arg("picture").toInt();
    if (validPictureSeconds(picture)) app->settings.pictureSeconds = picture;
    app->settings.pictureRandom = app->server.arg("pictureOrder") != "sequence";
    app->settings.pictureCrow = app->server.hasArg("pictureCrow");
    lastPictureChange = 0;  // apply now
  }
  saveSettings();
  applyBacklight(true);
  applyTimeZone();
  app->screen.invalidate();
  redirectHome("Settings saved.", "display");
}

void receiveWifi() {
  if (!postAllowed()) return;
  const String ssid = app->server.arg("ssid");
  const String wifi = app->server.arg("wifi");
  if (ssid.isEmpty() || ssid.length() > 32 || wifi.length() > 64) {
    redirectHome("Check the Wi-Fi name and password.", "system");
    return;
  }
  strlcpy(app->config.ssid, ssid.c_str(), sizeof(app->config.ssid));
  if (!wifi.isEmpty()) strlcpy(app->config.wifiPassword, wifi.c_str(), sizeof(app->config.wifiPassword));
  saveDeviceConfig(app->config);
  restartSoon("Saved. The clock is restarting and joining the new network.");
}

void receivePassword() {
  if (!postAllowed()) return;
  const String password = app->server.arg("password");
  if (!validPassword(password) || password != app->server.arg("confirm")) {
    redirectHome("Passwords must match and be 8-32 characters.", "system");
    return;
  }
  strlcpy(app->config.apiPassword, password.c_str(), sizeof(app->config.apiPassword));
  app->config.apiAuthEnabled = 1;
  saveDeviceConfig(app->config);
  redirectHome("Password changed. Sign in again with the new password.", "system");
}

void receiveFactoryReset() {
  if (!postAllowed()) return;
  if (filesystemReady) LittleFS.format();
  eraseDeviceConfig();
  restartSoon("Erased. The clock restarts into setup.");
}

// Ends an upload that did not install: the running firmware is untouched.
void abandonUpdate() {
  if (Update.isRunning()) Update.end();
  updateInProgress = false;
  uploadAllowed = false;
  applyTimeZone();  // the upload stopped all UDP, including time sync
  app->screen.invalidate();
}

// Called for each chunk of the upload, before the request handler. Checked
// once at the start; a refused upload is read and discarded, and the reply
// (401 or 403) comes from finishUpdate().
void receiveUpdate() {
  HTTPUpload &upload = app->server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    uploadAllowed = sameOrigin() && permitted();
    if (!uploadAllowed) return;
    updateInProgress = true;
    lastUploadActivity = millis();
    WiFiUDP::stopAll();
    app->screen.showMessage("Updating", "Do not power off");
    Update.begin(ESP.getFreeSketchSpace() & 0xFFFFF000);
    return;
  }
  if (!uploadAllowed) return;
  lastUploadActivity = millis();
  if (upload.status == UPLOAD_FILE_WRITE) {
    Update.write(upload.buf, upload.currentSize);
  } else if (upload.status == UPLOAD_FILE_END) {
    Update.end(true);
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    abandonUpdate();
  }
  yield();
}

void finishUpdate() {
  if (!postAllowed()) return;
  const bool installed = uploadAllowed && !Update.hasError() && !Update.isRunning();
  if (!installed) {
    abandonUpdate();
    redirectHome("Update failed. The current firmware keeps running.", "system");
    return;
  }
  updateInProgress = false;
  uploadAllowed = false;
  restartSoon("Update installed. The clock is restarting.");
}

// ------------------------------------------------------------------- memes
// /memes: built-in memes (show/hide) and uploads (add, show/hide, delete).
// The browser turns each chosen image into the clock's 56 x 56 format
// ("CWP1" header + RGB565 LE, see CawPictures.h) before uploading, so the
// clock never decodes JPEG/PNG. Thumbnails load one at a time from
// /memes/picture in the same format.

const char kMemesStyle[] PROGMEM =
    "<style>.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));"
    "gap:10px}.tile{background:#0c1117;border:1px solid #2b333d;border-radius:10px;"
    "padding:6px;text-align:center}.tile.off canvas{opacity:.3}canvas{width:84px;height:84px;"
    "image-rendering:pixelated;border-radius:4px;background:#000}.tile{position:relative}"
    ".gif{position:absolute;top:9px;right:9px;background:#6a35d6;color:#fff;font:700 10px sans-serif;"
    "padding:1px 4px;border-radius:4px}.tile button{margin-top:4px;"
    "padding:5px;font-size:12px}.tile .del{background:#3a1d1d;color:#ff9a9a}"
    "#progress{color:#b79cff;min-height:20px}</style>";

const char kMemesScript[] PROGMEM = R"JS(<script>
const S=56,MAXF=30,MINMS=83,PX=S*S*2;
/* One 56x56 frame as RGB565 little-endian; transparent pixels become black. */
function px(img){const d=img.data,o=new Uint8Array(PX);
for(let i=0,j=0;i<S*S;i++,j+=2){const a=d[i*4+3]/255,r=d[i*4]*a,g=d[i*4+1]*a,b=d[i*4+2]*a;
const v=((r>>3)<<11)|((g>>2)<<5)|(b>>3);o[j]=v&255;o[j+1]=v>>8}return o}
async function load(file){if(window.createImageBitmap){try{return await createImageBitmap(file)}catch(e){}}
return await new Promise((ok,fail)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>fail(new Error('not an image'));i.src=URL.createObjectURL(file)})}
/* Centre square, halved down in steps, then to 56x56. */
function shrink(src){const w=src.width,h=src.height,side=Math.min(w,h);
let c=document.createElement('canvas'),size=side;c.width=c.height=side;
c.getContext('2d').drawImage(src,(w-side)/2,(h-side)/2,side,side,0,0,side,side);
while(size/2>=S*2){const n=document.createElement('canvas');size=Math.floor(size/2);n.width=n.height=size;
const x=n.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(c,0,0,size,size);c=n}
const f=document.createElement('canvas');f.width=f.height=S;const x=f.getContext('2d');
x.imageSmoothingQuality='high';x.drawImage(c,0,0,S,S);return x.getImageData(0,0,S,S)}
function still(img){const o=new Uint8Array(8+PX);o.set([67,87,80,49,S,0,S,0]);o.set(px(shrink(img)),8);return o}

/* ---- GIF: block scan, LZW, compositing (frame disposal and transparency) ---- */
function lzw(min,data,n){const clear=1<<min,eoi=clear+1,out=new Uint8Array(n);
const prefix=new Uint16Array(4096),suffix=new Uint8Array(4096),stack=new Uint8Array(4097);
for(let i=0;i<clear&&i<256;i++)suffix[i]=i;
let size=min+1,mask=(1<<size)-1,next=eoi+1,old=-1,first=0,acc=0,bits=0,pos=0,o=0;
while(o<n){while(bits<size){if(pos>=data.length)return out;acc|=data[pos++]<<bits;bits+=8}
let code=acc&mask;acc>>>=size;bits-=size;
if(code===clear){size=min+1;mask=(1<<size)-1;next=eoi+1;old=-1;continue}
if(code===eoi)break;
if(old<0){out[o++]=suffix[code];old=code;first=code;continue}
let c=code,sp=0;if(code>=next){stack[sp++]=first;c=old}
while(c>=clear&&sp<4096){stack[sp++]=suffix[c];c=prefix[c]}
first=suffix[c];stack[sp++]=first;while(sp&&o<n)out[o++]=stack[--sp];
if(next<4096){prefix[next]=old;suffix[next]=first;next++;if((next&mask)===0&&size<12){size++;mask=(1<<size)-1}}
old=code}
return out}
function subBlocks(u,p){const parts=[];let n=0;while(u[p]){parts.push(u.subarray(p+1,p+1+u[p]));n+=u[p];p+=u[p]+1}
const o=new Uint8Array(n);let k=0;for(const a of parts){o.set(a,k);k+=a.length}return[o,p+1]}
function gifScan(u){if(u.length<14||u[0]!==71||u[1]!==73||u[2]!==70)throw new Error('not a GIF');
const w=u[6]|u[7]<<8,h=u[8]|u[9]<<8;let p=10;const f=u[p];p+=3;let gct=null;
if(f&128){const n=3<<((f&7)+1);gct=u.subarray(p,p+n);p+=n}
const frames=[];let gce=null;
while(p<u.length){const b=u[p++];if(b===0x3B)break;
if(b===0x21){const l=u[p++];
if(l===0xF9){gce={disp:(u[p+1]>>2)&7,tr:(u[p+1]&1)?u[p+4]:-1,ms:(u[p+2]|u[p+3]<<8)*10}}
let q=p;while(u[q])q+=u[q]+1;p=q+1}
else if(b===0x2C){const x=u[p]|u[p+1]<<8,y=u[p+2]|u[p+3]<<8,iw=u[p+4]|u[p+5]<<8,ih=u[p+6]|u[p+7]<<8,fl=u[p+8];p+=9;
let pal=gct;if(fl&128){const n=3<<((fl&7)+1);pal=u.subarray(p,p+n);p+=n}
const min=u[p++];const[data,np]=subBlocks(u,p);p=np;
frames.push({x,y,iw,ih,inter:!!(fl&64),pal,min,data,disp:gce?gce.disp:0,tr:gce?gce.tr:-1,
ms:gce&&gce.ms>10?gce.ms:100});gce=null}
else throw new Error('damaged GIF')}
if(!w||!h||!frames.length)throw new Error('empty GIF');return{w,h,frames}}
/* Calls emit(index, rgba) after each frame is drawn, with the canvas as the viewer shows it. */
function gifRender(g,emit){const{w,h}=g,cv=new Uint8ClampedArray(w*h*4);let prev=null;
g.frames.forEach((fr,i)=>{if(fr.disp===3)prev=cv.slice();
const idx=lzw(fr.min,fr.data,fr.iw*fr.ih),rows=new Int32Array(fr.ih);
if(fr.inter){let r=0;for(const[s,st]of[[0,8],[4,8],[2,4],[1,2]])for(let y=s;y<fr.ih;y+=st)rows[r++]=y}
else for(let y=0;y<fr.ih;y++)rows[y]=y;
for(let r=0;r<fr.ih;r++){const y=fr.y+rows[r];if(y>=h)continue;
for(let x=0;x<fr.iw;x++){const X=fr.x+x;if(X>=w)continue;const c=idx[r*fr.iw+x];if(c===fr.tr)continue;
const o=(y*w+X)*4,q=c*3;cv[o]=fr.pal?fr.pal[q]|0:0;cv[o+1]=fr.pal?fr.pal[q+1]|0:0;cv[o+2]=fr.pal?fr.pal[q+2]|0:0;cv[o+3]=255}}
emit(i,cv);
if(fr.disp===2){for(let y=fr.y;y<Math.min(h,fr.y+fr.ih);y++)for(let x=fr.x;x<Math.min(w,fr.x+fr.iw);x++)cv.fill(0,(y*w+x)*4,(y*w+x)*4+4)}
else if(fr.disp===3&&prev)cv.set(prev)})}
/* Evenly spaced moments of the loop, at least MINMS apart, at most MAXF. A frame hit by
   several moments is kept once, with a longer delay. Returns [{src,ms}]. */
function pick(frames){let T=0;for(const f of frames)T+=f.ms;
const step=Math.max(MINMS,Math.ceil(T/MAXF/10)*10),n=Math.min(MAXF,Math.max(1,Math.ceil(T/step))),out=[];
let acc=0,i=0;for(let k=0;k<n;k++){const t=k*step;while(i<frames.length-1&&acc+frames[i].ms<=t){acc+=frames[i].ms;i++}
const last=out[out.length-1];if(last&&last.src===i)last.n++;else out.push({src:i,n:1})}
const ms=Math.min(5000,Math.max(20,Math.round(step/10)*10));
return out.map(o=>({src:o.src,ms:Math.min(5000,ms*o.n)}))}
async function gifToBytes(buf,note){const g=gifScan(new Uint8Array(buf)),sel=pick(g.frames);
if(g.frames.length<2||sel.length<2){let first=null;gifRender({w:g.w,h:g.h,frames:g.frames.slice(0,1)},(i,cv)=>{first=cv.slice()});
const c=document.createElement('canvas');c.width=g.w;c.height=g.h;c.getContext('2d').putImageData(new ImageData(first,g.w,g.h),0,0);
note('one frame: added as a still');const o=new Uint8Array(8+PX);o.set([67,87,80,49,S,0,S,0]);o.set(px(shrink(c)),8);return o}
const need=new Map();sel.forEach((s,k)=>{if(!need.has(s.src))need.set(s.src,[]);need.get(s.src).push(k)});
const frames=new Array(sel.length),c=document.createElement('canvas');c.width=g.w;c.height=g.h;const x=c.getContext('2d');let done=0;
const todo=[];gifRender(g,(i,cv)=>{if(!need.has(i))return;const copy=cv.slice();todo.push([i,copy])});
for(const[i,cv]of todo){x.putImageData(new ImageData(cv,g.w,g.h),0,0);const p=px(shrink(c));for(const k of need.get(i))frames[k]=p;
if(++done%4===0){note('converting frame '+done+' of '+todo.length);await new Promise(r=>setTimeout(r))}}
const N=sel.length,o=new Uint8Array(12+N*(2+PX));o.set([67,87,65,49,S,0,S,0,N&255,N>>8,0,0]);
sel.forEach((s,k)=>{o[12+2*k]=s.ms&255;o[13+2*k]=s.ms>>8;o.set(frames[k],12+2*N+k*PX)});
note(g.frames.length+' frames in the GIF, '+N+' kept at about '+(1000/sel[0].ms).toFixed(1)+' per second');return o}

async function post(url,body){for(let t=0;t<2;t++){const r=await fetch(url,{method:'POST',body,credentials:'same-origin'});
if(r.status!==401)return r}throw new Error('sign-in needed: reload the page')}
async function upload(){const files=[...document.getElementById('files').files],p=document.getElementById('progress');
if(!files.length)return;let done=0;for(const f of files){const say=m=>p.textContent=f.name+': '+m;say('reading...');
try{const buf=await f.arrayBuffer(),u=new Uint8Array(buf,0,4),isGif=u[0]===71&&u[1]===73&&u[2]===70;
if(isGif&&buf.byteLength>30e6)throw new Error('that GIF is over 30 MB');
const bytes=isGif?await gifToBytes(buf,say):still(await load(f));
const form=new FormData();form.append('pic',new Blob([bytes],{type:'application/octet-stream'}),'meme.cwp');
say('sending '+Math.round(bytes.length/1024)+' KB...');
const r=await post('/memes/upload?bytes='+bytes.length,form);const msg=await r.text();if(!r.ok){p.textContent=f.name+': '+msg;return}done++}
catch(e){p.textContent=f.name+': '+e.message;return}}p.textContent='Added '+done+'. Reloading...';location.reload()}
async function act(url){const r=await post(url);if(!r.ok){alert(await r.text());return}location.reload()}
function show(k,on){act('/memes/show?k='+k+'&on='+(on?1:0))}
function del(k){if(confirm('Delete this meme from the clock?'))act('/memes/delete?k='+k)}
async function thumbs(){for(const c of document.querySelectorAll('canvas[data-k]')){try{
const r=await fetch('/memes/picture?k='+c.dataset.k,{credentials:'same-origin'});if(!r.ok)continue;
const b=new Uint8Array(await r.arrayBuffer());if(b.length!==8+PX)continue;
const x=c.getContext('2d'),img=x.createImageData(S,S);for(let i=0,o=8;i<S*S;i++,o+=2){const v=b[o]|b[o+1]<<8;
img.data[i*4]=(v>>11)*255/31;img.data[i*4+1]=((v>>5)&63)*255/63;img.data[i*4+2]=(v&31)*255/31;img.data[i*4+3]=255}
x.putImageData(img,0,0)}catch(e){}}}
thumbs();
</script>)JS";

void memeTile(String &page, uint32_t key, bool shown, bool deletable, bool animated = false) {
  page += shown ? F("<div class=tile>") : F("<div class='tile off'>");
  if (animated) page += F("<span class=gif>GIF</span>");
  page += F("<canvas width=56 height=56 data-k=");
  page += key;
  page += F("></canvas><button class=ghost onclick='show(");
  page += key;
  page += shown ? F(",0)'>Hide</button>") : F(",1)'>Show</button>");
  if (deletable) {
    page += F("<button class=del onclick='del(");
    page += key;
    page += F(")'>Delete</button>");
  }
  page += F("</div>");
}

void sendMemesPage() {
  if (!authorised()) return;
  CawPictures &pictures = app->pictures;
  pictures.configure(app->settings.pictureCrow, app->settings.builtinOff);
  String page;
  // ?embed=1: shown inside the Memes tab of the settings page (an iframe),
  // so no heading and no link back.
  const bool embedded = app->server.arg("embed") == "1";
  const size_t reserve = 4096 + 160UL * (pictures.builtinCount() + pictures.uploadCount());
  if (embedded) {
    page.reserve(reserve);
    page = F("<!doctype html><html lang=en><title>Memes</title>");
    page += FPSTR(kStyle);
    page += F("<main style='padding:0 0 4px'>");
  } else {
    beginPage(page, "Memes", reserve);
  }
  page += FPSTR(kMemesStyle);
  if (!embedded) page += F("<p><a style='color:#b79cff' href='/'>&larr; Settings</a></p>");

  uint32_t total = 0, used = 0;
  pictures.space(total, used);
  const uint16_t left = pictures.uploadsLeft();
  page += F("<section><h2>Add memes</h2><p><small>Pick one or more images (JPG, PNG, "
            "WebP, GIF). Each is cropped to its centre square and shrunk to 56 &times; 56 "
            "(a GIF keeps up to 30 frames, about 12 a second at most) "
            "in your browser, then stored on the clock. Firmware updates keep them; a "
            "factory reset erases them.</small></p>");
  if (left) {
    page += F("<input type=file id=files accept='image/*' multiple>"
              "<button onclick=upload()>Add to the clock</button>");
  } else {
    page += F("<p>Storage or meme limit reached: delete some uploaded memes first.</p>");
  }
  page += F("<p id=progress></p><small>");
  page += pictures.uploadCount();
  page += F(" uploaded, room for ");
  page += left;
  page += F(" more &middot; storage ");
  page += used / 1024;
  page += F(" of ");
  page += total / 1024;
  page += F(" KB used</small></section>");

  page += F("<section><h2>Uploaded (");
  page += pictures.uploadCount();
  page += F(")</h2>");
  if (!pictures.uploadCount()) page += F("<p><small>None yet.</small></p>");
  page += F("<div class=grid>");
  for (uint16_t index = 0; index < pictures.uploadCount(); ++index)
    memeTile(page, CawPictures::kUploadKeyBase + pictures.uploadId(index),
             pictures.uploadShown(index), true, pictures.uploadAnimated(index));
  page += F("</div></section><section><h2>Built in (");
  page += pictures.builtinCount() + 1;
  page += F(")</h2><p><small>Part of the firmware: they can be hidden but never deleted."
            "</small></p><div class=grid>");
  memeTile(page, CawPictures::kCrowKey, app->settings.pictureCrow, false);
  for (uint8_t index = 0; index < pictures.builtinCount(); ++index)
    memeTile(page, CawPictures::kBuiltinKeyBase + index, pictures.builtinShown(index), false,
             pictures.builtinAnimated(index));
  page += F("</div></section>");
  page += FPSTR(kMemesScript);
  page += F("</main>");
  app->server.send(200, "text/html", page);
}

uint32_t keyArgument() { return strtoul(app->server.arg("k").c_str(), nullptr, 10); }

// One picture as "CWP1" + 56 x 56 RGB565 LE, for the page's thumbnails.
void sendPicture() {
  if (!authorised()) return;
  const uint32_t key = keyArgument();
  char path[24];
  if (app->pictures.uploadPathFor(key, path, sizeof(path))) {
    File file = LittleFS.open(path, "r");
    if (file) {
      CawAnimation thumbnail;
      if (app->pictures.readAnimation(key, thumbnail)) {
        // An animation: send its first frame as a static picture (header
        // "CWP1", then frame 0), a row at a time.
        if (!file.seek(thumbnail.dataOffset)) {
          file.close();
          app->server.send(404, "text/plain", "No such picture");
          return;
        }
        static const uint8_t kHeader[kCawPictureHeaderBytes] = {'C', 'W', 'P', '1',
                                                                kCawPictureSize, 0, kCawPictureSize, 0};
        app->server.setContentLength(kCawPictureFileBytes);
        app->server.send(200, "application/octet-stream", "");
        app->server.sendContent(reinterpret_cast<const char *>(kHeader), sizeof(kHeader));
        uint8_t row[kCawPictureSize * 2];
        for (int16_t line = 0; line < kCawPictureSize; ++line) {
          if (file.read(row, sizeof(row)) != sizeof(row)) break;
          app->server.sendContent(reinterpret_cast<const char *>(row), sizeof(row));
        }
        file.close();
        return;
      }
      app->server.streamFile(file, F("application/octet-stream"));
      file.close();
      return;
    }
  }
  const uint8_t *mdi = app->pictures.builtinData(key);
  std::unique_ptr<uint8_t[]> buffer(mdi ? new (std::nothrow) uint8_t[kCawPictureFileBytes] : nullptr);
  if (!buffer) {
    app->server.send(404, "text/plain", "No such picture");
    return;
  }
  memcpy(buffer.get(), "CWP1", 4);
  buffer[4] = kCawPictureSize;
  buffer[5] = 0;
  buffer[6] = kCawPictureSize;
  buffer[7] = 0;
  memset(buffer.get() + kCawPictureHeaderBytes, 0, kCawPicturePixelBytes);
  const auto copyRow = [&](uint16_t line, uint16_t *pixels, uint16_t width) {
    if (line >= kCawPictureSize || width > kCawPictureSize) return;
    uint8_t *out = buffer.get() + kCawPictureHeaderBytes + line * kCawPictureSize * 2;
    for (uint16_t index = 0; index < width; ++index) {
      out[index * 2] = pixels[index] & 0xFF;
      out[index * 2 + 1] = pixels[index] >> 8;
    }
  };
  if (cawIsPaletteAnimation(mdi)) forEachPaletteRow(mdi, 0, copyRow);  // first frame
  else forEachMdiRow(mdi, copyRow);
  app->server.send(200, "application/octet-stream", buffer.get(), kCawPictureFileBytes);
}

// Upload chunks (before the request handler). Permission and space are
// checked once at the start; refused data is read and discarded.
void receivePictureUpload() {
  HTTPUpload &upload = app->server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    pictureUploadError = nullptr;
    pictureUploadAllowed = sameOrigin() && permitted();
    if (!pictureUploadAllowed) return;
    // The file's size comes in the URL (/memes/upload?bytes=N): form fields
    // sent before the file are only visible to the server once the whole
    // upload is parsed, but the query string is read first.
    const long announced = app->server.arg("bytes").toInt();
    pictureUploadError = app->pictures.beginUpload(announced > 0 ? static_cast<size_t>(announced)
                                                                 : kCawPictureFileBytes);
    if (pictureUploadError) pictureUploadAllowed = false;
    return;
  }
  if (!pictureUploadAllowed) return;
  if (upload.status == UPLOAD_FILE_WRITE) {
    if (!app->pictures.write(upload.buf, upload.currentSize)) {
      pictureUploadAllowed = false;
      pictureUploadError = "more data than announced, or storage is full";
    }
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    app->pictures.abortUpload();
    pictureUploadAllowed = false;
    pictureUploadError = "upload interrupted";
  }
  yield();
}

void finishPictureUpload() {
  if (!postAllowed()) {
    app->pictures.abortUpload();
    return;
  }
  uint32_t id = 0;
  const char *error = pictureUploadError;
  if (!error && pictureUploadAllowed) error = app->pictures.finishUpload(id);
  else if (!error) error = "upload refused";
  pictureUploadAllowed = false;
  pictureUploadError = nullptr;
  if (error) {
    app->pictures.abortUpload();
    app->server.send(error[0] == 's' ? 507 : 400, "text/plain", error);
    return;
  }
  app->server.send(200, "text/plain", String(id));
}

// (Re)reads the animation of the picture on screen, if it has one.
void loadAnimation() {
  animationKey = pictureKey;
  animationActive = app->pictures.readAnimation(pictureKey, animation) &&
                    (animation.builtin ||
                     app->pictures.uploadPathFor(pictureKey, animationPath, sizeof(animationPath)));
  animationFrame = 0;
  animationAt = millis();
}

// After a change, move on if the picture on screen is no longer shown.
void pictureListChanged() {
  animationKey = 0xFFFFFFFF;  // files may have been renamed or removed: reload
  app->pictures.configure(app->settings.pictureCrow, app->settings.builtinOff);
  bool stillShown = false;
  for (uint16_t position = 0; position < app->pictures.shownCount(); ++position)
    stillShown = stillShown || app->pictures.shownKey(position) == pictureKey;
  if (!stillShown) {
    nextPicture();
    lastPictureChange = millis();
  }
}

void receivePictureShow() {
  if (!postAllowed()) return;
  const uint32_t key = keyArgument();
  const bool shown = app->server.arg("on") == "1";
  bool ok = true;
  if (key == CawPictures::kCrowKey) {
    app->settings.pictureCrow = shown;
    ok = saveSettings();
  } else if (key < CawPictures::kUploadKeyBase) {
    const uint32_t index = key - CawPictures::kBuiltinKeyBase;
    ok = key >= CawPictures::kBuiltinKeyBase && index < app->pictures.builtinCount();
    if (ok) {
      if (shown) app->settings.builtinOff &= ~(1UL << index);
      else app->settings.builtinOff |= 1UL << index;
      ok = saveSettings();
    }
  } else {
    ok = app->pictures.setShown(key, shown);
  }
  if (!ok) {
    app->server.send(400, "text/plain", "Could not change that meme");
    return;
  }
  pictureListChanged();
  app->server.send(204);
}

void receivePictureDelete() {
  if (!postAllowed()) return;
  if (!app->pictures.remove(keyArgument())) {
    app->server.send(400, "text/plain", "Only uploaded memes can be deleted");
    return;
  }
  pictureListChanged();
  app->server.send(204);
}

// --------------------------------------------------------------------- wifi

void showSetupScreen(const char *title) {
  const String ssid = String(kSetupNetworkPrefix) + deviceSuffix();
  const String key = String("Key: ") + app->settings.setupKey;
  app->screen.showMessage(title, "Join Wi-Fi network", ssid.c_str(), key.c_str(),
                          "Open 192.168.4.1", wifiFailure ? wifiFailure : "");
}

// Records why the station could not join, from the SDK's last attempt.
void noteWifiFailure() {
  switch (WiFi.status()) {
    case WL_NO_SSID_AVAIL: wifiFailure = "network not found"; break;
    case WL_WRONG_PASSWORD: wifiFailure = "wrong Wi-Fi password"; break;
    // The ESP8266 reports most WPA2 authentication failures this way.
    case WL_CONNECT_FAILED: wifiFailure = "couldn't connect - check the Wi-Fi password"; break;
    default: break;
  }
}

const char *setupTitle() { return everConnected ? "Wi-Fi lost" : "Can't join Wi-Fi"; }

void startAccessPoint(const char *title) {
  if (accessPointRunning) return;
  ensureSetupKey();
  const String ssid = String(kSetupNetworkPrefix) + deviceSuffix();
  const bool configured = wifiConfigured(app->config);
  WiFi.mode(configured ? WIFI_AP_STA : WIFI_AP);
  if (configured) {
    // While the station keeps searching, the radio hops channels and phones
    // drop off the setup network. Retry the home network now and then instead.
    WiFi.setAutoReconnect(false);
    WiFi.disconnect();
    lastStationAttempt = millis();
  }
  WiFi.softAP(ssid.c_str(), app->settings.setupKey);
  WiFi.scanNetworks(true);  // list for the setup page
  accessPointRunning = true;
  showSetupScreen(title);
}

void stopAccessPoint() {
  if (!accessPointRunning) return;
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.scanDelete();
  accessPointRunning = false;
  app->screen.invalidate();
}

void handleWifi() {
  if (!wifiConfigured(app->config)) return;  // setup network stays up
  const bool connected = WiFi.status() == WL_CONNECTED;
  if (connected) {
    disconnectedSince = 0;
    if (!wasConnected) {
      const bool announce = !everConnected || accessPointRunning;
      wasConnected = true;
      everConnected = true;
      wifiFailure = nullptr;
      stopAccessPoint();
      app->screen.invalidate();
      if (announce) {
        // Tell a new owner where the settings page is.
        const String address = "http://" + WiFi.localIP().toString();
        app->screen.showMessage("Connected", "Settings page:", address.c_str(), "",
                                "Sign in as", configuredUsername(app->config));
        connectedNoticeUntil = millis() + kConnectedNoticeMs;
        if (!connectedNoticeUntil) connectedNoticeUntil = 1;
      }
    }
    return;
  }
  const char *before = wifiFailure;
  noteWifiFailure();
  if (accessPointRunning && wifiFailure != before) showSetupScreen(setupTitle());
  if (accessPointRunning) {
    // Retry the home network once a minute, but never while someone is on the
    // setup network (the retry would move the radio off its channel).
    if (WiFi.softAPgetStationNum() == 0 && millis() - lastStationAttempt >= kRecoveryRetryMs) {
      lastStationAttempt = millis();
      WiFi.begin(app->config.ssid, app->config.wifiPassword);
    }
    return;
  }
  if (wasConnected) {
    wasConnected = false;
    app->screen.invalidate();
  }
  if (!disconnectedSince) disconnectedSince = millis();
  if (!accessPointRunning && millis() - disconnectedSince >= kRecoveryAfterMs)
    startAccessPoint(setupTitle());
}

#if CAW_DUAL
void receiveMode() {
  if (!postAllowed()) return;
  if (!cawSetBootMode(false)) {
    redirectHome("Could not save the mode. The clock keeps showing CAW.");
    return;
  }
  restartSoon("Restarting in Home Assistant mode. Switch back on its Display page.");
}
#endif

}  // namespace

void cawAppSetup() {
  cawStage(1);
  cawCrashLogBegin();  // the record an abort left behind, before anything else
  checkBootGuard();
  app = new App();
  Serial.begin(115200);
  cawStage(2);
  filesystemReady = LittleFS.begin();
  cawCrashLogStore(filesystemReady, kVersion);
  loadSettings();
  cawStage(3);
  app->display.init();
  applyBacklight(true);
  app->screen.begin();
  cawStage(4);
  app->pictures.begin(filesystemReady);
  cawStage(5);
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    app->feeds[index].begin(filesystemReady);
    app->feeds[index].setStagger(index * kFetchStaggerMs);
  }
  loadDeviceConfig(app->config);
  applyTimeZone();

  WiFi.persistent(false);
  if (wifiConfigured(app->config)) {
    WiFi.mode(WIFI_STA);
    WiFi.hostname(configuredHostname(app->config));
    WiFi.setAutoReconnect(true);
    WiFi.begin(app->config.ssid, app->config.wifiPassword);
    disconnectedSince = millis();
    app->screen.showMessage("CAW Clock", "Connecting to", app->config.ssid);
  } else {
    startAccessPoint("Set up CAW Clock");
  }

  app->server.on("/", HTTP_GET, [] {
    if (fromSetupNetwork()) sendSetupPage();
    else sendPanel();
  });
  app->server.on("/setup", HTTP_POST, receiveSetup);
  app->server.on("/api/status", HTTP_GET, sendStatusJson);
  app->server.on("/settings", HTTP_POST, receiveSettings);
  app->server.on("/wifi", HTTP_POST, receiveWifi);
  app->server.on("/password", HTTP_POST, receivePassword);
  app->server.on("/restart", HTTP_POST, [] {
    if (!postAllowed()) return;
    restartSoon("Restarting.");
  });
  app->server.on("/factory-reset", HTTP_POST, receiveFactoryReset);
  app->server.on("/scan", HTTP_GET, [] {
    if (!fromSetupNetwork() && !authorised()) return;
    WiFi.scanDelete();
    WiFi.scanNetworks(true);
    app->server.send(200, "text/html",
                     F("<meta http-equiv=refresh content='5;url=/'><meta name=viewport "
                       "content='width=device-width'><body style='background:#0a0d12;color:#eee;"
                       "font:16px sans-serif;padding:20px'>Looking for networks...</body>"));
  });
#if CAW_DUAL
  app->server.on("/mode", HTTP_POST, receiveMode);
#endif
  app->server.on("/update", HTTP_POST, finishUpdate, receiveUpdate);
  app->server.on("/memes", HTTP_GET, sendMemesPage);
  app->server.on("/memes/picture", HTTP_GET, sendPicture);
  app->server.on("/memes/upload", HTTP_POST, finishPictureUpload, receivePictureUpload);
  app->server.on("/memes/show", HTTP_POST, receivePictureShow);
  app->server.on("/memes/delete", HTTP_POST, receivePictureDelete);
  app->server.onNotFound([] { app->server.send(404, "text/plain", "Not found"); });
  app->server.collectHeaders("Origin");  // for sameOrigin()
  app->server.begin();
  cawStage(9);
}

void cawAppLoop() {
  cawStage(10);
  app->server.handleClient();
  if (updateInProgress) {
    // An upload that stops without finishing (browser closed, connection
    // lost) must not leave the clock on the "Updating" screen.
    if (millis() - lastUploadActivity < 30000) return;
    abandonUpdate();
  }
  cawStage(11);
  handleWifi();

  const bool connected = WiFi.status() == WL_CONNECTED;
  if (!wifiConfigured(app->config) || (accessPointRunning && !connected)) {
    delay(2);
    return;  // the setup screen stays visible
  }

  static uint32_t lastBacklightCheck = 0;
  if (millis() - lastBacklightCheck >= 5000) {  // night mode starts/ends on time
    lastBacklightCheck = millis();
    cawStage(12);
    cawNoteHeap();
    applyBacklight();
  }

  if (!bootGuardCleared && millis() >= kStableAfterMs) {
    clearBootGuard();
    bootGuardCleared = true;
  }
  if (safeMode) {
    const String address = connected ? WiFi.localIP().toString() : String("not connected");
    if (address != safeModeAddress) {
      safeModeAddress = address;
      const String restarts = String("Restarted ") + quickRestarts + " times";
      const String open = connected ? "Open http://" + address : String("Wi-Fi: not connected");
      app->screen.showMessage("Safe mode", restarts.c_str(), "Price updates paused",
                              open.c_str());
    }
    delay(2);
    return;
  }

  // One fetch per pass, so the web panel and clock stay responsive between
  // the (blocking, a few seconds each) HTTPS requests.
  const time_t now = time(nullptr);
  if (fetchCooldownUntil && static_cast<int32_t>(millis() - fetchCooldownUntil) >= 0)
    fetchCooldownUntil = 0;
  if (connected && now >= kMinimumValidEpoch && !fetchCooldownUntil) {
    for (uint8_t index = 0; index < kCawChainCount; ++index) {
      if ((index == 0 || chainShown(index)) && app->feeds[index].due()) {
        cawStage(13, index);
        cawNoteHeap();
        if (!app->feeds[index].fetch(now)) {
          fetchCooldownUntil = millis() + kFetchCooldownMs;
          if (!fetchCooldownUntil) fetchCooldownUntil = 1;
        }
        lastScreenUpdate = 0;
        break;
      }
    }
  }

  cawStage(14, activeChain);
  if (!chainShown(activeChain) ||
      millis() - lastRotation >= app->settings.rotateSeconds * 1000UL) {
    lastRotation = millis();
    for (uint8_t step = 1; step <= kCawChainCount; ++step) {
      const uint8_t next = (activeChain + step) % kCawChainCount;
      if (chainShown(next)) {
        if (next != activeChain) {
          lastScreenUpdate = 0;
          if (app->settings.pictureSeconds == kPictureWithChain) nextPicture();
        }
        activeChain = next;
        break;
      }
    }
  }

  const uint16_t pictureSeconds = app->settings.pictureSeconds;
  if (lastPictureChange == 0 ||
      (pictureSeconds > kPictureWithChain && millis() - lastPictureChange >= pictureSeconds * 1000UL)) {
    lastPictureChange = millis();
    if (!lastPictureChange) lastPictureChange = 1;
    cawStage(15, pictureKey);
    nextPicture();
  }

  if (connectedNoticeUntil && static_cast<int32_t>(millis() - connectedNoticeUntil) >= 0) {
    connectedNoticeUntil = 0;  // "Connected" notice done: back to the CAW screen
    app->screen.invalidate();
    lastScreenUpdate = 0;
  }
  if (!connectedNoticeUntil &&
      (millis() - lastScreenUpdate >= 1000 || lastScreenUpdate == 0)) {
    lastScreenUpdate = millis();
    cawNoteHeap();
    cawStage(16, pictureKey);
    const CawFeedLite &feed = app->feeds[activeChain];
    const CawMarket &market = feed.market();
    const CawMarket &cronos = app->feeds[0].market();
    CawScreenData data;
    data.chain = feed.chain().label;
    data.chainId = feed.chain().id;
    char picturePath[24];
    data.pictureKey = pictureKey;
    data.picture = app->pictures.builtinData(pictureKey);
    data.picturePath =
        app->pictures.uploadPathFor(pictureKey, picturePath, sizeof(picturePath)) ? picturePath
                                                                                  : nullptr;
    data.price = feed.displayPrice();
    data.change1h = market.valid ? market.change1h : "--";
    data.change24h = market.valid ? market.change24h : "--";
    data.liquidity = market.valid ? market.liquidity : "--";
    data.volume = market.valid ? market.volume : "--";
    data.marketCap = cronos.valid ? cronos.marketCap : market.valid ? market.marketCap : "--";
    data.live = feed.live();
    data.wifiConnected = connected;
    data.history = feed.history();
    data.historyCount = CawFeedLite::kHistoryPoints;
    // Unique per chain and version, so switching chains redraws the chart.
    data.historyVersion = feed.historyVersion() * kCawChainCount + activeChain;
    app->screen.update(data);
    if (animationKey != pictureKey) loadAnimation();  // frame 0 was just drawn
    cawStage(17);
  }

  // Next frame of an animated picture, when its delay is up. The screen
  // draws the picture slot only; a price fetch (a few seconds) pauses it.
  if (animationActive && !connectedNoticeUntil && animationKey == pictureKey &&
      millis() - animationAt >= animation.delay[animationFrame]) {
    cawStage(18, animationFrame);
    animationAt = millis();
    animationFrame = (animationFrame + 1) % animation.frames;
    if (!(animation.builtin
              ? app->screen.drawPaletteAnimationFrame(animation.builtin, animationFrame)
              : app->screen.drawAnimationFrame(animationPath, animation.dataOffset, animationFrame)))
      animationActive = false;  // file gone or the screen is showing a message
  }
  delay(2);
}

#if !CAW_DUAL
void setup() { cawAppSetup(); }
void loop() { cawAppLoop(); }
#endif

#endif  // CAW_STANDALONE
