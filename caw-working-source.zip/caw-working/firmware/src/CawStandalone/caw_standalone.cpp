// Standalone CAW Clock firmware for the JUZIPi SD PRO.
//
// One fixed screen of CAW market data, rotating through the CAW pools on
// Cronos, Solana, Base and Robinhood (chosen in the panel), fetched directly over HTTPS
// (certificate-validated), no Home Assistant and no dashboard engine. That
// keeps enough heap free for the TLS fetch on the ESP8266 (measured with the
// CAW TLS probe: ~41 KB idle heap, ~15 KB used by a 4 KiB-buffer fetch).
//
// Access:
//  * Unconfigured clock: WPA2 setup network "CAW-Clock-XXXXXX" with the
//    key shown on screen; http://192.168.4.1 sets Wi-Fi, clock password and
//    time zone.
//  * Configured clock: panel at http://<clock IP>/ with HTTP Digest auth
//    (user "admin" or the stored user, clock password): status, display, Wi-Fi,
//    password, firmware update, restart, factory reset.
//  * Wi-Fi lost for 2 minutes: the same setup network opens again (recovery);
//    API authentication is never disabled. It closes when Wi-Fi returns.
#if CAW_STANDALONE

#include <Arduino.h>
#include <ArduinoJson.h>
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <LittleFS.h>
#include <TFT_eSPI.h>
#include <Updater.h>
#include <WiFiUdp.h>
#include <time.h>

#include <memory>
#include <type_traits>
#include <new>
#include <user_interface.h>  // rst_info

#include "../DeviceSettings.h"
#include "CawFeedLite.h"
#include "CawTimeZones.h"
#include "CawPictures.h"
#if !CAW_DUAL
#include "CawFurnace.h"  // The Great Furnace's burn picture (not a meme)
#endif
#include <StackThunk.h>
#include "CawApp.h"
#include "CawCrashLog.h"
#include "CawScreen.h"
#include "CawUpdater.h"
#include "../CawAlert.h"
#include "../CawBurn.h"
#include "../CawFirmwareCheck.h"
#include "../CawPage.h"
#include "../CawSchedule.h"
#if CAW_DUAL
#include "../CawBootMode.h"
#endif

namespace {

constexpr char kVersion[] = MINI_DISPLAY_VERSION;
constexpr char kSettingsPath[] = "/caw-settings.json";
constexpr char kSettingsTempPath[] = "/caw-settings.tmp";
// Setup / recovery network: "CAW-Clock-" + the last 6 MAC digits. Short
// enough to show at full size on the setup screen.
constexpr char kSetupNetworkPrefix[] = "CAW-Clock-";
constexpr uint32_t kRecoveryAfterMs = 2UL * 60UL * 1000UL;
constexpr time_t kMinimumValidEpoch = 1704067200;  // 2024-01-01

struct Settings {
  uint8_t brightness = 100;
  // Night mode: dim to nightBrightness (0 = backlight off) between nightStart
  // and nightEnd, in minutes after local midnight; may span midnight.
  bool nightEnabled = false;
  uint16_t nightStart = 22 * 60;
  uint16_t nightEnd = 7 * 60;
  uint8_t nightBrightness = 10;
  // UTC until the owner picks a zone; the setup page preselects the phone's
  // zone. Nothing location-specific is built into the firmware.
  char timezone[64] = "UTC0";
  char setupKey[17]{};           // WPA2 key of the setup/recovery network
  uint8_t chainMask = 0x0F;      // bit i: show kCawChains[i]; BSC (bit 4) off by default
  uint16_t rotateSeconds = 15;   // time on each chain
  // Top-left picture: 0 = crow only, 1 = new picture with each chain change,
  // otherwise seconds per picture. Pictures: CawPictures (crow, built-in
  // memes, uploads).
  uint16_t pictureSeconds = 1;  // default: a new picture with each chain
  bool pictureRandom = true;
  bool pictureCrow = true;   // keep the original crow in the rotation
  uint32_t builtinOff = 0;   // bit n: built-in meme n hidden
  // Price alert: the price flashes when a shown chain's 1-hour change passes
  // this many percent (up green, down red). 0 = off.
  uint8_t alertPercent = 10;
  bool clock24 = true;  // false: 12-hour clock
  bool burnAlerts = true;  // show CAW burned by the bridge (CawBurn.h)
  bool supplyScreen = true;   // supply screen in the rotation (on by default)
};

constexpr uint16_t kPictureOff = 0, kPictureWithChain = 1;
const uint16_t kPictureChoices[] = {kPictureOff, kPictureWithChain, 30, 60, 300, 900, 3600};

bool validPictureSeconds(int seconds) {
  for (uint16_t choice : kPictureChoices)
    if (seconds == choice) return true;
  return false;
}

const uint16_t kRotateChoices[] = {5, 10, 15, 30, 60, 120, 300};

const uint8_t kAlertChoices[] = {0, 5, 10, 15, 20, 25, 50};
constexpr uint32_t kAlertFlashMs = 5UL * 60UL * 1000UL;  // how long the price flashes

bool validAlertPercent(int percent) {
  for (uint8_t choice : kAlertChoices)
    if (percent == choice) return true;
  return false;
}

bool validRotate(int seconds) {
  for (uint16_t choice : kRotateChoices)
    if (seconds == choice) return true;
  return false;
}


// Everything sizeable lives in one heap object created at start-up. In the
// CAW + Home Assistant firmware this costs no RAM while Home Assistant mode
// runs (only one of the two apps is started per boot).
struct App {
  DeviceConfig config{};
  Settings settings;
  TFT_eSPI display;
  CawScreen screen{display};
  // Cronos is always fetched: its market cap is CAW's total (the other
  // chains' pools report only the supply on their own chain).
  // The four feeds (~3.7 KB) are created only outside update mode, which
  // needs every byte for GitHub's 16 KB TLS records.
  CawFeedLite *feeds = nullptr;
  ESP8266WebServer server{80};
  CawPictures pictures;
};
App *app = nullptr;

struct FeedSet {
  CawFeedLite items[kCawChainCount]{CawFeedLite(kCawChains[0]), CawFeedLite(kCawChains[1]),
                                    CawFeedLite(kCawChains[2]), CawFeedLite(kCawChains[3]),
                                    CawFeedLite(kCawChains[4])};
  static_assert(kCawChainCount == 5, "one CawFeedLite per chain above");
};
uint8_t activeChain = 0;
uint32_t pictureKey = CawPictures::kCrowKey;  // picture on screen
// Animated picture on screen (an uploaded GIF): frames play from the file.
CawAnimation animation;
bool animationActive = false;
uint32_t animationKey = 0xFFFFFFFF;  // picture the fields above belong to
uint16_t animationFrame = 0;
uint32_t animationAt = 0;  // millis() when the current frame was drawn
char animationPath[24];
uint32_t lastPictureChange = 0;
bool pictureUploadAllowed = false;  // the meme upload in progress passed the checks
const char *pictureUploadError = nullptr;
uint32_t lastRotation = 0;
CawMoveAlert alerts[kCawChainCount];  // price alert per chain
bool filesystemReady = false;
bool accessPointRunning = false;
bool wasConnected = false;
uint32_t disconnectedSince = 0;
uint32_t lastScreenUpdate = 0;
bool updateInProgress = false;
// Why the clock last failed to join the configured network (shown on the
// setup screen and page), or nullptr. A flash string.
const __FlashStringHelper *wifiFailure = nullptr;
// The same reason as it fits on the setup screen (one 240 px line).
PGM_P wifiFailureOnScreen = nullptr;
bool everConnected = false;
uint32_t connectedNoticeUntil = 0;  // millis(); 0 = normal screen
uint32_t lastStationAttempt = 0;
constexpr uint32_t kConnectedNoticeMs = 10000;
constexpr uint32_t kRecoveryRetryMs = 60UL * 1000UL;

// ---------------------------------------------------------------- boot guard
// Counts starts that follow each other within kStableAfterMs, in RTC memory
// (kept across restarts and crashes, cleared by power loss). After
// kSafeModeAfter quick restarts in a row the clock starts in safe mode: no
// HTTPS fetches, the panel and firmware upload stay available, so a crash in
// the price feed can never lock the owner out. Block 64 is clear of the
// eboot command at the start of RTC user memory.
constexpr uint32_t kBootGuardBlock = 64;
constexpr uint32_t kBootGuardMagic = 0xCA3B0071;
constexpr uint32_t kSafeModeAfter = 3;
constexpr uint32_t kStableAfterMs = 2UL * 60UL * 1000UL;

struct BootGuard {
  uint32_t magic;
  uint32_t count;
};

uint32_t quickRestarts = 0;
bool safeMode = false;
bool bootGuardCleared = false;
String safeModeAddress;

void checkBootGuard() {
  BootGuard guard{};
  ESP.rtcUserMemoryRead(kBootGuardBlock, reinterpret_cast<uint32_t *>(&guard), sizeof(guard));
  const rst_info *info = ESP.getResetInfoPtr();
  const bool coldStart = guard.magic != kBootGuardMagic || info->reason == REASON_DEFAULT_RST ||
                         info->reason == REASON_EXT_SYS_RST;
  guard.magic = kBootGuardMagic;
  guard.count = coldStart ? 1 : guard.count + 1;
  ESP.rtcUserMemoryWrite(kBootGuardBlock, reinterpret_cast<uint32_t *>(&guard), sizeof(guard));
  quickRestarts = guard.count - 1;
  safeMode = quickRestarts >= kSafeModeAfter;
}

// ------------------------------------------------------------ recovery mode
// A forgotten clock password while Wi-Fi works would leave no way in (even a
// factory reset needs it). Plugging the clock in three times in a row, each
// time for less than kPowerOnWindowMs, opens the setup network for
// kRecoveryMs with its key on the screen, as at first setup: there a new
// password can be set (Wi-Fi password blank keeps it). Nothing is erased.
// Power-ons are counted in a small file (RTC memory is cleared by power
// loss); the count is cleared once the clock has run kPowerOnWindowMs.
constexpr char kPowerOnsPath[] = "/caw-power-ons";
constexpr uint8_t kRecoveryPowerOns = 3;
constexpr uint32_t kPowerOnWindowMs = 10000;
constexpr uint32_t kRecoveryMs = 15UL * 60UL * 1000UL;
bool powerOnsCleared = false;
uint32_t recoveryUntil = 0;  // millis(); 0 = not in recovery

bool recoveryActive() {
  return recoveryUntil != 0 && !deadlinePassed(recoveryUntil, millis(), 2 * kRecoveryMs);
}

// At start, with the file system mounted: true when this power-on completes
// kRecoveryPowerOns short ones in a row. Restarts by the firmware don't count.
bool countPowerOn() {
  if (!filesystemReady) return false;
  const rst_info *info = ESP.getResetInfoPtr();
  if (info->reason != REASON_DEFAULT_RST && info->reason != REASON_EXT_SYS_RST) return false;
  uint8_t count = 0;
  if (File file = LittleFS.open(kPowerOnsPath, "r")) {
    if (file.read(&count, 1) != 1) count = 0;
    file.close();
  }
  if (++count >= kRecoveryPowerOns) {
    LittleFS.remove(kPowerOnsPath);
    powerOnsCleared = true;
    return true;
  }
  if (File file = LittleFS.open(kPowerOnsPath, "w")) {
    file.write(&count, 1);
    file.close();
  }
  return false;
}

// From the loop: once the clock has run kPowerOnWindowMs, the start was not
// a short one; the count starts again.
void clearPowerOns() {
  if (powerOnsCleared || millis() < kPowerOnWindowMs) return;
  powerOnsCleared = true;
  if (filesystemReady && LittleFS.exists(kPowerOnsPath)) LittleFS.remove(kPowerOnsPath);
}

void clearBootGuard() {
  BootGuard guard{kBootGuardMagic, 0};
  ESP.rtcUserMemoryWrite(kBootGuardBlock, reinterpret_cast<uint32_t *>(&guard), sizeof(guard));
}

// ------------------------------------------------------ rollback and updates
// A new firmware is "on trial" while its rollback copy exists: it counts as
// stable only after kCawRollbackConfirmMs (instead of kStableAfterMs), so
// restarts anywhere in that window add up, and three in a row bring the
// previous firmware back (CawUpdater).
bool rollbackPending = false;

// "Check for updates" and its install run in a separate start of the clock
// ("update mode"): no price feeds or memes are loaded, which leaves the most
// memory for GitHub's full-size TLS records. The request file starts it; the
// result file is shown on the System tab afterwards.
constexpr char kUpdateRequestPath[] = "/update-request.json";
constexpr char kUpdateResultPath[] = "/update-result.json";
enum class UpdateMode : uint8_t { Off, Check, Install };
UpdateMode updateMode = UpdateMode::Off;
CawReleaseInfo updateRelease{};
uint32_t updateModeSince = 0;

uint32_t stableAfterMs() { return rollbackPending ? kCawRollbackConfirmMs : kStableAfterMs; }

uint32_t lastUploadActivity = 0;  // millis() of the last upload chunk
bool uploadAllowed = false;       // the upload in progress passed the checks
CawFirmwareHead uploadHead;       // its first 16 bytes (CawFirmwareCheck.h)
bool uploadWrongBoard = false;    // ... were not firmware for this clock
// After a fetch where every source failed, wait before trying the next chain:
// each attempt can block for several seconds while the network is down, and
// the settings page must stay usable in between.
constexpr uint32_t kFetchCooldownMs = 20000;
uint32_t fetchCooldownUntil = 0;  // millis(); 0 = none
// Refresh times of the chains are spread this far apart.
constexpr uint32_t kFetchStaggerMs = 75000;

// Burn alert (CawBurn.h). One source is asked every kBurnPollEveryMs, in
// turn: each of the seven (six bridge chains and Solana's supply) about every
// 6 minutes. A burn takes over the screen for
// kBurnShowMs; at most one takeover per kBurnCooldownMs, burns in between
// are added up and shown together.
constexpr uint32_t kBurnPollEveryMs = 50000;
constexpr uint16_t kBurnRestartAfterFailures = 3;
constexpr uint32_t kBurnShowMs = 20000;
constexpr uint32_t kBurnCooldownMs = 10UL * 60UL * 1000UL;
constexpr uint32_t kBurnFrameMs = 100;
constexpr uint8_t kBurnMemeIndex = 15;  // the built-in GIF the owner chose
struct BurnWatch {
  uint64_t cursor = 0;  // next poll asks from cursor + 1; 0 = not known yet
  uint64_t seenBlock = 0;  // highest block with an event seen (polls overlap)
  const char *result = "waiting";
  int httpStatus = 0;
  int sslError = 0;
  bool fullBuffers = false;  // 4 KiB TLS buffer failed: use the full one
  uint16_t failures = 0;     // in a row
  uint16_t seen = 0;         // burns found since start
  uint32_t polledAt = 0;     // millis()
};
BurnWatch burnWatch[kCawBurnChainCount];
CawBurnSupply burnSupply[kCawBurnChainCount];  // for the total burned
// The total is shown only when every chain's figures are this recent.
constexpr uint32_t kBurnSupplyMaxAgeMs = 30UL * 60UL * 1000UL;
CawBurnGate burnGate;
uint8_t burnNextChain = 0;
bool burnPolled = false;
uint32_t burnPolledAt = 0;
uint32_t burnShowingSince = 0;  // millis(); 0 = no burn on screen
uint32_t burnFrameAt = 0;
uint16_t burnFrame = 0;
uint32_t burnFrameMs = kBurnFrameMs;  // the bridge fire: 100 ms; The Great Furnace: its GIF's own
uint16_t burnsShown = 0;
// The last burns found (newest first), for the Status tab and the test button.
struct BurnRecord {
  float burned = 0, bridged = 0;
  // Route ("robinhood", "another chain"); a direct burn: the burner ("The
  // Great Furnace") and its chain.
  char from[20]{}, to[14]{};
  uint32_t at = 0;            // millis()
  bool direct = false;
  bool furnace = false;       // direct, by The Great Furnace
  bool haveTx = false;
  uint8_t chain = 0;          // where the transaction is (kCawBurnChains)
  uint8_t tx[32]{};
};
constexpr uint8_t kBurnRecords = 3;
BurnRecord burnRecords[kBurnRecords];
uint8_t burnRecordCount = 0;
bool burnTestRequested = false;  // "Preview the burn alert" (Display tab)
// Daily check for updates (normal mode, like a price fetch): a newer version
// gets a green dot on the screen and a notice on the settings page; the
// owner installs it (System tab). The first check is 10 minutes after the
// start, then every day; one that fails is tried again after an hour.
constexpr uint32_t kAutoCheckFirstMs = 10UL * 60 * 1000;
constexpr uint32_t kAutoCheckEveryMs = 24UL * 60 * 60 * 1000;
constexpr uint32_t kAutoCheckRetryMs = 60UL * 60 * 1000;
uint32_t autoCheckFrom = 0, autoCheckWait = kAutoCheckFirstMs;
char availableVersion[24] = "";  // newer than this firmware ("" = none known)
// "Preview The Great Furnace burn": release candidates only (a version with
// "-rc", e.g. 0.7.0-rc1), so the release itself has no such button.
bool furnaceTestRequested = false;
bool releaseCandidate() { return strstr(kVersion, "-rc") != nullptr; }

// Supply screen: holder counts (kCawHolderSources), one GeckoTerminal request
// at a time: every minute until each is known, then one every 9 minutes
// (each source about hourly). The supply figures come with the burn polls.
constexpr uint32_t kHoldersFirstEveryMs = 60000;
constexpr uint32_t kHoldersEveryMs = 9UL * 60UL * 1000UL;
constexpr uint32_t kSupplyMinimumMs = 10000;  // on screen at least this long
uint32_t holderCounts[kCawHolderSourceCount]{};
bool holderKnown[kCawHolderSourceCount]{};
uint8_t holderNext = 0;
bool holdersPolled = false;
uint32_t holdersPolledAt = 0;
const char *holdersResult = "waiting";
uint32_t supplyShowingSince = 0;  // millis(); 0 = not on screen

// ------------------------------------------------------------------ settings

// The settings file read back needs ~460 bytes, ~485 with the longest
// built-in time zone and ~520 with a 63-character custom one: 512 left no
// room for a custom zone or for the next new setting. Only held briefly
// (start-up, saving), on the heap.
constexpr size_t kSettingsDocumentBytes = 1024;

void loadSettings() {
  if (!filesystemReady || !LittleFS.exists(kSettingsPath)) return;
  File file = LittleFS.open(kSettingsPath, "r");
  if (!file) return;
  // On the heap for the call: a 512-byte document here made cawAppSetup one
  // of the deepest frames on the 4 KB main stack. kSettingsDocumentBytes: a
  // file that does not fit fails to load, and every setting falls back to
  // its default.
  DynamicJsonDocument document(kSettingsDocumentBytes);
  if (document.capacity() == 0 || deserializeJson(document, file) ||
      (document["schemaVersion"] | 0) != 1) {
    file.close();
    return;
  }
  file.close();
  const int brightness = document["brightness"] | 100;
  if (brightness >= 0 && brightness <= 100) app->settings.brightness = brightness;
  app->settings.nightEnabled = document["nightEnabled"] | false;
  const int nightStart = document["nightStart"] | 22 * 60;
  const int nightEnd = document["nightEnd"] | 7 * 60;
  const int nightBrightness = document["nightBrightness"] | 10;
  if (nightStart >= 0 && nightStart < 24 * 60) app->settings.nightStart = nightStart;
  if (nightEnd >= 0 && nightEnd < 24 * 60) app->settings.nightEnd = nightEnd;
  if (nightBrightness >= 0 && nightBrightness <= 100) app->settings.nightBrightness = nightBrightness;
  const char *zone = document["timezone"] | "";
  if (timezoneValid(zone, sizeof(app->settings.timezone)))
    strlcpy(app->settings.timezone, zone, sizeof(app->settings.timezone));
  const int mask = document["chains"] | 0x0F;
  if (mask > 0 && mask < (1 << kCawChainCount)) app->settings.chainMask = mask;
  const int rotate = document["rotateSeconds"] | 15;
  if (validRotate(rotate)) app->settings.rotateSeconds = rotate;
  const int picture = document["pictureSeconds"] | kPictureWithChain;
  if (validPictureSeconds(picture)) app->settings.pictureSeconds = picture;
  app->settings.pictureRandom = document["pictureRandom"] | true;
  app->settings.pictureCrow = document["pictureCrow"] | true;
  app->settings.builtinOff = document["builtinOff"] | 0UL;
  const int alert = document["alertPercent"] | 10;
  if (validAlertPercent(alert)) app->settings.alertPercent = alert;
  app->settings.clock24 = document["clock24"] | true;
  app->settings.burnAlerts = document["burnAlerts"] | true;
  app->settings.supplyScreen = document["supplyScreen"] | true;
  const char *key = document["setupKey"] | "";
  if (strlen(key) >= 8 && strlen(key) < sizeof(app->settings.setupKey))
    strlcpy(app->settings.setupKey, key, sizeof(app->settings.setupKey));
}

bool saveSettings() {
  if (!filesystemReady) return false;
  DynamicJsonDocument document(kSettingsDocumentBytes);  // heap, not the main stack
  if (document.capacity() == 0) return false;
  document["schemaVersion"] = 1;
  document["brightness"] = app->settings.brightness;
  document["nightEnabled"] = app->settings.nightEnabled;
  document["nightStart"] = app->settings.nightStart;
  document["nightEnd"] = app->settings.nightEnd;
  document["nightBrightness"] = app->settings.nightBrightness;
  document["timezone"] = app->settings.timezone;
  document["setupKey"] = app->settings.setupKey;
  document["chains"] = app->settings.chainMask;
  document["rotateSeconds"] = app->settings.rotateSeconds;
  document["pictureSeconds"] = app->settings.pictureSeconds;
  document["pictureRandom"] = app->settings.pictureRandom;
  document["pictureCrow"] = app->settings.pictureCrow;
  document["builtinOff"] = app->settings.builtinOff;
  document["alertPercent"] = app->settings.alertPercent;
  document["clock24"] = app->settings.clock24;
  document["burnAlerts"] = app->settings.burnAlerts;
  document["supplyScreen"] = app->settings.supplyScreen;
  File file = LittleFS.open(kSettingsTempPath, "w");
  if (!file) return false;
  const bool written = serializeJson(document, file) > 0 && !file.getWriteError();
  file.close();
  if (!written) return false;
  LittleFS.remove(kSettingsPath);
  return LittleFS.rename(kSettingsTempPath, kSettingsPath);
}

// WPA2 key of the setup network: 10 characters from 31 unambiguous symbols
// (~50 bits), so a captured handshake cannot be brute-forced in practical
// time. Earlier firmware used 8 hex digits (32 bits); those are replaced.
// Call with the radio on (after WiFi.mode()): the core notes (Esp.cpp) that
// with Wi-Fi off the hardware generator behind ESP.random() is likely
// pseudo-random, and since core 3.0 Wi-Fi is off at boot.
constexpr uint8_t kSetupKeyLength = 10;

void ensureSetupKey() {
  static const char kAlphabet[] PROGMEM = "abcdefghjkmnpqrstuvwxyz23456789";
  if (strlen(app->settings.setupKey) >= kSetupKeyLength) return;
  delay(20);  // a moment for the radio that was just switched on
  for (uint8_t index = 0; index < kSetupKeyLength; ++index) {
    app->settings.setupKey[index] =
        pgm_read_byte(kAlphabet + ESP.random() % (sizeof(kAlphabet) - 1));
  }
  app->settings.setupKey[kSetupKeyLength] = '\0';
  saveSettings();
}

uint8_t appliedBrightness = 255;  // what the backlight is set to now

// Main-stack (4 KB "cont" stack) use. Start-up is measured on its own, then
// the mark is reset, so freeContStack shows what normal running needs. After
// each kind of work the lowest free value is checked and the work that set
// it is remembered (Wi-Fi interrupts land in whichever work was running).
uint32_t bootFreeContStack = 0;
uint32_t lowestFreeContStack = UINT32_MAX;
const char *lowestStackWork = "none";

void noteStack(const char *work) {
  const uint32_t free = ESP.getFreeContStack();
  if (free < lowestFreeContStack) {
    lowestFreeContStack = free;
    lowestStackWork = work;
  }
}

// True while the local time is inside the night window.
bool nightActive() {
  const Settings &settings = app->settings;
  if (!settings.nightEnabled) return false;
  const time_t now = time(nullptr);
  if (now < kMinimumValidEpoch) return false;  // clock not set yet
  struct tm local {};
  localtime_r(&now, &local);
  return nightWindowContains(settings.nightStart, settings.nightEnd,
                             local.tm_hour * 60 + local.tm_min);
}

// Sets the backlight for the current time (day or night brightness). Cheap
// when nothing changed, so the loop calls it regularly.
void applyBacklight(bool force = false) {
  const uint8_t level = nightActive() ? app->settings.nightBrightness : app->settings.brightness;
  if (!force && level == appliedBrightness) return;
  appliedBrightness = level;
#if CAW_C2
  app->display.setBrightness(level);  // PWM on the SDC2's active-low backlight (port/TFT_eSPI.cpp)
  return;
#endif
  pinMode(TFT_BL, OUTPUT);
  if (level == 0) {
    digitalWrite(TFT_BL, !TFT_BACKLIGHT_ON);
    return;
  }
  analogWriteRange(100);
  analogWrite(TFT_BL, TFT_BACKLIGHT_ON == LOW ? 100 - level : level);
}

String minutesText(uint16_t minutes) {
  char text[8];
  snprintf(text, sizeof(text), "%02u:%02u", static_cast<unsigned>(minutes / 60 % 24),
           static_cast<unsigned>(minutes % 60));
  return text;
}

// "HH:MM" from an <input type=time>; false when malformed.
bool parseMinutes(const String &text, uint16_t &minutes) {
  if (text.length() != 5 || text[2] != ':') return false;
  const int hours = text.substring(0, 2).toInt(), mins = text.substring(3).toInt();
  if (!isDigit(text[0]) || !isDigit(text[1]) || !isDigit(text[3]) || !isDigit(text[4]) ||
      hours > 23 || mins > 59)
    return false;
  minutes = hours * 60 + mins;
  return true;
}

void applyTimeZone() {
  configTime(app->settings.timezone, "pool.ntp.org", "time.google.com");
}

// --------------------------------------------------------------------- html

String escape(const char *text) {
  String out;
  for (const char *c = text; *c; ++c) {
    switch (*c) {
      case '&': out += F("&amp;"); break;
      case '<': out += F("&lt;"); break;
      case '>': out += F("&gt;"); break;
      case '"': out += F("&quot;"); break;
      case '\'': out += F("&#39;"); break;
      default: out += *c;
    }
  }
  return out;
}

const char kStyle[] PROGMEM =
    "<meta name=viewport content='width=device-width,initial-scale=1'>"
    "<meta charset=utf-8><style>:root{color-scheme:dark}body{margin:0;background:#0a0d12;"
    "color:#eef0f2;font:15px system-ui,sans-serif}main{max-width:460px;margin:auto;padding:16px}"
    "h1{font-size:22px;margin:4px 0 12px}h2{font-size:16px;margin:0 0 10px}"
    "section{background:#161b22;border:1px solid #2b333d;border-radius:12px;padding:14px;margin:12px 0}"
    "label{display:block;margin:10px 0 4px;color:#aab4c1;font-size:13px}"
    "input,select,button{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;"
    "border:1px solid #3a444f;background:#0c1117;color:#fff;font-size:15px}"
    "button{margin-top:12px;background:#6a35d6;color:#fff;font-weight:700;border:0}"
    "button.ghost{background:#2b333d;color:#fff}table{width:100%;border-collapse:collapse}"
    "td{padding:4px 0;border-bottom:1px solid #222a33}td:last-child{text-align:right}"
    "[hidden]{display:none!important}.tabs{display:flex;gap:6px;margin:0 0 4px}"
    ".tabs button{margin:0;padding:9px 4px;background:#161b22;color:#aab4c1;border:1px solid #2b333d}"
    ".tabs button.on{background:#6a35d6;color:#fff;border-color:#6a35d6}"
    "small{color:#8d97a3}.warn{color:#ffb454}h3{font-size:14px;margin:14px 0 0}.brand{color:#b79cff;font-weight:800;letter-spacing:.12em;font-size:12px}"
    "</style>";

// Pages are sent in pieces as they are built (CawPage.h): the settings and
// memes pages are 13-15 KB, more than is safe to hold in one heap block.
struct ServerPageSink {
  ESP8266WebServer &server;
  void begin() {
    server.setContentLength(CONTENT_LENGTH_UNKNOWN);
    server.send(200, "text/html", emptyString);
  }
  void chunk(const String &text) { server.sendContent(text); }
  void whole(const String &text) { server.send(200, "text/html", text); }
};
using Page = CawPageWriter<ServerPageSink, String>;

// Adds a long text from flash (styles, scripts) a slice at a time, so the
// page buffer never has to hold all of it at once.
void addFlashText(Page &page, PGM_P text) {
  char slice[65];
  for (size_t offset = 0, length = strlen_P(text); offset < length; offset += sizeof(slice) - 1) {
    const size_t count = std::min(sizeof(slice) - 1, length - offset);
    memcpy_P(slice, text + offset, count);
    slice[count] = '\0';
    page += slice;
  }
}

void beginPage(Page &page, const char *title) {
  page += F("<!doctype html><html lang=en><title>");
  page += title;
  page += F("</title>");
  addFlashText(page, kStyle);
  page += F("<main><div class=brand>CAW CLOCK</div><h1>");
  page += title;
  page += F("</h1>");
}

// Time zones grouped by region (CawTimeZones.h, from the IANA database), in
// flash. data-z carries the IANA name for the setup page's detection.
void timeZoneOptions(Page &page) {
  bool matched = false;
  const char *region = nullptr;
  for (uint8_t index = 0; index < kCawTimeZoneCount; ++index) {
    const CawTimeZone zone = cawTimeZone(index);
    if (zone.region != region) {
      if (region) page += F("</optgroup>");
      region = zone.region;
      page += F("<optgroup label='");
      page += FPSTR(zone.region);
      page += F("'>");
    }
    const bool selected = strcmp_P(app->settings.timezone, zone.rule) == 0 && !matched;
    matched = matched || selected;
    page += F("<option value='");
    page += FPSTR(zone.rule);
    page += F("' data-z='");
    page += FPSTR(zone.iana);
    page += selected ? F("' selected>") : F("'>");
    page += FPSTR(zone.label);
    page += F("</option>");
  }
  if (region) page += F("</optgroup>");
  if (!matched) {
    page += F("<option selected value='");
    page += escape(app->settings.timezone);
    page += F("'>Custom: ");
    page += escape(app->settings.timezone);
    page += F("</option>");
  }
}

// Setup page: preselect the phone's time zone while the clock is still on
// UTC. Exact IANA name first, else a zone with the same UTC offsets in
// January and July (covers aliases such as Asia/Calcutta).
const char kDetectZoneScript[] PROGMEM =
    "<script>(function(){var s=document.querySelector('select[name=timezone]');"
    "if(!s||s.value!=='UTC0')return;var z;try{z=Intl.DateTimeFormat().resolvedOptions().timeZone}"
    "catch(e){return}if(!z)return;function o(t,m){var d=new Date(Date.UTC(2026,m,15,12));"
    "try{return Math.round((new Date(d.toLocaleString('en-US',{timeZone:t}))-"
    "new Date(d.toLocaleString('en-US',{timeZone:'UTC'})))/6e4)}catch(e){return NaN}}"
    "var a=o(z,0),b=o(z,6),best=null;for(var i=0;i<s.options.length;i++){var p=s.options[i],"
    "q=p.getAttribute('data-z');if(!q)continue;if(q===z){best=p;break}"
    "if(!best&&q!=='Etc/UTC'&&o(q,0)===a&&o(q,6)===b)best=p}if(best)best.selected=true})()</script>";

bool readUpdateResult(JsonDocument &document) {
  if (!filesystemReady) return false;
  File file = LittleFS.open(kUpdateResultPath, "r");
  if (!file) return false;
  const bool ok = !deserializeJson(document, file);
  file.close();
  return ok;
}

// `version`: the latest release just checked (nullptr: none known).
void noteAvailable(const char *version) {
  const bool newer = version && cawCompareVersions(version, kVersion) == CawVersionOrder::Newer;
  strlcpy(availableVersion, newer ? version : "", sizeof(availableVersion));
  lastScreenUpdate = 0;  // the dot
}

void writeUpdateResult(const char *outcome, const CawReleaseInfo *release, const String &error) {
  DynamicJsonDocument document(512);
  document["outcome"] = outcome;  // checked / installed / failed
  document["at"] = static_cast<uint32_t>(time(nullptr));
  if (release) {
    document["version"] = release->version;
    document["file"] = release->file;
    document["sha256"] = release->sha256;
  }
  if (error.length()) document["error"] = error;
  noteAvailable(strcmp(outcome, "checked") == 0 && release && !error.length() ? release->version
                                                                              : nullptr);
  File file = LittleFS.open(kUpdateResultPath, "w");
  if (!file) return;
  serializeJson(document, file);
  file.close();
}

// Firmware section. `online`: also "Check for updates" and the rollback state
// (not on the setup network, which has no internet).
void firmwareForm(Page &page, bool online = false) {
  page += F("<section data-tab=system><h2>Firmware</h2><p><small>Installed: ");
  page += kVersion;
  page += F("</small></p>");
  if (online) {
    char failed[32], restored[32];
    if (cawRollbackNotice(failed, sizeof(failed), restored, sizeof(restored))) {
      page += F("<p class=warn>Version ");
      page += escape(failed);
      page += F(" didn't start correctly, so the clock went back to ");
      page += escape(restored);
      page += F(" automatically.</p><form method=post action=/rollback/dismiss>"
                "<button class=ghost>Dismiss</button></form>");
    }
    DynamicJsonDocument result(512);
    if (readUpdateResult(result)) {
      const char *outcome = result["outcome"] | "";
      const char *version = result["version"] | "";
      const char *error = result["error"] | "";
      page += F("<p>");
      if (strcmp(outcome, "failed") == 0) {
        page += F("Update not installed: ");
        page += escape(error);
        page += F(". The current firmware keeps running.");
      } else if (strcmp(outcome, "installed") == 0) {
        page += F("Updated to ");
        page += escape(version);
        page += '.';
      } else if (error[0]) {
        page += F("Could not check for updates: ");
        page += escape(error);
      } else {
        switch (cawCompareVersions(version, kVersion)) {
          case CawVersionOrder::Newer:
            page += F("<b>Version ");
            page += escape(version);
            page += F(" is available.</b>");
            break;
          case CawVersionOrder::Same:
            page += F("You have the latest version.");
            break;
          case CawVersionOrder::Older:
            page += F("The latest release (");
            page += escape(version);
            page += F(") is older than this firmware.");
            break;
          case CawVersionOrder::Unknown:
            page += F("Latest release: ");
            page += escape(version);
            page += '.';
            break;
        }
      }
      page += F("</p>");
      const CawVersionOrder order = cawCompareVersions(version, kVersion);
      if (strcmp(outcome, "checked") == 0 && !error[0] &&
          (order == CawVersionOrder::Newer || order == CawVersionOrder::Unknown)) {
        page += F("<form method=post action=/update/install><button>Install ");
        page += escape(version);
        page += F("</button></form><small>The clock restarts, downloads it from GitHub, checks "
                  "its SHA-256 and installs it only if it matches (about 2 minutes).</small>");
      }
    }
    page += F("<form method=post action=/update/check><button>Check for updates"
              "</button></form>");
#if CAW_C2
    // The SDC2's factory start-up loader has no app rollback: c2/main_app.cpp
    // goes back to the other slot after repeated crashed starts instead.
    page += F("<p><small>Automatic rollback: if a new firmware keeps crashing when it starts, "
              "the clock goes back to the previous one by itself.");
#else
    const CawRollbackSpace space = cawRollbackSpace();
    page += F("<p><small>Automatic rollback: ");
    if (cawRollbackFits(space)) {
      page += F("on. Before an update the clock keeps a copy of this firmware and goes "
                "back to it if the new one doesn't start correctly.");
    } else {
      page += F("off, not enough free space (");
      page += String(space.available / 1048576.0F, 1);
      page += F(" MB free, ");
      page += String(space.needed / 1048576.0F, 1);
      page += F(" MB needed). Delete some memes to turn it on, or update without it.");
    }
#endif
    page += F("</small></p><h3>Install a file</h3>");
  }
  page += F("<form method=post action=/update enctype=multipart/form-data><input type=file "
            "name=firmware accept=.bin required><button>Install firmware</button></form><small>"
            "Do not power off while the clock restarts.</small></section>");
}

// ------------------------------------------------------------------ access

bool fromSetupNetwork() {
  return accessPointRunning && app->server.client().localIP() == WiFi.softAPIP();
}

bool passwordSet() { return app->config.apiPassword[0] != '\0'; }

// DNS rebinding: a web page can point a domain of its own at the clock's
// address; its requests then carry that domain both as Host and as Origin,
// so sameOrigin() passes. With a clock password the browser has no sign-in
// for that domain, but without one nothing else would stop it (up to a
// firmware upload). So a clock without a password answers only under its
// own names: its IP address (shown on the screen) or its network name
// (caw-clock, caw-clock.local, or as home routers name it), which no
// website can take.
bool hostTrusted() {
  String host = app->server.hostHeader();
  const int colon = host.indexOf(':');
  if (colon >= 0) host.remove(colon);
  host.toLowerCase();
  if (host.isEmpty()) return false;
  if (host == WiFi.localIP().toString() || host == WiFi.softAPIP().toString()) return true;
  String name = configuredHostname(app->config);
  name.toLowerCase();
  if (host == name) return true;
  static const char *const kLocalSuffixes[] = {".local", ".lan", ".home", ".localdomain",
                                               ".home.arpa", ".fritz.box", ".box"};
  for (const char *suffix : kLocalSuffixes)
    if (host == name + suffix) return true;
  return false;
}

// True when the request may use the panel. Sends nothing.
bool permitted() {
  if (fromSetupNetwork()) return true;  // WPA2 key is shown on the clock
  if (!passwordSet()) return hostTrusted();  // until a password is set (panel warns)
  return app->server.authenticate(configuredUsername(app->config), app->config.apiPassword);
}

bool authorised() {
  if (permitted()) return true;
  if (!passwordSet()) {  // refused by hostTrusted(): say how to open the clock
    app->server.send(403, F("text/plain"),
                     String(F("Open the clock at http://")) + WiFi.localIP().toString() +
                         F("/ (the address on its screen), or set a clock password."));
    return false;
  }
  app->server.requestAuthentication(DIGEST_AUTH, "CAW Clock");
  return false;
}

// Browsers attach the saved sign-in to requests any web page makes to the
// clock, so another site could submit these forms (even a firmware upload).
// They also send that site's Origin; accept a form only from our own pages.
// Tools without an Origin header (curl) still have to authenticate.
bool sameOrigin() {
  const String &origin = app->server.header(F("Origin"));
  return origin.isEmpty() || origin == String(F("http://")) + app->server.hostHeader();
}

// Gate for every state-changing request.
bool postAllowed() {
  if (!sameOrigin()) {
    app->server.send(403, F("text/plain"),
                     F("Open the clock's settings page directly and try again."));
    return false;
  }
  return authorised();
}

// The page shown after a form: the message, then a link back to `tab`.
// Messages are flash strings (F("...")) or a built String, so their text
// takes no RAM while the clock runs; a plain "..." does not compile.
template <typename Message>
void redirectHome(const Message &message, const char *tab = "") {
  static_assert(!std::is_convertible<Message, const char *>::value,
                "page messages are flash strings: write F(\"...\")");
  ServerPageSink sink{app->server};
  Page page(sink);
  beginPage(page, "CAW Clock");
  page += F("<section><p>");
  page += message;
  // The result of a POST is shown at "/" so that refreshing the page never
  // resubmits the form (e.g. a firmware upload).
  page += F("</p><p><a style='color:#b79cff' href='/?back#");  // the query makes it a real page load, not a hash jump
  page += tab;
  page += F("'>Back</a></p></section></main><script>history.replaceState(null,'','/')</script>");
  page.finish();
}

template <typename Message>
void restartSoon(const Message &message) {
  clearBootGuard();  // deliberate restarts never count towards safe mode
  redirectHome(message);
  // A page sent in pieces ends with an empty piece, which the web server
  // only sends after the handler returns: send it now, before the restart.
  // (Nothing is sent for a page that went out whole.)
  app->server.sendContent("");
  delay(500);
  ESP.restart();
}

// ------------------------------------------------------------------- pages

void sendSetupPage() {
  ServerPageSink sink{app->server};
  Page page(sink);
  beginPage(page, "Set up CAW Clock");
  if (wifiFailure && app->config.ssid[0]) {
    page += F("<section style='border-color:#ff4d4d'><h2>Couldn't join your Wi-Fi</h2><p>");
    page += escape(app->config.ssid);
    page += F(": ");
    page += wifiFailure;
    page += F(". Names are case-sensitive and the clock needs a 2.4 GHz network.</p></section>");
  }
  page += F("<section><form method=post action=/setup><label>Wi-Fi network</label>");
  // Networks the clock can see (2.4 GHz only), strongest first, so the name
  // never has to be typed. "Other" covers hidden networks.
  const int scanned = WiFi.scanComplete();
  const int found = scanned > 32 ? 32 : scanned;  // strongest of the first 32 seen
  bool listed = false;
  if (found > 0) {
    page += F("<select name=network id=network onchange=\"other.hidden=this.value!==''\">");
    bool used[32]{};
    for (int pick = 0; pick < found; ++pick) {
      int best = -1;
      for (int index = 0; index < found; ++index) {
        if (used[index] || WiFi.SSID(index).isEmpty()) continue;
        if (best < 0 || WiFi.RSSI(index) > WiFi.RSSI(best)) best = index;
      }
      if (best < 0) break;
      used[best] = true;
      const String name = WiFi.SSID(best);
      bool duplicate = false;
      for (int index = 0; index < found; ++index)
        if (used[index] && index != best && WiFi.SSID(index) == name) duplicate = true;
      if (duplicate) continue;  // same name on several access points
      page += F("<option value='");
      page += escape(name.c_str());
      page += name == app->config.ssid || (!listed && !app->config.ssid[0]) ? F("' selected>") : F("'>");
      page += escape(name.c_str());
      const int32_t rssi = WiFi.RSSI(best);
      page += rssi > -60 ? F(" (strong)") : rssi > -75 ? F(" (good)") : F(" (weak)");
      page += F("</option>");
      listed = true;
    }
    page += F("<option value=''>Other network...</option></select>");
  }
  page += listed ? F("<div id=other hidden>") : F("<div id=other>");
  page += F("<label>Network name</label><input name=ssid maxlength=32 autocapitalize=none "
            "autocorrect=off spellcheck=false value='");
  page += escape(app->config.ssid);
  page += F("'></div>");
  if (scanned == WIFI_SCAN_RUNNING) page += F("<small>Looking for networks... reload in a few seconds.</small>");
  page += F("<small><a style='color:#b79cff' href=/scan>Scan again</a></small>"
            "<label>Wi-Fi password</label><input name=wifi type=password maxlength=64>"
            "<label>Clock password (8-32 characters)");
  if (app->config.apiPassword[0]) page += F(", leave blank to keep");
  page += F("</label><input name=password type=password minlength=8 maxlength=32");
  if (!app->config.apiPassword[0]) page += F(" required");
  page += F("><label>Time zone</label><select name=timezone>");
  timeZoneOptions(page);
  page += F("</select><button>Save and connect</button></form><small>Sign in to the "
            "clock later as <b>");
  page += escape(configuredUsername(app->config));
  page += F("</b> with this password.</small></section>");
  addFlashText(page, kDetectZoneScript);
  firmwareForm(page);
  page += F("</main>");
  page.finish();
}

// Next top-left picture: random (never the same twice in a row) or in order.
// "Original crow only" shows the crow whatever else is enabled.
void nextPicture() {
  CawPictures &pictures = app->pictures;
  pictures.configure(app->settings.pictureCrow, app->settings.builtinOff);
  pictureKey = app->settings.pictureSeconds == kPictureOff
                   ? CawPictures::kCrowKey
                   : pictures.next(pictureKey, app->settings.pictureRandom);
}

bool chainShown(uint8_t index) { return app->settings.chainMask & (1U << index); }

// Total burned as text ("11.521T", as the Discord bot), when every chain's
// figures are recent enough.
bool burnTotalText(char *out, size_t size) {
  double burned = 0;
  if (!cawBurnTotal(burnSupply, kCawBurnChainCount, millis(), kBurnSupplyMaxAgeMs, burned))
    return false;
  cawFormatCawAmount(burned, out, size, 3);
  return true;
}

// Status tab: total burned, the last burns found and each chain's last check.
void statusBurnsPanel(Page &page) {
  page += F("<section data-tab=status><h2>Burns</h2><table>");
  if (!app->settings.burnAlerts) {
    page += F("<tr><td style=white-space:nowrap>Burn alert</td><td>Off (Display tab)</td></tr></table></section>");
    return;
  }
  char text[16];
  page += F("<tr><td style=white-space:nowrap>Total burned</td><td>");
  if (burnTotalText(text, sizeof(text))) page += text;
  else page += F("counting<br><small>every chain is asked within 6 minutes</small>");
  page += F("</td></tr>");
  if (!burnRecordCount) page += F("<tr><td style=white-space:nowrap>Last burns</td><td>none since the clock started</td></tr>");
  for (uint8_t index = 0; index < burnRecordCount; ++index) {
    const BurnRecord &record = burnRecords[index];
    const uint32_t minutes = (millis() - record.at) / 60000;
    page += F("<tr><td style=white-space:nowrap>");
    if (minutes < 1) page += F("just now");
    else if (minutes < 120) { page += minutes; page += F(" min ago"); }
    else { page += minutes / 60; page += F(" h ago"); }
    page += F("</td><td>");
    cawFormatCawAmount(record.burned, text, sizeof(text));
    page += text;
    page += F("<br><small>");
    page += record.from;
    if (record.direct) {
      page += F(" &middot; ");
      page += record.to;
    } else {
      page += F(" to ");
      page += record.to;
      page += F(" &middot; bridged ");
      cawFormatCawAmount(record.bridged, text, sizeof(text));
      page += text;
    }
    // The transaction on the chain's explorer, to check it there.
    if (const char *explorer = record.haveTx ? cawBurnExplorer(record.chain) : nullptr) {
      char hash[67] = "0x";
      for (uint8_t at = 0; at < 32; ++at) snprintf(hash + 2 + 2 * at, 3, "%02x", record.tx[at]);
      page += F(" &middot; <a style='color:#b79cff' target=_blank rel=noopener href='https://");
      page += explorer;
      page += F("/tx/");
      page += hash;
      page += F("'>tx</a>");
    }
    page += F("</small></td></tr>");
  }
  page += F("<tr><td style=white-space:nowrap>Checks</td><td><small>");
  for (uint8_t index = 0; index < kCawBurnChainCount; ++index) {
    if (index) page += F(" &middot; ");
    char name[12];
    page += F("<span style=white-space:nowrap>");  // "polygon ok" stays on one line
    page += cawBurnText(kCawBurnChains[index].name, name, sizeof(name));
    page += ' ';
    page += burnWatch[index].result;
    page += F("</span>");
  }
  page += F("</small></td></tr></table></section>");
}

void sendPanel() {
  if (!authorised()) return;
  ServerPageSink sink{app->server};
  Page page(sink);
  beginPage(page, "CAW Clock");
  if (safeMode) {
    page += F("<section style='border-color:#ff4d4d'><h2>Safe mode</h2><p>The clock restarted ");
    page += quickRestarts;
    page += F(" times in a row (last: ");
    page += escape(ESP.getResetReason().c_str());
    page += F("), so price updates are paused. Install other firmware below, or "
              "try a normal start.</p><form method=post action=/restart>"
              "<button>Restart normally</button></form></section>");
  }
  if (availableVersion[0] && !safeMode) {
    page += F("<section><b>Version ");
    page += escape(availableVersion);
    page += F(" is available.</b> Install it on the <a href='/?update#system'>System</a> tab.</section>");
  }
  if (!passwordSet() && !fromSetupNetwork()) {
    page += F("<section style='border-color:#ff4d4d'><h2>No clock password</h2><p>Anyone on "
              "your network can change these settings or install firmware. Set a password "
              "under <b>Clock password</b> below.</p></section>");
  }
  page += F("<nav class=tabs hidden><button data-go=status>Status</button>"
            "<button data-go=display>Display</button><button data-go=memes>Memes</button>"
            "<button data-go=system>System</button></nav>"
            "<section data-tab=status><h2>Markets</h2><table>");
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    const CawFeedLite &feed = app->feeds[index];
    if (!chainShown(index) && index != 0) continue;
    const CawMarket &market = feed.market();
    page += F("<tr><td>");
    page += feed.chain().label;
    page += F("<br><small>");
    const int32_t age = feed.secondsSinceSuccess();
    if (age < 0) page += F("no data yet");
    else { page += age / 60; page += F(" min ago"); }
    page += F(" · ");
    page += feed.lastResult();
    page += F("</small></td><td>");
    page += escape(feed.displayPrice());
    page += F("<br><small>");
    page += market.valid ? escape(market.change1h) : String("--");
    page += F(" / ");
    page += market.valid ? escape(market.change24h) : String("--");
    page += F("</small></td></tr>");
  }
  page += F("</table></section><section data-tab=status><h2>Clock</h2><table><tr><td>Wi-Fi</td><td>");
  page += escape(app->config.ssid);
  page += F(" · ");
  page += WiFi.RSSI();
  page += F(" dBm</td></tr><tr><td>Address</td><td>");
  page += WiFi.localIP().toString();
  page += F("</td></tr><tr><td>Firmware</td><td>");
  page += kVersion;
  page += F("</td></tr><tr><td>Memory free</td><td>");
  page += ESP.getFreeHeap();
  page += F(" B (block ");
  page += ESP.getMaxFreeBlockSize();
  page += F(")</td></tr></table></section>");
  statusBurnsPanel(page);

  page += F("<section data-tab='display memes'><form method=post action=/settings>"
            "<div data-tab=display><h2>Display</h2><label>Brightness</label><input type=range name=brightness min=0 max=100 value=");
  page += app->settings.brightness;
  page += F("><label style='color:#eef0f2'><input type=checkbox style='width:auto' name=night");
  page += app->settings.nightEnabled ? F(" checked") : F("");
  page += F("> Night mode: dim the screen</label><div style='display:flex;gap:10px'>"
            "<div style='flex:1'><label>From</label><input type=time name=nightStart value=");
  page += minutesText(app->settings.nightStart);
  page += F("></div><div style='flex:1'><label>Until</label><input type=time name=nightEnd value=");
  page += minutesText(app->settings.nightEnd);
  page += F("></div></div><label>Night brightness (0 turns the screen off)</label>"
            "<input type=range name=nightBrightness min=0 max=100 value=");
  page += app->settings.nightBrightness;
  page += F("><label>Chains to show</label>");
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    page += F("<label style='display:inline-block;margin-right:14px;color:#eef0f2'>"
              "<input type=checkbox style='width:auto' name=chain");
    page += index;
    page += chainShown(index) ? F(" checked> ") : F("> ");
    page += kCawChains[index].label;
    page += F("</label>");
  }
  page += F("<label>Time on each chain</label><select name=rotate>");
  for (uint16_t choice : kRotateChoices) {
    page += F("<option value=");
    page += choice;
    page += choice == app->settings.rotateSeconds ? F(" selected>") : F(">");
    if (choice < 60) { page += choice; page += F(" seconds"); }
    else { page += choice / 60; page += choice == 60 ? F(" minute") : F(" minutes"); }
    page += F("</option>");
  }
  page += F("</select><label>Price alert: flash the price when a chain moves this much in 1 hour"
            "</label><select name=alert>");
  for (uint8_t choice : kAlertChoices) {
    page += F("<option value=");
    page += choice;
    page += choice == app->settings.alertPercent ? F(" selected>") : F(">");
    if (choice == 0) page += F("Off");
    else { page += choice; page += '%'; }
    page += F("</option>");
  }
  page += F("</select><label>Burn alert: show CAW burned when someone bridges (checked every "
            "few minutes)</label><select name=burn><option value=1");
  page += app->settings.burnAlerts ? F(" selected") : F("");
  page += F(">On</option><option value=0");
  page += app->settings.burnAlerts ? F("") : F(" selected");
  // The preview button right under its setting, then the supply screen.
  page += F(">Off</option></select><button type=submit class=ghost formaction=/burn/test "
            "style='margin-top:8px'>Preview the burn alert</button>");
  if (releaseCandidate())
    page += F("<button type=submit class=ghost formaction=/burn/furnace-test style='margin-top:8px'>"
              "Preview The Great Furnace burn</button>");
  page += F("<label>Supply screen: where CAW is, burned and holders "
            "(once each round of chains)</label><select name=supply><option value=1");
  page += app->settings.supplyScreen ? F(" selected") : F("");
  page += F(">On</option><option value=0");
  page += app->settings.supplyScreen ? F("") : F(" selected");
  page += F(">Off</option></select>");
  page += F("<label>Clock</label><select name=clock><option value=24");
  page += app->settings.clock24 ? F(" selected") : F("");
  page += F(">24-hour (19:05)</option><option value=12");
  page += app->settings.clock24 ? F("") : F(" selected");
  page += F(">12-hour (7:05)</option></select><label>Time zone</label><select name=timezone>");
  timeZoneOptions(page);
  page += F("</select></div><div data-tab=memes><h2>Memes</h2><label>Meme (top left): ");
  page += app->pictures.builtinCount();
  page += F(" built-in + ");
  page += app->pictures.uploadCount();
  page += F(" uploaded memes</label><select name=picture>");
  for (uint16_t choice : kPictureChoices) {
    page += F("<option value=");
    page += choice;
    page += choice == app->settings.pictureSeconds ? F(" selected>") : F(">");
    if (choice == kPictureOff) page += F("Original crow only");
    else if (choice == kPictureWithChain) page += F("New meme with each chain");
    else if (choice < 60) { page += F("Every "); page += choice; page += F(" seconds"); }
    else if (choice == 60) page += F("Every minute");
    else if (choice < 3600) { page += F("Every "); page += choice / 60; page += F(" minutes"); }
    else page += F("Every hour");
    page += F("</option>");
  }
  page += F("</select><label>Meme order</label><select name=pictureOrder><option value=random");
  page += app->settings.pictureRandom ? F(" selected") : F("");
  page += F(">Random</option><option value=sequence");
  page += app->settings.pictureRandom ? F("") : F(" selected");
  page += F(">In order</option></select><label style='color:#eef0f2'><input type=checkbox "
            "style='width:auto' name=pictureCrow");
  page += app->settings.pictureCrow ? F(" checked") : F("");
  page += F("> Include the original crow</label></div><button>Save</button></form></section>"
            "<section data-tab=memes style='padding:0;border:0;background:none'>"
            "<iframe title=memes data-src='/memes?embed=1' scrolling=no "
            "style='width:100%;height:700px;border:0'></iframe></section>");

  page += F("<section data-tab=system><h2>Wi-Fi</h2><form method=post action=/wifi>"
            "<label>Network name (case-sensitive, 2.4 GHz)</label><input name=ssid maxlength=32 "
            "required autocapitalize=none autocorrect=off spellcheck=false value='");
  page += escape(app->config.ssid);
  page += F("'><label>Password</label><input name=wifi type=password maxlength=64>"
            "<button>Save and restart</button></form></section>");

  page += F("<section data-tab=system><h2>Clock password</h2><form method=post action=/password>"
            "<label>New password (8-32 characters)</label>"
            "<input name=password type=password minlength=8 maxlength=32 required>"
            "<label>Repeat</label><input name=confirm type=password minlength=8 maxlength=32 required>"
            "<button>Change password</button></form></section>");
  firmwareForm(page, true);
#if CAW_DUAL
  page += F("<section><h2>Screen mode</h2><p>Showing the CAW screen. Home Assistant "
            "mode shows the dashboards Home Assistant sends to the clock.</p>"
            "<form method=post action=/mode><button>Restart in Home Assistant mode</button>"
            "</form></section>");
#endif
  page += F("<section data-tab=system><h2>Maintenance</h2><form method=post action=/restart>"
            "<button class=ghost>Restart</button></form>"
            "<form method=post action=/factory-reset onsubmit=\"return confirm('Erase Wi-Fi, "
            "password and settings?')\"><button class=ghost>Factory reset</button></form>"
            "</section>");
  page += F("</main><script>(function(){var t=document.querySelectorAll('[data-tab]'),"
            "b=document.querySelectorAll('.tabs button'),n=document.querySelector('.tabs');"
            "var f=document.querySelector('iframe');function fit(){try{var d=f.contentDocument;"
            "if(d&&d.body)f.style.height=d.documentElement.scrollHeight+'px'}catch(e){}}"
            "setInterval(fit,400);"
            "function go(k){if(k=='memes'&&!f.src)f.src=f.dataset.src;for(var i=0;i<t.length;i++)t[i].hidden=(' '+t[i].dataset.tab+' ')"
            ".indexOf(' '+k+' ')<0;for(i=0;i<b.length;i++)b[i].className=b[i].dataset.go==k?'on':'';"
            "try{history.replaceState(null,'','#'+k)}catch(e){}}"
            "for(var i=0;i<b.length;i++)b[i].onclick=function(){go(this.dataset.go)};"
            "n.hidden=false;var h=location.hash.slice(1);"
            "go(['status','display','memes','system'].indexOf(h)<0?'status':h)})()</script>");
  page.finish();
}

// /api/status is filled in three parts, each its own (not inlined) function:
// their temporaries are gone again before the next part and before the
// response is sent, which keeps this handler's main-stack use low.
__attribute__((noinline)) void statusSystem(JsonDocument &document) {
  document["firmware"] = kVersion;
#if CAW_DUAL
  document["edition"] = "caw+homeassistant";
  document["mode"] = "caw";
#else
  document["edition"] = "caw";
#endif
  document["uptimeSeconds"] = millis() / 1000;
  // Why the clock last started: power-on, software restart (update or panel),
  // or an exception / watchdog reset, which would point to a crash.
  document["resetReason"] = ESP.getResetReason();
  document["safeMode"] = safeMode;
  document["recovery"] = recoveryActive();
  document["quickRestarts"] = quickRestarts;
  {
    const rst_info *info = ESP.getResetInfoPtr();
    char hex[11];
    JsonObject reset = document.createNestedObject("lastReset");
    reset["reason"] = info->reason;
    reset["exception"] = info->exccause;
    snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(info->epc1));
    reset["epc1"] = hex;
    snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(info->excvaddr));
    reset["excvaddr"] = hex;
  }
  document["ip"] = WiFi.localIP().toString();
  document["rssi"] = WiFi.RSSI();
  document["freeHeap"] = ESP.getFreeHeap();
  document["maxFreeBlock"] = ESP.getMaxFreeBlockSize();
  document["timezone"] = app->settings.timezone;
  document["brightness"] = app->settings.brightness;
  {
    JsonObject night = document.createNestedObject("nightMode");
    night["enabled"] = app->settings.nightEnabled;
    night["active"] = nightActive();
    night["from"] = minutesText(app->settings.nightStart);
    night["until"] = minutesText(app->settings.nightEnd);
    night["brightness"] = app->settings.nightBrightness;
  }
  document["backlight"] = appliedBrightness;
  // Raw ADC (0-1023). If this changes when the clock is covered, the board
  // has a light sensor that automatic dimming could use.
  document["lightSensorRaw"] = analogRead(A0);
  document["shownChain"] = kCawChains[activeChain].id;
  document["rotateSeconds"] = app->settings.rotateSeconds;
  {
    JsonObject memes = document.createNestedObject("memes");
    uint32_t total = 0, used = 0;
    app->pictures.space(total, used);
    memes["showing"] = pictureKey;  // 0 crow, 256+n built-in n, 16777216+id upload
    memes["builtin"] = app->pictures.builtinCount();
    memes["uploaded"] = app->pictures.uploadCount();
    memes["animated"] = app->pictures.animatedCount();
    memes["playing"] = animationActive;
    memes["inRotation"] = app->pictures.shownCount();
    memes["uploadsLeft"] = app->pictures.uploadsLeft();
    memes["maxUploads"] = CawPictures::kMaxUploads;
    memes["storageBytes"] = total;
    memes["storageUsedBytes"] = used;
  }
  document["passwordSet"] = passwordSet();
  document["rollbackCopy"] = rollbackPending;  // a new firmware is on trial
  // Stack high-water marks: bytes of the 4 KB main stack never used since
  // start (painted-stack scan), and the most the 6 KB TLS stack has used.
  document["freeContStack"] = ESP.getFreeContStack();  // since start-up ended
  document["freeContStackBoot"] = bootFreeContStack;     // during start-up
  document["stackLowWork"] = lowestStackWork;            // web / fetch / screen
  document["tlsStackMax"] = cawTlsStackMax();
  document["tlsRsaRoots"] = cawTlsRsaRoots();
}

__attribute__((noinline)) void statusCrash(JsonDocument &document) {
  {
    // The last crash or watchdog reset: where it happened, the size and
    // caller of the allocation that failed, and a stack trail to decode.
    const CawCrashRecord &crash = cawLastCrash();
    if (crash.valid) {
      char hex[11];
      JsonObject item = document.createNestedObject("lastCrash");
      item["firmware"] = crash.version;
      item["uptimeSeconds"] = crash.uptime;
      item["stage"] = crash.stage;
      item["detail"] = crash.detail;
      item["freeHeapAtStage"] = crash.heap;
      item["reason"] = crash.reason;
      item["exception"] = crash.exception;
      snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.epc1));
      item["epc1"] = hex;
      snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.excvaddr));
      item["excvaddr"] = hex;
      item["source"] = crash.fromResetInfo ? "reset_info" : "crash_handler";
      item["storedEarlier"] = crash.fromFile;
      item["failedAllocBytes"] = crash.failSize;
      snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.failAddr));
      item["failedAllocCaller"] = hex;
      JsonArray stack = item.createNestedArray("stack");
      for (uint8_t index = 0; index < crash.stackCount; ++index) {
        snprintf(hex, sizeof(hex), "0x%08lx", static_cast<unsigned long>(crash.stack[index]));
        stack.add(hex);
      }
    }
  }
}

__attribute__((noinline)) void statusBurns(JsonDocument &document) {
  JsonObject burns = document.createNestedObject("burns");
  burns["enabled"] = app->settings.burnAlerts;
  burns["shown"] = burnsShown;
  burns["waiting"] = burnGate.count;
  burns["coolingDown"] = burnGate.cooling;
  burns["supplyScreen"] = app->settings.supplyScreen;
  burns["holdersResult"] = holdersResult;
  double burned = 0;
  if (cawBurnTotal(burnSupply, kCawBurnChainCount, millis(), kBurnSupplyMaxAgeMs, burned))
    burns["totalBurned"] = burned;
  else
    burns["totalBurned"] = nullptr;
  JsonArray chains = burns.createNestedArray("chains");
  for (uint8_t index = 0; index < kCawBurnChainCount; ++index) {
    const BurnWatch &watch = burnWatch[index];
    JsonObject item = chains.createNestedObject();
    char name[12];
    item["chain"] = cawBurnText(kCawBurnChains[index].name, name, sizeof(name));
    item["result"] = watch.result;
    item["block"] = static_cast<double>(watch.cursor);
    item["seenBlock"] = static_cast<double>(watch.seenBlock);
    item["seen"] = watch.seen;
    item["failures"] = watch.failures;
    item["httpStatus"] = watch.httpStatus;
    item["sslError"] = watch.sslError;
    item["fullBuffers"] = watch.fullBuffers;
    if (burnSupply[index].known) item["circulating"] = burnSupply[index].circulating;
    uint32_t holders = 0;
    bool anyHolders = false;
    for (uint8_t source = 0; source < kCawHolderSourceCount; ++source)
      if (kCawHolderSources[source].chain == index && holderKnown[source]) {
        holders += holderCounts[source];
        anyHolders = true;
      }
    if (anyHolders) item["holders"] = holders;
    item["secondsAgo"] = watch.polledAt ? static_cast<int32_t>((millis() - watch.polledAt) / 1000) : -1;
  }
}

__attribute__((noinline)) void statusChains(JsonDocument &document) {
  JsonArray chains = document.createNestedArray("chains");
  for (uint8_t index = 0; index < kCawChainCount; ++index) {
    const CawFeedLite &feed = app->feeds[index];
    const CawMarket &market = feed.market();
    JsonObject item = chains.createNestedObject();
    item["chain"] = feed.chain().id;
    item["shown"] = chainShown(index);
    item["pair"] = feed.chain().pair;
    item["price"] = market.price;
    item["display"] = feed.displayPrice();
    item["change1h"] = market.change1h;
    item["change24h"] = market.change24h;
    item["liquidity"] = market.liquidity;
    item["volume"] = market.volume;
    item["marketCap"] = market.marketCap;
    item["live"] = feed.live();
    item["alert"] = cawMoveAlertActive(alerts[index], millis());
    JsonObject fetch = item.createNestedObject("feed");
    fetch["result"] = feed.lastResult();
    fetch["source"] = feed.lastSource();
    fetch["primaryResult"] = feed.primaryResult();
    fetch["failures"] = feed.failures();
    fetch["httpStatus"] = feed.lastHttpStatus();
    fetch["sslError"] = feed.lastSslError();
    fetch["secondsSinceSuccess"] = feed.secondsSinceSuccess();
    fetch["freeHeapBefore"] = feed.lastFetchFreeHeap();
    fetch["minimumHeap"] = feed.lastFetchMinimumHeap();
    fetch["connectMs"] = feed.lastConnectMs();
    fetch["maxConnectMs"] = feed.maxConnectMs();
    fetch["resumed"] = feed.resumedConnections();
    fetch["connections"] = feed.connections();
    JsonObject chart = item.createNestedObject("chart");
    chart["points"] = feed.historyPoints();
    chart["backfill"] = feed.backfillResult();
  }
}

void sendStatusJson() {
  if (!authorised()) return;
  // 4 KB holds today's worst case (~3.5 KB with a crash record). A field that
  // does not fit is dropped silently, and the chains come last, so should a
  // later addition overflow it, the document is built again with more room.
  // When the heap has no block for the larger document, the smaller one is
  // sent as it is: what didn't fit is the end (the burns section).
  String body;
  for (size_t capacity = 4096; capacity <= 8192; capacity += 2048) {
    DynamicJsonDocument document(capacity);
    if (document.capacity() == 0) break;  // the heap has no block that size just now
    statusSystem(document);
    statusCrash(document);
    statusChains(document);
    statusBurns(document);
    body = String();
    serializeJson(document, body);
    if (!document.overflowed()) break;
  }
  if (!body.length()) {
    app->server.send_P(503, "text/plain", PSTR("Not enough free memory just now"));
    return;
  }
  app->server.send(200, "application/json", body);
}

// ------------------------------------------------------------------ actions

bool validPassword(const String &password) {
  return password.length() >= 8 && password.length() <= 32;
}

void receiveSetup() {
  if (!fromSetupNetwork() || !sameOrigin()) {
    app->server.send_P(403, "text/plain", PSTR("Setup is only available on the clock's setup network"));
    return;
  }
  const String picked = app->server.arg("network");
  const String ssid = picked.isEmpty() ? app->server.arg("ssid") : picked;
  const String wifi = app->server.arg("wifi");
  const String password = app->server.arg("password");
  const String zone = app->server.arg("timezone");
  if (ssid.isEmpty() || ssid.length() > 32 || wifi.length() > 64 ||
      (!password.isEmpty() && !validPassword(password)) ||
      (password.isEmpty() && !app->config.apiPassword[0])) {
    redirectHome(F("Check the Wi-Fi name and use a clock password of 8-32 characters."));
    return;
  }
  const bool configured = deviceConfigValid(app->config);
  DeviceConfig next = configured ? app->config : DeviceConfig{};
  strlcpy(next.ssid, ssid.c_str(), sizeof(next.ssid));
  if (!wifi.isEmpty() || !configured) strlcpy(next.wifiPassword, wifi.c_str(), sizeof(next.wifiPassword));
  if (!password.isEmpty()) strlcpy(next.apiPassword, password.c_str(), sizeof(next.apiPassword));
  if (!next.username[0]) strlcpy(next.username, "admin", sizeof(next.username));
  if (!next.hostname[0]) strlcpy(next.hostname, "caw-clock", sizeof(next.hostname));
  next.apiAuthEnabled = 1;
  next.otaAuthEnabled = 0;
  next.directOtaEnabled = 0;
  next.resetApiAuthOnRecovery = 0;
  if (!next.wifiRetryLimit) next.wifiRetryLimit = kDefaultWifiRetryLimit;
  app->config = next;
  saveDeviceConfig(app->config);
  if (timezoneValid(zone.c_str(), sizeof(app->settings.timezone)))
    strlcpy(app->settings.timezone, zone.c_str(), sizeof(app->settings.timezone));
  saveSettings();
  restartSoon(F("Saved. The clock is restarting and joining your Wi-Fi."));
}

void receiveSettings() {
  if (!postAllowed()) return;
  // Every group is applied only when its fields were sent, so a partial
  // request can't, say, read a missing brightness as 0 and blank the screen.
  if (app->server.hasArg("brightness")) {
    const int brightness = app->server.arg("brightness").toInt();
    if (brightness >= 0 && brightness <= 100) app->settings.brightness = brightness;
  }
  if (app->server.hasArg("nightBrightness")) {
    app->settings.nightEnabled = app->server.hasArg("night");
    parseMinutes(app->server.arg("nightStart"), app->settings.nightStart);
    parseMinutes(app->server.arg("nightEnd"), app->settings.nightEnd);
    const int nightBrightness = app->server.arg("nightBrightness").toInt();
    if (nightBrightness >= 0 && nightBrightness <= 100)
      app->settings.nightBrightness = nightBrightness;
  }
  const String zone = app->server.arg("timezone");
  if (timezoneValid(zone.c_str(), sizeof(app->settings.timezone)))
    strlcpy(app->settings.timezone, zone.c_str(), sizeof(app->settings.timezone));
  if (app->server.hasArg("rotate")) {  // sent with the chain checkboxes
    uint8_t mask = 0;
    for (uint8_t index = 0; index < kCawChainCount; ++index)
      if (app->server.hasArg(String("chain") + index)) mask |= 1U << index;
    app->settings.chainMask = mask ? mask : 0x01;  // at least Cronos
    const int rotate = app->server.arg("rotate").toInt();
    if (validRotate(rotate)) app->settings.rotateSeconds = rotate;
  }
  if (app->server.hasArg("clock")) app->settings.clock24 = app->server.arg("clock") != "12";
  if (app->server.hasArg("supply")) app->settings.supplyScreen = app->server.arg("supply") == "1";
  if (app->server.hasArg("burn")) {
    app->settings.burnAlerts = app->server.arg("burn") != "0";
    if (!app->settings.burnAlerts) burnGate = CawBurnGate{};  // nothing waiting to show
  }
  if (app->server.hasArg("alert")) {
    const int alert = app->server.arg("alert").toInt();
    if (validAlertPercent(alert)) app->settings.alertPercent = alert;
    if (alert == 0)
      for (CawMoveAlert &item : alerts) item = CawMoveAlert{};
  }
  if (app->server.hasArg("picture")) {
    const int picture = app->server.arg("picture").toInt();
    if (validPictureSeconds(picture)) app->settings.pictureSeconds = picture;
    app->settings.pictureRandom = app->server.arg("pictureOrder") != "sequence";
    app->settings.pictureCrow = app->server.hasArg("pictureCrow");
    lastPictureChange = 0;  // apply now
  }
  saveSettings();
  applyBacklight(true);
  applyTimeZone();
  app->screen.invalidate();
  redirectHome(F("Settings saved."), "display");
}

void receiveWifi() {
  if (!postAllowed()) return;
  const String ssid = app->server.arg("ssid");
  const String wifi = app->server.arg("wifi");
  if (ssid.isEmpty() || ssid.length() > 32 || wifi.length() > 64) {
    redirectHome(F("Check the Wi-Fi name and password."), "system");
    return;
  }
  strlcpy(app->config.ssid, ssid.c_str(), sizeof(app->config.ssid));
  if (!wifi.isEmpty()) strlcpy(app->config.wifiPassword, wifi.c_str(), sizeof(app->config.wifiPassword));
  saveDeviceConfig(app->config);
  restartSoon(F("Saved. The clock is restarting and joining the new network."));
}

void receivePassword() {
  if (!postAllowed()) return;
  const String password = app->server.arg("password");
  if (!validPassword(password) || password != app->server.arg("confirm")) {
    redirectHome(F("Passwords must match and be 8-32 characters."), "system");
    return;
  }
  strlcpy(app->config.apiPassword, password.c_str(), sizeof(app->config.apiPassword));
  app->config.apiAuthEnabled = 1;
  saveDeviceConfig(app->config);
  redirectHome(F("Password changed. Sign in again with the new password."), "system");
}

void receiveFactoryReset() {
  if (!postAllowed()) return;
  if (filesystemReady) LittleFS.format();
  eraseDeviceConfig();
  restartSoon(F("Erased. The clock restarts into setup."));
}

// Ends an upload that did not install: the running firmware is untouched.
void abandonUpdate() {
  if (Update.isRunning()) Update.end();
  cawRollbackDiscard();  // nothing was installed: the copy is not needed
  updateInProgress = false;
  uploadAllowed = false;
  applyTimeZone();  // the upload stopped all UDP, including time sync
  app->screen.invalidate();
}

void showRollbackProgress(uint8_t percent) {
  static char line[8];
  static bool drawn = false;
  snprintf(line, sizeof(line), "%u%%", percent);
  if (!drawn || percent == 0) {  // the whole message once per copy
    app->screen.showMessage(PSTR("Updating"), PSTR("Saving a copy of"),
                            PSTR("this firmware first"), line, PSTR("Do not power off"));
    drawn = true;
  } else if (percent % 5 == 0) {  // then only the figure, in 5% steps
    app->screen.showMessageLine(2, line);
  }
}

// Keeps the running firmware for an automatic rollback, if there is room.
bool saveRollbackCopy() {
  if (!filesystemReady || !cawRollbackFits(cawRollbackSpace())) return false;
  return cawRollbackSave(kVersion, showRollbackProgress);
}

// "Check for updates" / "Install": restart into update mode.
bool requestUpdateMode(const char *action, const CawReleaseInfo *release) {
  DynamicJsonDocument document(384);
  document["action"] = action;
  if (release) {
    document["version"] = release->version;
    document["file"] = release->file;
    document["sha256"] = release->sha256;
  }
  File file = LittleFS.open(kUpdateRequestPath, "w");
  if (!file) return false;
  const bool ok = serializeJson(document, file) > 0 && !file.getWriteError();
  file.close();
  return ok;
}

// The clock does not answer while it updates (update mode runs no web
// server: waiting browser requests would take memory the download needs), so
// the page polls until it is back, then opens the System tab.
const char kUpdateReload[] PROGMEM =
    "<script>setTimeout(function p(){fetch('/api/status',{cache:'no-store'}).then(function(){"
    "location='/?back#system'}).catch(function(){setTimeout(p,4000)})},20000)</script>";

// POST /burn/furnace-test (release candidates): The Great Furnace's burn
// screen, as for its 119.04M burn of 2026-11-22 (tx 0xa8f6c449...).
void receiveFurnaceTest() {
  if (!postAllowed()) return;
  if (!releaseCandidate()) {
    app->server.send_P(404, "text/plain", PSTR("Not found"));
    return;
  }
  furnaceTestRequested = true;
  redirectHome(F("The Great Furnace preview is on the clock's screen for 20 seconds."), "display");
}

// POST /burn/test: the burn screen now, for a look (Display tab button).
void receiveBurnTest() {
  if (!postAllowed()) return;
  burnTestRequested = true;
  redirectHome(F("The burn alert preview is on the clock's screen for 20 seconds."), "display");
}

void receiveRollbackDismiss() {
  if (!postAllowed()) return;
  cawRollbackClearNotice();
  redirectHome(F("<meta http-equiv=refresh content='0;url=/?back#system'>Done."), "system");
}

void receiveUpdateCheck() {
  if (!postAllowed()) return;
  const time_t now = time(nullptr);
  if (WiFi.status() != WL_CONNECTED || now < kMinimumValidEpoch) {
    redirectHome(F("The clock needs Wi-Fi and the time to check for updates."), "system");
    return;
  }
  // Normally checked right here (one small request, like a price fetch).
  CawReleaseInfo latest{};
  String error;
  bool lowMemory = false;
  app->screen.showMessage(PSTR("Checking for"), PSTR("updates"));
  const bool found =
      cawCheckLatestVersion(now, latest.version, sizeof(latest.version), error, lowMemory);
  app->screen.invalidate();
  lastScreenUpdate = 0;
  if (found || !lowMemory) {
    writeUpdateResult("checked", found ? &latest : nullptr, found ? String() : error);
    // Straight back to the System tab, where the result is shown.
    redirectHome(F("<meta http-equiv=refresh content='0;url=/?back#system'>Checked."), "system");
    return;
  }
  // Too little free memory just now: check in update mode instead.
  if (!requestUpdateMode("check", nullptr)) {
    redirectHome(F("Could not start the check (storage error)."), "system");
    return;
  }
  String message = FPSTR(kUpdateReload);
  message += F("Not enough free memory to check while showing prices, so the clock restarts "
               "to check, then restarts again. This page opens the System tab when it is back.");
  restartSoon(message);
}

void receiveUpdateInstall() {
  if (!postAllowed()) return;
  // Install the version the last check found (never one from the form). Its
  // file name and SHA-256 are read from the release in update mode.
  DynamicJsonDocument result(512);
  CawReleaseInfo release{};
  if (readUpdateResult(result) && strcmp(result["outcome"] | "", "checked") == 0 &&
      !result.containsKey("error")) {
    strlcpy(release.version, result["version"] | "", sizeof(release.version));
  }
  uint16_t parts[3];
  if (!cawParseVersion(release.version, parts) || !requestUpdateMode("install", &release)) {
    redirectHome(F("Check for updates first."), "system");
    return;
  }
  String message = FPSTR(kUpdateReload);
  message += F("Installing version ");
  message += escape(release.version);
  message += F(". The clock restarts, downloads and checks it, then restarts again "
               "(about 2 minutes; its screen shows the progress). Do not power off. This page "
               "opens the System tab when the clock is back.");
  restartSoon(message);
}

// `step` and `line2` are flash strings (PSTR) or, for a progress figure, a
// RAM buffer; both only go to the screen, which reads either.
void showUpdateStep(const char *step, const char *line2 = nullptr) {
  static const char *shownStep = nullptr;
  static const char *shownLine = nullptr;
  if (step == shownStep && line2 == shownLine) {
    // Same step: only a progress figure (one reused buffer) can have changed;
    // redraw just that line so the screen does not flash.
    const char first = line2 ? static_cast<char>(pgm_read_byte(line2)) : '\0';
    if (first >= '0' && first <= '9') app->screen.showMessageLine(2, line2);
    return;
  }
  shownStep = step;
  shownLine = line2;
  const bool install = updateMode == UpdateMode::Install;
  app->screen.showMessage(install ? PSTR("Updating") : PSTR("Checking for"),
                          install ? updateRelease.version : PSTR("updates"), step, line2,
                          PSTR("Do not power off"));
}

void showDownloadProgress(uint32_t done, uint32_t total) {
  static uint8_t shown = 255;
  const uint8_t percent = total ? static_cast<uint8_t>(static_cast<uint64_t>(done) * 100 / total) : 0;
  if (percent == shown || percent % 5) return;
  shown = percent;
  static char line[16];
  snprintf(line, sizeof(line), "%u%%", percent);
  showUpdateStep(PSTR("Downloading"), line);
}

void finishUpdateMode() {
  clearBootGuard();  // a deliberate restart
  delay(500);
  ESP.restart();
}

// One pass of update mode: wait for Wi-Fi and the time (certificates are
// checked against it), then check or install once and restart.
constexpr uint32_t kUpdateModeTimeoutMs = 120000;

// Not inlined: its locals would otherwise widen cawAppLoop's frame, which
// sits under every price fetch.
__attribute__((noinline)) void updateModeLoop() {
  const time_t now = time(nullptr);
  const bool ready = WiFi.status() == WL_CONNECTED && now >= kMinimumValidEpoch;
  if (!ready) {
    if (millis() - updateModeSince < kUpdateModeTimeoutMs) {
      showUpdateStep(WiFi.status() == WL_CONNECTED ? PSTR("Getting the time")
                                                   : PSTR("Joining Wi-Fi"));
      delay(50);
      return;
    }
    writeUpdateResult(updateMode == UpdateMode::Check ? "checked" : "failed",
                      updateMode == UpdateMode::Install ? &updateRelease : nullptr,
                      F("no internet connection"));
    finishUpdateMode();
    return;
  }
  String error;
  if (updateMode == UpdateMode::Check) {
    showUpdateStep(PSTR("Asking GitHub"));
    CawReleaseInfo latest{};
    bool lowMemory = false;
    if (cawCheckLatestVersion(now, latest.version, sizeof(latest.version), error, lowMemory))
      writeUpdateResult("checked", &latest, String());
    else
      writeUpdateResult("checked", nullptr, error);
    finishUpdateMode();
    return;
  }
  // The release's own SHA256SUMS.txt (over HTTPS) gives the file name and the
  // checksum the download must match.
  showUpdateStep(PSTR("Reading the release"));
  CawReleaseInfo release{};
  // The file host's 16 KB TLS records need nearly all free memory on the
  // ESP8266: the file system (its caches and state) is unmounted for both
  // downloads and mounted again for the copy and the result file.
  LittleFS.end();
  const bool fetched = cawFetchLatestRelease(now, release, error);
  LittleFS.begin();
  if (!fetched ||
      strcmp(release.version, updateRelease.version) != 0) {
    if (!error.length()) error = F("the latest release changed; check again");
    writeUpdateResult("failed", &updateRelease, error);
    finishUpdateMode();
    return;
  }
  updateRelease = release;
  // Install: rollback copy first (skipped without room), then the download,
  // installed only when its SHA-256 matches the release's SHA256SUMS.txt.
  showUpdateStep(PSTR("Saving a copy of"), PSTR("this firmware"));
  const bool copied = saveRollbackCopy();
  showUpdateStep(PSTR("Downloading"));
  LittleFS.end();
  const bool installed = cawInstallRelease(now, updateRelease, error, showDownloadProgress);
  LittleFS.begin();
  if (installed) {
    writeUpdateResult("installed", &updateRelease, String());
    showUpdateStep(PSTR("Installed"), PSTR("Restarting"));
  } else {
    if (copied) cawRollbackDiscard();
    writeUpdateResult("failed", &updateRelease, error);
    showUpdateStep(PSTR("Not installed"), PSTR("Restarting"));
  }
  finishUpdateMode();
}

// Start-up: the request file (written by the panel) turns this start into
// update mode. It is deleted first, so a crash can never loop back into it.
void readUpdateRequest() {
  if (!filesystemReady || !LittleFS.exists(kUpdateRequestPath)) return;
  File file = LittleFS.open(kUpdateRequestPath, "r");
  DynamicJsonDocument document(384);
  const bool ok = file && !deserializeJson(document, file);
  if (file) file.close();
  LittleFS.remove(kUpdateRequestPath);
  if (!ok || safeMode) return;
  const char *action = document["action"] | "";
  if (strcmp(action, "check") == 0) {
    updateMode = UpdateMode::Check;
  } else if (strcmp(action, "install") == 0) {
    strlcpy(updateRelease.version, document["version"] | "", sizeof(updateRelease.version));
    uint16_t parts[3];
    if (cawParseVersion(updateRelease.version, parts)) updateMode = UpdateMode::Install;
  }
  updateModeSince = millis();
}

void showRollbackMessage(const char *version) {
  app->screen.showMessage(PSTR("Updating"), PSTR("Returning to the"), PSTR("previous version"),
                          version, PSTR("Do not power off"));
}

// Called for each chunk of the upload, before the request handler. Checked
// once at the start; a refused upload is read and discarded, and the reply
// (401 or 403) comes from finishUpdate().
void receiveUpdate() {
  HTTPUpload &upload = app->server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    uploadHead = CawFirmwareHead{};
    uploadWrongBoard = false;
    uploadAllowed = sameOrigin() && permitted();
    if (!uploadAllowed) return;
    updateInProgress = true;
    lastUploadActivity = millis();
    WiFiUDP::stopAll();
    saveRollbackCopy();  // before anything is written; skipped when there is no room
    lastUploadActivity = millis();
    app->screen.showMessage(PSTR("Updating"), PSTR("Do not power off"));
    Update.begin(ESP.getFreeSketchSpace() & 0xFFFFF000);
    return;
  }
  if (!uploadAllowed) return;
  lastUploadActivity = millis();
  if (upload.status == UPLOAD_FILE_WRITE) {
    // The other SD PRO board's firmware (or no firmware at all) is refused
    // within its first 16 bytes, long before the end that would install it
    // (on the ESP8266 it would be installed: its updater can't tell).
    if (!uploadHead.feed(upload.buf, upload.currentSize)) {
      uploadWrongBoard = true;
      abandonUpdate();  // uploadAllowed = false: the rest is read and dropped
      return;
    }
    Update.write(upload.buf, upload.currentSize);
  } else if (upload.status == UPLOAD_FILE_END) {
    if (!uploadHead.accepted()) {  // under 16 bytes: not firmware
      uploadWrongBoard = true;
      abandonUpdate();
      return;
    }
    Update.end(true);
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    abandonUpdate();
  }
  yield();
}

void finishUpdate() {
  if (!postAllowed()) return;
  const bool installed = uploadAllowed && uploadHead.accepted() && !Update.hasError() && !Update.isRunning();
  if (!installed) {
    abandonUpdate();
    if (uploadWrongBoard) {
      uploadWrongBoard = false;
#if CAW_C2
      redirectHome(F("This file is not firmware for this clock. This clock has the ESP32-C2 board: "
                     "install caw-clock-sdc2-&lt;version&gt;.bin. Nothing was changed."), "system");
#else
      redirectHome(F("This file is not firmware for this clock. This clock has the ESP8266 board: "
                     "install caw-clock-&lt;version&gt;.bin (not the sdc2 file). Nothing was changed."), "system");
#endif
      return;
    }
    redirectHome(F("Update failed. The current firmware keeps running."), "system");
    return;
  }
  updateInProgress = false;
  uploadAllowed = false;
  restartSoon(F("Update installed. The clock is restarting."));
}

// ------------------------------------------------------------------- memes
// /memes: built-in memes (show/hide) and uploads (add, show/hide, delete).
// The browser turns each chosen image into the clock's 56 x 56 format
// ("CWP1" header + RGB565 LE, see CawPictures.h) before uploading, so the
// clock never decodes JPEG/PNG. Thumbnails load one at a time from
// /memes/picture in the same format.

const char kMemesStyle[] PROGMEM =
    "<style>.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));"
    "gap:10px}.tile{background:#0c1117;border:1px solid #2b333d;border-radius:10px;"
    "padding:6px;text-align:center}.tile.off canvas{opacity:.3}canvas{width:84px;height:84px;"
    "image-rendering:pixelated;border-radius:4px;background:#000}.tile{position:relative}"
    ".gif{position:absolute;top:9px;right:9px;background:#6a35d6;color:#fff;font:700 10px sans-serif;"
    "padding:1px 4px;border-radius:4px}.tile button{margin-top:4px;"
    "padding:5px;font-size:12px}.tile .del{background:#3a1d1d;color:#ff9a9a}"
    "#progress{color:#b79cff;min-height:20px}</style>";

const char kMemesScript[] PROGMEM = R"JS(<script>
const S=56,MAXF=30,MINMS=83,PX=S*S*2;
/* One 56x56 frame as RGB565 little-endian; transparent pixels become black. */
function px(img){const d=img.data,o=new Uint8Array(PX);
for(let i=0,j=0;i<S*S;i++,j+=2){const a=d[i*4+3]/255,r=d[i*4]*a,g=d[i*4+1]*a,b=d[i*4+2]*a;
const v=((r>>3)<<11)|((g>>2)<<5)|(b>>3);o[j]=v&255;o[j+1]=v>>8}return o}
async function load(file){if(window.createImageBitmap){try{return await createImageBitmap(file)}catch(e){}}
return await new Promise((ok,fail)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>fail(new Error('not an image'));i.src=URL.createObjectURL(file)})}
/* Centre square, halved down in steps, then to 56x56. */
function shrink(src){const w=src.width,h=src.height,side=Math.min(w,h);
let c=document.createElement('canvas'),size=side;c.width=c.height=side;
c.getContext('2d').drawImage(src,(w-side)/2,(h-side)/2,side,side,0,0,side,side);
while(size/2>=S*2){const n=document.createElement('canvas');size=Math.floor(size/2);n.width=n.height=size;
const x=n.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(c,0,0,size,size);c=n}
const f=document.createElement('canvas');f.width=f.height=S;const x=f.getContext('2d');
x.imageSmoothingQuality='high';x.drawImage(c,0,0,S,S);return x.getImageData(0,0,S,S)}
function still(img){const o=new Uint8Array(8+PX);o.set([67,87,80,49,S,0,S,0]);o.set(px(shrink(img)),8);return o}

/* ---- GIF: block scan, LZW, compositing (frame disposal and transparency) ---- */
function lzw(min,data,n){const clear=1<<min,eoi=clear+1,out=new Uint8Array(n);
const prefix=new Uint16Array(4096),suffix=new Uint8Array(4096),stack=new Uint8Array(4097);
for(let i=0;i<clear&&i<256;i++)suffix[i]=i;
let size=min+1,mask=(1<<size)-1,next=eoi+1,old=-1,first=0,acc=0,bits=0,pos=0,o=0;
while(o<n){while(bits<size){if(pos>=data.length)return out;acc|=data[pos++]<<bits;bits+=8}
let code=acc&mask;acc>>>=size;bits-=size;
if(code===clear){size=min+1;mask=(1<<size)-1;next=eoi+1;old=-1;continue}
if(code===eoi)break;
if(old<0){out[o++]=suffix[code];old=code;first=code;continue}
let c=code,sp=0;if(code>=next){stack[sp++]=first;c=old}
while(c>=clear&&sp<4096){stack[sp++]=suffix[c];c=prefix[c]}
first=suffix[c];stack[sp++]=first;while(sp&&o<n)out[o++]=stack[--sp];
if(next<4096){prefix[next]=old;suffix[next]=first;next++;if((next&mask)===0&&size<12){size++;mask=(1<<size)-1}}
old=code}
return out}
function subBlocks(u,p){const parts=[];let n=0;while(u[p]){parts.push(u.subarray(p+1,p+1+u[p]));n+=u[p];p+=u[p]+1}
const o=new Uint8Array(n);let k=0;for(const a of parts){o.set(a,k);k+=a.length}return[o,p+1]}
function gifScan(u){if(u.length<14||u[0]!==71||u[1]!==73||u[2]!==70)throw new Error('not a GIF');
const w=u[6]|u[7]<<8,h=u[8]|u[9]<<8;let p=10;const f=u[p];p+=3;let gct=null;
if(f&128){const n=3<<((f&7)+1);gct=u.subarray(p,p+n);p+=n}
const frames=[];let gce=null;
while(p<u.length){const b=u[p++];if(b===0x3B)break;
if(b===0x21){const l=u[p++];
if(l===0xF9){gce={disp:(u[p+1]>>2)&7,tr:(u[p+1]&1)?u[p+4]:-1,ms:(u[p+2]|u[p+3]<<8)*10}}
let q=p;while(u[q])q+=u[q]+1;p=q+1}
else if(b===0x2C){const x=u[p]|u[p+1]<<8,y=u[p+2]|u[p+3]<<8,iw=u[p+4]|u[p+5]<<8,ih=u[p+6]|u[p+7]<<8,fl=u[p+8];p+=9;
let pal=gct;if(fl&128){const n=3<<((fl&7)+1);pal=u.subarray(p,p+n);p+=n}
const min=u[p++];const[data,np]=subBlocks(u,p);p=np;
frames.push({x,y,iw,ih,inter:!!(fl&64),pal,min,data,disp:gce?gce.disp:0,tr:gce?gce.tr:-1,
ms:gce&&gce.ms>10?gce.ms:100});gce=null}
else throw new Error('damaged GIF')}
if(!w||!h||!frames.length)throw new Error('empty GIF');return{w,h,frames}}
/* Calls emit(index, rgba) after each frame is drawn, with the canvas as the viewer shows it. */
function gifRender(g,emit){const{w,h}=g,cv=new Uint8ClampedArray(w*h*4);let prev=null;
g.frames.forEach((fr,i)=>{if(fr.disp===3)prev=cv.slice();
const idx=lzw(fr.min,fr.data,fr.iw*fr.ih),rows=new Int32Array(fr.ih);
if(fr.inter){let r=0;for(const[s,st]of[[0,8],[4,8],[2,4],[1,2]])for(let y=s;y<fr.ih;y+=st)rows[r++]=y}
else for(let y=0;y<fr.ih;y++)rows[y]=y;
for(let r=0;r<fr.ih;r++){const y=fr.y+rows[r];if(y>=h)continue;
for(let x=0;x<fr.iw;x++){const X=fr.x+x;if(X>=w)continue;const c=idx[r*fr.iw+x];if(c===fr.tr)continue;
const o=(y*w+X)*4,q=c*3;cv[o]=fr.pal?fr.pal[q]|0:0;cv[o+1]=fr.pal?fr.pal[q+1]|0:0;cv[o+2]=fr.pal?fr.pal[q+2]|0:0;cv[o+3]=255}}
emit(i,cv);
if(fr.disp===2){for(let y=fr.y;y<Math.min(h,fr.y+fr.ih);y++)for(let x=fr.x;x<Math.min(w,fr.x+fr.iw);x++)cv.fill(0,(y*w+x)*4,(y*w+x)*4+4)}
else if(fr.disp===3&&prev)cv.set(prev)})}
/* Evenly spaced moments of the loop, at least MINMS apart, at most MAXF. A frame hit by
   several moments is kept once, with a longer delay. Returns [{src,ms}]. */
function pick(frames){let T=0;for(const f of frames)T+=f.ms;
const step=Math.max(MINMS,Math.ceil(T/MAXF/10)*10),n=Math.min(MAXF,Math.max(1,Math.ceil(T/step))),out=[];
let acc=0,i=0;for(let k=0;k<n;k++){const t=k*step;while(i<frames.length-1&&acc+frames[i].ms<=t){acc+=frames[i].ms;i++}
const last=out[out.length-1];if(last&&last.src===i)last.n++;else out.push({src:i,n:1})}
const ms=Math.min(5000,Math.max(20,Math.round(step/10)*10));
return out.map(o=>({src:o.src,ms:Math.min(5000,ms*o.n)}))}
async function gifToBytes(buf,note){const g=gifScan(new Uint8Array(buf)),sel=pick(g.frames);
if(g.frames.length<2||sel.length<2){let first=null;gifRender({w:g.w,h:g.h,frames:g.frames.slice(0,1)},(i,cv)=>{first=cv.slice()});
const c=document.createElement('canvas');c.width=g.w;c.height=g.h;c.getContext('2d').putImageData(new ImageData(first,g.w,g.h),0,0);
note('one frame: added as a still');const o=new Uint8Array(8+PX);o.set([67,87,80,49,S,0,S,0]);o.set(px(shrink(c)),8);return o}
const need=new Map();sel.forEach((s,k)=>{if(!need.has(s.src))need.set(s.src,[]);need.get(s.src).push(k)});
const frames=new Array(sel.length),c=document.createElement('canvas');c.width=g.w;c.height=g.h;const x=c.getContext('2d');let done=0;
const todo=[];gifRender(g,(i,cv)=>{if(!need.has(i))return;const copy=cv.slice();todo.push([i,copy])});
for(const[i,cv]of todo){x.putImageData(new ImageData(cv,g.w,g.h),0,0);const p=px(shrink(c));for(const k of need.get(i))frames[k]=p;
if(++done%4===0){note('converting frame '+done+' of '+todo.length);await new Promise(r=>setTimeout(r))}}
const N=sel.length,o=new Uint8Array(12+N*(2+PX));o.set([67,87,65,49,S,0,S,0,N&255,N>>8,0,0]);
sel.forEach((s,k)=>{o[12+2*k]=s.ms&255;o[13+2*k]=s.ms>>8;o.set(frames[k],12+2*N+k*PX)});
note(g.frames.length+' frames in the GIF, '+N+' kept at about '+(1000/sel[0].ms).toFixed(1)+' per second');return o}

async function post(url,body){for(let t=0;t<2;t++){const r=await fetch(url,{method:'POST',body,credentials:'same-origin'});
if(r.status!==401)return r}throw new Error('sign-in needed: reload the page')}
async function upload(){const files=[...document.getElementById('files').files],p=document.getElementById('progress');
if(!files.length)return;let done=0;for(const f of files){const say=m=>p.textContent=f.name+': '+m;say('reading...');
try{const buf=await f.arrayBuffer(),u=new Uint8Array(buf,0,4),isGif=u[0]===71&&u[1]===73&&u[2]===70;
if(isGif&&buf.byteLength>30e6)throw new Error('that GIF is over 30 MB');
const bytes=isGif?await gifToBytes(buf,say):still(await load(f));
const form=new FormData();form.append('pic',new Blob([bytes],{type:'application/octet-stream'}),'meme.cwp');
say('sending '+Math.round(bytes.length/1024)+' KB...');
const r=await post('/memes/upload?bytes='+bytes.length,form);const msg=await r.text();if(!r.ok){p.textContent=f.name+': '+msg;return}done++}
catch(e){p.textContent=f.name+': '+e.message;return}}p.textContent='Added '+done+'. Reloading...';location.reload()}
async function act(url){const r=await post(url);if(!r.ok){alert(await r.text());return}location.reload()}
function show(k,on){act('/memes/show?k='+k+'&on='+(on?1:0))}
function del(k){if(confirm('Delete this meme from the clock?'))act('/memes/delete?k='+k)}
function every(g,on){act('/memes/all?g='+g+'&on='+(on?1:0))}
async function thumbs(){for(const c of document.querySelectorAll('canvas[data-k]')){try{
const r=await fetch('/memes/picture?k='+c.dataset.k,{credentials:'same-origin'});if(!r.ok)continue;
const b=new Uint8Array(await r.arrayBuffer());if(b.length!==8+PX)continue;
const x=c.getContext('2d'),img=x.createImageData(S,S);for(let i=0,o=8;i<S*S;i++,o+=2){const v=b[o]|b[o+1]<<8;
img.data[i*4]=(v>>11)*255/31;img.data[i*4+1]=((v>>5)&63)*255/63;img.data[i*4+2]=(v&31)*255/31;img.data[i*4+3]=255}
x.putImageData(img,0,0)}catch(e){}}}
thumbs();
</script>)JS";

void memeTile(Page &page, uint32_t key, bool shown, bool deletable, bool animated = false) {
  page += shown ? F("<div class=tile>") : F("<div class='tile off'>");
  if (animated) page += F("<span class=gif>GIF</span>");
  page += F("<canvas width=56 height=56 data-k=");
  page += key;
  page += F("></canvas><button class=ghost onclick='show(");
  page += key;
  page += shown ? F(",0)'>Hide</button>") : F(",1)'>Show</button>");
  if (deletable) {
    page += F("<button class=del onclick='del(");
    page += key;
    page += F(")'>Delete</button>");
  }
  page += F("</div>");
}

// "Show all" / "Hide all" for one group of memes (to keep just one: hide
// all, then show that one).
void allButtons(Page &page, const char *group) {
  page += F("<div style='display:flex;gap:8px;margin:0 0 12px'><button class=ghost "
            "style='margin:0' onclick=\"every('");
  page += group;
  page += F("',1)\">Show all</button><button class=ghost style='margin:0' onclick=\"every('");
  page += group;
  page += F("',0)\">Hide all</button></div>");
}

void sendMemesPage() {
  if (!authorised()) return;
  CawPictures &pictures = app->pictures;
  pictures.configure(app->settings.pictureCrow, app->settings.builtinOff);
  ServerPageSink sink{app->server};
  Page page(sink);
  // ?embed=1: shown inside the Memes tab of the settings page (an iframe),
  // so no heading and no link back.
  const bool embedded = app->server.arg("embed") == "1";
  if (embedded) {
    page += F("<!doctype html><html lang=en><title>Memes</title>");
    addFlashText(page, kStyle);
    page += F("<main style='padding:0 0 4px'>");
  } else {
    beginPage(page, "Memes");
  }
  addFlashText(page, kMemesStyle);
  if (!embedded) page += F("<p><a style='color:#b79cff' href='/'>&larr; Settings</a></p>");

  uint32_t total = 0, used = 0;
  pictures.space(total, used);
  const uint16_t left = pictures.uploadsLeft();
  page += F("<section><h2>Add memes</h2><p><small>Pick one or more images (JPG, PNG, "
            "WebP, GIF). Each is cropped to its centre square and shrunk to 56 &times; 56 "
            "(a GIF keeps up to 30 frames, about 12 a second at most) "
            "in your browser, then stored on the clock. Firmware updates keep them; a "
            "factory reset erases them.</small></p>");
  if (left) {
    page += F("<input type=file id=files accept='image/*' multiple>"
              "<button onclick=upload()>Add to the clock</button>");
  } else {
    page += F("<p>Storage or meme limit reached: delete some uploaded memes first.</p>");
  }
  page += F("<p id=progress></p><small>");
  page += pictures.uploadCount();
  page += F(" uploaded, room for ");
  page += left;
  page += F(" more &middot; storage ");
  page += used / 1024;
  page += F(" of ");
  page += total / 1024;
  page += F(" KB used</small></section>");

  page += F("<section><h2>Uploaded (");
  page += pictures.uploadCount();
  page += F(")</h2>");
  if (!pictures.uploadCount()) page += F("<p><small>None yet.</small></p>");
  else allButtons(page, "uploaded");
  page += F("<div class=grid>");
  for (uint16_t index = 0; index < pictures.uploadCount(); ++index)
    memeTile(page, CawPictures::kUploadKeyBase + pictures.uploadId(index),
             pictures.uploadShown(index), true, pictures.uploadAnimated(index));
  page += F("</div></section><section><h2>Built in (");
  page += pictures.builtinCount() + 1;
  page += F(")</h2><p><small>Part of the firmware: they can be hidden but never deleted."
            "</small></p>");
  allButtons(page, "builtin");
  page += F("<div class=grid>");
  memeTile(page, CawPictures::kCrowKey, app->settings.pictureCrow, false);
  for (uint8_t index = 0; index < pictures.builtinCount(); ++index)
    memeTile(page, CawPictures::kBuiltinKeyBase + index, pictures.builtinShown(index), false,
             pictures.builtinAnimated(index));
  page += F("</div></section>");
  addFlashText(page, kMemesScript);
  page += F("</main>");
  page.finish();
}

uint32_t keyArgument() { return strtoul(app->server.arg("k").c_str(), nullptr, 10); }

// One picture as "CWP1" + 56 x 56 RGB565 LE, for the page's thumbnails.
void sendPicture() {
  if (!authorised()) return;
  const uint32_t key = keyArgument();
  char path[24];
  if (app->pictures.uploadPathFor(key, path, sizeof(path))) {
    File file = LittleFS.open(path, "r");
    if (file) {
      CawAnimation thumbnail;
      if (app->pictures.readAnimation(key, thumbnail)) {
        // An animation: send its first frame as a static picture (header
        // "CWP1", then frame 0), a row at a time.
        if (!file.seek(thumbnail.dataOffset)) {
          file.close();
          app->server.send_P(404, "text/plain", PSTR("No such picture"));
          return;
        }
        static const uint8_t kHeader[kCawPictureHeaderBytes] = {'C', 'W', 'P', '1',
                                                                kCawPictureSize, 0, kCawPictureSize, 0};
        app->server.setContentLength(kCawPictureFileBytes);
        app->server.send(200, "application/octet-stream", "");
        app->server.sendContent(reinterpret_cast<const char *>(kHeader), sizeof(kHeader));
        uint8_t row[kCawPictureSize * 2];
        for (int16_t line = 0; line < kCawPictureSize; ++line) {
          if (file.read(row, sizeof(row)) != sizeof(row)) break;
          app->server.sendContent(reinterpret_cast<const char *>(row), sizeof(row));
        }
        file.close();
        return;
      }
      app->server.streamFile(file, F("application/octet-stream"));
      file.close();
      return;
    }
  }
  const uint8_t *mdi = app->pictures.builtinData(key);
  std::unique_ptr<uint8_t[]> buffer(mdi ? new (std::nothrow) uint8_t[kCawPictureFileBytes] : nullptr);
  if (!buffer) {
    app->server.send_P(404, "text/plain", PSTR("No such picture"));
    return;
  }
  memcpy(buffer.get(), "CWP1", 4);
  buffer[4] = kCawPictureSize;
  buffer[5] = 0;
  buffer[6] = kCawPictureSize;
  buffer[7] = 0;
  memset(buffer.get() + kCawPictureHeaderBytes, 0, kCawPicturePixelBytes);
  const auto copyRow = [&](uint16_t line, uint16_t *pixels, uint16_t width) {
    if (line >= kCawPictureSize || width > kCawPictureSize) return;
    uint8_t *out = buffer.get() + kCawPictureHeaderBytes + line * kCawPictureSize * 2;
    for (uint16_t index = 0; index < width; ++index) {
      out[index * 2] = pixels[index] & 0xFF;
      out[index * 2 + 1] = pixels[index] >> 8;
    }
  };
  if (cawIsPaletteAnimation(mdi)) forEachPaletteRow(mdi, 0, copyRow);  // first frame
  else forEachMdiRow(mdi, copyRow);
  app->server.send(200, "application/octet-stream", buffer.get(), kCawPictureFileBytes);
}

// Upload chunks (before the request handler). Permission and space are
// checked once at the start; refused data is read and discarded.
void receivePictureUpload() {
  HTTPUpload &upload = app->server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    pictureUploadError = nullptr;
    pictureUploadAllowed = sameOrigin() && permitted();
    if (!pictureUploadAllowed) return;
    // The file's size comes in the URL (/memes/upload?bytes=N): form fields
    // sent before the file are only visible to the server once the whole
    // upload is parsed, but the query string is read first.
    const long announced = app->server.arg("bytes").toInt();
    pictureUploadError = app->pictures.beginUpload(announced > 0 ? static_cast<size_t>(announced)
                                                                 : kCawPictureFileBytes);
    if (pictureUploadError) pictureUploadAllowed = false;
    return;
  }
  if (!pictureUploadAllowed) return;
  if (upload.status == UPLOAD_FILE_WRITE) {
    if (!app->pictures.write(upload.buf, upload.currentSize)) {
      pictureUploadAllowed = false;
      pictureUploadError = "more data than announced, or storage is full";
    }
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    app->pictures.abortUpload();
    pictureUploadAllowed = false;
    pictureUploadError = "upload interrupted";
  }
  yield();
}

void finishPictureUpload() {
  if (!postAllowed()) {
    app->pictures.abortUpload();
    return;
  }
  uint32_t id = 0;
  const char *error = pictureUploadError;
  if (!error && pictureUploadAllowed) error = app->pictures.finishUpload(id);
  else if (!error) error = "upload refused";
  pictureUploadAllowed = false;
  pictureUploadError = nullptr;
  if (error) {
    app->pictures.abortUpload();
    app->server.send(error[0] == 's' ? 507 : 400, "text/plain", error);
    return;
  }
  app->server.send(200, "text/plain", String(id));
}

// (Re)reads the animation of the picture on screen, if it has one.
void loadAnimation() {
  animationKey = pictureKey;
  animationActive = app->pictures.readAnimation(pictureKey, animation) &&
                    (animation.builtin ||
                     app->pictures.uploadPathFor(pictureKey, animationPath, sizeof(animationPath)));
  animationFrame = 0;
  animationAt = millis();
}

// After a change, move on if the picture on screen is no longer shown.
void pictureListChanged() {
  animationKey = 0xFFFFFFFF;  // files may have been renamed or removed: reload
  app->pictures.configure(app->settings.pictureCrow, app->settings.builtinOff);
  bool stillShown = false;
  for (uint16_t position = 0; position < app->pictures.shownCount(); ++position)
    stillShown = stillShown || app->pictures.shownKey(position) == pictureKey;
  if (!stillShown) {
    nextPicture();
    lastPictureChange = millis();
  }
}

void receivePictureShow() {
  if (!postAllowed()) return;
  const uint32_t key = keyArgument();
  const bool shown = app->server.arg("on") == "1";
  bool ok = true;
  if (key == CawPictures::kCrowKey) {
    app->settings.pictureCrow = shown;
    ok = saveSettings();
  } else if (key < CawPictures::kUploadKeyBase) {
    const uint32_t index = key - CawPictures::kBuiltinKeyBase;
    ok = key >= CawPictures::kBuiltinKeyBase && index < app->pictures.builtinCount();
    if (ok) {
      if (shown) app->settings.builtinOff &= ~(1UL << index);
      else app->settings.builtinOff |= 1UL << index;
      ok = saveSettings();
    }
  } else {
    ok = app->pictures.setShown(key, shown);
  }
  if (!ok) {
    app->server.send_P(400, "text/plain", PSTR("Could not change that meme"));
    return;
  }
  pictureListChanged();
  app->server.send(204);
}

// POST /memes/all?g=builtin|uploaded&on=0|1: shows or hides a whole group.
// The built-in group includes the original crow. With everything hidden the
// clock shows the crow.
void receivePictureAll() {
  if (!postAllowed()) return;
  const bool shown = app->server.arg("on") == "1";
  bool ok = true;
  if (app->server.arg("g") == "builtin") {
    const uint8_t count = app->pictures.builtinCount();
    app->settings.pictureCrow = shown;
    app->settings.builtinOff = shown ? 0 : count >= 32 ? 0xFFFFFFFFUL : (1UL << count) - 1;
    ok = saveSettings();
  } else if (app->server.arg("g") == "uploaded") {
    for (uint16_t index = 0; index < app->pictures.uploadCount(); ++index) {
      ok = app->pictures.setShown(CawPictures::kUploadKeyBase + app->pictures.uploadId(index),
                                  shown) && ok;
      yield();  // up to 200 file renames: keep Wi-Fi and the watchdog served
    }
  } else {
    ok = false;
  }
  if (!ok) {
    app->server.send_P(400, "text/plain", PSTR("Could not change those memes"));
    return;
  }
  pictureListChanged();
  app->server.send(204);
}

void receivePictureDelete() {
  if (!postAllowed()) return;
  if (!app->pictures.remove(keyArgument())) {
    app->server.send_P(400, "text/plain", PSTR("Only uploaded memes can be deleted"));
    return;
  }
  pictureListChanged();
  app->server.send(204);
}

// --------------------------------------------------------------------- wifi

void showSetupScreen(const char *title) {
  const String ssid = String(kSetupNetworkPrefix) + deviceSuffix();
  const String key = String("Key: ") + app->settings.setupKey;
  app->screen.showMessage(title, PSTR("Join Wi-Fi network"), ssid.c_str(), key.c_str(),
                          PSTR("Open 192.168.4.1"),
                          // In recovery the home Wi-Fi is fine: no Wi-Fi problem line.
                          wifiFailure && !recoveryActive() ? wifiFailureOnScreen : nullptr);
}

// Records why the station could not join, from the SDK's last attempt.
void noteWifiFailure() {
  switch (WiFi.status()) {
    case WL_NO_SSID_AVAIL:
      wifiFailure = F("network not found");
      wifiFailureOnScreen = PSTR("network not found");
      break;
    case WL_WRONG_PASSWORD:
      wifiFailure = F("wrong Wi-Fi password");
      wifiFailureOnScreen = PSTR("wrong Wi-Fi password");
      break;
    // The ESP8266 reports most WPA2 authentication failures this way.
    case WL_CONNECT_FAILED:
      wifiFailure = F("couldn't connect - check the Wi-Fi password");
      wifiFailureOnScreen = PSTR("check the Wi-Fi password");  // the full text is too wide
      break;
    default: break;
  }
}

// Titles of the setup screen are flash strings (PSTR): they only go to the screen.
const char *setupTitle() {
  if (recoveryActive()) return PSTR("Recovery");
  return everConnected ? PSTR("Wi-Fi lost") : PSTR("Can't join Wi-Fi");
}

void startAccessPoint(const char *title) {
  if (accessPointRunning) return;
  const String ssid = String(kSetupNetworkPrefix) + deviceSuffix();
  const bool configured = wifiConfigured(app->config);
  WiFi.mode(configured ? WIFI_AP_STA : WIFI_AP);
  ensureSetupKey();  // a new key only once the radio is on (see there)
  if (configured) {
    // While the station keeps searching, the radio hops channels and phones
    // drop off the setup network. Retry the home network now and then instead.
    WiFi.setAutoReconnect(false);
    WiFi.disconnect();
    lastStationAttempt = millis();
  }
  WiFi.softAP(ssid.c_str(), app->settings.setupKey);
  WiFi.scanNetworks(true);  // list for the setup page
  accessPointRunning = true;
  showSetupScreen(title);
}

void stopAccessPoint() {
  if (!accessPointRunning) return;
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.scanDelete();
  accessPointRunning = false;
  app->screen.invalidate();
}

void handleWifi() {
  if (!wifiConfigured(app->config)) return;  // setup network stays up
  const bool connected = WiFi.status() == WL_CONNECTED;
  if (connected) {
    disconnectedSince = 0;
    if (!wasConnected) {
      const bool announce = !everConnected || accessPointRunning;
      wasConnected = true;
      everConnected = true;
      wifiFailure = nullptr;
      if (recoveryActive()) return;  // the setup network and its screen stay
      stopAccessPoint();
      app->screen.invalidate();
      if (announce) {
        // Tell a new owner where the settings page is.
        const String address = "http://" + WiFi.localIP().toString();
        app->screen.showMessage(PSTR("Connected"), PSTR("Settings page:"), address.c_str(),
                                nullptr, PSTR("Sign in as"), configuredUsername(app->config));
        connectedNoticeUntil = millis() + kConnectedNoticeMs;
        if (!connectedNoticeUntil) connectedNoticeUntil = 1;
      }
    }
    return;
  }
  const __FlashStringHelper *before = wifiFailure;
  noteWifiFailure();
  if (accessPointRunning && wifiFailure != before) showSetupScreen(setupTitle());
  if (accessPointRunning) {
    // Retry the home network once a minute, but never while someone is on the
    // setup network (the retry would move the radio off its channel).
    if (WiFi.softAPgetStationNum() == 0 && millis() - lastStationAttempt >= kRecoveryRetryMs) {
      lastStationAttempt = millis();
      WiFi.begin(app->config.ssid, app->config.wifiPassword);
    }
    return;
  }
  if (wasConnected) {
    wasConnected = false;
    app->screen.invalidate();
  }
  if (!disconnectedSince) disconnectedSince = millis();
  if (!accessPointRunning && millis() - disconnectedSince >= kRecoveryAfterMs)
    startAccessPoint(setupTitle());
}

#if CAW_DUAL
void receiveMode() {
  if (!postAllowed()) return;
  if (!cawSetBootMode(false)) {
    redirectHome(F("Could not save the mode. The clock keeps showing CAW."));
    return;
  }
  restartSoon(F("Restarting in Home Assistant mode. Switch back on its Display page."));
}
#endif

}  // namespace

void cawAppSetup() {
  cawStage(1);
  cawCrashLogBegin();  // the record an abort left behind, before anything else
  checkBootGuard();
  app = new App();
  Serial.begin(115200);
  cawStage(2);
  filesystemReady = LittleFS.begin();
  cawCrashLogStore(filesystemReady, kVersion);
  loadSettings();
  cawStage(3);
  app->display.init();
  applyBacklight(true);
  app->screen.begin();
#if CAW_C2
  // The SDC2's glass hides the last 3 rows the panel draws: the picture is
  // moved up by 3 (hardware scroll), checked on the owner's clock.
  app->display.setVerticalOffset(3);
#endif
  cawStage(4);
  if (filesystemReady) {
    switch (cawRollbackBoot(kVersion, safeMode, showRollbackMessage)) {
      case CawRollbackBoot::RestoreReady:
        clearBootGuard();  // the restored firmware starts with a clean count
        delay(300);
        ESP.restart();
        break;
      case CawRollbackBoot::Pending:
        rollbackPending = true;
        break;
      case CawRollbackBoot::RolledBack:
        LittleFS.remove(kUpdateResultPath);  // "Updated to ..." no longer true
        break;
      default:
        break;
    }
  }
  readUpdateRequest();
  {  // the last check's answer (a newer version stays "available" across restarts)
    DynamicJsonDocument result(512);
    if (readUpdateResult(result) && strcmp(result["outcome"] | "", "checked") == 0 &&
        !result.containsKey("error"))
      noteAvailable(result["version"] | "");
  }
  if (updateMode == UpdateMode::Off) {
    app->feeds = (new FeedSet)->items;  // lives as long as the app
    cawBurnSessionsBegin();
    app->pictures.begin(filesystemReady);
    cawStage(5);
    for (uint8_t index = 0; index < kCawChainCount; ++index) {
      app->feeds[index].begin(filesystemReady);
      app->feeds[index].setStagger(index * kFetchStaggerMs);
    }
  }
  loadDeviceConfig(app->config);
  applyTimeZone();

  const bool recovery = countPowerOn();
  WiFi.persistent(false);
  if (wifiConfigured(app->config)) {
    WiFi.mode(WIFI_STA);
    WiFi.hostname(configuredHostname(app->config));
    WiFi.setAutoReconnect(true);
    WiFi.begin(app->config.ssid, app->config.wifiPassword);
    disconnectedSince = millis();
    app->screen.showMessage(PSTR("CAW Clock"), PSTR("Connecting to"), app->config.ssid);
    if (recovery) {  // three short power-ons: the setup network, as at first setup
      recoveryUntil = millis() + kRecoveryMs;
      if (!recoveryUntil) recoveryUntil = 1;
      startAccessPoint(PSTR("Recovery"));
    }
  } else {
    startAccessPoint(PSTR("Set up CAW Clock"));  // not set up yet: this is the way in anyway
  }

  if (updateMode != UpdateMode::Off) {
    // No web server: requests would wait in memory the download needs.
    bootFreeContStack = ESP.getFreeContStack();
    ESP.resetFreeContStack();
    cawStage(9);
    return;
  }
  app->server.on("/", HTTP_GET, [] {
    if (fromSetupNetwork()) sendSetupPage();
    else sendPanel();
  });
  app->server.on("/update/check", HTTP_POST, receiveUpdateCheck);
  app->server.on("/update/install", HTTP_POST, receiveUpdateInstall);
  app->server.on("/rollback/dismiss", HTTP_POST, receiveRollbackDismiss);
  app->server.on("/burn/test", HTTP_POST, receiveBurnTest);
  app->server.on("/burn/furnace-test", HTTP_POST, receiveFurnaceTest);
  app->server.on("/setup", HTTP_POST, receiveSetup);
  app->server.on("/api/status", HTTP_GET, sendStatusJson);
  app->server.on("/settings", HTTP_POST, receiveSettings);
  app->server.on("/wifi", HTTP_POST, receiveWifi);
  app->server.on("/password", HTTP_POST, receivePassword);
  app->server.on("/restart", HTTP_POST, [] {
    if (!postAllowed()) return;
    restartSoon(F("Restarting."));
  });
  app->server.on("/factory-reset", HTTP_POST, receiveFactoryReset);
  app->server.on("/scan", HTTP_GET, [] {
    if (!fromSetupNetwork() && !authorised()) return;
    WiFi.scanDelete();
    WiFi.scanNetworks(true);
    app->server.send(200, "text/html",
                     F("<meta http-equiv=refresh content='5;url=/'><meta name=viewport "
                       "content='width=device-width'><body style='background:#0a0d12;color:#eee;"
                       "font:16px sans-serif;padding:20px'>Looking for networks...</body>"));
  });
#if CAW_DUAL
  app->server.on("/mode", HTTP_POST, receiveMode);
#endif
  app->server.on("/update", HTTP_POST, finishUpdate, receiveUpdate);
  app->server.on("/memes", HTTP_GET, sendMemesPage);
  app->server.on("/memes/picture", HTTP_GET, sendPicture);
  app->server.on("/memes/upload", HTTP_POST, finishPictureUpload, receivePictureUpload);
  app->server.on("/memes/show", HTTP_POST, receivePictureShow);
  app->server.on("/memes/delete", HTTP_POST, receivePictureDelete);
  app->server.on("/memes/all", HTTP_POST, receivePictureAll);
  app->server.onNotFound([] { app->server.send_P(404, "text/plain", PSTR("Not found")); });
  app->server.collectHeaders("Origin");  // for sameOrigin()
  app->server.begin();
  bootFreeContStack = ESP.getFreeContStack();
  ESP.resetFreeContStack();  // from here on, measure normal running only
  cawStage(9);
}

const uint8_t *burnMeme() {
  return app->pictures.builtinData(CawPictures::kBuiltinKeyBase + kBurnMemeIndex);
}

// Asks the next bridge chain for new burns (one HTTPS request).
void pollBurns(time_t now) {
  const uint8_t index = burnNextChain;
  burnNextChain = (burnNextChain + 1) % kCawBurnChainCount;
  BurnWatch &watch = burnWatch[index];
  cawStage(40, index);
  cawNoteHeap();
  // On the heap for the poll only (RAM is short; not the 4 KB main stack).
  std::unique_ptr<CawBurnReader> owned(new (std::nothrow) CawBurnReader);
  if (!owned) {
    watch.result = "low_memory";
    return;
  }
  CawBurnReader &reader = *owned;
  reader.scale = pow(10.0, kCawBurnChains[index].decimals);  // Arbitrum's CAW: 0 decimals
  reader.newerThan = watch.seenBlock;
  // Cronos asks for two event lists (bridge burns, The Great Furnace's).
  reader.expectLogLists = kCawBurnChains[index].home && watch.cursor ? 2 : 1;
  watch.result = cawBurnFetch(index, watch.cursor ? watch.cursor + 1 : 0, now, watch.fullBuffers,
                              reader, watch.httpStatus, watch.sslError);
  watch.polledAt = millis();
  noteStack("burn");
  const CawBurnChain &chain = kCawBurnChains[index];
  if (strcmp(watch.result, "ok") == 0) {
    cawBurnSupplyFrom(chain, reader, millis(), burnSupply[index]);
    // The events were asked for but not answered (an error, a range too
    // wide): counted as a failure, the same range is asked again.
    if (watch.cursor && !chain.solana && !reader.logsAnswered) watch.result = "events_refused";
  }
  if (strcmp(watch.result, "ok") != 0) {
    if (watch.failures < 0xFFFF) ++watch.failures;
    // TLS records larger than the 4 KiB buffer: this server gets the full
    // one from now on.
    if (strcmp(watch.result, "tls_too_large") == 0) watch.fullBuffers = true;
    // Several failures in a row (a range grown too wide, an answer too big
    // to read): start over from the newest block. Burns in between are lost,
    // but the chain works again.
    if (watch.failures >= kBurnRestartAfterFailures) watch.cursor = 0;
    return;
  }
  watch.failures = 0;
  if (chain.solana) return;  // Solana: supply only (its burns arrive elsewhere)
  const uint64_t cursor = watch.cursor;
  for (uint8_t item = 0; item < reader.count; ++item) {
    const CawBurnLog &log = reader.logs[item];  // only new ones (reader.newerThan)
    if (watch.seen < 0xFFFF) ++watch.seen;
    // An arrival burn is a bridge from Solana (see CawBurn.h). A direct
    // burn (CAW sent to the dead wallet): the burner and its chain.
    char burner[20];
    const char *from = log.direct    ? cawBurnBurnerName(log.burner, burner, sizeof(burner))
                       : log.arrived ? "solana"
                                     : chain.name;
    const char *to = log.direct || log.arrived ? chain.name : cawBurnChainName(log.dstEid);
    const bool furnace = log.direct && cawBurnIsFurnace(log.burner);
    if (app->settings.burnAlerts)
      cawBurnAdd(burnGate, log.burned, log.total, from, to, 1, log.direct, furnace);
    for (uint8_t slot = kBurnRecords - 1; slot > 0; --slot) burnRecords[slot] = burnRecords[slot - 1];
    BurnRecord &record = burnRecords[0];
    record.burned = log.burned;
    record.bridged = log.total;
    cawBurnText(from, record.from, sizeof(record.from));
    cawBurnText(to, record.to, sizeof(record.to));
    record.at = millis();
    record.direct = log.direct;
    record.furnace = furnace;
    record.haveTx = log.haveTx;
    record.chain = index;
    memcpy(record.tx, log.tx, sizeof(record.tx));
    if (burnRecordCount < kBurnRecords) ++burnRecordCount;
  }
  if (reader.extra && app->settings.burnAlerts) {  // more than fit: added up, "N bridges"
    watch.seen = watch.seen + reader.extra > 0xFFFF ? 0xFFFF : watch.seen + reader.extra;
    cawBurnAdd(burnGate, reader.extraBurned, reader.extraTotal, chain.name, chain.name,
               reader.extra);
  }
  watch.seenBlock = cawBurnSeenAfter(watch.seenBlock, cursor, reader);
  watch.cursor = cawBurnNextCursor(cursor, reader);
}

// The Great Furnace's own picture for its burns (CawFurnace.h, not one of
// the memes); every other burn has the usual fire.
const uint8_t *furnaceMeme() {
#if CAW_HAVE_FURNACE_MEME
  return kCawFurnaceMeme;
#else
  return burnMeme();
#endif
}
const uint8_t *burnShownMeme = nullptr;  // the picture the burn screen animates

// Takes over the screen for kBurnShowMs. `to` nullptr: `from` is the whole
// route line ("3 bridges"). `direct`: a burn to the dead wallet, `from` the
// burner and `to` its chain; `furnace`: by The Great Furnace (its picture).
void drawBurn(double burnedAmount, double bridgedAmount, const char *from, const char *to,
              bool direct = false, bool furnace = false) {
  const uint8_t *meme = furnace ? furnaceMeme() : burnMeme();
  if (!meme) return;  // nothing to draw: the screen stays as it is
  burnShownMeme = meme;
  burnFrameMs = furnace && meme != burnMeme() ? cawPaletteDelay(meme, 0) : kBurnFrameMs;
  supplyShowingSince = 0;  // a burn replaces the supply screen; the rotation goes on after it
  char amount[16], bridged[16], total[16];
  const bool haveTotal = burnTotalText(total, sizeof(total));
  cawFormatCawAmount(burnedAmount, amount, sizeof(amount));
  cawFormatCawAmount(bridgedAmount, bridged, sizeof(bridged));
  cawStage(45, 0);
  if (direct)  // "The Great Furnace", then "on cronos" in place of the bridged amount
    app->screen.showBurn(meme, amount, from, nullptr, nullptr, haveTotal ? total : nullptr, to);
  else
    app->screen.showBurn(meme, amount, from, to, bridged, haveTotal ? total : nullptr);
  burnShowingSince = millis() ? millis() : 1;
  burnFrame = 0;
  burnFrameAt = millis();
}

// The burn screen: one burn ("cronos to base"), or the burns added up
// during the cool-down ("3 bridges").
void showBurnAlert() {
  char route[24];
  const bool several = burnGate.count > 1;
  // Several during the cool-down: "3 bridges", "2 furnace burns", or "3 burns"
  // (other burns, or mixed); The Great Furnace's picture only when all are its.
  const bool allFurnace = burnGate.furnaces == burnGate.count;
  if (several)
    snprintf(route, sizeof(route),
             burnGate.directs == 0 ? "%u bridges"
             : allFurnace          ? "%u furnace burns"
                                   : "%u burns",
             burnGate.count);
  if (several && burnGate.directs == burnGate.count)  // only dead-wallet burns: "on cronos"
    drawBurn(burnGate.burned, 0, route, burnGate.to, true, allFurnace);
  else
    drawBurn(burnGate.burned, burnGate.bridged, several ? route : burnGate.from,
             several ? nullptr : burnGate.to, !several && burnGate.direct,
             !several && burnGate.furnace);
  cawBurnShown(burnGate, millis());
  if (burnsShown < 0xFFFF) ++burnsShown;
}

// "Preview the burn alert": the last burn found, or the one from the CAW Discord
// (2026-11-18, bsc to solana) when none was found since the clock started.
// The cool-down and the count of burns shown are not touched.
void showTestBurn() {
  if (burnRecordCount) {
    const BurnRecord &record = burnRecords[0];
    drawBurn(record.burned, record.bridged, record.from, record.to, record.direct, record.furnace);
  } else {
    drawBurn(67116015.0, 13423203007.0, "bsc", "solana");
  }
}

bool holdersAllKnown() {
  for (bool known : holderKnown)
    if (!known) return false;
  return true;
}

// Asks GeckoTerminal for the next source's holder count (one HTTPS request).
void pollHolders(time_t now) {
  const uint8_t source = holderNext;
  holderNext = (holderNext + 1) % kCawHolderSourceCount;
  cawNoteHeap();
  uint32_t count = 0;
  holdersResult = cawHoldersFetch(source, now, count);
  noteStack("holders");
  if (strcmp(holdersResult, "ok") == 0) {
    holderCounts[source] = count;
    holderKnown[source] = true;
  }
}

// The supply screen with the clock's own figures; false (nothing drawn)
// until every chain's supply is known.
bool showSupplyScreen() {
  double burned = 0;
  if (!cawBurnTotal(burnSupply, kCawBurnChainCount, millis(), kBurnSupplyMaxAgeMs, burned))
    return false;
  double circulating = 0;
  for (const CawBurnSupply &supply : burnSupply) circulating += supply.circulating;
  if (!(circulating > 0)) return false;
  // The chains' colours in the ring (as the CAW site).
  static const uint32_t kColors[kCawBurnChainCount] = {0x4DD9FF, 0xF3BA2F, 0x2B4BFF, 0x8247E5,
                                                       0x28A0F0, 0xCCFF00, 0xE040FB};
  // On the stack (~310 bytes) only while the screen is drawn: this runs from
  // the rotation, never inside a fetch (the main stack's deepest path).
  char names[kCawBurnChainCount][12], percents[kCawBurnChainCount][16],
      holders[kCawBurnChainCount][14];
  char circulatingText[16], burnedText[16], holdersText[14];
  CawScreen::SupplyView view{};
  uint32_t holdersTotal = 0;
  bool holdersComplete = holdersAllKnown();
  for (uint8_t index = 0; index < kCawBurnChainCount; ++index) {
    const double share = burnSupply[index].circulating / circulating;
    cawBurnText(kCawBurnChains[index].name, names[index], sizeof(names[index]));
    cawFormatShare(share, percents[index], sizeof(percents[index]));
    uint32_t chainHolders = 0;
    bool any = false;
    for (uint8_t source = 0; source < kCawHolderSourceCount; ++source)
      if (kCawHolderSources[source].chain == index && holderKnown[source]) {
        chainHolders += holderCounts[source];
        any = true;
      }
    holders[index][0] = '\0';
    if (any) cawFormatThousands(chainHolders, holders[index], sizeof(holders[index]));
    holdersTotal += chainHolders;
    const uint32_t rgb = kColors[index];
    view.rows[index] = {names[index],
                        static_cast<uint16_t>(((rgb >> 19) & 0x1F) << 11 | ((rgb >> 10) & 0x3F) << 5 |
                                              ((rgb >> 3) & 0x1F)),
                        static_cast<float>(share), percents[index], holders[index]};
  }
  view.count = kCawBurnChainCount;
  // Largest share first, as the site.
  for (uint8_t a = 0; a < view.count; ++a)
    for (uint8_t b = a + 1; b < view.count; ++b)
      if (view.rows[b].share > view.rows[a].share) std::swap(view.rows[a], view.rows[b]);
  cawFormatCawAmount(circulating, circulatingText, sizeof(circulatingText));
  cawFormatCawAmount(burned, burnedText, sizeof(burnedText));
  holdersText[0] = '\0';
  if (holdersComplete) cawFormatThousands(holdersTotal, holdersText, sizeof(holdersText));
  view.circulating = circulatingText;
  view.burned = burnedText;
  view.holders = holdersText;
  cawStage(47);
  app->screen.showSupply(view);
  supplyShowingSince = millis() ? millis() : 1;
  return true;
}

void endSupplyScreen() {
  supplyShowingSince = 0;
  app->screen.invalidate();
  lastScreenUpdate = 0;
  animationKey = 0xFFFFFFFF;  // redraw the meme
}

void cawAppLoop() {
  cawStage(10);
  clearPowerOns();
  if (recoveryUntil && !recoveryActive()) {  // recovery over: back to normal
    recoveryUntil = 0;
    stopAccessPoint();
    if (WiFi.status() != WL_CONNECTED) WiFi.begin(app->config.ssid, app->config.wifiPassword);
    lastScreenUpdate = 0;
  }
  // Finished price alerts are cleared at once, in every mode and for hidden
  // chains too (see cawMoveAlertExpire: they would come back ~25 days later).
  for (CawMoveAlert &alert : alerts) cawMoveAlertExpire(alert, millis());
  app->server.handleClient();
  noteStack("web");
  if (updateInProgress) {
    // An upload that stops without finishing (browser closed, connection
    // lost) must not leave the clock on the "Updating" screen.
    if (millis() - lastUploadActivity < 30000) return;
    abandonUpdate();
  }
  cawStage(11);
  handleWifi();
  if (updateMode != UpdateMode::Off) {
    updateModeLoop();
    return;
  }

  const bool connected = WiFi.status() == WL_CONNECTED;
  if (!wifiConfigured(app->config) || (accessPointRunning && !connected) || recoveryActive()) {
    delay(2);
    return;  // the setup (or recovery) screen stays visible
  }

  static uint32_t lastBacklightCheck = 0;
  if (millis() - lastBacklightCheck >= 5000) {  // night mode starts/ends on time
    lastBacklightCheck = millis();
    cawStage(12);
    cawNoteHeap();
    applyBacklight();
  }

  if (!bootGuardCleared && millis() >= stableAfterMs()) {
    clearBootGuard();
    bootGuardCleared = true;
  }
#if CAW_ROLLBACK_TEST
  // Test build only (-D CAW_ROLLBACK_TEST=1): while on trial (a rollback copy
  // exists) and not in safe mode, crash 30 s after each start. Three crashes
  // in a row must bring the previous firmware back. In safe mode it stops
  // crashing, so a failed rollback still leaves the panel and upload usable.
  if (rollbackPending && !safeMode && millis() >= 30000) {
    app->screen.showMessage("Rollback test", "Crashing on purpose", "(restart", String(quickRestarts + 1).c_str(), "of 3)");
    delay(2000);
    abort();
  }
#endif
  if (rollbackPending && !safeMode && millis() >= kCawRollbackConfirmMs) {
    cawRollbackDiscard();  // the new firmware ran long enough: keep it
    rollbackPending = false;
  }
  if (safeMode) {
    const String address = connected ? WiFi.localIP().toString() : String("not connected");
    if (address != safeModeAddress) {
      safeModeAddress = address;
      const String restarts = String("Restarted ") + quickRestarts + " times";
      const String open = connected ? "Open http://" + address : String("Wi-Fi: not connected");
      app->screen.showMessage(PSTR("Safe mode"), restarts.c_str(), PSTR("Price updates paused"),
                              open.c_str());
    }
    delay(2);
    return;
  }

  // One fetch per pass, so the web panel and clock stay responsive between
  // the (blocking, a few seconds each) HTTPS requests.
  const time_t now = time(nullptr);
  if (fetchCooldownUntil && deadlinePassed(fetchCooldownUntil, millis(), 2 * kFetchCooldownMs))
    fetchCooldownUntil = 0;
  bool fetchedPrice = false;
  if (connected && now >= kMinimumValidEpoch && !fetchCooldownUntil) {
    for (uint8_t index = 0; index < kCawChainCount; ++index) {
      if ((index == 0 || chainShown(index)) && app->feeds[index].due()) {
        fetchedPrice = true;
        cawStage(13, index);
        cawNoteHeap();
        if (!app->feeds[index].fetch(now)) {
          fetchCooldownUntil = millis() + kFetchCooldownMs;
          if (!fetchCooldownUntil) fetchCooldownUntil = 1;
        } else if (chainShown(index) &&
                   cawMoveAlertUpdate(alerts[index],
                                      cawParsePercent(app->feeds[index].market().change1h),
                                      app->settings.alertPercent, millis(), kAlertFlashMs)) {
          activeChain = index;  // a big move: show that chain now
          lastRotation = millis();
        }
        noteStack("fetch");
        lastScreenUpdate = 0;
        break;
      }
    }
  }

  // Burn alert: at most one request per pass, never in the same pass as a
  // price fetch, and not while a burn is on screen.
  // (Not without the burn meme: the CAW + Home Assistant build has none.)
  bool burnPolledNow = false;
  if ((app->settings.burnAlerts || app->settings.supplyScreen) && burnMeme() && connected &&
      now >= kMinimumValidEpoch && !fetchCooldownUntil && !fetchedPrice && !burnShowingSince &&
      (!burnPolled || millis() - burnPolledAt >= kBurnPollEveryMs)) {
    burnPolled = true;
    burnPolledAt = millis();
    pollBurns(now);
    burnPolledNow = true;
    lastScreenUpdate = 0;
  }
  if (app->settings.supplyScreen && burnMeme() && connected && now >= kMinimumValidEpoch &&
      !fetchCooldownUntil && !fetchedPrice && !burnPolledNow && !burnShowingSince &&
      (!holdersPolled ||
       millis() - holdersPolledAt >= (holdersAllKnown() ? kHoldersEveryMs : kHoldersFirstEveryMs))) {
    holdersPolled = true;
    holdersPolledAt = millis();
    pollHolders(now);
    lastScreenUpdate = 0;
  }
  if (connected && now >= kMinimumValidEpoch && !fetchCooldownUntil && !fetchedPrice &&
      !burnPolledNow && !burnShowingSince && millis() - autoCheckFrom >= autoCheckWait) {
    autoCheckFrom = millis();
    CawReleaseInfo latest{};
    String error;
    bool lowMemory = false;
    cawStage(19);
    const bool found =
        cawCheckLatestVersion(now, latest.version, sizeof(latest.version), error, lowMemory);
    autoCheckWait = found ? kAutoCheckEveryMs : kAutoCheckRetryMs;
    // Kept quiet unless it changes something: a newer version, or one no
    // longer offered. Failures are not written (the next try is in an hour).
    if (found && (availableVersion[0] ||
                  cawCompareVersions(latest.version, kVersion) == CawVersionOrder::Newer))
      writeUpdateResult("checked", &latest, String());
    noteStack("update check");
    lastScreenUpdate = 0;
  }
  if (burnShowingSince) {
    if (millis() - burnShowingSince < kBurnShowMs) {
      if (millis() - burnFrameAt >= burnFrameMs) {
        burnFrameAt = millis();
        const uint8_t *meme = burnShownMeme ? burnShownMeme : burnMeme();
        cawStage(45, burnFrame);
        if (meme && !app->screen.drawBurnFrame(meme, ++burnFrame)) {
          burnFrame = 0;
          app->screen.drawBurnFrame(meme, 0);
        }
      }
      delay(2);
      return;  // the burn has the whole screen
    }
    burnShowingSince = 0;  // back to the CAW screen
    app->screen.invalidate();
    lastScreenUpdate = 0;
    animationKey = 0xFFFFFFFF;  // the meme slot was drawn over: reload it
  } else if (burnTestRequested) {
    burnTestRequested = false;
    showTestBurn();
    delay(2);
    return;
  } else if (furnaceTestRequested) {
    furnaceTestRequested = false;
    drawBurn(119041680.0, 0, "The Great Furnace", "cronos", true, true);
    delay(2);
    return;
  } else if (!connectedNoticeUntil && cawBurnDue(burnGate, millis(), kBurnCooldownMs)) {
    showBurnAlert();
    delay(2);
    return;
  }

  cawStage(14, activeChain);
  const uint32_t rotateMs = app->settings.rotateSeconds * 1000UL;
  const uint32_t stayMs =
      supplyShowingSince ? (rotateMs > kSupplyMinimumMs ? rotateMs : kSupplyMinimumMs) : rotateMs;
  if (!chainShown(activeChain) || millis() - lastRotation >= stayMs) {
    lastRotation = millis();
    bool supplyNow = false;
    if (supplyShowingSince) {
      endSupplyScreen();  // back to the chains
    } else if (app->settings.supplyScreen) {
      // After the last shown chain, before the first again: the supply screen.
      uint8_t next = activeChain;
      for (uint8_t step = 1; step <= kCawChainCount; ++step) {
        next = (activeChain + step) % kCawChainCount;
        if (chainShown(next)) break;
      }
      if (next <= activeChain) supplyNow = showSupplyScreen();
    }
    if (!supplyNow) {
      for (uint8_t step = 1; step <= kCawChainCount; ++step) {
        const uint8_t next = (activeChain + step) % kCawChainCount;
        if (chainShown(next)) {
          if (next != activeChain) {
            lastScreenUpdate = 0;
            if (app->settings.pictureSeconds == kPictureWithChain) nextPicture();
          }
          activeChain = next;
          break;
        }
      }
    }
  }
  if (supplyShowingSince) {
    cawStage(47);
    delay(2);
    return;  // the supply screen has the whole screen until the next turn
  }

  const uint16_t pictureSeconds = app->settings.pictureSeconds;
  if (lastPictureChange == 0 ||
      (pictureSeconds > kPictureWithChain && millis() - lastPictureChange >= pictureSeconds * 1000UL)) {
    lastPictureChange = millis();
    if (!lastPictureChange) lastPictureChange = 1;
    cawStage(15, pictureKey);
    nextPicture();
  }

  if (connectedNoticeUntil &&
      deadlinePassed(connectedNoticeUntil, millis(), 2 * kConnectedNoticeMs)) {
    connectedNoticeUntil = 0;  // "Connected" notice done: back to the CAW screen
    app->screen.invalidate();
    lastScreenUpdate = 0;
  }
  // While the shown chain's price alert runs, redraw twice a second so the
  // price flashes (alert colour, white, alert colour...).
  // (Turning alerts off clears them.)
  const bool alertFlashing = cawMoveAlertActive(alerts[activeChain], millis());
  if (!connectedNoticeUntil &&
      (millis() - lastScreenUpdate >= (alertFlashing ? 500UL : 1000UL) || lastScreenUpdate == 0)) {
    lastScreenUpdate = millis();
    cawNoteHeap();
    cawStage(16, pictureKey);
    const CawFeedLite &feed = app->feeds[activeChain];
    const CawMarket &market = feed.market();
    const CawMarket &cronos = app->feeds[0].market();
    CawScreenData data;
    data.chain = feed.chain().label;
    data.chainId = feed.chain().id;
    char picturePath[24];
    data.pictureKey = pictureKey;
    data.picture = app->pictures.builtinData(pictureKey);
    data.picturePath =
        app->pictures.uploadPathFor(pictureKey, picturePath, sizeof(picturePath)) ? picturePath
                                                                                  : nullptr;
    data.price = feed.displayPrice();
    if (alertFlashing && (millis() / 500) % 2 == 0)
      data.priceFlash = alerts[activeChain].up ? 1 : -1;
    data.change1h = market.valid ? market.change1h : "--";
    data.change24h = market.valid ? market.change24h : "--";
    data.liquidity = market.valid ? market.liquidity : "--";
    data.volume = market.valid ? market.volume : "--";
    data.marketCap = cronos.valid ? cronos.marketCap : market.valid ? market.marketCap : "--";
    data.live = feed.live();
    data.wifiConnected = connected;
    data.updateAvailable = availableVersion[0] != '\0';
    data.clock24 = app->settings.clock24;
    data.history = feed.history();
    data.historyCount = CawFeedLite::kHistoryPoints;
    // Unique per chain and version, so switching chains redraws the chart.
    data.historyVersion = feed.historyVersion() * kCawChainCount + activeChain;
    app->screen.update(data);
    if (animationKey != pictureKey) loadAnimation();  // frame 0 was just drawn
    noteStack("screen");
    cawStage(17);
  }

  // Next frame of an animated picture, when its delay is up. The screen
  // draws the picture slot only; a price fetch (a few seconds) pauses it.
  if (animationActive && !connectedNoticeUntil && animationKey == pictureKey &&
      millis() - animationAt >= animation.delay[animationFrame]) {
    cawStage(18, animationFrame);
    animationAt = millis();
    animationFrame = (animationFrame + 1) % animation.frames;
    if (!(animation.builtin
              ? app->screen.drawPaletteAnimationFrame(animation.builtin, animationFrame)
              : app->screen.drawAnimationFrame(animationPath, animation.dataOffset, animationFrame)))
      animationActive = false;  // file gone or the screen is showing a message
  }
  delay(2);
}

#if !CAW_DUAL
void setup() { cawAppSetup(); }
void loop() { cawAppLoop(); }
#endif

#endif  // CAW_STANDALONE
