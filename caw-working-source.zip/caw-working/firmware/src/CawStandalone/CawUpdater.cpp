#if CAW_STANDALONE

#include "CawUpdater.h"

#include <ArduinoJson.h>
#include <ESP8266WiFi.h>
#include <LittleFS.h>
#include <MD5Builder.h>
#include <Updater.h>
#include <WiFiClientSecureBearSSL.h>
#include <bearssl/bearssl_hash.h>

#include <memory>
#include <new>

#include "CawFeedLite.h"  // cawTlsHeapProbe
#include "CawUpdateAnchors.h"

namespace {

constexpr char kBackupPath[] = "/fw-prev.bin";
constexpr char kBackupTempPath[] = "/fw-prev.tmp";
constexpr char kMetaPath[] = "/fw-prev.json";
constexpr char kNoticePath[] = "/fw-rollback.json";
// Room kept free beside the copy, for LittleFS metadata and settings writes.
constexpr uint32_t kSpareBytes = 64UL * 1024UL;
constexpr size_t kChunk = 2048;
constexpr uint32_t kReadTimeoutMs = 20000;

struct Meta {
  char version[32];  // firmware the copy holds
  uint32_t size;
  char md5[33];
  bool restoring;    // the copy was written back; the next start runs it
  char failed[32];   // the firmware that kept restarting
};

bool readMeta(Meta &meta) {
  meta = Meta{};
  File file = LittleFS.open(kMetaPath, "r");
  if (!file) return false;
  DynamicJsonDocument document(384);
  const bool ok = document.capacity() && !deserializeJson(document, file);
  file.close();
  if (!ok) return false;
  strlcpy(meta.version, document["version"] | "", sizeof(meta.version));
  strlcpy(meta.md5, document["md5"] | "", sizeof(meta.md5));
  strlcpy(meta.failed, document["failed"] | "", sizeof(meta.failed));
  meta.size = document["size"] | 0UL;
  meta.restoring = document["restoring"] | false;
  return meta.version[0] && meta.size && strlen(meta.md5) == 32;
}

bool writeMeta(const Meta &meta) {
  DynamicJsonDocument document(384);
  if (!document.capacity()) return false;
  document["version"] = meta.version;
  document["size"] = meta.size;
  document["md5"] = meta.md5;
  document["restoring"] = meta.restoring;
  document["failed"] = meta.failed;
  File file = LittleFS.open(kMetaPath, "w");
  if (!file) return false;
  const bool ok = serializeJson(document, file) > 0 && !file.getWriteError();
  file.close();
  return ok;
}

void removeCopy() {
  LittleFS.remove(kBackupTempPath);
  LittleFS.remove(kBackupPath);
  LittleFS.remove(kMetaPath);
}

// Writes the copy back into the update area, checked against its MD5. On
// success the boot loader installs it at the next restart.
bool restoreCopy(const Meta &meta) {
  File file = LittleFS.open(kBackupPath, "r");
  if (!file || file.size() != meta.size) return false;
  std::unique_ptr<uint8_t[]> buffer(new (std::nothrow) uint8_t[kChunk]);
  if (!buffer || !Update.begin(meta.size)) {
    file.close();
    return false;
  }
  bool ok = Update.setMD5(meta.md5);
  uint32_t done = 0;
  while (ok && done < meta.size) {
    const size_t want = std::min<size_t>(kChunk, meta.size - done);
    ok = file.read(buffer.get(), want) == static_cast<int>(want) &&
         Update.write(buffer.get(), want) == want;
    if (ok) done += want;
    yield();
  }
  file.close();
  if (!ok || done != meta.size) {
    // Not finished: end() then writes no boot command, it only releases the
    // updater and its 4 KB buffer, so safe mode's firmware upload can start.
    Update.end();
    return false;
  }
  return Update.end() && !Update.hasError();
}

// ---------------------------------------------------------------- download

// One root certificate as a trust list. Only one is held at a time: the
// core's X509List keeps both the certificate and its parsed key, ~8 KB for all
// six, which GitHub's 16 KB TLS records cannot spare.
std::unique_ptr<BearSSL::X509List> anchorList(uint8_t index) {
  const CawDerAnchor &anchor = kCawUpdateAnchors[index];
  std::unique_ptr<uint8_t[]> der(new (std::nothrow) uint8_t[anchor.length]);
  if (!der) return nullptr;
  memcpy_P(der.get(), anchor.der, anchor.length);
  std::unique_ptr<BearSSL::X509List> list(new (std::nothrow) BearSSL::X509List);
  if (list && !list->append(der.get(), anchor.length)) list.reset();
  return list;
}

constexpr uint8_t kAnchorCount = sizeof(kCawUpdateAnchors) / sizeof(kCawUpdateAnchors[0]);
// Root tried first per host family (see CawUpdateAnchors.h): github.com
// (USERTrust ECC) and the file host (ISRG Root X1). Updated to the one that
// worked, so a wrong guess costs one handshake at most once per start.
uint8_t gGithubAnchor = 0, gAssetAnchor = 1;

bool isAssetHost(const char *host) {
  static const char kSuffix[] = "githubusercontent.com";
  const size_t length = strlen(host), suffix = sizeof(kSuffix) - 1;
  return length >= suffix && strcmp(host + length - suffix, kSuffix) == 0;
}

// Connects to `host` with each root in turn until its chain is trusted. Every
// attempt gets a new client: the core builds a failed attempt's replacement
// (e.g. its 3 KB certificate checker) before freeing the old one, and its
// allocations restart the clock when they fail, so memory is also checked
// before each attempt. On failure `error` says why, with the memory figures.
bool connectTrusted(std::unique_ptr<BearSSL::WiFiClientSecure> &client, const char *host,
                    bool small, time_t now, std::unique_ptr<BearSSL::X509List> &list,
                    String &error) {
  uint8_t &preferred = isAssetHost(host) ? gAssetAnchor : gGithubAnchor;
  // Engine (~3.6 KB), certificate checker (3 KB), output buffer and the
  // receive buffer (4 or 16 KB + 325 B) still to come after the client exists.
  const uint32_t receive = (small ? 4096U : 16384U) + 325U;
  // Plus ~2.5 KB spare: the core restarts the clock when one of these fails.
  const uint32_t needFree = receive + 597 + 3600 + 3100 + 2560;
  for (uint8_t step = 0; step < kAnchorCount; ++step) {
    const uint8_t index = (preferred + step) % kAnchorCount;
    client.reset();
    list.reset();
    // BearSSL's own stack (6.2 KB) is allocated with the first client.
    if (ESP.getMaxFreeBlockSize() < 6200 + 512) {
      error = F("Not enough memory");
      return false;
    }
    client.reset(new (std::nothrow) BearSSL::WiFiClientSecure);
    list = anchorList(index);
    const uint32_t freeHeap = ESP.getFreeHeap(), maxBlock = ESP.getMaxFreeBlockSize();
    String memory = String(F("; ")) + (small ? F("4") : F("16")) + F(" KB buffers, free memory ") +
                    freeHeap + F(", largest block ") + maxBlock;
    // Free memory in total is not enough: a 3,080-byte certificate checker
    // failed with 25 KB free in pieces (and restarted the clock). The client
    // exists, so BearSSL's stack is already allocated.
    if (!client || !list || freeHeap < needFree || maxBlock < receive ||
        !cawTlsHeapProbe(small ? 4096 : 0, false)) {
      error = String(F("Not enough memory to connect to ")) + host + memory;
      return false;
    }
    client->setBufferSizes(small ? 4096 : 16384, 512);
    client->setX509Time(now);
    client->setTimeout(kReadTimeoutMs);
    client->setTrustAnchors(list.get());
    if (client->connect(host, 443)) {
      preferred = index;
      return true;
    }
    const int ssl = client->getLastSSLError();
    if (ssl == BR_ERR_X509_NOT_TRUSTED) {
      error = String(F("Could not connect to ")) + host +
              F(" (its certificate is not from a known root)") + memory;
      continue;
    }
    error = String(F("Could not connect to ")) + host;
    if (ssl) error += String(F(" (TLS error ")) + ssl + ')';
    error += memory;
    return false;
  }
  return false;
}

int readByteTimeout(BearSSL::WiFiClientSecure &client) {
  const uint32_t started = millis();
  while (!client.available()) {
    if (!client.connected() || millis() - started > kReadTimeoutMs) return -1;
    delay(1);
  }
  return client.read();
}

// GET over HTTPS, following GitHub's redirects (github.com -> the asset host,
// whose signed URL is ~1 KB). Returns the final HTTP status with `client`
// positioned at the body, or 0 with `error` set.
int httpsGetFollowing(const char *url, std::unique_ptr<BearSSL::WiFiClientSecure> &client,
                      std::unique_ptr<BearSSL::X509List> &anchors, time_t now, int32_t &length,
                      String &error) {
  // GitHub's signed asset URLs measured ~920 characters (2026-11); room to grow.
  constexpr size_t kUrlBytes = 1600;
  // One buffer on the heap (not the 4 KB main stack): the URL, then, once the
  // request is sent, the header lines, with the next Location kept at its
  // start.
  std::unique_ptr<char[]> buffer(new (std::nothrow) char[kUrlBytes]);
  if (!buffer) {
    error = F("Not enough memory");
    return 0;
  }
  char *current = buffer.get();
  strlcpy(current, url, kUrlBytes);
  for (uint8_t hop = 0; hop < 5; ++hop) {
    char host[96];
    const char *path = nullptr;
    if (!cawSplitHttpsUrl(current, host, sizeof(host), &path)) {
      error = F("Unexpected download address");
      return 0;
    }
    client.reset();  // the previous hop's connection first: memory
    anchors.reset();
    // 4 KB receive buffers when the host agrees to send small TLS records
    // (Max Fragment Length), else the full 16 KB: ~12 KB less memory.
    const bool small = BearSSL::WiFiClientSecure::probeMaxFragmentLength(host, 443, 4096);
    bool connected = connectTrusted(client, host, small, now, anchors, error);
    if (!connected && error.startsWith(F("Not enough memory"))) {
      // The last connection's network buffers can take a moment to be
      // released. One more try.
      client.reset();
      anchors.reset();
      delay(2000);
      connected = connectTrusted(client, host, small, now, anchors, error);
    }
    if (!connected) return 0;  // `error` says why
    // HTTP/1.0: no chunked bodies, the length comes from Content-Length.
    client->print(F("GET "));
    client->print(path);
    client->print(F(" HTTP/1.0\r\nHost: "));
    client->print(host);
    client->print(F("\r\nUser-Agent: CAW-Clock\r\nAccept: */*\r\nConnection: close\r\n\r\n"));
    BearSSL::WiFiClientSecure &stream = *client;
    const auto read = [&stream] { return readByteTimeout(stream); };
    const int status = readHttpStatus(read);
    if (!status || !cawReadHttpHeadersInPlace(read, current, kUrlBytes, length)) {
      error = String(F("No valid reply from ")) + host;
      return 0;
    }
    if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
      if (!current[0]) {
        error = F("Redirect without a usable address");
        return 0;
      }
      continue;  // `current` now holds the Location
    }
    if (status != 200) error = String(F("GitHub answered HTTP ")) + status;
    return status;
  }
  error = F("Too many redirects");
  return 0;
}

}  // namespace

// ---------------------------------------------------------------- rollback

CawRollbackSpace cawRollbackSpace() {
  CawRollbackSpace space{ESP.getSketchSize() + kSpareBytes, 0};
  FSInfo info{};
  if (!LittleFS.info(info)) return space;
  space.available = info.totalBytes > info.usedBytes ? info.totalBytes - info.usedBytes : 0;
  File old = LittleFS.open(kBackupPath, "r");
  if (old) {
    space.available += old.size();  // replaced by the new copy
    old.close();
  }
  return space;
}

bool cawRollbackSave(const char *version, void (*progress)(uint8_t percent)) {
  cawRollbackClearNotice();
  if (!cawRollbackFits(cawRollbackSpace())) return false;
  removeCopy();
  const uint32_t size = ESP.getSketchSize();
  std::unique_ptr<uint32_t[]> words(new (std::nothrow) uint32_t[kChunk / 4]);
  File file = LittleFS.open(kBackupTempPath, "w");
  if (!words || !file || size == 0) {
    if (file) file.close();
    removeCopy();
    return false;
  }
  uint8_t *buffer = reinterpret_cast<uint8_t *>(words.get());
  MD5Builder md5;
  md5.begin();
  uint32_t done = 0;
  uint8_t shown = 255;
  while (done < size) {
    const size_t want = std::min<size_t>(kChunk, size - done);
    // Flash reads are whole 32-bit words.
    if (!ESP.flashRead(done, words.get(), (want + 3) & ~static_cast<size_t>(3))) break;
    md5.add(buffer, want);
    if (file.write(buffer, want) != want) break;
    done += want;
    const uint8_t percent = static_cast<uint8_t>(static_cast<uint64_t>(done) * 100 / size);
    if (progress && percent != shown) progress(shown = percent);
    yield();
  }
  const bool written = done == size && !file.getWriteError();
  file.close();
  if (!written || !LittleFS.rename(kBackupTempPath, kBackupPath)) {
    removeCopy();
    return false;
  }
  md5.calculate();
  Meta meta{};
  strlcpy(meta.version, version, sizeof(meta.version));
  meta.size = size;
  strlcpy(meta.md5, md5.toString().c_str(), sizeof(meta.md5));
  if (!writeMeta(meta)) {
    removeCopy();
    return false;
  }
  return true;
}

void cawRollbackDiscard() { removeCopy(); }

CawRollbackBoot cawRollbackBoot(const char *version, bool crashLoop,
                                 void (*message)(const char *line)) {
  Meta meta;
  if (!readMeta(meta)) {
    removeCopy();  // a copy without its description is useless
    return CawRollbackBoot::None;
  }
  if (strcmp(meta.version, version) == 0) {
    // The copy's own firmware runs: either it was just restored, or the
    // update it guarded never took over (failed, or the same version).
    const bool restored = meta.restoring;
    if (restored) {
      DynamicJsonDocument notice(256);
      notice["failed"] = meta.failed;
      notice["restored"] = meta.version;
      File file = LittleFS.open(kNoticePath, "w");
      if (file) {
        serializeJson(notice, file);
        file.close();
      }
    }
    removeCopy();
    return restored ? CawRollbackBoot::RolledBack : CawRollbackBoot::None;
  }
  if (!LittleFS.exists(kBackupPath)) {
    removeCopy();
    return CawRollbackBoot::None;
  }
  if (!crashLoop) return CawRollbackBoot::Pending;
  if (message) message(meta.version);
  strlcpy(meta.failed, version, sizeof(meta.failed));
  meta.restoring = true;
  // Mark first: if the restart comes from the boot loader's copy itself, the
  // restored firmware still finds out what happened.
  if (!writeMeta(meta) || !restoreCopy(meta)) {
    removeCopy();  // unusable copy: carry on in safe mode instead
    return CawRollbackBoot::None;
  }
  return CawRollbackBoot::RestoreReady;
}

bool cawRollbackNotice(char *failed, size_t failedSize, char *restored, size_t restoredSize) {
  File file = LittleFS.open(kNoticePath, "r");
  if (!file) return false;
  DynamicJsonDocument document(256);
  const bool ok = document.capacity() && !deserializeJson(document, file);
  file.close();
  if (!ok) return false;
  strlcpy(failed, document["failed"] | "", failedSize);
  strlcpy(restored, document["restored"] | "", restoredSize);
  return failed[0] != '\0';
}

void cawRollbackClearNotice() { LittleFS.remove(kNoticePath); }

// ---------------------------------------------------------------- updates

bool cawCheckLatestVersion(time_t now, char *version, size_t versionSize, String &error,
                           bool &lowMemory) {
  // Same limits as the price fetch: BearSSL's 6.2 KB stack must be
  // allocatable (the core aborts when it is not), plus the buffers.
  lowMemory = ESP.getFreeHeap() < 22000 || ESP.getMaxFreeBlockSize() < 6200 + 1024;
  if (lowMemory) {
    error = F("Not enough free memory");
    return false;
  }
  const bool small = BearSSL::WiFiClientSecure::probeMaxFragmentLength("github.com", 443, 4096);
  lowMemory = !small && (ESP.getFreeHeap() < 32000 || ESP.getMaxFreeBlockSize() < 20000);
  if (lowMemory) {
    error = F("Not enough free memory for full-size TLS records");
    return false;
  }
  std::unique_ptr<BearSSL::X509List> anchors;
  std::unique_ptr<char[]> buffers(new (std::nothrow) char[512 * 2]);
  std::unique_ptr<BearSSL::WiFiClientSecure> client;
  if (!buffers) {
    error = F("Not enough memory");
    return false;
  }
  if (!connectTrusted(client, "github.com", small, now, anchors, error)) {
    lowMemory = error.startsWith(F("Not enough memory"));
    return false;
  }
  client->print(F("GET /" CAW_RELEASE_REPOSITORY "/releases/latest HTTP/1.0\r\n"
                  "Host: github.com\r\nUser-Agent: CAW-Clock\r\nAccept: */*\r\n"
                  "Connection: close\r\n\r\n"));
  BearSSL::WiFiClientSecure &stream = *client;
  const auto read = [&stream] { return readByteTimeout(stream); };
  char *line = buffers.get();
  char *location = line + 512;
  int32_t length = -1;
  const int status = readHttpStatus(read);
  const bool headers = status && cawReadHttpHeaders(read, line, 512, location, 512, length);
  client->stop();
  if (!headers) {
    error = F("No valid reply from github.com");
    return false;
  }
  if (status == 404) {
    error = F("No release published yet");
    return false;
  }
  if ((status != 302 && status != 301) ||
      !cawVersionFromTagUrl(location, CAW_RELEASE_REPOSITORY, version, versionSize)) {
    error = String(F("Unexpected reply from github.com (HTTP ")) + status + ')';
    return false;
  }
  return true;
}

bool cawFetchLatestRelease(time_t now, CawReleaseInfo &out, String &error) {
  std::unique_ptr<BearSSL::X509List> anchors;
  std::unique_ptr<BearSSL::WiFiClientSecure> client;
  int32_t length = -1;
  const int status = httpsGetFollowing(
      "https://github.com/" CAW_RELEASE_REPOSITORY "/releases/latest/download/SHA256SUMS.txt",
      client, anchors, now, length, error);
  // A release is "latest" a few minutes before its files are attached.
  if (status == 404) error = F("the release's files are still being uploaded; try again in a few minutes");
  else if (status && status != 200) error = String(F("Unexpected reply from GitHub (HTTP ")) + status + ')';
  if (status != 200) return false;
  constexpr size_t kMaxSums = 2048;  // five lines of ~100 characters
  if (length > static_cast<int32_t>(kMaxSums)) {
    error = F("Unexpected SHA256SUMS.txt");
    return false;
  }
  std::unique_ptr<char[]> text(new (std::nothrow) char[kMaxSums]);
  if (!text) {
    error = F("Not enough memory");
    return false;
  }
  size_t used = 0;
  for (int c; used < kMaxSums && (length < 0 || used < static_cast<size_t>(length)) &&
              (c = readByteTimeout(*client)) >= 0;)
    text[used++] = static_cast<char>(c);
  client->stop();
  if (!cawFindFirmwareInSums(text.get(), used, out)) {
    error = F("No firmware in the latest release");
    return false;
  }
  return true;
}

bool cawInstallRelease(time_t now, const CawReleaseInfo &release, String &error,
                       void (*progress)(uint32_t done, uint32_t total)) {
  std::unique_ptr<BearSSL::X509List> anchors;
  String url = F("https://github.com/" CAW_RELEASE_REPOSITORY "/releases/download/v");
  url += release.version;
  url += '/';
  url += release.file;
  std::unique_ptr<BearSSL::WiFiClientSecure> client;
  int32_t length = -1;
  if (httpsGetFollowing(url.c_str(), client, anchors, now, length, error) != 200) return false;
  if (length <= 0 || static_cast<uint32_t>(length) > (ESP.getFreeSketchSpace() & 0xFFFFF000)) {
    error = F("The firmware file has an unexpected size");
    return false;
  }
  std::unique_ptr<uint8_t[]> buffer(new (std::nothrow) uint8_t[1024]);
  if (!buffer || !Update.begin(length)) {
    error = F("Could not start the update");
    return false;
  }
  br_sha256_context sha;
  br_sha256_init(&sha);
  uint32_t done = 0, lastData = millis();
  while (done < static_cast<uint32_t>(length)) {
    const int ready = client->available();
    if (ready <= 0) {
      if (!client->connected() || millis() - lastData > kReadTimeoutMs) break;
      delay(1);
      continue;
    }
    const size_t want =
        std::min<size_t>({static_cast<size_t>(ready), size_t{1024}, static_cast<size_t>(length) - done});
    const int got = client->read(buffer.get(), want);
    if (got <= 0) continue;
    br_sha256_update(&sha, buffer.get(), got);
    if (Update.write(buffer.get(), got) != static_cast<size_t>(got)) break;
    done += got;
    lastData = millis();
    if (progress) progress(done, length);
    yield();
  }
  client->stop();
  if (done != static_cast<uint32_t>(length)) {
    error = Update.hasError() ? F("Writing the firmware failed") : F("The download stopped");
    // Unfinished, so end() writes no boot command: it only releases the
    // updater. The current firmware keeps running after the restart.
    Update.end();
    return false;
  }
  uint8_t digest[32];
  br_sha256_out(&sha, digest);
  char hex[65];
  cawHex32(digest, hex);
  if (strcmp(hex, release.sha256) != 0) {
    // Every byte is written, so Update.end() would install it: never call it
    // here. Without it no boot command is written; the clock restarts into
    // the current firmware.
    error = F("Checksum mismatch: the download was not installed");
    return false;
  }
  if (!Update.end() || Update.hasError()) {
    error = F("Activating the firmware failed");
    return false;
  }
  return true;
}

#endif  // CAW_STANDALONE
