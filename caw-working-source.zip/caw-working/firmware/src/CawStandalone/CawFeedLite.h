#pragma once

// CAW market data for the standalone firmware.
//
// Sources, in order: DexScreener with a 4 KiB TLS receive buffer, DexScreener
// with the full 16 KiB buffer (only when the heap allows), GeckoTerminal with
// a 4 KiB buffer. A host that refused the connection is not tried twice in
// one fetch, and failed fetches back off (1, 2, 4, 8, 15 minutes). Certificates are always validated (GTS Root R1/R4, ISRG
// Root X1/X2, loaded only for the fetch). Measured on the device: a 4 KiB
// fetch needs about 15 KB of heap, a full-buffer fetch about 28 KB.
//
// The last good values and the 48 x 30-minute chart buckets are cached in
// LittleFS, so the screen and chart survive a restart. Empty buckets are
// back-filled from GeckoTerminal's hourly candles (24 h), so the chart is
// complete minutes after the first start instead of after a day.
#if CAW_STANDALONE

#include <Arduino.h>
#include <time.h>

// One CAW market (the deepest CAW pool on a chain). Addresses checked
// against DexScreener and GeckoTerminal on 2026-11-15.
struct CawChain {
  const char *id;            // cache file and settings name
  const char *label;         // shown on screen
  const char *quote;         // quote token, e.g. "wcro"
  const char *dexChain;      // DexScreener chain id
  const char *geckoNetwork;  // GeckoTerminal network id
  const char *pair;          // pool / pair address
};

constexpr uint8_t kCawChainCount = 4;
extern const CawChain kCawChains[kCawChainCount];

struct CawMarket {
  char price[48]{};      // "$0.000000004785" (exact decimal)
  char change1h[16]{};   // "+0.9%"
  char change24h[16]{};  // "-2.4%"
  char liquidity[24]{};  // "$776K"
  char volume[24]{};
  char marketCap[24]{};
  bool valid = false;
};

// Most of the TLS (BearSSL) stack any connection has used since start.
uint32_t cawTlsStackMax();

class CawFeedLite {
 public:
  static constexpr uint8_t kHistoryPoints = 48;
  struct Source;  // a market data endpoint (see CawFeedLite.cpp)

  explicit CawFeedLite(const CawChain &chain) : chain_(chain) {}
  const CawChain &chain() const { return chain_; }

  void begin(bool filesystemReady);
  // Extra delay added once, after the first successful fetch, so the chains
  // refresh spread across the interval instead of back-to-back.
  void setStagger(uint32_t milliseconds) { staggerMs_ = milliseconds; }
  // True when a fetch should run now.
  bool due() const;
  // Blocking HTTPS fetch (a few seconds). Returns true on new data.
  bool fetch(time_t now);

  const CawMarket &market() const { return market_; }
  // Compact display price, "$0.0₈4785".
  const char *displayPrice() const;
  bool live() const;
  const float *history() const { return history_; }
  uint32_t historyVersion() const { return historyVersion_; }

  // Diagnostics for the panel.
  const char *lastResult() const { return lastResult_; }
  // Result of the first (DexScreener) source in the last fetch; differs from
  // lastResult() when a fallback source was used.
  const char *primaryResult() const { return primaryResult_; }
  uint8_t failures() const { return failures_; }
  const char *backfillResult() const { return backfillResult_; }
  uint8_t historyPoints() const;
  const char *lastSource() const { return lastSource_; }
  int lastHttpStatus() const { return lastHttpStatus_; }
  int lastSslError() const { return lastSslError_; }
  uint32_t lastFetchFreeHeap() const { return lastFetchFreeHeap_; }
  uint32_t lastFetchMaxBlock() const { return lastFetchMaxBlock_; }
  uint32_t lastFetchMinimumHeap() const { return lastFetchMinimumHeap_; }
  // TLS connect (handshake) time of the last fetch and the longest so far;
  // connections that reused a TLS session (no certificate check or key
  // exchange needed) out of all connections.
  uint32_t lastConnectMs() const { return lastConnectMs_; }
  uint32_t maxConnectMs() const { return maxConnectMs_; }
  uint32_t resumedConnections() const { return resumed_; }
  uint32_t connections() const { return connections_; }
  int32_t secondsSinceSuccess() const;

 private:
  bool fetchFrom(const Source &source, time_t now, CawMarket &out);
  void record(float price, time_t now);
  void advanceTo(uint32_t bucket);
  bool backfill(time_t now);
  void setMarket(const CawMarket &market);
  void loadCache();
  void saveCache();

  const CawChain &chain_;
  char cachePath_[32]{};
  CawMarket market_{};
  // compactDisplayPrice() returns a shared static buffer; each feed keeps
  // its own copy so several chains can be shown at once (panel, status).
  char display_[32]{};
  uint32_t staggerMs_ = 0;
  uint8_t preferred_ = 0;  // index in kSources of the source that last worked
  uint8_t fetches_ = 0;    // successful fetches (wraps), to retry the first source now and then
  uint8_t failures_ = 0;  // consecutive fetches where every source failed
  const char *primaryResult_ = "not_started";
  float history_[kHistoryPoints];
  uint32_t historyBucket_ = 0;  // epoch / 1800 of the newest bucket
  uint16_t bucketSamples_ = 0;
  uint32_t historyVersion_ = 1;
  bool filesystemReady_ = false;
  uint32_t nextAttemptAt_ = 0;
  uint32_t lastSuccessAt_ = 0;
  uint32_t lastCacheSavedAt_ = 0;
  uint32_t savedBucket_ = 0;
  const char *lastResult_ = "not_started";
  const char *backfillResult_ = "not_started";
  uint32_t lastBackfillAt_ = 0;
  const char *lastSource_ = "";
  int lastHttpStatus_ = 0;
  int lastSslError_ = 0;
  uint32_t lastFetchFreeHeap_ = 0;
  uint32_t lastFetchMaxBlock_ = 0;
  uint32_t lastFetchMinimumHeap_ = 0;
  uint32_t lastConnectMs_ = 0;
  uint32_t maxConnectMs_ = 0;
  uint32_t resumed_ = 0;
  uint32_t connections_ = 0;
  void noteConnect(uint32_t milliseconds, bool resumed);
};

#endif  // CAW_STANDALONE
