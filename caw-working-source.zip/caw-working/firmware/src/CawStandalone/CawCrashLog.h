#pragma once

// Crash trail. An abort() (out of memory, an assertion, an uncaught error)
// restarts the clock and leaves only "Software/System restart" with zeroed
// fields, so the core's crash hook (custom_crash_callback) copies the facts
// into RTC memory just before the restart:
//   * which step the firmware was in (cawStage) and its detail value,
//   * the size and caller of the last failed memory allocation,
//   * up to 16 code addresses found on the stack (a rough backtrace that
//     tools/addr2line turns into function names for the exact firmware build).
// The next start reads the record, keeps it in /caw-crash.json and reports it
// in /api/status as "lastCrash".
#if CAW_STANDALONE

#include <Arduino.h>

constexpr uint8_t kCrashStackWords = 16;

struct CawCrashRecord {
  bool valid = false;
  bool fromFile = false;  // an earlier boot's record, read back from flash
  uint32_t reason = 0;    // rst_info.reason of the crash (254 = abort/panic)
  uint32_t exception = 0;
  uint32_t epc1 = 0;
  uint32_t excvaddr = 0;
  uint32_t failSize = 0;  // bytes of the last allocation that failed
  uint32_t failAddr = 0;  // code address that asked for it
  uint32_t stage = 0;
  uint32_t detail = 0;
  uint32_t heap = 0;      // free heap at the last stage mark
  uint32_t uptime = 0;    // seconds since start when it happened (approx.)
  bool fromResetInfo = false;  // the crash hook left nothing: built from the
                               // chip's reset info and the RTC stage marks
  char version[24]{};     // firmware that was running
  uint8_t stackCount = 0;
  uint32_t stack[kCrashStackWords]{};
};

// Where the firmware is now. Cheap (two stores): call it at every step that
// could fail. Codes (see caw_standalone.cpp / CawFeedLite.cpp):
//   1-9 start-up, 10-19 main loop, 20-29 price fetch, 30-39 chart back-fill.
extern volatile uint8_t gCawStage;
extern volatile uint32_t gCawStageDetail;
extern volatile uint32_t gCawStageHeap;

// The same marks are mirrored into RTC user memory (offsets 100-104, outside
// eboot's 0-31, the boot guard's 64-65 and the crash record's 72-98), which
// survives every kind of reset. A watchdog reset or a crash whose hook never
// ran still leaves the stage; it is a plain store, no SDK call.
constexpr uint32_t kCawRtcLiveOffset = 100;
constexpr uint32_t kCawRtcLiveMagic = 0xCA3C57A6;
#if CAW_C2
// ESP32-C2: no RTC memory; RAM that a restart leaves as it was (CawCrashLogC2.cpp).
volatile uint32_t *cawRtcLive();
#else
inline volatile uint32_t *cawRtcLive() {
  return reinterpret_cast<volatile uint32_t *>(0x60001200 + 4 * kCawRtcLiveOffset);
}
#endif

inline void cawStage(uint8_t stage, uint32_t detail = 0) {
  gCawStage = stage;
  gCawStageDetail = detail;
  volatile uint32_t *live = cawRtcLive();
  live[1] = stage;
  live[2] = detail;
}

// Free heap at the last call; ESP.getFreeHeap() walks the heap, so this is
// called at a few points (fetch start, once a second), not at every stage.
inline void cawNoteHeap() {
  gCawStageHeap = ESP.getFreeHeap();
  volatile uint32_t *live = cawRtcLive();
  live[3] = gCawStageHeap;
  live[4] = millis() / 1000;
}

// Read the record the last crash left in RTC memory (call first thing at
// start-up), then once the filesystem is up keep it in flash / load an
// earlier one.
void cawCrashLogBegin();
void cawCrashLogStore(bool filesystemReady, const char *version);
const CawCrashRecord &cawLastCrash();

#endif  // CAW_STANDALONE
