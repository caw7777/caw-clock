#pragma once

// Fixed CAW screen drawn directly to the panel: no dashboard JSON, scene
// graph or frame buffer. Layout follows the CAW design (240 x 240):
//   56 x 56 picture, "crow with knife", Wi-Fi icon, chain logo + name, clock
//   subscript price (48 px), 1H / 24H changes, 24-hour chart
//   liq / vol / mcap boxes, ticker with a green / red / grey ring
// Each element is redrawn only when its text or colour changes.
#if CAW_STANDALONE

#include <Arduino.h>
#include <TFT_eSPI.h>

struct CawScreenData {
  const char *chain = "cronos";    // second row
  const char *chainId = "cronos";  // selects the chain logo
  // Top-left picture (CawPictures): redrawn when the key changes. Built-ins
  // come as PROGMEM MDI2 (`picture`), uploads as a file (`picturePath`);
  // neither = the crow.
  uint32_t pictureKey = 0;
  const uint8_t *picture = nullptr;
  const char *picturePath = nullptr;
  const char *price = "--";        // "$0.0₈4785"
  int8_t priceFlash = 0;           // price alert: 1 green, -1 red, 0 white
  const char *change1h = "--";     // "+0.9%"
  const char *change24h = "--";    // "-2.4%"
  const char *liquidity = "--";    // "$776K"
  const char *volume = "--";
  const char *marketCap = "--";
  bool live = false;               // false: ring grey (stale or no data)
  bool wifiConnected = false;
  bool clock24 = true;             // false: 12-hour clock ("7:05")
  const float *history = nullptr;  // oldest first, NaN for empty buckets
  uint8_t historyCount = 0;
  uint32_t historyVersion = 0;     // bump when the series changes
};

class CawScreen {
 public:
  explicit CawScreen(TFT_eSPI &display) : display_(display) {}

  void begin();
  // True while the normal screen is showing (not a message), so the
  // animation may redraw the picture.
  // Same for a built-in animation (CawPictures.h, "CWB1", PROGMEM).
  bool drawPaletteAnimationFrame(const uint8_t *data, uint16_t frame);
  bool pictureReady() const { return staticDrawn_ && pictureValid_; }
  // Draws frame `frame` of an animated picture file (CawPictures.h, "CWA1";
  // `dataOffset` = where frame 0 starts) into the picture slot. One row-sized
  // buffer, no heap.
  bool drawAnimationFrame(const char *path, uint32_t dataOffset, uint16_t frame);
  // Full redraw of every element on the next update().
  void invalidate();
  void update(const CawScreenData &data);

  // Simple full-screen messages (setup, connecting, updating).
  // Up to five lines; a line wider than the screen is drawn at 13 px. Text
  // may be in flash (PSTR("...")) or RAM, up to 63 bytes a line.
  void showMessage(const char *title, const char *line1 = nullptr,
                   const char *line2 = nullptr, const char *line3 = nullptr,
                   const char *line4 = nullptr, const char *line5 = nullptr);
  // Replaces one line (0-4, line1-line5) of the message on screen without
  // clearing the rest: progress figures update without the screen flashing.
  void showMessageLine(uint8_t line, const char *text);

  // Full-screen burn alert (CAW burned when bridged): `meme` is a built-in
  // palette animation drawn at twice its size; drawBurnFrame() steps it. The
  // texts may be in flash (PSTR) or RAM, e.g. "67.11M", "bsc", "solana",
  // "13.42B", "11.521T". `to` nullptr: `from` is the whole route line ("3
  // bridges"); `total` nullptr: no total.
  void showBurn(const uint8_t *meme, const char *amount, const char *from, const char *to,
                const char *bridged, const char *total);
  bool drawBurnFrame(const uint8_t *meme, uint16_t frame);

 private:
  struct Cache {
    char text[40];
    uint16_t color;
    bool valid;
  };

  bool changed(Cache &cache, const char *text, uint16_t color);
  void drawStatic();
  void drawPicture(int16_t x, int16_t y, const uint8_t *mdi);
  bool drawPaletteFrame(int16_t x, int16_t y, const uint8_t *data, uint16_t frame);
  bool drawPictureFile(int16_t x, int16_t y, const char *path);
  bool drawFileFrame(int16_t x, int16_t y, File &file);
  void drawSmooth(uint8_t size, const char *text, int16_t x, int16_t y,
                  uint8_t datum, uint16_t color);
  void drawPrice(const char *text, uint16_t color);
  void drawChart(const CawScreenData &data, uint16_t color);
  void drawTicker(const CawScreenData &data, uint16_t ring, uint16_t moves);

  TFT_eSPI &display_;
  bool staticDrawn_ = false;
  Cache chain_{}, clock_{}, wifi_{}, price_{}, h1_{}, h24_{}, liq_{}, vol_{}, mcap_{},
      ticker_{}, moves_{}, ring_{};
  uint32_t chartVersion_ = 0xFFFFFFFF;
  uint32_t pictureKey_ = 0;
  bool pictureValid_ = false;
  uint16_t chartColor_ = 0;
};

#endif  // CAW_STANDALONE
