#if CAW_STANDALONE

#include "CawCrashLog.h"

#include <ArduinoJson.h>
#include <LittleFS.h>
#include <user_interface.h>

volatile uint8_t gCawStage = 0;
volatile uint32_t gCawStageDetail = 0;
volatile uint32_t gCawStageHeap = 0;

namespace {

// Words of RTC user memory (offset 72..96; the boot guard uses 64-65).
constexpr uint32_t kRecordOffset = 72;
constexpr uint32_t kRecordMagic = 0xCA3C0C01;
constexpr char kFilePath[] = "/caw-crash.json";

struct RtcRecord {
  uint32_t magic;
  uint32_t reason, exception, epc1, excvaddr;
  uint32_t failSize, failAddr;
  uint32_t stage, detail, heap;
  uint32_t stackCount;
  uint32_t stack[kCrashStackWords];
};
static_assert(kRecordOffset + sizeof(RtcRecord) / 4 <= kCawRtcLiveOffset, "RTC areas overlap");

CawCrashRecord record;

}  // namespace

// The umm allocator's note of the last allocation that returned nothing.
extern "C" {
#if CAW_DUAL
// The Home Assistant engine's crash record (CrashDiagnostics.cpp).
void homeAssistantCrashCallback(struct rst_info *info, uint32_t stack, uint32_t stackEnd);
#endif
extern void *umm_last_fail_alloc_addr;
extern int umm_last_fail_alloc_size;

// Called by the core's crash handler just before it restarts the clock. Keep
// it short and allocation-free (the heap may be exhausted).
void IRAM_ATTR custom_crash_callback(struct rst_info *info, uint32_t stack, uint32_t stackEnd) {
  RtcRecord rtc{};
  rtc.magic = kRecordMagic;
  rtc.reason = info->reason;
  rtc.exception = info->exccause;
  rtc.epc1 = info->epc1;
  rtc.excvaddr = info->excvaddr;
  rtc.failSize = umm_last_fail_alloc_addr ? static_cast<uint32_t>(umm_last_fail_alloc_size) : 0;
  rtc.failAddr = reinterpret_cast<uint32_t>(umm_last_fail_alloc_addr);
  rtc.stage = gCawStage;
  rtc.detail = gCawStageDetail;
  rtc.heap = gCawStageHeap;
  for (uint32_t address = stack; address + 4 <= stackEnd && rtc.stackCount < kCrashStackWords;
       address += 4) {
    const uint32_t value = *reinterpret_cast<volatile uint32_t *>(address);
    const bool iram = value >= 0x40100000 && value < 0x40110000;
    const bool flash = value >= 0x40200000 && value < 0x40300000;
    if (iram || flash) rtc.stack[rtc.stackCount++] = value;
  }
  system_rtc_mem_write(64 + kRecordOffset, &rtc, sizeof(rtc));
#if CAW_DUAL
  homeAssistantCrashCallback(info, stack, stackEnd);
#endif
}
}  // extern "C"

void cawCrashLogBegin() {
  // Stage marks of the run that just ended (any reset), then a fresh area.
  volatile uint32_t *live = cawRtcLive();
  const bool liveValid = live[0] == kCawRtcLiveMagic;
  const uint32_t liveStage = liveValid ? live[1] : 0, liveDetail = liveValid ? live[2] : 0;
  const uint32_t liveHeap = liveValid ? live[3] : 0, liveUptime = liveValid ? live[4] : 0;
  live[0] = kCawRtcLiveMagic;
  for (uint8_t index = 1; index <= 4; ++index) live[index] = 0;

  RtcRecord rtc{};
  system_rtc_mem_read(64 + kRecordOffset, &rtc, sizeof(rtc));
  if (rtc.magic != kRecordMagic) {
    // No record from the crash hook. For an exception or a watchdog reset,
    // build one from the chip's reset info and the stage marks.
    const rst_info *info = ESP.getResetInfoPtr();
    if (info->reason != REASON_EXCEPTION_RST && info->reason != REASON_SOFT_WDT_RST &&
        info->reason != REASON_WDT_RST)
      return;
    record = CawCrashRecord{};
    record.valid = true;
    record.fromResetInfo = true;
    record.reason = info->reason;
    record.exception = info->exccause;
    record.epc1 = info->epc1;
    record.excvaddr = info->excvaddr;
    record.stage = liveStage;
    record.detail = liveDetail;
    record.heap = liveHeap;
    record.uptime = liveUptime;
    return;
  }
  record = CawCrashRecord{};
  record.uptime = liveUptime;
  record.valid = true;
  record.reason = rtc.reason;
  record.exception = rtc.exception;
  record.epc1 = rtc.epc1;
  record.excvaddr = rtc.excvaddr;
  record.failSize = rtc.failSize;
  record.failAddr = rtc.failAddr;
  record.stage = rtc.stage;
  record.detail = rtc.detail;
  record.heap = rtc.heap;
  record.stackCount = rtc.stackCount > kCrashStackWords ? kCrashStackWords : rtc.stackCount;
  for (uint8_t index = 0; index < record.stackCount; ++index) record.stack[index] = rtc.stack[index];
  rtc.magic = 0;  // report each crash once
  system_rtc_mem_write(64 + kRecordOffset, &rtc.magic, sizeof(rtc.magic));
}

void cawCrashLogStore(bool filesystemReady, const char *version) {
  if (!filesystemReady) return;
  if (record.valid && !record.fromFile) {
    strlcpy(record.version, version, sizeof(record.version));
    DynamicJsonDocument document(1024);
    document["uptime"] = record.uptime;
    document["fromResetInfo"] = record.fromResetInfo;
    document["version"] = record.version;
    document["reason"] = record.reason;
    document["exception"] = record.exception;
    document["epc1"] = record.epc1;
    document["excvaddr"] = record.excvaddr;
    document["failSize"] = record.failSize;
    document["failAddr"] = record.failAddr;
    document["stage"] = record.stage;
    document["detail"] = record.detail;
    document["heap"] = record.heap;
    JsonArray stack = document.createNestedArray("stack");
    for (uint8_t index = 0; index < record.stackCount; ++index) stack.add(record.stack[index]);
    File file = LittleFS.open(kFilePath, "w");
    if (file) {
      serializeJson(document, file);
      file.close();
    }
    return;
  }
  if (record.valid || !LittleFS.exists(kFilePath)) return;
  File file = LittleFS.open(kFilePath, "r");
  if (!file) return;
  DynamicJsonDocument document(1024);
  const bool ok = !deserializeJson(document, file);
  file.close();
  if (!ok) return;
  record.valid = true;
  record.fromFile = true;
  record.reason = document["reason"] | 0U;
  record.exception = document["exception"] | 0U;
  record.epc1 = document["epc1"] | 0U;
  record.excvaddr = document["excvaddr"] | 0U;
  record.failSize = document["failSize"] | 0U;
  record.failAddr = document["failAddr"] | 0U;
  record.stage = document["stage"] | 0U;
  record.detail = document["detail"] | 0U;
  record.heap = document["heap"] | 0U;
  record.uptime = document["uptime"] | 0U;
  record.fromResetInfo = document["fromResetInfo"] | false;
  strlcpy(record.version, document["version"] | "", sizeof(record.version));
  for (JsonVariantConst value : document["stack"].as<JsonArrayConst>()) {
    if (record.stackCount < kCrashStackWords) record.stack[record.stackCount++] = value | 0U;
  }
}

const CawCrashRecord &cawLastCrash() { return record; }

#endif  // CAW_STANDALONE
