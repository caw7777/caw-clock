#if CAW_STANDALONE

#include "CawPictures.h"

#include "CawCrow.h"
#if CAW_DUAL
// The CAW + Home Assistant image has no room for the bundled memes.
namespace {
struct CawMemeAsset {
  const uint8_t *data;
  uint16_t size;
};
constexpr uint8_t kCawMemeCount = 0;
const CawMemeAsset *const kCawMemes = nullptr;
}  // namespace
#else
#include "CawMemes.h"
#endif

namespace {

constexpr char kDirectory[] = "/m";
constexpr char kIncomingPath[] = "/m/incoming.tmp";
constexpr char kMagic[4] = {'C', 'W', 'P', '1'};

// "<8 hex digits>.raw|off" -> id; 0 when the name doesn't match.
uint32_t parseName(const String &name, bool &shown) {
  if (name.length() != 12 || name[8] != '.') return 0;
  const String suffix = name.substring(9);
  if (suffix != "raw" && suffix != "off") return 0;
  shown = suffix == "raw";
  uint32_t id = 0;
  for (uint8_t index = 0; index < 8; ++index) {
    const char c = name[index];
    const uint8_t digit = c >= '0' && c <= '9'   ? c - '0'
                          : c >= 'a' && c <= 'f' ? c - 'a' + 10
                                                 : 0xFF;
    if (digit == 0xFF) return 0;
    id = id << 4 | digit;
  }
  return id;
}

}  // namespace

void CawPictures::begin(bool filesystemReady) {
  filesystemReady_ = filesystemReady;
  uploadCount_ = 0;
  if (!filesystemReady_) return;
  if (!LittleFS.exists(kDirectory)) LittleFS.mkdir(kDirectory);
  LittleFS.remove(kIncomingPath);  // an upload cut off by a restart
  Dir dir = LittleFS.openDir(kDirectory);
  while (dir.next()) {
    bool shown = false;
    const uint32_t id = parseName(dir.fileName(), shown);
    const size_t size = dir.fileSize();
    const bool animated = size != kCawPictureFileBytes && cawFramesForSize(size) != 0;
    if (!id || (size != kCawPictureFileBytes && !animated)) continue;
    if (uploadCount_ >= kMaxUploads) break;
    insert(id, shown, animated);
    if (id >= nextId_) nextId_ = id + 1;
  }
}

uint8_t CawPictures::builtinCount() const { return kCawMemeCount; }

void CawPictures::setBit(uint8_t *bits, uint16_t index, bool value) {
  if (value) bits[index / 8] |= 1U << (index % 8);
  else bits[index / 8] &= ~(1U << (index % 8));
}

bool CawPictures::builtinAnimated(uint8_t index) const {
  return index < kCawMemeCount && cawIsPaletteAnimation(kCawMemes[index].data);
}

uint16_t CawPictures::animatedCount() const {
  uint16_t count = 0;
  for (uint16_t index = 0; index < uploadCount_; ++index) count += uploadAnimated(index);
  return count;
}

// Keeps ids_ ascending (directory order is not guaranteed).
void CawPictures::insert(uint32_t id, bool shown, bool animated) {
  uint16_t at = uploadCount_;
  while (at > 0 && ids_[at - 1] > id) --at;
  for (uint16_t index = uploadCount_; index > at; --index) {
    ids_[index] = ids_[index - 1];
    setShownBit(index, uploadShown(index - 1));
    setBit(animated_, index, uploadAnimated(index - 1));
  }
  ids_[at] = id;
  setShownBit(at, shown);
  setBit(animated_, at, animated);
  ++uploadCount_;
}

void CawPictures::erase(uint16_t at) {
  for (uint16_t index = at; index + 1 < uploadCount_; ++index) {
    ids_[index] = ids_[index + 1];
    setShownBit(index, uploadShown(index + 1));
    setBit(animated_, index, uploadAnimated(index + 1));
  }
  --uploadCount_;
}

int16_t CawPictures::uploadIndex(uint32_t id) const {
  for (uint16_t index = 0; index < uploadCount_; ++index)
    if (ids_[index] == id) return index;
  return -1;
}

uint16_t CawPictures::shownCount() const {
  uint16_t count = includeCrow_ ? 1 : 0;
  for (uint8_t index = 0; index < kCawMemeCount; ++index) count += builtinShown(index);
  for (uint16_t index = 0; index < uploadCount_; ++index) count += uploadShown(index);
  return count;
}

uint32_t CawPictures::shownKey(uint16_t position) const {
  if (includeCrow_) {
    if (position == 0) return kCrowKey;
    --position;
  }
  for (uint8_t index = 0; index < kCawMemeCount; ++index) {
    if (!builtinShown(index)) continue;
    if (position-- == 0) return kBuiltinKeyBase + index;
  }
  for (uint16_t index = 0; index < uploadCount_; ++index) {
    if (!uploadShown(index)) continue;
    if (position-- == 0) return kUploadKeyBase + ids_[index];
  }
  return kCrowKey;
}

uint32_t CawPictures::next(uint32_t current, bool random) const {
  const uint16_t count = shownCount();
  if (count == 0) return kCrowKey;  // everything hidden: the crow
  if (count == 1) return shownKey(0);
  uint16_t position = count;  // position of `current`, or count if not shown
  for (uint16_t index = 0; index < count; ++index)
    if (shownKey(index) == current) position = index;
  if (random) {
    uint16_t pick = position;
    while (pick == position) pick = ESP.random() % count;
    return shownKey(pick);
  }
  return shownKey(position + 1 >= count ? 0 : position + 1);
}

bool CawPictures::valid(uint32_t key) const {
  if (key == kCrowKey) return true;
  if (key >= kUploadKeyBase) return uploadIndex(key - kUploadKeyBase) >= 0;
  return key >= kBuiltinKeyBase && key - kBuiltinKeyBase < kCawMemeCount;
}

const uint8_t *CawPictures::crow() { return kCawCrowMdi; }

const uint8_t *CawPictures::builtinData(uint32_t key) const {
  if (key == kCrowKey) return kCawCrowMdi;
  if (key >= kBuiltinKeyBase && key < kUploadKeyBase && key - kBuiltinKeyBase < kCawMemeCount)
    return kCawMemes[key - kBuiltinKeyBase].data;
  return nullptr;
}

void CawPictures::uploadPath(uint32_t id, bool shown, char *path, size_t capacity) {
  snprintf(path, capacity, "%s/%08lx.%s", kDirectory, static_cast<unsigned long>(id),
           shown ? "raw" : "off");
}

bool CawPictures::uploadPathFor(uint32_t key, char *path, size_t capacity) const {
  if (key < kUploadKeyBase) return false;
  const int16_t index = uploadIndex(key - kUploadKeyBase);
  if (index < 0) return false;
  uploadPath(ids_[index], uploadShown(index), path, capacity);
  return true;
}

void CawPictures::space(uint32_t &total, uint32_t &used) const {
  FSInfo info{};
  if (!filesystemReady_ || !LittleFS.info(info)) {
    total = used = 0;
    return;
  }
  total = info.totalBytes;
  used = info.usedBytes;
}

uint16_t CawPictures::uploadsLeft() const {
  uint32_t total = 0, used = 0;
  space(total, used);
  if (total <= used + kReserveBytes) return 0;
  const uint32_t byBlocks = (total - used - kReserveBytes) / 8192;
  const uint16_t byCount = kMaxUploads - uploadCount_;
  return byBlocks < byCount ? byBlocks : byCount;
}

// Blocks of 8 KB a file of `bytes` occupies.
static uint32_t blocksFor(size_t bytes) { return (bytes + 8191) / 8192; }

const char *CawPictures::beginUpload(size_t declaredBytes) {
  abortUpload();
  if (!filesystemReady_) return "storage unavailable";
  if (declaredBytes != kCawPictureFileBytes && cawFramesForSize(declaredBytes) == 0)
    return "not a 56 x 56 picture";
  if (uploadCount_ >= kMaxUploads) return "the meme limit is reached; delete some first";
  // Free blocks beyond the reserve (see CawPictures.h) must hold the file.
  uint32_t total = 0, used = 0;
  space(total, used);
  const uint32_t freeBlocks = total > used + kReserveBytes ? (total - used - kReserveBytes) / 8192 : 0;
  if (freeBlocks < blocksFor(declaredBytes))
    return "storage is full; delete some memes first";
  file_ = LittleFS.open(kIncomingPath, "w");
  if (!file_) return "storage unavailable";
  declared_ = declaredBytes;
  received_ = 0;
  return nullptr;
}

bool CawPictures::write(const uint8_t *data, size_t length) {
  if (!file_) return false;
  if (received_ + length > declared_) {  // more than announced: not a picture
    abortUpload();
    return false;
  }
  if (file_.write(data, length) != length) {
    abortUpload();
    return false;
  }
  received_ += length;
  return true;
}

const char *CawPictures::finishUpload(uint32_t &id) {
  if (!file_) return "upload failed";
  file_.close();
  File check = LittleFS.open(kIncomingPath, "r");
  // Large enough for a static header or an animated header plus its delays.
  uint8_t header[kCawAnimHeaderBytes + 2 * kCawMaxFrames]{};
  size_t length = 0;
  size_t size = 0;
  if (check) {
    size = check.size();
    length = check.read(header, size < sizeof(header) ? size : sizeof(header));
    check.close();
  }
  bool animated = false;
  bool ok = false;
  if (size == declared_ && size == kCawPictureFileBytes) {
    ok = length >= kCawPictureHeaderBytes && memcmp(header, kMagic, sizeof(kMagic)) == 0 &&
         (header[4] | header[5] << 8) == kCawPictureSize &&
         (header[6] | header[7] << 8) == kCawPictureSize;
  } else if (size == declared_) {
    CawAnimation animation;
    animated = ok = cawParseAnimation(header, length, size, animation);
  }
  if (!ok) {
    LittleFS.remove(kIncomingPath);
    return "not a 56 x 56 picture";
  }
  char path[24];
  uploadPath(nextId_, true, path, sizeof(path));
  if (!LittleFS.rename(kIncomingPath, path)) {
    LittleFS.remove(kIncomingPath);
    return "storage error";
  }
  id = nextId_++;
  insert(id, true, animated);
  return nullptr;
}

bool CawPictures::readAnimation(uint32_t key, CawAnimation &out) const {
  if (key >= kBuiltinKeyBase && key < kUploadKeyBase) {
    const uint32_t index = key - kBuiltinKeyBase;
    if (index >= kCawMemeCount || !builtinAnimated(index)) return false;
    const uint8_t *data = kCawMemes[index].data;
    const uint16_t frames = cawPaletteFrames(data);
    if (frames < 2 || frames > kCawMaxFrames) return false;
    out = CawAnimation{};
    for (uint16_t frame = 0; frame < frames; ++frame) {
      out.delay[frame] = cawPaletteDelay(data, frame);
      if (out.delay[frame] < kCawMinDelayMs || out.delay[frame] > kCawMaxDelayMs) return false;
    }
    out.frames = frames;
    out.builtin = data;
    return true;
  }
  if (key < kUploadKeyBase) return false;
  const int16_t index = uploadIndex(key - kUploadKeyBase);
  if (index < 0 || !uploadAnimated(index)) return false;
  char path[24];
  uploadPath(ids_[index], uploadShown(index), path, sizeof(path));
  File file = LittleFS.open(path, "r");
  if (!file) return false;
  uint8_t header[kCawAnimHeaderBytes + 2 * kCawMaxFrames]{};
  const size_t size = file.size();
  const size_t length = file.read(header, size < sizeof(header) ? size : sizeof(header));
  file.close();
  out = CawAnimation{};
  return cawParseAnimation(header, length, size, out);
}

void CawPictures::abortUpload() {
  if (file_) file_.close();
  if (filesystemReady_) LittleFS.remove(kIncomingPath);
  received_ = 0;
}

bool CawPictures::setShown(uint32_t key, bool shown) {
  if (key < kUploadKeyBase) return false;
  const int16_t index = uploadIndex(key - kUploadKeyBase);
  if (index < 0) return false;
  if (uploadShown(index) == shown) return true;
  char from[24], to[24];
  uploadPath(ids_[index], !shown, from, sizeof(from));
  uploadPath(ids_[index], shown, to, sizeof(to));
  if (!LittleFS.rename(from, to)) return false;
  setShownBit(index, shown);
  return true;
}

bool CawPictures::remove(uint32_t key) {
  if (key < kUploadKeyBase) return false;  // built-ins can only be hidden
  const int16_t index = uploadIndex(key - kUploadKeyBase);
  if (index < 0) return false;
  char path[24];
  uploadPath(ids_[index], uploadShown(index), path, sizeof(path));
  if (!LittleFS.remove(path)) return false;
  erase(index);
  return true;
}

#endif  // CAW_STANDALONE
