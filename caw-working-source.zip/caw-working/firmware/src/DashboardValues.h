#pragma once

#include <Arduino.h>
#include "FeatureFlags.h"

inline constexpr uint8_t kMaxDashboardValues = 32;
// CAW values are short (the longest, the ticker, is about 26 bytes), so CAW
// builds use the same slot size and keep 1.5 KiB of RAM for the TLS fetch.
inline constexpr size_t kDashboardValueCapacity = 49;

struct DashboardValue {
  char *source = nullptr;
  uint32_t sourceHash = 0;
  uint32_t sourceCheck = 0;
  char state[kDashboardValueCapacity]{};
  bool available = false;
};

class DashboardValues {
 public:
  DashboardValue *find(const char *source, bool create);
  uint8_t indexOf(const DashboardValue *value) const;
  DashboardValue *data() { return values_; }
  const DashboardValue *data() const { return values_; }
  uint8_t size() const { return size_; }

 private:
  DashboardValue values_[kMaxDashboardValues]{};
  uint8_t size_ = 0;
};
