// CawFirmwareCheck.h: each SD PRO board accepts only its own firmware. The
// headers are the first 16 bytes of the real files (CAW 0.7.0-rc1 and its
// installers, the stock SD PRO V1.0.6, the factory SDC2 firmware). Built twice
// by the Makefile: as the ESP8266 clock and with -DCAW_C2=1.
#include "CawFirmwareCheck.h"

#include <cassert>
#include <cstdio>
#include <vector>

namespace {
const uint8_t kCaw8266[16] = {0xe9, 0x02, 0x02, 0x40, 0x80, 0xf4, 0x10, 0x40, 0x00, 0xf0, 0x10, 0x40, 0x60, 0x0d, 0x00, 0x00};
const uint8_t kStock8266[16] = {0xe9, 0x01, 0x02, 0x40, 0x5c, 0xf4, 0x10, 0x40, 0x00, 0xf0, 0x10, 0x40, 0x00, 0x0e, 0x00, 0x00};
const uint8_t kCawC2[16] = {0xe9, 0x05, 0x02, 0x2f, 0xc4, 0x1a, 0x38, 0x40, 0xee, 0x00, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x00};
const uint8_t kFactoryC2[16] = {0xe9, 0x05, 0x02, 0x2f, 0x22, 0x0f, 0x38, 0x40, 0xee, 0x00, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x00};
const uint8_t kEsp32[16] = {0xe9, 0x05, 0x02, 0x2f, 0x00, 0x00, 0x08, 0x40, 0xee, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
const uint8_t kPng[16] = {0x89, 'P', 'N', 'G', 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0x0d, 'I', 'H', 'D', 'R'};

// Feeds a 3000-byte file starting with `header` in pieces of `piece` bytes.
bool upload(const uint8_t *header, size_t piece) {
  std::vector<uint8_t> file(3000, 0xAA);
  for (int i = 0; i < 16; ++i) file[i] = header[i];
  CawFirmwareHead head;
  for (size_t at = 0; at < file.size(); at += piece)
    if (!head.feed(file.data() + at, std::min(piece, file.size() - at))) return false;
  return head.accepted();
}
}  // namespace

int main() {
  assert(cawFirmwareKind(kCaw8266, 16) == CawFirmwareKind::Esp8266);
  assert(cawFirmwareKind(kStock8266, 16) == CawFirmwareKind::Esp8266);
  assert(cawFirmwareKind(kCawC2, 16) == CawFirmwareKind::Esp32C2);
  assert(cawFirmwareKind(kFactoryC2, 16) == CawFirmwareKind::Esp32C2);
  assert(cawFirmwareKind(kEsp32, 16) == CawFirmwareKind::OtherEsp32);
  assert(cawFirmwareKind(kPng, 16) == CawFirmwareKind::Unknown);
  assert(cawFirmwareKind(kCaw8266, 15) == CawFirmwareKind::Unknown);  // too short to tell
#if CAW_C2
  const bool own = true;
  for (size_t piece : {1, 3, 15, 16, 17, 2048}) {
    assert(upload(kCawC2, piece) && upload(kFactoryC2, piece));
    assert(!upload(kCaw8266, piece) && !upload(kStock8266, piece) && !upload(kEsp32, piece) && !upload(kPng, piece));
  }
#else
  const bool own = false;
  for (size_t piece : {1, 3, 15, 16, 17, 2048}) {
    assert(upload(kCaw8266, piece) && upload(kStock8266, piece));
    assert(!upload(kCawC2, piece) && !upload(kFactoryC2, piece) && !upload(kEsp32, piece) && !upload(kPng, piece));
  }
#endif
  // A file of fewer than 16 bytes is never accepted.
  CawFirmwareHead tiny;
  assert(tiny.feed(kCaw8266, 10) && !tiny.accepted());
  std::printf("caw firmware check (%s): each board takes only its own firmware\n", own ? "ESP32-C2" : "ESP8266");
}
