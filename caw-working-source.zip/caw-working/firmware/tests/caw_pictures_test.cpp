// CawPictures against a host-directory LittleFS: uploads, validation,
// show/hide, delete, reload after a restart, limits and rotation.
#include "CawStandalone/CawPictures.h"

#include <cassert>
#include <cstdio>
#include <set>
#include <vector>

namespace {

std::vector<uint8_t> picture(uint8_t shade) {
  std::vector<uint8_t> data(kCawPictureFileBytes, shade);
  const uint8_t header[8] = {'C', 'W', 'P', '1', 56, 0, 56, 0};
  std::copy(header, header + 8, data.begin());
  return data;
}

uint32_t add(CawPictures &pictures, const std::vector<uint8_t> &data, const char **error = nullptr) {
  const char *reason = pictures.beginUpload();
  if (!reason) {
    // In uneven chunks, like HTTP upload buffers.
    for (size_t offset = 0; offset < data.size() && !reason; offset += 1460) {
      const size_t length = std::min<size_t>(1460, data.size() - offset);
      if (!pictures.write(data.data() + offset, length)) reason = "write";
    }
  }
  uint32_t id = 0;
  if (!reason) reason = pictures.finishUpload(id);
  if (error) *error = reason;
  return reason ? 0 : id;
}

// An animated file: header, `frames` delays (start, start + 10, ...), frames of one shade.
std::vector<uint8_t> animation(uint16_t frames, uint16_t startDelay, uint8_t shade, char magic = 'C') {
  std::vector<uint8_t> data(cawAnimatedFileBytes(frames), shade);
  const uint8_t header[12] = {static_cast<uint8_t>(magic), 'W', 'A', '1', 56, 0, 56, 0,
                              static_cast<uint8_t>(frames & 255), static_cast<uint8_t>(frames >> 8), 0, 0};
  std::copy(header, header + 12, data.begin());
  for (uint16_t index = 0; index < frames; ++index) {
    const uint16_t delay = startDelay + 10 * index;
    data[12 + 2 * index] = delay & 255;
    data[13 + 2 * index] = delay >> 8;
  }
  return data;
}

uint32_t addAnimation(CawPictures &pictures, const std::vector<uint8_t> &data,
                      const char **error = nullptr, size_t announced = 0) {
  const char *reason = pictures.beginUpload(announced ? announced : data.size());
  for (size_t offset = 0; offset < data.size() && !reason; offset += 1460) {
    const size_t length = std::min<size_t>(1460, data.size() - offset);
    if (!pictures.write(data.data() + offset, length)) reason = "write";
  }
  uint32_t id = 0;
  if (!reason) reason = pictures.finishUpload(id);
  if (error) *error = reason;
  return reason ? 0 : id;
}

}  // namespace

int main() {
  const std::string root = fs_fake::temp_directory_path() / "caw-pictures-test";
  fs_fake::remove_all(root);
  fs_fake::create_directories(root);
  LittleFS.root = root;

  CawPictures pictures;
  pictures.begin(true);
  assert(pictures.uploadCount() == 0 && fs_fake::exists(root + "/m"));

  // Uploads get increasing ids and are shown.
  const uint32_t a = add(pictures, picture(1));
  const uint32_t b = add(pictures, picture(2));
  assert(a == 1 && b == 2 && pictures.uploadCount() == 2);
  assert(pictures.uploadShown(0) && pictures.uploadShown(1));
  assert(fs_fake::file_size(root + "/m/00000001.raw") == kCawPictureFileBytes);
  assert(!fs_fake::exists(root + "/m/incoming.tmp"));

  // Bad uploads are refused and leave nothing behind.
  const char *error = nullptr;
  std::vector<uint8_t> wrongMagic = picture(3);
  wrongMagic[0] = 'X';
  assert(!add(pictures, wrongMagic, &error) && error);
  std::vector<uint8_t> wrongSize = picture(3);
  wrongSize[4] = 48;
  assert(!add(pictures, wrongSize, &error) && error);
  assert(!add(pictures, std::vector<uint8_t>(100, 0), &error) && error);           // short
  assert(!add(pictures, std::vector<uint8_t>(kCawPictureFileBytes + 1, 0), &error));  // long
  assert(pictures.uploadCount() == 2 && !fs_fake::exists(root + "/m/incoming.tmp"));

  // Hide / show renames the file; delete removes it. Built-ins can't be deleted.
  const uint32_t keyA = CawPictures::kUploadKeyBase + a;
  assert(pictures.setShown(keyA, false) && !pictures.uploadShown(0));
  assert(fs_fake::exists(root + "/m/00000001.off"));
  char path[24];
  assert(pictures.uploadPathFor(keyA, path, sizeof(path)) && std::string(path) == "/m/00000001.off");
  assert(pictures.setShown(keyA, true) && fs_fake::exists(root + "/m/00000001.raw"));
  assert(!pictures.remove(CawPictures::kCrowKey));
  assert(!pictures.remove(CawPictures::kBuiltinKeyBase));
  assert(pictures.remove(CawPictures::kUploadKeyBase + b) && pictures.uploadCount() == 1);
  assert(!fs_fake::exists(root + "/m/00000002.raw"));

  // A restart reloads the list; a stray temp file and foreign files are ignored,
  // and new ids continue after the highest one still on disk (upload 2 was
  // deleted, so the next id is 2 again; ids only need to be unique).
  { std::ofstream(root + "/m/incoming.tmp") << "partial"; }
  { std::ofstream(root + "/m/readme.txt") << "x"; }
  pictures.setShown(keyA, false);
  CawPictures reloaded;
  reloaded.begin(true);
  assert(reloaded.uploadCount() == 1 && !reloaded.uploadShown(0) && reloaded.uploadId(0) == 1);
  assert(!fs_fake::exists(root + "/m/incoming.tmp"));
  assert(add(reloaded, picture(4)) == 2);

  // Built-in pictures (however many this build has) decode to a full 56 x 56
  // image each, and the crow too.
  const uint32_t builtins = reloaded.builtinCount();
  {
    std::vector<uint32_t> keys = {CawPictures::kCrowKey};
    for (uint32_t index = 0; index < builtins; ++index) keys.push_back(CawPictures::kBuiltinKeyBase + index);
    for (uint32_t key : keys) {
      const uint8_t *mdi = reloaded.builtinData(key);
      assert(mdi && reloaded.valid(key));
      if (cawIsPaletteAnimation(mdi)) continue;  // checked with the animations below
      uint16_t rows = 0, widest = 0;
      assert(forEachMdiRow(mdi, [&](uint16_t line, uint16_t *, uint16_t width) {
        assert(line == rows);
        ++rows;
        widest = width;
      }));
      assert(rows == kCawPictureSize && widest == kCawPictureSize);
    }
    assert(!reloaded.valid(CawPictures::kBuiltinKeyBase + builtins));
    assert(reloaded.builtinData(CawPictures::kBuiltinKeyBase + builtins) == nullptr);
  }

  // Rotation with the built-ins hidden: crow + uploads, hidden uploads skipped.
  const uint32_t allOff = builtins >= 32 ? 0xFFFFFFFFu : (1u << builtins) - 1;
  reloaded.configure(true, allOff);
  assert(reloaded.shownCount() == 2);  // crow + upload 2 (upload 1 hidden)
  assert(reloaded.shownKey(0) == CawPictures::kCrowKey);
  assert(reloaded.shownKey(1) == CawPictures::kUploadKeyBase + 2);
  assert(reloaded.next(CawPictures::kCrowKey, false) == CawPictures::kUploadKeyBase + 2);
  assert(reloaded.next(CawPictures::kUploadKeyBase + 2, false) == CawPictures::kCrowKey);
  for (int i = 0; i < 50; ++i) {  // random never repeats with two choices
    assert(reloaded.next(CawPictures::kCrowKey, true) == CawPictures::kUploadKeyBase + 2);
  }
  reloaded.configure(false, allOff);  // crow excluded too
  assert(reloaded.shownCount() == 1 && reloaded.next(0, true) == CawPictures::kUploadKeyBase + 2);
  reloaded.setShown(CawPictures::kUploadKeyBase + 2, false);
  assert(reloaded.shownCount() == 0 && reloaded.next(0, true) == CawPictures::kCrowKey);
  reloaded.setShown(CawPictures::kUploadKeyBase + 2, true);

  // Built-ins visible: crow, then built-ins in order, then uploads; hiding
  // one removes only it; random order eventually shows every picture.
  reloaded.configure(true, 0);
  assert(reloaded.shownCount() == 2 + builtins);
  if (builtins >= 2) {
    assert(reloaded.shownKey(1) == CawPictures::kBuiltinKeyBase);
    assert(reloaded.next(CawPictures::kCrowKey, false) == CawPictures::kBuiltinKeyBase);
    assert(reloaded.next(CawPictures::kBuiltinKeyBase + builtins - 1, false) ==
           CawPictures::kUploadKeyBase + 2);
    reloaded.configure(true, 1u);  // hide built-in 0
    assert(reloaded.shownCount() == 1 + builtins);
    assert(reloaded.shownKey(1) == CawPictures::kBuiltinKeyBase + 1);
    reloaded.configure(true, 0);
    std::set<uint32_t> seen;
    uint32_t current = CawPictures::kCrowKey;
    for (int i = 0; i < 2000; ++i) {
      const uint32_t next = reloaded.next(current, true);
      assert(next != current);
      seen.insert(next);
      current = next;
    }
    assert(seen.size() == static_cast<size_t>(reloaded.shownCount()));  // every picture appears
  }

  // Space: refused while fewer than 16 free blocks would remain.
  LittleFS.totalBytes = (8 + 2 + 16) * 8192;  // system + 2 uploads + reserve
  assert(reloaded.uploadsLeft() == 0);
  assert(!add(reloaded, picture(5), &error) && error && error[0] == 's');
  LittleFS.totalBytes = 253 * 8192;
  assert(reloaded.uploadsLeft() > 0);

  // Count limit.
  for (uint16_t n = reloaded.uploadCount(); n < CawPictures::kMaxUploads; ++n)
    assert(add(reloaded, picture(6)));
  assert(reloaded.uploadCount() == CawPictures::kMaxUploads && reloaded.uploadsLeft() == 0);
  assert(!add(reloaded, picture(7), &error) && error);

  // ---- Animated pictures (uploaded GIFs) ----
  fs_fake::remove_all(root);
  fs_fake::create_directories(root);
  LittleFS.totalBytes = 253 * 8192;
  {
    // Sizes: 12 + 6,274 x frames, 2..30 frames; nothing else is animated.
    assert(cawAnimatedFileBytes(2) == 12 + 2 * 6274 && cawAnimatedFileBytes(30) == 12 + 30 * 6274);
    assert(cawFramesForSize(cawAnimatedFileBytes(2)) == 2 && cawFramesForSize(cawAnimatedFileBytes(30)) == 30);
    assert(cawFramesForSize(cawAnimatedFileBytes(17)) == 17);
    assert(cawFramesForSize(kCawPictureFileBytes) == 0 && cawFramesForSize(cawAnimatedFileBytes(2) - 1) == 0);
    assert(cawFramesForSize(cawAnimatedFileBytes(30) + 2) == 0 && cawFramesForSize(cawAnimatedFileBytes(31)) == 0);
    assert(cawFramesForSize(0) == 0 && cawFramesForSize(cawAnimatedFileBytes(5) + 1) == 0);

    CawAnimation parsed;
    std::vector<uint8_t> good = animation(4, 100, 9);
    assert(cawParseAnimation(good.data(), good.size(), good.size(), parsed));
    assert(parsed.frames == 4 && parsed.delay[0] == 100 && parsed.delay[3] == 130 && parsed.dataOffset == 12 + 8);
    auto bad = [&](std::vector<uint8_t> data, size_t fileSize) {
      CawAnimation out;
      return cawParseAnimation(data.data(), data.size(), fileSize, out);
    };
    std::vector<uint8_t> header(good.begin(), good.begin() + 12 + 8);  // header and delays only
    assert(bad(header, good.size()));                                  // the frames aren't needed to parse
    auto mutate = [&](size_t at, uint8_t value) { auto m = header; m[at] = value; return m; };
    assert(!bad(mutate(0, 'X'), good.size()));        // magic
    assert(!bad(mutate(4, 48), good.size()));         // width
    assert(!bad(mutate(7, 1), good.size()));          // height 312
    assert(!bad(mutate(8, 1), good.size()));          // 1 frame
    assert(!bad(mutate(8, 31), good.size()));         // 31 frames
    assert(!bad(mutate(8, 3), good.size()));          // frame count disagrees with the file size
    assert(!bad(mutate(10, 1), good.size()));         // reserved field
    assert(!bad(mutate(12, 10), good.size()));        // delay 10 ms (< 20)
    auto slow = header; slow[12] = 0x89; slow[13] = 0x13;  // 5,001 ms
    assert(!bad(slow, good.size()));
    assert(!bad(header, good.size() + 1));            // the file size must match exactly
    assert(!bad(std::vector<uint8_t>(good.begin(), good.begin() + 11), good.size()));  // short buffer
    assert(!bad(std::vector<uint8_t>(good.begin(), good.begin() + 12 + 6), good.size()));  // delays cut off

    CawPictures pictures;
    pictures.begin(true);
    // Mixed order: static, animated, static; flags follow their pictures.
    const uint32_t s1 = add(pictures, picture(1));
    const uint32_t a1 = addAnimation(pictures, animation(6, 80, 2));
    const uint32_t s2 = add(pictures, picture(3));
    assert(s1 && a1 && s2 && pictures.uploadCount() == 3 && pictures.animatedCount() == 1);
    assert(!pictures.uploadAnimated(0) && pictures.uploadAnimated(1) && !pictures.uploadAnimated(2));
    assert(fs_fake::file_size(root + "/m/00000002.raw") == cawAnimatedFileBytes(6));

    CawAnimation read;
    assert(pictures.readAnimation(CawPictures::kUploadKeyBase + a1, read));
    assert(read.frames == 6 && read.delay[5] == 80 + 5 * 10 && read.dataOffset == 12 + 12);
    assert(!pictures.readAnimation(CawPictures::kUploadKeyBase + s1, read));  // static: no animation
    assert(!pictures.readAnimation(CawPictures::kCrowKey, read) &&
           !pictures.readAnimation(CawPictures::kUploadKeyBase + 99, read));

    // Hide, show: the file is renamed, the animation stays readable.
    const uint32_t key = CawPictures::kUploadKeyBase + a1;
    assert(pictures.setShown(key, false) && fs_fake::exists(root + "/m/00000002.off"));
    assert(pictures.uploadAnimated(1) && pictures.readAnimation(key, read) && read.frames == 6);
    assert(pictures.setShown(key, true));

    // Deleting an earlier picture shifts the flags correctly.
    assert(pictures.remove(CawPictures::kUploadKeyBase + s1));
    assert(pictures.uploadCount() == 2 && pictures.uploadAnimated(0) && !pictures.uploadAnimated(1));
    assert(pictures.uploadId(0) == a1 && pictures.uploadId(1) == s2);

    // A restart finds animated files by size.
    CawPictures reloaded;
    reloaded.begin(true);
    assert(reloaded.uploadCount() == 2 && reloaded.animatedCount() == 1 && reloaded.uploadAnimated(0));
    assert(reloaded.readAnimation(CawPictures::kUploadKeyBase + a1, read) && read.frames == 6);
    // A file of a wrong size in /m is ignored, whatever its name.
    { std::ofstream(root + "/m/00000009.raw", std::ios::binary) << std::string(10000, 'x'); }
    CawPictures ignoring;
    ignoring.begin(true);
    assert(ignoring.uploadCount() == 2);
    fs_fake::remove(root + "/m/00000009.raw");

    // Refused uploads, each leaving nothing behind.
    const char *error = nullptr;
    assert(pictures.beginUpload(6281) && pictures.beginUpload(12000) && pictures.beginUpload(1));  // sizes that are no picture
    assert(pictures.beginUpload(cawAnimatedFileBytes(31)) && pictures.beginUpload(0));
    assert(!addAnimation(pictures, animation(1 + 1, 100, 1, 'X'), &error) && error);   // wrong magic
    auto wrongSize = animation(5, 100, 1);
    wrongSize.resize(wrongSize.size() - 100);                                          // cut short
    assert(!addAnimation(pictures, wrongSize, &error, cawAnimatedFileBytes(5)) && error);
    auto longer = animation(5, 100, 1);
    longer.push_back(0);                                                               // longer than announced
    assert(!addAnimation(pictures, longer, &error, cawAnimatedFileBytes(5)) && error);
    auto lying = animation(5, 100, 1);                                                 // announces 7 frames, header says 5
    lying.resize(cawAnimatedFileBytes(7), 0);
    assert(!addAnimation(pictures, lying, &error, cawAnimatedFileBytes(7)) && error);
    assert(pictures.uploadCount() == 2 && !fs_fake::exists(root + "/m/incoming.tmp"));

    // Space: an animation needs its blocks beyond the 16-block reserve.
    const size_t blocks20 = (cawAnimatedFileBytes(20) + 8191) / 8192;  // 16
    assert(blocks20 == 16);
    uint32_t total = 0, used = 0;
    pictures.space(total, used);
    LittleFS.totalBytes = used + (16 + 15) * 8192;    // the reserve plus one block too few
    assert(!addAnimation(pictures, animation(20, 100, 1), &error) && error && error[0] == 's');
    assert(add(pictures, picture(4)));                // a static picture still fits
    pictures.space(total, used);
    LittleFS.totalBytes = used + (16 + 16) * 8192;    // the reserve plus exactly the 16 blocks it needs
    const uint32_t big = addAnimation(pictures, animation(20, 100, 1));
    assert(big && pictures.animatedCount() == 2);
    assert(pictures.remove(CawPictures::kUploadKeyBase + big) && pictures.animatedCount() == 1);
    assert(pictures.remove(key) && pictures.animatedCount() == 0 && pictures.uploadCount() == 2);
  }

  {  // built-in animations (palette data in the firmware)
    CawPictures pictures;
    pictures.begin(true);
    unsigned animated = 0;
    for (uint8_t index = 0; index < pictures.builtinCount(); ++index) {
      const uint32_t key = CawPictures::kBuiltinKeyBase + index;
      CawAnimation animation;
      assert(pictures.builtinAnimated(index) == pictures.readAnimation(key, animation));
      if (!pictures.builtinAnimated(index)) continue;
      ++animated;
      assert(animation.builtin && animation.frames >= 2 && animation.frames <= kCawMaxFrames);
      assert(cawIsPaletteAnimation(pictures.builtinData(key)));
      unsigned rows = 0;  // every frame decodes to 56 rows of 56 pixels
      for (uint16_t frame = 0; frame < animation.frames; ++frame)
        forEachPaletteRow(animation.builtin, frame, [&](uint16_t, uint16_t *, uint16_t width) {
          assert(width == kCawPictureSize);
          ++rows;
        });
      assert(rows == animation.frames * kCawPictureSize);
    }
    assert(animated >= 2);
    CawAnimation none;
    assert(!pictures.readAnimation(CawPictures::kCrowKey, none));
  }

  fs_fake::remove_all(root);
  puts("caw pictures: uploads, animations, validation, show/hide, delete, reload, limits, rotation");
  return 0;
}
