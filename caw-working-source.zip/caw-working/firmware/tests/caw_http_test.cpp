#include "CawHttp.h"

#include <cassert>
#include <cstdio>
#include <string>

namespace {

struct Stream {
  std::string data;
  size_t position = 0;
  int operator()() {
    return position < data.size() ? static_cast<unsigned char>(data[position++]) : -1;
  }
};

int status(const std::string &text, size_t *consumed = nullptr) {
  Stream stream{text};
  const int result = readHttpStatus([&] { return stream(); });
  if (consumed) *consumed = stream.position;
  return result;
}

}  // namespace

int main() {
  size_t used = 0;
  assert(status("HTTP/1.1 200 OK\r\nServer: x\r\n", &used) == 200 && used == 17);
  assert(status("HTTP/1.0 404 Not Found\r\n") == 404);
  assert(status("HTTP/1.1 429\r\n") == 429);
  assert(status("HTTP/2 200\r\n") == 0);         // not HTTP/1.x
  assert(status("HTTP/1.1 2x0 OK\r\n") == 0);    // not a number
  assert(status("HTTP/1.1200 OK\r\n") == 0);     // missing space
  assert(status("") == 0 && status("HTTP/1.1 20") == 0);  // truncated
  assert(status("garbage\r\n") == 0);

  // Headers, CRLF and bare LF, then the body starts.
  Stream stream{"Date: now\r\nReport-To: " + std::string(600, 'x') + "\r\n\r\n{\"a\":1}"};
  assert(skipHttpHeaders([&] { return stream(); }));
  assert(stream.data.substr(stream.position) == "{\"a\":1}");
  Stream bare{"A: b\nC: d\n\nBODY"};
  assert(skipHttpHeaders([&] { return bare(); }) && bare.data.substr(bare.position) == "BODY");
  Stream none{"\r\nBODY"};
  assert(skipHttpHeaders([&] { return none(); }) && none.data.substr(none.position) == "BODY");

  // Ends before the blank line, or never ends.
  Stream truncated{"A: b\r\nC: d\r\n"};
  assert(!skipHttpHeaders([&] { return truncated(); }));
  Stream endless{std::string(kCawHttpMaxHeaderBytes + 100, 'x')};
  assert(!skipHttpHeaders([&] { return endless(); }));

  puts("caw http: status line and headers parsed without allocation");
  return 0;
}
