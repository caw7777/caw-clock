#include "CawSchedule.h"

#include <cassert>
#include <cstdio>

int main() {
  // 22:00 - 07:00 spans midnight.
  const uint16_t start = 22 * 60, end = 7 * 60;
  assert(nightWindowContains(start, end, 23 * 60));
  assert(nightWindowContains(start, end, 0));
  assert(nightWindowContains(start, end, 3 * 60));
  assert(nightWindowContains(start, end, start));        // starts on the minute
  assert(!nightWindowContains(start, end, end));         // ends on the minute
  assert(!nightWindowContains(start, end, 12 * 60));
  assert(!nightWindowContains(start, end, 21 * 60 + 59));
  // Same-day window.
  assert(nightWindowContains(13 * 60, 15 * 60, 14 * 60));
  assert(!nightWindowContains(13 * 60, 15 * 60, 15 * 60));
  assert(!nightWindowContains(13 * 60, 15 * 60, 12 * 60 + 59));
  // Empty window never matches.
  assert(!nightWindowContains(600, 600, 600));

  // 1, 2, 4, 8 minutes, then capped at 15.
  const uint32_t minute = 60000, cap = 15 * minute;
  assert(retryDelayMs(0, minute, cap) == minute);
  assert(retryDelayMs(1, minute, cap) == 2 * minute);
  assert(retryDelayMs(3, minute, cap) == 8 * minute);
  assert(retryDelayMs(4, minute, cap) == cap);
  assert(retryDelayMs(255, minute, cap) == cap);  // no overflow

  // Source order: list order, then the working later source first, with the
  // first source retried every sixth fetch; bad input falls back to list order.
  uint8_t order[3];
  assert(sourceOrder(0, 5, 3, order) == 3 && order[0] == 0 && order[1] == 1 && order[2] == 2);
  assert(sourceOrder(2, 1, 3, order) == 3 && order[0] == 2 && order[1] == 0 && order[2] == 1);
  assert(sourceOrder(2, 5, 3, order) == 3 && order[0] == 2 && order[1] == 0 && order[2] == 1);
  assert(sourceOrder(2, 6, 3, order) == 3 && order[0] == 0 && order[1] == 1 && order[2] == 2);
  assert(sourceOrder(2, 0, 3, order) == 3 && order[0] == 0);   // first fetch: list order
  assert(sourceOrder(2, 12, 3, order) == 3 && order[0] == 0);
  assert(sourceOrder(1, 3, 3, order) == 3 && order[0] == 1 && order[1] == 0 && order[2] == 2);
  assert(sourceOrder(7, 3, 3, order) == 3 && order[0] == 0 && order[1] == 1);  // out of range

  // However long the clock runs (here ~3.5 days of 5-minute fetches), a chain
  // that moved to a later source still tries the first one every sixth fetch.
  uint8_t fetches = 0;
  unsigned firstTries = 0, gap = 0, longestGap = 0;
  for (unsigned success = 0; success < 1000; ++success) {
    sourceOrder(2, fetches, 3, order);
    if (order[0] == 0) {
      ++firstTries;
      gap = 0;
    } else if (++gap > longestGap) {
      longestGap = gap;
    }
    fetches = nextFetchCount(fetches);
  }
  assert(longestGap == kCawFirstSourceEvery - 1);
  assert(firstTries == (1000 + kCawFirstSourceEvery - 1) / kCawFirstSourceEvery);

  // Deadlines: due on time, and still due however long overdue (a chain that
  // was hidden for weeks), where a signed difference turns negative after
  // 2^31 ms (~24.9 days).
  const uint32_t ahead = 3600000;  // never set more than an hour ahead
  const uint32_t deadline = 0xFFFFF000U;  // just before millis() wraps
  assert(!deadlinePassed(deadline, deadline - 1, ahead));
  assert(!deadlinePassed(deadline, deadline - ahead, ahead));
  assert(deadlinePassed(deadline, deadline, ahead));
  assert(deadlinePassed(deadline, deadline + 1, ahead));  // across the wrap
  const uint32_t overdue[] = {60000U, 0x80000000U, 0x80000001U, 0xC0000000U,
                              0xFFFFFFFFU - ahead};
  for (const uint32_t late : overdue) assert(deadlinePassed(deadline, deadline + late, ahead));
  // The signed difference used before reads "not yet" from 2^31 ms overdue.
  assert(static_cast<int32_t>((deadline + 0x80000001U) - deadline) < 0);

  puts("caw schedule: night window and retry back-off");
  return 0;
}
