#include "CawSchedule.h"

#include <cassert>
#include <cstdio>

int main() {
  // 22:00 - 07:00 spans midnight.
  const uint16_t start = 22 * 60, end = 7 * 60;
  assert(nightWindowContains(start, end, 23 * 60));
  assert(nightWindowContains(start, end, 0));
  assert(nightWindowContains(start, end, 3 * 60));
  assert(nightWindowContains(start, end, start));        // starts on the minute
  assert(!nightWindowContains(start, end, end));         // ends on the minute
  assert(!nightWindowContains(start, end, 12 * 60));
  assert(!nightWindowContains(start, end, 21 * 60 + 59));
  // Same-day window.
  assert(nightWindowContains(13 * 60, 15 * 60, 14 * 60));
  assert(!nightWindowContains(13 * 60, 15 * 60, 15 * 60));
  assert(!nightWindowContains(13 * 60, 15 * 60, 12 * 60 + 59));
  // Empty window never matches.
  assert(!nightWindowContains(600, 600, 600));

  // 1, 2, 4, 8 minutes, then capped at 15.
  const uint32_t minute = 60000, cap = 15 * minute;
  assert(retryDelayMs(0, minute, cap) == minute);
  assert(retryDelayMs(1, minute, cap) == 2 * minute);
  assert(retryDelayMs(3, minute, cap) == 8 * minute);
  assert(retryDelayMs(4, minute, cap) == cap);
  assert(retryDelayMs(255, minute, cap) == cap);  // no overflow

  // Source order: list order, then the working later source first, with the
  // first source retried every sixth fetch; bad input falls back to list order.
  uint8_t order[3];
  assert(sourceOrder(0, 5, 3, order) == 3 && order[0] == 0 && order[1] == 1 && order[2] == 2);
  assert(sourceOrder(2, 1, 3, order) == 3 && order[0] == 2 && order[1] == 0 && order[2] == 1);
  assert(sourceOrder(2, 5, 3, order) == 3 && order[0] == 2 && order[1] == 0 && order[2] == 1);
  assert(sourceOrder(2, 6, 3, order) == 3 && order[0] == 0 && order[1] == 1 && order[2] == 2);
  assert(sourceOrder(2, 0, 3, order) == 3 && order[0] == 0);   // first fetch: list order
  assert(sourceOrder(2, 12, 3, order) == 3 && order[0] == 0);
  assert(sourceOrder(1, 3, 3, order) == 3 && order[0] == 1 && order[1] == 0 && order[2] == 2);
  assert(sourceOrder(7, 3, 3, order) == 3 && order[0] == 0 && order[1] == 1);  // out of range

  puts("caw schedule: night window and retry back-off");
  return 0;
}
