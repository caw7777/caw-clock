#include "CawAlert.h"

#include <cassert>
#include <cmath>
#include <cstdio>

int main() {
  // The feeds' 1-hour change text.
  assert(std::fabs(cawParsePercent("+12.3%") - 12.3F) < 1e-4F);
  assert(std::fabs(cawParsePercent("-0.4%") + 0.4F) < 1e-4F);
  assert(cawParsePercent("15%") == 15.0F);
  assert(std::isnan(cawParsePercent("12.3x")));
  assert(std::isnan(cawParsePercent("+%")));
  assert(cawParsePercent("0.0%") == 0.0F);
  assert(std::isnan(cawParsePercent("--")));
  assert(std::isnan(cawParsePercent("")));
  assert(std::isnan(cawParsePercent(nullptr)));
  assert(std::isnan(cawParsePercent("N/A")));

  const uint32_t minute = 60000, duration = 5 * minute;
  CawMoveAlert alert;

  // Below the threshold: nothing.
  assert(!cawMoveAlertUpdate(alert, 9.9F, 10.0F, 0, duration));
  assert(!cawMoveAlertActive(alert, 0));
  // Passing it alerts once, upwards, for the duration.
  assert(cawMoveAlertUpdate(alert, 10.0F, 10.0F, 1000, duration));
  assert(alert.up);
  assert(cawMoveAlertActive(alert, 1000 + duration - 1));
  assert(!cawMoveAlertActive(alert, 1000 + duration));
  // Staying high or hovering around the threshold: no repeat.
  assert(!cawMoveAlertUpdate(alert, 14.0F, 10.0F, 2000, duration));
  assert(!cawMoveAlertUpdate(alert, 9.0F, 10.0F, 3000, duration));
  assert(!cawMoveAlertUpdate(alert, 10.5F, 10.0F, 4000, duration));
  // Settling below 70% of the threshold re-arms it; a drop then alerts down.
  assert(!cawMoveAlertUpdate(alert, 6.9F, 10.0F, 5000, duration));
  assert(alert.armed);
  assert(cawMoveAlertUpdate(alert, -11.0F, 10.0F, 6000, duration));
  assert(!alert.up);

  // Unknown change and alerts off change nothing.
  CawMoveAlert off;
  assert(!cawMoveAlertUpdate(off, NAN, 10.0F, 0, duration));
  assert(!cawMoveAlertUpdate(off, 50.0F, 0.0F, 0, duration));
  assert(off.armed && off.until == 0);

  // millis() wrap: active across the overflow, then over.
  CawMoveAlert wrap;
  assert(cawMoveAlertUpdate(wrap, 20.0F, 10.0F, 0xFFFFFFFFU - 1000U, duration));
  assert(cawMoveAlertActive(wrap, 0xFFFFFFFFU));
  assert(cawMoveAlertActive(wrap, 1000));
  assert(!cawMoveAlertActive(wrap, duration));

  // Long after it ended. A signed difference reads as "running" again 2^31 ms
  // (~24.9 days) after the end, which is why a finished alert is cleared.
  CawMoveAlert old;
  assert(cawMoveAlertUpdate(old, 20.0F, 10.0F, 1000, duration));
  const uint32_t end = 1000 + duration;
  assert(cawMoveAlertActive(old, end + 0x80000001U));  // what clearing prevents
  cawMoveAlertExpire(old, end - 1);  // still flashing: kept
  assert(old.until == end && cawMoveAlertActive(old, end - 1));
  cawMoveAlertExpire(old, end);  // over: cleared
  assert(old.until == 0);
  const uint32_t later[] = {end + 0x80000001U, end + 0xC0000000U, end + 0xFFFFFFFFU};
  for (const uint32_t now : later) assert(!cawMoveAlertActive(old, now));
  // An alert that never ran is left alone.
  CawMoveAlert idle;
  cawMoveAlertExpire(idle, 12345);
  assert(idle.until == 0 && idle.armed);

  std::puts("caw alert: percent parsing, threshold, once per move, re-arm, wrap");
  return 0;
}
