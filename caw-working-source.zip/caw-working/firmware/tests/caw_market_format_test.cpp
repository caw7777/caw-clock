// Shared CAW market formatting (CawMarketFormat.h), host build.
#include <cassert>
#include <cstdio>
#include <cstring>

#include "CawMarketFormat.h"

namespace {

void expectChange(const char *json, const char *expected) {
  StaticJsonDocument<64> document;
  assert(!deserializeJson(document, json));
  char out[16]{};
  assert(format24hChange(document["v"], out, sizeof(out)));
  if (std::strcmp(out, expected) != 0) {
    std::fprintf(stderr, "change %s -> %s, expected %s\n", json, out, expected);
    assert(false);
  }
}

void expectUsd(const char *json, const char *expected) {
  StaticJsonDocument<64> document;
  assert(!deserializeJson(document, json));
  char out[24]{};
  assert(compactUsd(document["v"], out, sizeof(out)));
  if (std::strcmp(out, expected) != 0) {
    std::fprintf(stderr, "usd %s -> %s, expected %s\n", json, out, expected);
    assert(false);
  }
}

void expectPrice(const char *input, const char *expected) {
  char out[48]{};
  assert(copyPrice(input, out, sizeof(out)));
  if (std::strcmp(out, expected) != 0) {
    std::fprintf(stderr, "price %s -> %s, expected %s\n", input, out, expected);
    assert(false);
  }
}

}  // namespace

int main() {
  // DexScreener numbers and GeckoTerminal strings; no float printf.
  expectChange("{\"v\":0.94}", "+0.9%");
  expectChange("{\"v\":-2.36}", "-2.4%");
  expectChange("{\"v\":0}", "+0.0%");
  expectChange("{\"v\":\"12.4\"}", "+12.4%");
  expectChange("{\"v\":\"-0.05\"}", "-0.1%");
  expectChange("{\"v\":null}", "+0.0%");  // absent: no trades, no change
  expectChange("{}", "+0.0%");
  {
    char out[16]{};
    assert(formatChangePercent(0.04, out, sizeof(out)) && std::strcmp(out, "+0.0%") == 0);
    assert(formatChangePercent(-5.06, out, sizeof(out)) && std::strcmp(out, "-5.1%") == 0);
    assert(!formatChangePercent(1e9, out, sizeof(out)));
  }
  expectUsd("{\"v\":776432.5}", "$776K");
  expectUsd("{\"v\":\"3912345.8\"}", "$3.9M");
  expectUsd("{\"v\":\"4123.4\"}", "$4K");
  expectUsd("{\"v\":12}", "$12");
  expectUsd("{\"v\":null}", "N/A");
  expectPrice("0.000000004785", "$0.000000004785");
  expectPrice("0.0000000047978733422540", "$0.000000004797873342254");
  expectPrice("4.785e-9", "$0.000000004785");
  {
    // GeckoTerminal's Solana pool price has ~70 decimals (live sample).
    char out[48]{};
    assert(copyPrice("0.00000000479328644373549300815474458720417759033948196240234616416799469",
                     out, sizeof(out)));
    assert(std::strncmp(out, "$0.0000000047932864437", 22) == 0);
    std::printf("long price -> %s\n", out);
    // Too many integer digits is still rejected.
    assert(!copyPrice("1234567890123456789012345678901234567890123", out, sizeof(out)));
  }
  puts("caw market format: changes, USD and prices formatted without float printf");
  return 0;
}
