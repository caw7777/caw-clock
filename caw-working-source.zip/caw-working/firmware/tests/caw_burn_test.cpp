#include "CawBurn.h"

#include <cassert>
#include <cmath>
#include <cstdio>
#include <string>

namespace {

CawBurnReader read(const std::string &text) {
  CawBurnReader reader;
  for (unsigned char c : text) reader.feed(c);
  return reader;
}

// Real answers (2026-11-19), from cronos-evm-rpc.publicnode.com,
// bsc-rpc.publicnode.com, rpc.mainnet.chain.robinhood.com and
// base-rpc.publicnode.com.
const char kCronosBurn[] =
    R"([{"jsonrpc":"2.0","id":1,"result":"0x65ba2a8"},{"jsonrpc":"2.0","id":2,"result":[{"address":"0x74897ef1b152e5a733d797cab5cee383fe052c56","topics":["0x63c3e78bc4e2d8174461ececdeef203ef623f259bbb24514c3eb5dacc89e0e33","0x0000000000000000000000002f039e3e699355ff4f1a23884807c2fdb9a3547d"],"data":"0x000000000000000000000000000000000000000022cfe0ab0ef89d9d96a15be10000000000000000000000000000000000000000002c8f340e27a4a0c9b6911900000000000000000000000000000000000000000000000000000000000075e8","blockNumber":"0x65b1076","transactionHash":"0x46552298172e32804557712ae90f6b13267d640f8cc07f6d11f9a6c81efff31f","transactionIndex":"0x0","blockHash":"0x6bbe0fa88127a64244862e0896ac219a86934803252057bcc4fd3c78cfbe900c","blockTimestamp":"0x0","logIndex":"0x2","removed":false}]}])";
// A bridge from Solana arriving on Cronos (evm.cronos.org, 2026-11-13).
const char kCronosArrival[] =
    R"([{"id":1,"result":"0x65bb22e","jsonrpc":"2.0"},{"id":2,"result":[{"address":"0x74897ef1b152e5a733d797cab5cee383fe052c56","topics":["0x9e179a6f930feb2737bb5ec3c2c395675aca53d058aa68d4d042aba58184c942","0x00000000000000000000000034327028c727613872cd80122b9a489a4b9c0bfa"],"data":"0x0000000000000000000000000000000000000000bcb11114209dc19c50000000000000000000000000000000000000000000000000f1867c42b91bd91a000000","blockNumber":"0x64bde5d","transactionHash":"0x49fc8e41a4a7c712c10e7163d553b7ca5890d2f9a3fdc5ed748a6661c4e59111","transactionIndex":"0x0","blockHash":"0x4de2466ff6bc776025116540e52bbd0c3866a0fca573be1235c19d46facf3ae3","blockTimestamp":"0x6af72f7d","logIndex":"0x2","removed":false}],"jsonrpc":"2.0"}])";
const char kBscNone[] =
    R"([{"jsonrpc":"2.0","id":1,"result":"0x802977f"},{"jsonrpc":"2.0","id":2,"result":[]}])";
const char kBaseError[] =
    R"([{"id":1,"jsonrpc":"2.0","result":"0x387fe56"},{"jsonrpc":"2.0","error":{"code":-32602,"message":"Archive requests require a personal token. Get one at: https://www.allnodes.com/publicnode"},"id":2}])";
const char kBscRangeError[] =
    R"([{"id":1,"jsonrpc":"2.0","result":"0x802955b"},{"jsonrpc":"2.0","error":{"code":-32701,"message":"exceed maximum block range: 50000"},"id":2}])";

std::string log(const char *block, const char *data, const char *removed = "false") {
  return std::string(R"({"data":")") + data + R"(","blockNumber":")" + block +
         R"(","removed":)" + removed + "}";
}

// The Discord post's burn (BSC block 134255412): 13.42B bridged, 67.11M
// burned, to Solana.
const char kData[] =
    "0x"
    "00000000000000000000000000000000000000002b5f69cd1b43da938537a679"
    "00000000000000000000000000000000000000000037845e772d23a72339e0d5"
    "00000000000000000000000000000000000000000000000000000000000075d8";

}  // namespace

int main() {
  // Request bodies.
  char body[640];
  char big[1024];
  // Cronos, first poll: block number and the three supply figures, no events.
  const size_t first = cawBurnRequest(kCawBurnChains[0], 0, big, sizeof(big));
  assert(first > 0 && std::string(big) ==
         R"([{"jsonrpc":"2.0","id":1,"method":"eth_blockNumber","params":[]},)"
         R"({"jsonrpc":"2.0","id":3,"method":"eth_call","params":[{"to":"0xcCcCcCcCdbEC186DC426F8B5628AF94737dF0E60","data":"0x18160ddd"},"latest"]},)"
         R"({"jsonrpc":"2.0","id":4,"method":"eth_call","params":[{"to":"0xcCcCcCcCdbEC186DC426F8B5628AF94737dF0E60","data":"0x70a08231000000000000000000000000000000000000000000000000000000000000dEaD"},"latest"]},)"
         R"({"jsonrpc":"2.0","id":5,"method":"eth_call","params":[{"to":"0xcCcCcCcCdbEC186DC426F8B5628AF94737dF0E60","data":"0x70a0823100000000000000000000000074897ef1b152E5a733D797CAb5Cee383fe052C56"},"latest"]}])");
  assert(cawBurnRequest(kCawBurnChains[0], 123, big, sizeof(big)) < 1000);
  // Other chains: supply only.
  cawBurnRequest(kCawBurnChains[1], 0, big, sizeof(big));
  assert(std::string(big).find(R"("id":4)") == std::string::npos);
  // Solana: the token supply.
  cawBurnRequest(kCawBurnChains[6], 0, big, sizeof(big));
  assert(std::string(big) == R"({"jsonrpc":"2.0","id":1,"method":"getTokenSupply","params":["CAW777xcHVTQZ4CRwVQGB8CV1BVKPm5bNVxFJHWFKiH8"]})");
  const size_t next = cawBurnRequest(kCawBurnChains[5], 0x7046977, body, sizeof(body));
  assert(next > 0 && next < sizeof(body));
  assert(std::string(body).find(R"("fromBlock":"0x7046977","toBlock":"latest","address":"0x0Ef0330255579725B0a5f7F3890af6c0FC857D2A","topics":[["0x63c3e78bc4e2d8174461ececdeef203ef623f259bbb24514c3eb5dacc89e0e33","0x9e179a6f930feb2737bb5ec3c2c395675aca53d058aa68d4d042aba58184c942"]])") != std::string::npos);
  assert(cawBurnRequest(kCawBurnChains[0], 1, body, 100) == 0);  // too small: refused
  char hex[20];
  assert(cawHex(0, hex, sizeof(hex)) && std::string(hex) == "0x0");
  assert(cawHex(0xFFFFFFFFFFFFFFFFULL, hex, sizeof(hex)) && std::string(hex) == "0xffffffffffffffff");
  assert(!cawHex(0x123, hex, 5));

  // Names, amounts.
  assert(std::string(cawBurnChainName(30168)) == "solana");
  assert(std::string(cawBurnChainName(30184)) == "base");
  assert(std::string(cawBurnChainName(30416)) == "robinhood");
  assert(std::string(cawBurnChainName(1)) == "another chain");
  assert(kCawBurnChains[4].decimals == 0 && std::string(kCawBurnChains[4].name) == "arbitrum");
  char amount[16];
  cawFormatCawAmount(67116015.3, amount, sizeof(amount));
  assert(std::string(amount) == "67.11M");
  cawFormatCawAmount(13423203007.0, amount, sizeof(amount));
  assert(std::string(amount) == "13.42B");
  cawFormatCawAmount(11521000000000.0, amount, sizeof(amount));
  assert(std::string(amount) == "11.52T");
  cawFormatCawAmount(11521302215744.0, amount, sizeof(amount), 3);
  assert(std::string(amount) == "11.521T");
  cawFormatCawAmount(35500000.0, amount, sizeof(amount));
  assert(std::string(amount) == "35.50M");
  cawFormatCawAmount(1000.0, amount, sizeof(amount));
  assert(std::string(amount) == "1.00K");
  cawFormatCawAmount(950.7, amount, sizeof(amount));
  assert(std::string(amount) == "950");
  cawFormatCawAmount(-1, amount, sizeof(amount));
  assert(std::string(amount) == "?");
  cawFormatCawAmount(NAN, amount, sizeof(amount));
  assert(std::string(amount) == "?");

  // The real Cronos burn: 10.77B bridged, 53.86M burned, to Base.
  CawBurnReader cronos = read(kCronosBurn);
  assert(cronos.done() && cronos.haveLatest && cronos.latest == 0x65ba2a8);
  assert(cronos.logsAnswered && !cronos.rpcError && cronos.count == 1 && !cronos.extra);
  assert(cronos.logs[0].block == 0x65b1076 && cronos.logs[0].dstEid == 30184);
  cawFormatCawAmount(cronos.logs[0].total, amount, sizeof(amount));
  assert(std::string(amount) == "10.77B");
  cawFormatCawAmount(cronos.logs[0].burned, amount, sizeof(amount));
  assert(std::string(amount) == "53.86M");
  assert(std::fabs(cronos.logs[0].burned / cronos.logs[0].total - 0.005) < 1e-9);

  assert(!cronos.logs[0].arrived);
  CawBurnReader arrival = read(kCronosArrival);
  assert(arrival.done() && arrival.count == 1 && arrival.logs[0].arrived && arrival.logs[0].dstEid == 0);
  assert(arrival.logs[0].block == 0x64bde5d);
  cawFormatCawAmount(arrival.logs[0].total, amount, sizeof(amount));
  assert(std::string(amount) == "58.39B");
  cawFormatCawAmount(arrival.logs[0].burned, amount, sizeof(amount));
  assert(std::string(amount) == "291.98M");
  // Neither two nor three words: unreadable.
  CawBurnReader odd = read(R"([{"id":2,"result":[)" + log("0x5", "0x0000000000000000000000000000000000000000000000000000000000000001") + "]}]");
  assert(odd.done() && odd.count == 0 && odd.invalid == 1);

  CawBurnReader none = read(kBscNone);
  assert(none.done() && none.haveLatest && none.latest == 0x802977f && none.logsAnswered &&
         none.count == 0 && !none.rpcError);

  // A refused eth_getLogs: the same range is asked again (the caller starts
  // over after a few failures), so no burn in it is skipped.
  for (const char *text : {kBaseError, kBscRangeError}) {
    CawBurnReader refused = read(text);
    assert(refused.done() && refused.haveLatest && refused.rpcError && !refused.logsAnswered);
    assert(cawBurnNextCursor(1000, refused) == 1000);
    assert(cawBurnNextCursor(0, refused) == refused.latest);  // first answer: start from now
  }
  // One error object for the whole batch.
  CawBurnReader single = read(R"({"jsonrpc":"2.0","id":null,"error":{"code":-32600,"message":"batch"}})");
  assert(single.done() && single.rpcError && !single.haveLatest);
  assert(cawBurnNextCursor(5, single) == 5);
  // Only the block number (the first poll).
  CawBurnReader only = read(R"([{"jsonrpc":"2.0","id":1,"result":"0x10"}])");
  assert(only.done() && only.haveLatest && only.latest == 16 && !only.logsAnswered);
  assert(cawBurnNextCursor(0, only) == 16);
  assert(cawBurnSeenAfter(0, 0, only) == 16);  // older burns are not new

  // Several events; one withdrawn by a reorganisation, one unreadable, more
  // than fit.
  std::string many = R"([{"id":1,"result":"0x100"},{"id":2,"result":[)";
  many += log("0x101", kData) + "," + log("0x102", kData, "true") + "," +
          log("0x103", "0x1234") + "," + log("0x104", kData) + "," + log("0x105", kData) + "," +
          log("0x106", kData) + "," + log("0x107", kData) + "]}]";
  CawBurnReader several = read(many);
  assert(several.done() && several.count == 4 && several.extra == 1 && several.invalid == 1);
  assert(several.logs[0].block == 0x101 && several.logs[1].block == 0x104);
  // The burns beyond the first four are added up, not dropped.
  assert(several.extraTotal > 13.4e9 && several.extraBurned > 67e6 && several.extraBurned < 68e6);
  assert(several.maxLogBlock == 0x107);
  // Overlap: the cursor stays kCawBurnOverlapBlocks below the newest block.
  assert(cawBurnNextCursor(0x50, several) == 0x100 - kCawBurnOverlapBlocks);
  assert(cawBurnNextCursor(0xF0, several) == 0xF0);  // never backwards
  assert(cawBurnSeenAfter(0x90, 0x50, several) == 0x107);
  cawFormatCawAmount(several.logs[0].burned, amount, sizeof(amount));
  assert(std::string(amount) == "67.11M");
  assert(several.logs[0].dstEid == 30168);
  // Events in blocks already seen (the overlap) are skipped.
  CawBurnReader again;
  again.newerThan = 0x104;
  for (unsigned char c : many) again.feed(c);
  assert(again.done() && again.count == 3 && again.logs[0].block == 0x105 && !again.extra);
  assert(again.maxLogBlock == 0x107);
  // A lagging server: eth_getLogs stopped at 0x104 while the batch said
  // 0x100 + 64: the next poll still covers 0x105 and later.
  CawBurnReader lag = read(R"([{"id":1,"result":"0x140"},{"id":2,"result":[)" + log("0x104", kData) + "]}]");
  const uint64_t resume = cawBurnNextCursor(0x100, lag);
  assert(resume + 1 <= 0x105 && resume == 0x140 - kCawBurnOverlapBlocks);
  // Key order and spacing vary between servers.
  CawBurnReader spaced = read(
      "[ {\"result\" : \"0x20\" , \"id\" : 1 } ,\n {\"result\":[ " + log("0x21", kData) + " ], \"id\":2} ]");
  assert(spaced.done() && spaced.latest == 0x20 && spaced.count == 1);
  // A uint32 has nothing above its last 8 digits.
  std::string bad = kData;
  bad[2 + 128 + 10] = '1';
  CawBurnReader high = read(R"([{"id":2,"result":[)" + log("0x5", bad.c_str()) + "]}]");
  assert(high.done() && high.count == 0 && high.invalid == 1);

  // Not JSON, cut short, too deep, trailing text: not done.
  for (const char *text : {"", "<html>", "[{\"id\":1,\"result\":\"0x10\"}", "[[[[[[[[[[]]]]]]]]]]",
                           "[{\"id\":1}] x", "\"0x10\"", "[{\"a\":}]", "[1,]x", "{\"a\" 1}"}) {
    assert(!read(text).done());
    assert(cawBurnNextCursor(7, read(text)) == 7);
  }
  CawBurnReader cut;
  for (char c : std::string("[{\"id\":1,\"result\":\"0x10\"}")) cut.feed(c);
  assert(!cut.feed(-1) && !cut.done());
  // A long string or key is cut, not overflowed.
  CawBurnReader longText = read("[{\"" + std::string(500, 'k') + "\":\"" + std::string(5000, 'v') +
                                "\",\"result\":\"0x" + std::string(40, '1') + "\"}]");
  assert(longText.done() && !longText.haveLatest);

  // Supplies and the total, from real answers (2026-11-19): 11.521T, as the
  // Discord bot.
  const char *answers[] = {
      R"([{"jsonrpc":"2.0","id":1,"result":"0x65bb8f9"},{"jsonrpc":"2.0","id":3,"result":"0x0000000000000000000000000000000000002658ef8aa700af9246edd3240000"},{"jsonrpc":"2.0","id":4,"result":"0x000000000000000000000000000000000000008c1e51465846a90f5bd680f72f"},{"jsonrpc":"2.0","id":5,"result":"0x0000000000000000000000000000000000000315fdb6674e88f382c31ec7e8a5"}])",
      R"([{"jsonrpc":"2.0","id":1,"result":"0x1"},{"jsonrpc":"2.0","id":3,"result":"0x000000000000000000000000000000000000002dbfb1f7379627f2a83f9d86be"}])",
      R"([{"jsonrpc":"2.0","id":1,"result":"0x1"},{"jsonrpc":"2.0","id":3,"result":"0x0000000000000000000000000000000000000135c694857111016ee5b5d4e4ec"}])",
      R"([{"jsonrpc":"2.0","id":1,"result":"0x1"},{"jsonrpc":"2.0","id":3,"result":"0x000000000000000000000000000000000000000a0b85078756e0be30c89f9361"}])",
      R"([{"jsonrpc":"2.0","id":1,"result":"0x1f51b4c5"},{"jsonrpc":"2.0","id":3,"result":"0x0000000000000000000000000000000000000000000000000000058a0036173f"}])",
      R"([{"jsonrpc":"2.0","id":1,"result":"0x1"},{"jsonrpc":"2.0","id":3,"result":"0x00000000000000000000000000000000000000700b5bd57b403beb265dd563e4"}])",
      R"({"jsonrpc":"2.0","result":{"context":{"apiVersion":"4.4.0","slot":471105360},"value":{"amount":"1823881050644038","decimals":2,"uiAmount":18238810506440.38,"uiAmountString":"18238810506440.38"}},"id":1})"};
  CawBurnSupply supplies[kCawBurnChainCount];
  for (uint8_t index = 0; index < kCawBurnChainCount; ++index) {
    CawBurnReader reader;
    reader.scale = std::pow(10.0, kCawBurnChains[index].decimals);
    for (unsigned char c : std::string(answers[index])) reader.feed(c);
    assert(cawBurnSupplyFrom(kCawBurnChains[index], reader, 1000, supplies[index]));
  }
  assert(std::fabs(supplies[0].circulating / 1e12 - 704.0869) < 1e-3);
  assert(std::fabs(supplies[0].homeSupply / 1e12 - 777.7778) < 1e-3);
  assert(std::fabs(supplies[4].circulating / 1e12 - 6.0903) < 1e-3);  // 0 decimals
  assert(std::fabs(supplies[6].circulating / 1e12 - 18.2388) < 1e-3);
  assert(supplies[0].known && supplies[6].known);
  double burned = 0;
  assert(cawBurnTotal(supplies, kCawBurnChainCount, 2000, 60000, burned));
  char total[16];
  cawFormatCawAmount(burned, total, sizeof(total), 3);
  assert(std::string(total) == "11.521T");
  // Too old, or one chain missing: no total.
  assert(!cawBurnTotal(supplies, kCawBurnChainCount, 1000 + 60001, 60000, burned));
  CawBurnSupply missing[kCawBurnChainCount];
  for (uint8_t index = 0; index < kCawBurnChainCount; ++index) missing[index] = supplies[index];
  missing[5] = CawBurnSupply{};
  assert(!cawBurnTotal(missing, kCawBurnChainCount, 2000, 60000, burned));
  // A rate-limit answer gives no figures.
  CawBurnReader limited = read(R"({"jsonrpc":"2.0","error":{"code":429,"message":"Too Many Requests"}})");
  CawBurnSupply none2;
  assert(limited.done() && limited.rpcError && !cawBurnSupplyFrom(kCawBurnChains[5], limited, 0, none2));

  // Supply screen texts.
  char thousands[16];
  cawFormatThousands(12667, thousands, sizeof(thousands));
  assert(std::string(thousands) == "12,667");
  cawFormatThousands(29960, thousands, sizeof(thousands));
  assert(std::string(thousands) == "29,960");
  cawFormatThousands(126, thousands, sizeof(thousands));
  assert(std::string(thousands) == "126");
  cawFormatThousands(1234567, thousands, sizeof(thousands));
  assert(std::string(thousands) == "1,234,567");
  cawFormatThousands(0, thousands, sizeof(thousands));
  assert(std::string(thousands) == "0");
  cawFormatThousands(1234567, thousands, 4);  // cut, never overflowed
  assert(strlen(thousands) <= 3);
  char share[12];
  cawFormatShare(0.9186, share, sizeof(share));
  assert(std::string(share) == "91.9%");
  cawFormatShare(0.0010, share, sizeof(share));
  assert(std::string(share) == "0.1%");
  cawFormatShare(1.5, share, sizeof(share));
  assert(std::string(share) == "100.0%");
  cawFormatShare(-1, share, sizeof(share));
  assert(std::string(share) == "0.0%");
  for (const CawHolderSource &source : kCawHolderSources) assert(source.chain < kCawBurnChainCount);

  // Cool-down: the first burn shows at once, later ones wait and add up.
  const uint32_t cooldown = 600000;
  CawBurnGate gate;
  assert(!cawBurnDue(gate, 0, cooldown));
  cawBurnAdd(gate, 67.0e6, 13.4e9, "bsc", "solana");
  assert(cawBurnDue(gate, 1000, cooldown));
  cawBurnShown(gate, 1000);
  assert(!cawBurnDue(gate, 1001, cooldown));
  cawBurnAdd(gate, 1e6, 2e8, "cronos", "base");
  cawBurnAdd(gate, 2e6, 4e8, "cronos", "robinhood");
  assert(!cawBurnDue(gate, 1000 + cooldown - 1, cooldown));
  assert(cawBurnDue(gate, 1000 + cooldown, cooldown));
  assert(gate.count == 2 && gate.burned == 3e6 && gate.bridged == 6e8);
  assert(std::string(gate.from) == "cronos" && std::string(gate.to) == "robinhood");
  cawBurnShown(gate, 1000 + cooldown);
  assert(gate.count == 0 && !gate.pending);
  // Across the millis() wrap.
  CawBurnGate wrap;
  cawBurnAdd(wrap, 1, 2, "a", "b");
  cawBurnShown(wrap, 0xFFFFFFF0u);
  cawBurnAdd(wrap, 1, 2, "a", "b");
  assert(!cawBurnDue(wrap, 100, cooldown));
  assert(cawBurnDue(wrap, 0xFFFFFFF0u + cooldown, cooldown));
  // Long route names are cut to fit.
  CawBurnGate names;
  cawBurnAdd(names, 1, 2, "a-very-long-chain-name", "another-very-long-name");
  CawBurnGate many2;
  cawBurnAdd(many2, 1, 2, "a", "b", 0xFFFF);
  cawBurnAdd(many2, 1, 2, "a", "b", 5);
  assert(many2.count == 0xFFFF);
  assert(strlen(names.from) == sizeof(names.from) - 1 && strlen(names.to) == sizeof(names.to) - 1);

  std::puts("caw burn: request, reader (real answers, errors, damaged input), amounts, cursor, cool-down");
}
