// Built with -DMINI_DISPLAY_FEATURE_CAW=1: the CAW fonts store subscript
// digits and icons in the C1 slots (scripts/caw_font_assets.py).
#include <cassert>

#include "CoverageFont.h"

namespace {

uint32_t first(const char *text) { return nextCoverageCode(text); }

}  // namespace

int main() {
  // U+2080..U+2089 subscript digits -> U+0080..U+0089.
  assert(first("₀") == 0x80);
  assert(first("₈") == 0x88);
  assert(first("₉") == 0x89);
  // Icons: Wi-Fi U+E000, Wi-Fi off U+E001, play U+25B6.
  assert(first("") == 0x8A);
  assert(first("") == 0x8B);
  assert(first("▶") == 0x8C);
  // Neighbouring and ordinary characters are unchanged.
  assert(first("ⁿ") == 0x207F);
  assert(first("₊") == 0x208A);
  assert(first("") == 0xE002);
  assert(first("A") == 'A');
  assert(first("ą") == 0x105);  // Polish a-ogonek
  // The decoder advances past the whole sequence.
  const char *text = "$0.0₈5";
  uint32_t codes[5];
  for (uint32_t &code : codes) code = nextCoverageCode(text);
  assert(codes[3] == '0' && codes[4] == 0x88 && *text == '5');
  return 0;
}
