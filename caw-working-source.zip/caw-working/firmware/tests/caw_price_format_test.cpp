#include <cassert>
#include <cstring>

#include "CawPriceFormat.h"

namespace {

void expect(const char *input, const char *expected) {
  const char *actual = compactDisplayPrice(input);
  if (std::strcmp(actual, expected) != 0) {
    std::fprintf(stderr, "compactDisplayPrice(\"%s\") = \"%s\", expected \"%s\"\n",
                 input, actual, expected);
    assert(false);
  }
}

}  // namespace

int main() {
  // Subscript counts every zero after the decimal point; four digits follow.
  expect("$0.000000005191", "$0.0₈5191");
  expect("0.000000005191", "$0.0₈5191");
  // Digits are truncated, never rounded.
  expect("$0.0000000051919999", "$0.0₈5191");
  expect("$0.00000000519", "$0.0₈5190");  // padded to four digits
  expect("$0.001", "$0.0₂1000");
  // Two-digit zero counts use two subscript digits.
  expect("$0.0000000000001234", "$0.0₁₂1234");
  // Fewer than two leading zeros: four significant digits.
  expect("$0.01234567", "$0.01234");
  expect("$0.5", "$0.5");
  expect("$12.3456", "$12.34");
  expect("$12345.6", "$12345");
  expect("$0", "$0");
  // Placeholders and invalid input.
  expect("N/A", "N/A");
  expect("", "--");
  expect(nullptr, "--");
  expect("$.5", "--");
  expect("$1234567890123.5", "--");
  return 0;
}
