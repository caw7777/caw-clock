// RequestBodyWebServer::refuseRequestsEarly answers before the body is read.
#include <cassert>
#include <cstdio>
#include <cstring>
#include <functional>
#include <string>

#include "RequestBodyWebServer.h"

struct Text : std::string {
  using std::string::string;
  bool startsWith(const char *prefix) const { return find(prefix) == 0; }
};

struct Client {
  std::string written;
  size_t write_P(const char *data, size_t length) {
    written.append(data, length);
    return length;
  }
};

class Server {
 protected:
  struct Argument { std::string key; std::string value; };
  Argument _currentArgs[1];
  int _currentArgCount = 0;
  int _currentArgsHavePlain = 0;

 public:
  static constexpr int CLIENT_REQUEST_CAN_CONTINUE = 0;
  static constexpr int CLIENT_REQUEST_IS_HANDLED = 1;
  std::function<int(const Text &, const Text &, Client *, int)> hook;
  template <typename Hook> void addHook(Hook value) { hook = value; }
  explicit Server(int) {}
};

int main() {
  static const char response[] = "HTTP/1.1 409 Conflict\r\n\r\n{}";
  bool enabled = true;
  RequestBodyWebServer<Server> server(80);
  server.refuseRequestsEarly(
      [&](const Text &method, const Text &url) {
        return enabled && method == "PATCH" && url.startsWith("/api/v1/data");
      },
      response, sizeof(response) - 1);

  Client refused;
  assert(server.hook("PATCH", "/api/v1/data", &refused, 0) ==
         Server::CLIENT_REQUEST_IS_HANDLED);
  assert(refused.written == response);

  Client other;
  assert(server.hook("GET", "/api/v1/status", &other, 0) ==
         Server::CLIENT_REQUEST_CAN_CONTINUE);
  assert(other.written.empty());

  enabled = false;  // e.g. Home Assistant mode
  Client allowed;
  assert(server.hook("PATCH", "/api/v1/data", &allowed, 0) ==
         Server::CLIENT_REQUEST_CAN_CONTINUE);
  assert(allowed.written.empty());
  puts("request refusal: refused before body, others and disabled pass through");
  return 0;
}
