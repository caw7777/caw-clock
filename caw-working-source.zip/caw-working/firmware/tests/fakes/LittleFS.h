#pragma once
// LittleFS backed by a host directory (FakeLittleFS::root), enough for
// CawPictures: open/exists/mkdir/remove/rename/openDir/info.
#include <Arduino.h>

#include <filesystem>
#include <fstream>
#include <memory>

namespace fs_fake = std::filesystem;

struct FSInfo {
  size_t totalBytes = 0;
  size_t usedBytes = 0;
};

class File {
 public:
  File() = default;
  File(const std::string &path, bool write)
      : stream_(std::make_shared<std::fstream>(
            path, write ? std::ios::out | std::ios::binary | std::ios::trunc
                        : std::ios::in | std::ios::binary)),
        path_(path) {
    if (!*stream_) stream_.reset();
  }
  explicit operator bool() const { return stream_ != nullptr; }
  size_t write(const uint8_t *data, size_t length) {
    stream_->write(reinterpret_cast<const char *>(data), length);
    return *stream_ ? length : 0;
  }
  size_t read(uint8_t *data, size_t length) {
    stream_->read(reinterpret_cast<char *>(data), length);
    return stream_->gcount();
  }
  bool seek(uint32_t position) {
    stream_->clear();
    stream_->seekg(position);
    return bool(*stream_);
  }
  size_t size() const { return fs_fake::file_size(path_); }
  void close() { stream_.reset(); }

 private:
  std::shared_ptr<std::fstream> stream_;
  std::string path_;
};

class Dir {
 public:
  explicit Dir(const std::string &path) : it_(path), end_() {}
  bool next() {
    if (started_) ++it_;
    started_ = true;
    if (it_ == end_) return false;
    current_ = *it_;
    return true;
  }
  String fileName() const { return current_.path().filename().string(); }
  size_t fileSize() const { return fs_fake::file_size(current_.path()); }

 private:
  fs_fake::directory_iterator it_, end_;
  fs_fake::directory_entry current_;
  bool started_ = false;
};

class FakeLittleFS {
 public:
  std::string root;
  size_t totalBytes = 253 * 8192;
  std::string at(const char *path) const { return root + path; }
  File open(const char *path, const char *mode) {
    return File(at(path), mode[0] == 'w');
  }
  bool exists(const char *path) const { return fs_fake::exists(at(path)); }
  bool mkdir(const char *path) { return fs_fake::create_directories(at(path)); }
  bool remove(const char *path) { return fs_fake::remove(at(path)); }
  bool rename(const char *from, const char *to) {
    std::error_code error;
    fs_fake::rename(at(from), at(to), error);
    return !error;
  }
  Dir openDir(const char *path) { return Dir(at(path)); }
  // Like LittleFS: every file takes whole 8 KB blocks; 8 blocks of system use.
  bool info(FSInfo &info) const {
    size_t used = 8 * 8192;
    for (const auto &entry : fs_fake::recursive_directory_iterator(root))
      if (entry.is_regular_file()) used += (entry.file_size() + 8191) / 8192 * 8192;
    info.totalBytes = totalBytes;
    info.usedBytes = used;
    return true;
  }
};
inline FakeLittleFS LittleFS;
