#pragma once
// Minimal Arduino surface for native tests of CawPictures (see
// caw_pictures_test.cpp). Not a general Arduino emulation.
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#define PROGMEM
inline uint8_t pgm_read_byte(const uint8_t *address) { return *address; }

class String : public std::string {
 public:
  String() = default;
  String(const char *text) : std::string(text) {}
  String(const std::string &text) : std::string(text) {}
  String substring(size_t from) const { return String(std::string::substr(from)); }
  bool isEmpty() const { return empty(); }
};

struct FakeEsp {
  uint32_t state = 12345;
  uint32_t random() { return state = state * 1103515245u + 12345u; }
};
inline FakeEsp ESP;
