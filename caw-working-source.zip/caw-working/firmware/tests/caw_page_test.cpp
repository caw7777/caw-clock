#include "CawPage.h"

#include <cassert>
#include <cstdio>
#include <string>
#include <vector>

namespace {

// Stand-in for Arduino's String: only what CawPageWriter uses.
struct Text : std::string {
  using std::string::string;
  Text &operator+=(const char *text) { append(text); return *this; }
  Text &operator+=(char c) { push_back(c); return *this; }
  Text &operator+=(unsigned value) { append(std::to_string(value)); return *this; }
  void remove(size_t index) { erase(index); }
};

struct Sink {
  bool begun = false;
  std::string sentWhole;
  std::vector<std::string> chunks;
  void begin() { assert(!begun); begun = true; }
  void chunk(const Text &text) { assert(begun); chunks.push_back(text); }
  void whole(const Text &text) { assert(!begun); sentWhole = text; }
};

}  // namespace

int main() {
  // A small page goes out whole, as before.
  {
    Sink sink;
    CawPageWriter<Sink, Text> page(sink, 64);
    page += "<p>Saved.</p>";
    page += 'x';
    page += 42u;
    page.finish();
    page.finish();  // twice is harmless
    assert(!sink.begun && sink.chunks.empty());
    assert(sink.sentWhole == "<p>Saved.</p>x42");
  }
  // A big page goes out in pieces that add up to exactly the same text.
  {
    Sink sink;
    CawPageWriter<Sink, Text> page(sink, 100);
    std::string expected;
    for (unsigned index = 0; index < 500; ++index) {
      const std::string part = "<option value='" + std::to_string(index) + "'>zone</option>";
      page += part.c_str();
      page += index;
      expected += part + std::to_string(index);
    }
    page.finish();
    assert(sink.begun && sink.sentWhole.empty());
    std::string joined;
    for (const std::string &chunk : sink.chunks) {
      assert(!chunk.empty());
      assert(chunk.size() < 100 + 40);  // a piece is sent as soon as it is full
      joined += chunk;
    }
    assert(joined == expected);
  }
  // Exactly one piece: started, and nothing empty sent at the end.
  {
    Sink sink;
    CawPageWriter<Sink, Text> page(sink, 10);
    page += "0123456789";
    page.finish();
    assert(sink.begun && sink.chunks.size() == 1 && sink.chunks[0] == "0123456789");
  }
  std::puts("caw page: small pages whole, big pages in pieces with the same bytes");
  return 0;
}
