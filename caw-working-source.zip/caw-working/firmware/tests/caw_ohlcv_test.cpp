#include "CawOhlcv.h"

#include <cassert>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace {

struct Candle {
  uint32_t ts;
  float open, close;
};

std::vector<Candle> parse(const std::string &body, uint16_t *returned = nullptr) {
  size_t position = 0;
  std::vector<Candle> out;
  const uint16_t count = parseOhlcvList(
      [&]() -> int {
        return position < body.size() ? static_cast<unsigned char>(body[position++]) : -1;
      },
      [&](uint32_t ts, float open, float close) { out.push_back({ts, open, close}); });
  if (returned) *returned = count;
  return out;
}

bool near(double a, double b) { return std::fabs(a - b) <= std::fabs(b) * 1e-5; }

}  // namespace

int main() {
  // GeckoTerminal shape, newest first, exponent notation, meta after the list.
  std::string body =
      "{\"data\":{\"id\":\"x\",\"type\":\"ohlcv_request_response\",\"attributes\":"
      "{\"ohlcv_list\":[";
  for (int i = 0; i < 25; ++i) {
    char row[160];
    snprintf(row, sizeof(row), "%s[%u,%.4e,5e-09,4e-09,%.4e,1234.5]", i ? "," : "",
             1763197200u - i * 3600u, 4.7e-9 + i * 1e-11, 4.71e-9 + i * 1e-11);
    body += row;
  }
  body += "]}},\"meta\":{\"base\":{\"name\":\"CAW\"},\"quote\":{\"symbol\":\"WCRO\"}}}";
  uint16_t count = 0;
  auto candles = parse(body, &count);
  assert(count == 25 && candles.size() == 25);
  assert(candles[0].ts == 1763197200u && near(candles[0].open, 4.7e-9) &&
         near(candles[0].close, 4.71e-9));
  assert(candles[24].ts == 1763197200u - 24 * 3600u && near(candles[24].close, 4.95e-9));

  // Whitespace, quoted numbers, plain decimals.
  candles = parse("{\"ohlcv_list\" : [ [ \"1700000000\" , \"0.000000004785\" , 1, 1,"
                  " 0.000000004800 , 9 ] ] }");
  assert(candles.size() == 1 && candles[0].ts == 1700000000u &&
         near(candles[0].open, 4.785e-9) && near(candles[0].close, 4.8e-9));

  // A malformed candle is skipped; the next still parses.
  candles = parse("{\"ohlcv_list\":[[1700000000,abc,1,1,2,3],[1700003600,1,1,1,2,3]]}");
  assert(candles.size() == 1 && candles[0].ts == 1700003600u);

  // Real GeckoTerminal row (Cronos, 2026-11-15): exact timestamp, float prices.
  candles = parse("{\"ohlcv_list\":[[1794718800,4.713552791073199e-09,4.797873342254099e-09,"
                  "4.713552791073199e-09,4.797873342254099e-09,149.91995278416397]]}");
  assert(candles.size() == 1 && candles[0].ts == 1794718800u &&
         near(candles[0].open, 4.713552791073199e-09) &&
         near(candles[0].close, 4.797873342254099e-09));
  // A fractional or oversized timestamp is rejected.
  assert(parse("{\"ohlcv_list\":[[1700000000.5,1,1,1,2,3]]}").empty());
  assert(parse("{\"ohlcv_list\":[[99999999999,1,1,1,2,3]]}").empty());

  // Too few fields, empty list, missing key, truncated body.
  assert(parse("{\"ohlcv_list\":[[1700000000,1,2]]}").empty());
  assert(parse("{\"ohlcv_list\":[]}").empty());
  assert(parse("{\"data\":{\"attributes\":{}}}").empty());
  assert(parse("{\"ohlcv_list\":[[1700000000,1,1,1,").empty());
  // A key-like prefix does not confuse the matcher.
  assert(parse("{\"\"ohlcv_list\":[[1700000000,1,1,1,2,3]]}").size() == 1);
  // Oversized number token is rejected.
  assert(parse("{\"ohlcv_list\":[[1700000000,1111111111111111111111111111111111,1,1,2,3]]}")
             .empty());

  puts("caw ohlcv: streamed candles parsed, malformed input rejected");
  return 0;
}
