#include "CawRelease.h"

#include <cassert>
#include <cstdio>
#include <cstring>
#include <string>

namespace {

struct Reader {
  std::string text;
  size_t position = 0;
  int operator()() { return position < text.size() ? static_cast<unsigned char>(text[position++]) : -1; }
};

}  // namespace

int main() {
  // Versions.
  uint16_t parts[3];
  assert(cawParseVersion("0.4.0", parts) && parts[0] == 0 && parts[1] == 4 && parts[2] == 0);
  assert(cawParseVersion("v12.0.3", parts) && parts[0] == 12 && parts[2] == 3);
  assert(cawParseVersion("1.2.3-rc1", parts) && parts[2] == 3);
  assert(!cawParseVersion("caw-test-6b47c7c", parts));
  assert(!cawParseVersion("1.2", parts));
  assert(!cawParseVersion("", parts));
  assert(!cawParseVersion("99999.0.0", parts));
  assert(cawCompareVersions("0.4.1", "0.4.0") == CawVersionOrder::Newer);
  assert(cawCompareVersions("0.10.0", "0.9.9") == CawVersionOrder::Newer);  // not text order
  assert(cawCompareVersions("0.4.0", "0.4.0") == CawVersionOrder::Same);
  assert(cawCompareVersions("0.3.0", "0.4.0") == CawVersionOrder::Older);
  assert(cawCompareVersions("0.4.0", "caw-test-6b47c7c") == CawVersionOrder::Unknown);

  // SHA256SUMS.txt as the release workflow writes it.
  const std::string hashBin(64, 'a'), hashSrc(64, 'b');
  const std::string sums = std::string(64, 'c') + "  LICENSE\n" + hashSrc +
                           "  caw-clock-0.4.1-source.tar.gz\n" + std::string(64, 'd') +
                           "  caw-clock-0.4.1-relink.tar.gz\r\n" + "ABCDEF" +
                           hashBin.substr(6) + " *caw-clock-0.4.1.bin\r\n";
  CawReleaseInfo info{};
  assert(cawFindFirmwareInSums(sums.data(), sums.size(), info));
  assert(std::strcmp(info.version, "0.4.1") == 0);
  assert(std::strcmp(info.file, "caw-clock-0.4.1.bin") == 0);
  assert(std::strncmp(info.sha256, "abcdef", 6) == 0);  // lowercased
  assert(std::strlen(info.sha256) == 64);
  const std::string noBin = hashSrc + "  caw-clock-0.4.1-source.tar.gz\n";
  assert(!cawFindFirmwareInSums(noBin.data(), noBin.size(), info));
  const std::string badHash = std::string(63, 'a') + "g  caw-clock-0.4.1.bin\n";
  assert(!cawFindFirmwareInSums(badHash.data(), badHash.size(), info));
  const std::string badVersion = hashBin + "  caw-clock-test.bin\n";
  assert(!cawFindFirmwareInSums(badVersion.data(), badVersion.size(), info));
  const std::string noNewline = hashBin + "  caw-clock-1.0.0.bin";
  assert(cawFindFirmwareInSums(noNewline.data(), noNewline.size(), info));
  assert(std::strcmp(info.version, "1.0.0") == 0);

  // URLs.
  char host[64];
  const char *path = nullptr;
  assert(cawSplitHttpsUrl("https://github.com/caw7777/caw-clock/releases", host, sizeof(host), &path));
  assert(std::strcmp(host, "github.com") == 0 && std::strcmp(path, "/caw7777/caw-clock/releases") == 0);
  assert(cawSplitHttpsUrl("https://example.com", host, sizeof(host), &path) && std::strcmp(path, "/") == 0);
  assert(cawSplitHttpsUrl("https://a.b/x?sig=1", host, sizeof(host), &path) && std::strcmp(path, "/x?sig=1") == 0);
  assert(!cawSplitHttpsUrl("http://github.com/", host, sizeof(host), &path));
  assert(!cawSplitHttpsUrl("https://evil.com:8443/x", host, sizeof(host), &path));
  assert(!cawSplitHttpsUrl("https:///x", host, sizeof(host), &path));
  char tiny[4];
  assert(!cawSplitHttpsUrl("https://github.com/", tiny, sizeof(tiny), &path));

  // Redirect headers.
  char line[1100], location[1100];
  int32_t length = 0;
  const std::string longUrl = "https://release-assets.githubusercontent.com/x?" + std::string(900, 's');
  Reader redirect{"Server: GitHub.com\r\nLOCATION: " + longUrl +
                  "\r\nSet-Cookie: " + std::string(3000, 'k') + "\r\ncontent-length:  0\r\n\r\nbody"};
  assert(cawReadHttpHeaders([&] { return redirect(); }, line, sizeof(line), location, sizeof(location), length));
  assert(longUrl == location);
  assert(length == 0);
  assert(redirect() == 'b');  // stops right after the blank line
  Reader plain{"Content-Length: 976320\r\nX: y\r\n\r\n"};
  assert(cawReadHttpHeaders([&] { return plain(); }, line, sizeof(line), location, sizeof(location), length));
  assert(location[0] == '\0' && length == 976320);
  Reader tooLong{"Location: https://x/" + std::string(1200, 'p') + "\r\nContent-Length: abc\r\n\r\n"};
  assert(cawReadHttpHeaders([&] { return tooLong(); }, line, sizeof(line), location, sizeof(location), length));
  assert(location[0] == '\0' && length == -1);  // dropped, not truncated
  Reader cut{"Location: https://x/\r\n"};
  assert(!cawReadHttpHeaders([&] { return cut(); }, line, sizeof(line), location, sizeof(location), length));

  // Headers read into one buffer, Location kept at its start.
  {
    char one[1100];
    int32_t size = 0;
    Reader both{"Server: x\r\nLocation: " + longUrl + "\r\nX-Other: " + std::string(120, 'o') +
                "\r\nContent-Length: 12\r\nSet-Cookie: " + std::string(3000, 'c') + "\r\n\r\nB"};
    assert(cawReadHttpHeadersInPlace([&] { return both(); }, one, sizeof(one), size));
    assert(longUrl == one && size == 12);
    assert(both() == 'B');
    Reader none{"Content-Length: 5\r\nX: " + std::string(1500, 'x') + "\r\n\r\n"};
    assert(cawReadHttpHeadersInPlace([&] { return none(); }, one, sizeof(one), size));
    assert(one[0] == '\0' && size == 5);
    Reader big{"Location: https://x/" + std::string(1200, 'p') + "\r\n\r\n"};
    assert(cawReadHttpHeadersInPlace([&] { return big(); }, one, sizeof(one), size));
    assert(one[0] == '\0');  // too long: dropped, not truncated
    Reader late{"Content-Length: 7\r\n" + std::string("Location: https://a.b/c\r\n") +
                "X: " + std::string(1080, 'y') + "\r\n\r\n"};  // a line longer than what is left
    assert(cawReadHttpHeadersInPlace([&] { return late(); }, one, sizeof(one), size));
    assert(std::strcmp(one, "https://a.b/c") == 0 && size == 7);
    Reader cutShort{"Location: https://a.b/c\r\n"};
    assert(!cawReadHttpHeadersInPlace([&] { return cutShort(); }, one, sizeof(one), size));
  }

  // The latest-release redirect.
  char version[16];
  assert(cawVersionFromTagUrl("https://github.com/caw7777/caw-clock/releases/tag/v0.4.1",
                              "caw7777/caw-clock", version, sizeof(version)));
  assert(std::strcmp(version, "0.4.1") == 0);
  assert(!cawVersionFromTagUrl("https://github.com/other/caw-clock/releases/tag/v0.4.1",
                               "caw7777/caw-clock", version, sizeof(version)));
  assert(!cawVersionFromTagUrl("https://evil.com/caw7777/caw-clock/releases/tag/v0.4.1",
                               "caw7777/caw-clock", version, sizeof(version)));
  assert(!cawVersionFromTagUrl("https://github.com/caw7777/caw-clock/releases/tag/v0.4.1-rc1",
                               "caw7777/caw-clock", version, sizeof(version)));
  assert(!cawVersionFromTagUrl("https://github.com/caw7777/caw-clock/releases/tag/v0.4.1/x",
                               "caw7777/caw-clock", version, sizeof(version)));
  assert(!cawVersionFromTagUrl("https://github.com/caw7777/caw-clock/releases",
                               "caw7777/caw-clock", version, sizeof(version)));
  assert(!cawVersionFromTagUrl("https://github.com/caw7777/caw-clock/releases/tag/v1.2",
                               "caw7777/caw-clock", version, sizeof(version)));

  // Digest to hex.
  uint8_t digest[32];
  for (uint8_t index = 0; index < 32; ++index) digest[index] = static_cast<uint8_t>(index * 8);
  char hex[65];
  cawHex32(digest, hex);
  assert(std::strncmp(hex, "0008101820", 10) == 0 && std::strlen(hex) == 64);

  std::puts("caw release: versions, SHA256SUMS, URLs, redirect headers, hex");
  return 0;
}
