"""Approximate the firmware's free-layout scene for the CAW dashboard.

Usage (after a CAW build has generated the fonts; needs Pillow):
  python3 firmware/scripts/caw_dashboard.py /tmp/caw.json
  python3 firmware/scripts/preview_caw_layout.py \
    firmware/.pio/build/sdpro_caw/caw_generated/fonts_caw /tmp/caw.json out.png up logo48.png
STATE is "up" or "down". Not a substitute for a screenshot from the clock.

Follows the rules read from ScenePageCompiler/SceneTextCompiler/FreeTextSizing,
CoverageFont.h and StaticSmoothFont.h, using the generated CAW font data. It is
a layout check, not a pixel-exact renderer.
"""
import json, math, random, re, struct, sys
from pathlib import Path
from PIL import Image, ImageDraw

G = Path(sys.argv[1]); DASH = json.load(open(sys.argv[2])); OUT = sys.argv[3]; STATE = sys.argv[4]
LOGO = sys.argv[5]

def hexb(t): return bytes(int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", t))
def remap(c):
    if 0x2080 <= c <= 0x2089: return c - 0x2000
    if c in (0xE000, 0xE001): return c - 0xDF76
    if c == 0x25B6: return 0x8C
    return c

# GFX metrics (fitting)
def gfx(name):
    t = (G / f"{name}.h").read_text()
    gl = [tuple(map(int, m.groups()[:6])) for m in re.finditer(r"\{\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(-?\d+),\s*(-?\d+)\s*\}, // U\+", t)]
    return gl, int(re.search(r"0x0020, 0x017F, (\d+)", t)[1])
GFX = {13: gfx("InterTightCompact13"), 18: gfx("InterTightBold18"), 24: gfx("InterTightBold24"), 36: gfx("InterTightBold36")}
def gwidth(size, s):
    gl, _ = GFX[size]; w = 0
    for ch in s:
        c = remap(ord(ch))
        if 0x20 <= c <= 0x17F: w += gl[c - 0x20][3]
    return w

# smooth VLW
st = (G / "InterTightSmooth.h").read_text(); SMOOTH = {}
for size in (13, 18, 24):
    d = hexb(re.search(rf"InterTightSmooth{size}\[\] PROGMEM = \{{(.*?)\}};", st, re.S)[1])
    n, _, _, _, asc, desc = struct.unpack_from(">6I", d); pos = 24 + 7 * n; g = {}
    for i in range(n):
        c, h, w, a, dy, dx = struct.unpack_from(">HBBBbb", d, 24 + 7 * i); g[c] = (h, w, a, dy, dx, d[pos:pos + w * h]); pos += w * h
    line = {18: 23, 24: 30, 13: asc + desc + 2}[size]
    SMOOTH[size] = dict(g=g, asc=asc, desc=desc, line=line, space=(asc + desc) * 2 // 7)
# coverage
ct = (G / "CoverageFonts.inc").read_text(); COV = {}
for size, (asc, desc) in ((36, (36, 9)), (48, (48, 12))):
    px = hexb(re.search(rf"coveragePixels{size}\[\] PROGMEM = \{{(.*?)\}};", ct, re.S)[1])
    recs = [list(map(int, r.split(","))) for r in re.findall(r"\{([^{}]+)\}", re.search(rf"coverageGlyphs{size}\[\] PROGMEM = \{{(.*?)\}};", ct, re.S)[1])]
    COV[size] = dict(px=px, g={r[1]: r for r in recs}, asc=asc, desc=desc)

def hexc(s): s = s.lstrip("#"); return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
img = Image.new("RGB", (240, 240), hexc(DASH["pages"][0]["style"]["background"]))
draw = ImageDraw.Draw(img)

def blend(x, y, color, a):
    if not (0 <= x < 240 and 0 <= y < 240): return
    b = img.getpixel((x, y)); img.putpixel((x, y), tuple(round(b[i] + (color[i] - b[i]) * a) for i in range(3)))

def paint(text, x, y, renderer, size, datum, color, clip):
    cx0, cy0, cx1, cy1 = clip
    def put(px, py, a):
        if cx0 <= px < cx1 and cy0 <= py < cy1 and a: blend(px, py, color, a)
    if renderer == "coverage":
        f = COV[size]; width = gwidth(36, text)  # width via GFX like the device
        # use real advances for positioning
        width = sum(f["g"].get(remap(ord(c)), [0, 0, 0, 0, 0])[4] for c in text)
        if datum % 3 == 1: x -= width // 2
        if datum % 3 == 2: x -= width
        base = y + f["asc"]
        if 3 <= datum <= 5: base -= f["asc"] // 2
        if 6 <= datum <= 8: base -= f["asc"] + f["desc"]
        for ch in text:
            r = f["g"].get(remap(ord(ch)))
            if not r: x += 8; continue
            off, c, w, h, a, gx, gy = r; vals = []; p = off
            while len(vals) < w * h: e = f["px"][p]; p += 1; vals += [e >> 6] * ((e & 63) + 1)
            for i in range(w * h): put(x + gx + i % w, base + gy + i // w, vals[i] / 3)
            x += a
        return
    f = SMOOTH[size]
    width = 0
    for ch in text:
        c = remap(ord(ch))
        if c == 32: width += f["space"]; continue
        width += f["g"][c][2] if c in f["g"] else f["space"] + 1
    if datum % 3 == 1: x -= width // 2
    if datum % 3 == 2: x -= width
    if 3 <= datum <= 5: y -= f["line"] // 2
    if 6 <= datum <= 8: y -= f["line"]
    for ch in text:
        c = remap(ord(ch))
        if c == 32: x += f["space"]; continue
        if c not in f["g"]:
            draw.rectangle([x, y, x + f["space"], y + f["asc"]], outline=color); x += f["space"] + 1; continue
        h, w, a, dy, dx, al = f["g"][c]
        for i in range(w * h): put(x + dx + i % w, y + f["asc"] - dy + i // w, al[i] / 255)
        x += a

def font_for(text, w, h, scroll=False):
    for size in (3, 2, 1, 0):
        gsize = {3: 36, 2: 36, 1: 24, 0: 18}[size]
        if GFX[gsize][1] <= h and (scroll or gwidth(gsize, text) <= w - 8):
            return {3: ("coverage", 48), 2: ("coverage", 36), 1: ("smooth", 24), 0: ("smooth", 18)}[size]
    return ("smooth", 13)

def frame(fr): return [round(fr[k] * 2.4 + 1e-9) for k in ("x", "y", "width", "height")]
def mapping(card, value):
    for m in card.get("colorMappings", []):
        op, match = m["operator"], m["match"]
        if (op == "equals" and value == match) or (op == "starts_with" and value.startswith(match)) or (op == "contains" and match in value):
            return m
    return {}

def text_item(value, style, fr, fg, title):
    x, y, w, h = fr
    halign = style.get("horizontalAlign", "left" if title else "center")
    valign = style.get("verticalAlign", "top" if title else "middle")
    renderer, size = font_for(value, w, h, style.get("marquee", True))
    left, right = halign == "left", halign == "right"
    top, bottom = valign == "top", valign == "bottom"
    tight = title
    tx = x + 4 if left else x + w - 4 if right else x + w // 2
    ty = y + (0 if tight else 3) if top else (y + h - (1 if tight else 3)) if bottom else y + h // 2
    col = 0 if left else 2 if right else 1
    row = 0 if top else 6 if bottom else 3
    paint(value, tx, ty, renderer, size, row + col, fg, (x + 4, y, x + w - 4, y + h))
    return renderer, size

def rounded(box, r, fill=None, outline=None):
    draw.rounded_rectangle(box, r, fill=fill, outline=outline)

STATES = {
 "up": {"sensor.caw_usd_price_display": "$0.0₈5191", "sensor.caw_change_1h_display": "+0.9%", "sensor.caw_change_24h_display": "+2.4%",
        "sensor.caw_liquidity_display": "$776K", "sensor.caw_volume_24h_display": "$4K", "sensor.caw_market_cap_display": "$3.9M",
        "sensor.caw_ticker_display": "▶ caw  $0.0₈5191", "sensor.caw_ticker_changes_display": "+0.9%  +2.4%",
        "sensor.caw_trend_display": "up", "sensor.caw_wifi_status_display": ""},
}
STATES["down"] = dict(STATES["up"], **{"sensor.caw_change_1h_display": "-1.2%", "sensor.caw_change_24h_display": "-12.4%",
    "sensor.caw_ticker_changes_display": "-1.2%  -12.4%", "sensor.caw_trend_display": "down", "sensor.caw_wifi_status_display": ""})
values = STATES[STATE]
report = []
for card in DASH["pages"][0]["rows"][0]["cards"]:
    x, y, w, h = frame(card["frame"]); style = card.get("style", {})
    value = card.get("text") or values.get(card.get("source"), "--")
    if card["type"] == "clock": value = "14:32"
    m = mapping(card, value)
    bg = hexc(m.get("background") or style.get("background") or "#1E222A")
    fg = hexc(m.get("foreground") or style.get("foreground") or "#FFFFFF")
    r = {"small": 4, "medium": 8, "large": 12}.get(style.get("radius"), 0)
    if not card.get("transparentBackground") and card["type"] != "image":
        rounded([x, y, x + w - 1, y + h - 1], r, fill=bg)
    if style.get("borderStyle") == "solid":
        rounded([x, y, x + w - 1, y + h - 1], r, outline=hexc(style["border"]))
    if card["type"] == "image":
        img.paste(Image.open(LOGO).resize((w, h)), (x, y)); continue
    if card["type"] == "chart":
        gm = mapping(card, values.get(card["graph"].get("colorSource"), ""))
        gc = hexc(gm.get("foreground") or card["graph"]["color"]); random.seed(4 if STATE == "up" else 9)
        pts = []; v = 0
        for i in range(48): v += random.uniform(-1, 1.25 if STATE == "up" else 0.75); pts.append(v)
        lo, hi = min(pts), max(pts); pad = 3
        coords = [(x + 4 + i * (w - 8) / 47, y + h - pad - (p - lo) / (hi - lo) * (h - 2 * pad)) for i, p in enumerate(pts)]
        for px in range(x + 4, x + w - 4):
            i = min(46, int((px - x - 4) / (w - 8) * 47)); t = (px - coords[i][0]) / (coords[i + 1][0] - coords[i][0])
            yy = coords[i][1] + (coords[i + 1][1] - coords[i][1]) * t
            for py in range(int(yy), y + h): blend(px, py, gc, 0.3 * card["graph"]["fillOpacity"] / 30 * 0.6)
        draw.line(coords, fill=gc, width=2); continue
    vs = card.get("valueStyle", style); vfg = hexc(m.get("foreground") or vs.get("foreground") or style.get("foreground") or "#FFFFFF")
    vfr = frame(card["valueFrame"]) if "valueFrame" in card else [x, y, w, h]
    rv = text_item(value, vs, vfr, vfg, False)
    report.append((value, rv, vfr))
    if card.get("title"):
        ts = card.get("titleStyle", style); tfg = hexc(m.get("foreground") or ts.get("foreground") or "#D3D3D3")
        rt = text_item(card["title"], ts, frame(card["titleFrame"]), tfg, True)
        report.append((card["title"], rt, frame(card["titleFrame"])))
img.resize((720, 720), Image.NEAREST).save(OUT)
for v, r, fr in report: print(f"{r[0]:8s}{r[1]:3d}  frame={fr}  {v!r}")
