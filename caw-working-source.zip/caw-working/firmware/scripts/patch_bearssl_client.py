"""Install the CAW DexScreener BearSSL profile without changing sdpro.

The #else side of every change is the original ESP8266 client. sdpro does not
define MINI_DISPLAY_FEATURE_CAW, so it keeps that code.

Live api.dexscreener.com:443, checked against the GTS Root R4 certificate
embedded in CawMarketFeed.cpp and no other trust anchor:

  Protocol:     TLS 1.2
  Cipher:       TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256
                (ECDHE-ECDSA-CHACHA20-POLY1305)
  Leaf:         CN=dexscreener.com, P-256, ecdsa-with-SHA256, issuer WE1
  Intermediate: WE1, P-256, ecdsa-with-SHA384, issuer GTS Root R4
  Trust anchor: GTS Root R4, P-384, ecdsa-with-SHA384
                The server also sends a cross-signed copy of that root
                (RSA-SHA256 by GlobalSign). Its public key matches the
                embedded root, so chain validation stops there and does
                not use RSA.

Kept at every trim level, because the handshake or the chain needs them:
  TLS 1.2, X25519, P-256, P-384, ECDSA verify, SHA-256, SHA-384,
  ChaCha20-Poly1305, and the minimal X.509 validator with time checks.

Not used by this peer, and dropped only from the CAW client as the trim
level rises. OTA signing still calls br_rsa_pkcs1_vrfy_get_default and
br_ec_get_default; those references are left alone.

  0  original client
  1  ChaCha-only suite, so AES is not negotiated or linked
  2  3DES unreferenced
  3  SHA-224 and SHA-512 unreferenced
  4  RSA client hook, RSA key exchange, client-certificate signers
  5  client EC path is P-256/P-384/X25519 only
  6  fingerprint and insecure validator unreferenced
  7  TLS 1.2 only; MD5, SHA-1 and the TLS 1.0 PRF unreferenced

CAW_BEARSSL_TRIM selects the level. CAW_LINK_BOLD48=1 keeps the unused 48 px
font so a TLS measurement is not mixed with that removal.
"""

import json
import os
from pathlib import Path

Import("env")  # noqa: F821 - PlatformIO/SCons build environment

DATA = json.loads(
    (Path(env["PROJECT_DIR"]) / "scripts" / "bearssl_profile_data.json").read_text()  # noqa: F821
)

REQUIRED_AT_FINAL = (
    "BR_TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256",
    "BR_EC_secp256r1",
    "BR_EC_secp384r1",
    "BR_EC_curve25519",
    "br_ecdsa_i15_vrfy_asn1",
    "br_sha256_vtable",
    "br_sha384_vtable",
    "br_ssl_engine_set_default_chapol",
    "br_tls12_sha256_prf",
)
FORBIDDEN_AT_FINAL = (
    "set_default_aes",
    "set_default_des",
    "br_md5_vtable",
    "br_sha1_vtable",
    "br_sha224_vtable",
    "br_sha512_vtable",
    "br_tls10_prf",
    "set_default_rsavrfy",
    "set_default_rsapub",
    "br_x509_insecure_init",
)


def marker(name):
    return (
        f"/* CAW_BEARSSL_REGION {name} */\n",
        f"/* CAW_BEARSSL_REGION_END {name} */\n",
    )


def span(text, name, original, legacy):
    begin, end = marker(name)
    if begin in text:
        start = text.index(begin)
        finish = text.index(end, start) + len(end)
        return start, finish
    if original and original in text:
        start = text.index(original)
        return start, start + len(original)
    if legacy and legacy in text:
        start = text.index(legacy)
        return start, start + len(legacy)
    raise RuntimeError(f"BearSSL client patch no longer matches ({name})")


def replace_region(text, name, original, legacy, code, enabled):
    start, finish = span(text, name, original, legacy)
    if not enabled:
        replacement = original
    else:
        begin, end = marker(name)
        if not code.endswith("\n"):
            code += "\n"
        replacement = begin + code + end
    if text[start:finish] == replacement:
        return text, False
    return text[:start] + replacement + text[finish:], True


def original_body(function_text):
    lines = function_text.splitlines()
    return "\n".join(lines[1:-1]) + "\n"


def hash_lines(names):
    return "\n".join(
        f"    br_x509_minimal_set_hash(x509, br_{name}_ID, &br_{name}_vtable);"
        for name in names
    )


def client_code(level):
    if level <= 0:
        return DATA["client_original"], False
    statements = [
        "#ifdef MINI_DISPLAY_FEATURE_CAW",
        "    static const uint16_t dexSuite[] = {",
        "        BR_TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256};",
        "    br_ssl_client_zero(cc);",
        "    br_ssl_engine_add_flags(&cc->eng, BR_OPT_NO_RENEGOTIATION);",
    ]
    if level >= 7:
        statements.append("    br_ssl_engine_set_versions(&cc->eng, BR_TLS12, BR_TLS12);")
    else:
        statements.append("    br_ssl_engine_set_versions(&cc->eng, BR_TLS10, BR_TLS12);")
    statements.append(
        "    br_ssl_engine_set_suites(&cc->eng, dexSuite, sizeof(dexSuite) / sizeof(dexSuite[0]));"
    )
    if level < 4:
        statements.append("    br_ssl_client_set_default_rsapub(cc);")
        statements.append("    br_ssl_engine_set_default_rsavrfy(&cc->eng);")
    if level >= 5:
        statements.append("    br_ssl_engine_set_ec(&cc->eng, &br_ec_caw_dexscreener);")
        statements.append("    br_ssl_engine_set_ecdsa(&cc->eng, br_ecdsa_i15_vrfy_asn1);")
    else:
        statements.extend(
            [
                "#ifndef BEARSSL_SSL_BASIC",
                "    br_ssl_engine_set_default_ecdsa(&cc->eng);",
                "#endif",
            ]
        )
    hashes = ["md5", "sha1", "sha224", "sha256", "sha384", "sha512"]
    if level >= 3:
        hashes = [name for name in hashes if name not in ("sha224", "sha512")]
    if level >= 7:
        hashes = ["sha256", "sha384"]
    for name in hashes:
        statements.append(
            f"    br_ssl_engine_set_hash(&cc->eng, br_{name}_ID, &br_{name}_vtable);"
        )
    if level < 7:
        statements.append("    br_ssl_engine_set_prf10(&cc->eng, &br_tls10_prf);")
    statements.append("    br_ssl_engine_set_prf_sha256(&cc->eng, &br_tls12_sha256_prf);")
    if level < 7:
        statements.append("    br_ssl_engine_set_prf_sha384(&cc->eng, &br_tls12_sha384_prf);")
    cipher_calls = ["    br_ssl_engine_set_default_chapol(&cc->eng);"]
    if level < 2:
        cipher_calls.insert(0, "    br_ssl_engine_set_default_des_cbc(&cc->eng);")
    statements.append("#ifndef BEARSSL_SSL_BASIC")
    statements.extend(cipher_calls)
    statements.append("#endif")
    statements.extend(
        [
            "    (void)cipher_list;",
            "    (void)cipher_cnt;",
            "#else",
        ]
    )
    helpers = DATA["client_helpers"] if level >= 5 else ""
    if helpers and not helpers.endswith("\n"):
        helpers += "\n"
    code = (
        helpers
        + "  static void br_ssl_client_base_init(br_ssl_client_context *cc, "
        + "const uint16_t *cipher_list, int cipher_cnt) {\n"
        + "\n".join(statements)
        + "\n"
        + original_body(DATA["client_original"])
        + "#endif\n"
        + "  }\n"
    )
    if level >= 7:
        head, func = code.split("  static void br_ssl_client_base_init", 1)
        caw_only = head + func.split("#else", 1)[0]
        for token in REQUIRED_AT_FINAL:
            if token not in caw_only:
                raise RuntimeError(f"final BearSSL profile lost {token}")
        for token in FORBIDDEN_AT_FINAL:
            if token in caw_only:
                raise RuntimeError(f"final BearSSL profile still references {token}")
    return code, True


def hashes_code(level):
    if level < 3:
        return DATA["hashes_original"], False
    names = ["md5", "sha1", "sha256", "sha384"] if level < 7 else ["sha256", "sha384"]
    code = (
        "  static void br_x509_minimal_install_hashes(br_x509_minimal_context *x509) {\n"
        "#ifdef MINI_DISPLAY_FEATURE_CAW\n"
        + hash_lines(names)
        + "\n#else\n"
        + original_body(DATA["hashes_original"])
        + "#endif\n"
        "  }\n"
    )
    if level >= 7:
        for token in ("br_sha256_vtable", "br_sha384_vtable"):
            if token not in code:
                raise RuntimeError(f"certificate hashes lost {token}")
        for token in ("br_md5_vtable", "br_sha1_vtable", "br_sha512_vtable"):
            # The #else keeps these for sdpro. Only the CAW branch is checked.
            caw = code.split("#else", 1)[0]
            if token in caw:
                raise RuntimeError(f"CAW certificate hashes still reference {token}")
    return code, True


def insecure_code(level):
    if level < 6:
        return DATA["insecure_prefix"], False
    prefix = DATA["insecure_prefix"]
    lines = prefix.splitlines(keepends=True)
    if not lines[0].startswith("bool WiFiClientSecureCtx::_installClientX509Validator()"):
        raise RuntimeError("insecure validator prefix does not start at the function")
    code = (
        lines[0]
        + "#ifdef MINI_DISPLAY_FEATURE_CAW\n"
        + "  // Trust-anchor validation only. Fingerprint and known-key modes\n"
        + "  // hash the certificate with SHA-1 or skip the chain. The CAW\n"
        + "  // client never enables them.\n"
        + "  if (!_ta) {\n"
        + '    DEBUG_BSSL("_installClientX509Validator: CAW requires a trust anchor\\n");\n'
        + "    return false;\n"
        + "  }\n"
        + "  {\n"
        + "#else\n"
        + "".join(lines[1:])
        + "#endif\n"
    )
    if "br_x509_insecure_init" not in code.split("#else", 1)[1]:
        raise RuntimeError("sdpro insecure validator was dropped")
    if "br_x509_insecure_init" in code.split("#else", 1)[0]:
        raise RuntimeError("CAW insecure validator is still compiled")
    return code, True


def apply(text, level):
    changed = False
    regions = [
        ("client_init", DATA["client_original"], DATA["client_legacy"], client_code(level)),
        ("x509_hashes", DATA["hashes_original"], DATA["hashes_legacy"], hashes_code(level)),
        (
            "x509_rsa",
            DATA["rsa_original"],
            DATA["rsa_legacy"],
            (DATA["rsa_legacy"], level >= 4),
        ),
        (
            "client_cert",
            DATA["cert_original"],
            DATA["cert_legacy"],
            (DATA["cert_legacy"], level >= 4),
        ),
        (
            "insecure_validator",
            DATA["insecure_prefix"],
            None,
            insecure_code(level),
        ),
    ]
    for name, original, legacy, generated in regions:
        code, enabled = generated
        text, did = replace_region(text, name, original, legacy, code, enabled)
        changed = changed or did
    return text, changed


def write_options(trim, link_bold48):
    project = Path(env["PROJECT_DIR"])  # noqa: F821
    path = project / "src" / "caw_build_opts.h"
    contents = (
        "#pragma once\n\n"
        "// Written by scripts/patch_bearssl_client.py. Do not edit by hand.\n"
        f"#define CAW_BEARSSL_TRIM {trim}\n"
        f"#define CAW_LINK_BOLD48 {1 if link_bold48 else 0}\n"
    )
    if not path.exists() or path.read_text() != contents:
        path.write_text(contents)


if env.PioPlatform().name == "espressif8266":  # noqa: F821
    trim = int(os.environ.get("CAW_BEARSSL_TRIM", "7"))
    if trim < 0 or trim > 7:
        raise RuntimeError(f"CAW_BEARSSL_TRIM must be 0..7, got {trim}")
    link_bold48 = os.environ.get("CAW_LINK_BOLD48", "0") == "1"
    write_options(trim, link_bold48)
    framework = env.PioPlatform().get_package_dir("framework-arduinoespressif8266")  # noqa: F821
    path = Path(framework) / "libraries/ESP8266WiFi/src/WiFiClientSecureBearSSL.cpp"
    source = path.read_text()
    updated, changed = apply(source, trim)
    if changed:
        path.write_text(updated)
    print(
        f"BearSSL client: CAW trim {trim}, bold48={'kept' if link_bold48 else 'dropped'}"
        + (" (rewritten)" if changed else " (unchanged)")
    )
