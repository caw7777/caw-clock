"""Harden the on-device HTTPS server used by the CAW profile.

The CAW web interface is served over HTTPS (DualWebServer) with an EC
certificate that the device generates or the owner uploads. The stock
ESP8266 server profile still accepts TLS 1.0/1.1, 3DES, CBC with SHA-1,
static ECDH (no forward secrecy) and CCM-8, and it links a second P-256
implementation next to the one the DexScreener client already uses.

With MINI_DISPLAY_FEATURE_CAW the server is narrowed to:

  Protocol:  TLS 1.2 only
  Suites:    ECDHE-ECDSA-CHACHA20-POLY1305
             ECDHE-ECDSA-AES128-GCM-SHA256
  Curves:    X25519, P-256, P-384, P-521 (ECDHE and certificate keys)
  Hashes:    SHA-256, SHA-384

Every current browser negotiates one of those suites. Nothing weaker than
the stock profile remains, so this is a hardening as well as a size
reduction. The RSA server path and client-certificate validation are not
reachable from the CAW firmware (TlsCertificateManager accepts EC keys
only and DualWebServer never installs client trust anchors); with the
CAW flag they fail closed instead of being linked.

The #else side of every region is the original core code, so builds
without MINI_DISPLAY_FEATURE_CAW (sdpro) are unchanged.

The core's make_stack_thunk() emits SigningVerifier's thunk into a .text
section the linker never discards, so the OTA signature verifier is always
linked, and through br_ec_get_default() so is br_ec_all_m15 with its
separate P-256 code. With the CAW flag the verifier uses br_ec_prime_i15
(P-256/384/521, constant time), which TLS already links. Signed OTA keeps
working if it is enabled; only the duplicate curve code goes away.

CAW_BEARSSL_SERVER_TRIM=0 restores the stock server for measurements.
Requires patch_bearssl_client.py at trim level 5 or higher, which defines
the shared cawDex* curve dispatchers.
"""

import os
from pathlib import Path

Import("env")  # noqa: F821 - PlatformIO/SCons build environment

SERVER_ORIGINAL = (
    "  static void br_ssl_server_base_init(br_ssl_server_context *cc, const uint16_t *cipher_list, int cipher_cnt) {\n"
    "    uint16_t suites[cipher_cnt];\n"
    "    memcpy_P(suites, cipher_list, cipher_cnt * sizeof(cipher_list[0]));\n"
    "    br_ssl_server_zero(cc);\n"
    "    br_ssl_engine_add_flags(&cc->eng, BR_OPT_NO_RENEGOTIATION);  // forbid SSL renegotiation, as we free the Private Key after handshake\n"
    "    br_ssl_engine_set_versions(&cc->eng, BR_TLS10, BR_TLS12);\n"
    "    br_ssl_engine_set_suites(&cc->eng, suites, (sizeof suites) / (sizeof suites[0]));\n"
    "#ifndef BEARSSL_SSL_BASIC\n"
    "    br_ssl_engine_set_default_ec(&cc->eng);\n"
    "#endif\n"
    "\n"
    "    br_ssl_client_install_hashes(&cc->eng);\n"
    "    br_ssl_engine_set_prf10(&cc->eng, &br_tls10_prf);\n"
    "    br_ssl_engine_set_prf_sha256(&cc->eng, &br_tls12_sha256_prf);\n"
    "    br_ssl_engine_set_prf_sha384(&cc->eng, &br_tls12_sha384_prf);\n"
    "    br_ssl_engine_set_default_aes_cbc(&cc->eng);\n"
    "#ifndef BEARSSL_SSL_BASIC\n"
    "    br_ssl_engine_set_default_aes_ccm(&cc->eng);\n"
    "    br_ssl_engine_set_default_aes_gcm(&cc->eng);\n"
    "    br_ssl_engine_set_default_des_cbc(&cc->eng);\n"
    "    br_ssl_engine_set_default_chapol(&cc->eng);\n"
    "#endif\n"
    "  }\n"
)

SERVER_CAW = """  static const br_ec_impl br_ec_caw_server PROGMEM = {
      (1UL << BR_EC_secp256r1) | (1UL << BR_EC_secp384r1) |
          (1UL << BR_EC_secp521r1) | (1UL << BR_EC_curve25519),
      &cawDexGenerator, &cawDexOrder, &cawDexXoff, &cawDexMul, &cawDexMulgen, &cawDexMuladd};
#endif
  static void br_ssl_server_base_init(br_ssl_server_context *cc, const uint16_t *cipher_list, int cipher_cnt) {
#ifdef MINI_DISPLAY_FEATURE_CAW
    // CAW on-device HTTPS: TLS 1.2, forward-secret AEAD suites only.
    static const uint16_t cawServerSuites[] = {
        BR_TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,
        BR_TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256};
    br_ssl_server_zero(cc);
    br_ssl_engine_add_flags(&cc->eng, BR_OPT_NO_RENEGOTIATION);
    br_ssl_engine_set_versions(&cc->eng, BR_TLS12, BR_TLS12);
    br_ssl_engine_set_suites(&cc->eng, cawServerSuites, sizeof(cawServerSuites) / sizeof(cawServerSuites[0]));
    br_ssl_engine_set_ec(&cc->eng, &br_ec_caw_server);
    br_ssl_engine_set_hash(&cc->eng, br_sha256_ID, &br_sha256_vtable);
    br_ssl_engine_set_hash(&cc->eng, br_sha384_ID, &br_sha384_vtable);
    br_ssl_engine_set_prf_sha256(&cc->eng, &br_tls12_sha256_prf);
    br_ssl_engine_set_default_chapol(&cc->eng);
    br_ssl_engine_set_default_aes_gcm(&cc->eng);
    (void)cipher_list;
    (void)cipher_cnt;
#else
"""

VALIDATOR_HEAD = (
    "bool WiFiClientSecureCtx::_installServerX509Validator(const X509List *client_CA_ta) {\n"
)
VALIDATOR_CAW = (
    "#ifdef MINI_DISPLAY_FEATURE_CAW\n"
    "  // The CAW web server never requests client certificates.\n"
    "  if (client_CA_ta) {\n"
    "    _freeSSL();\n"
    "    return false;\n"
    "  }\n"
    "  return true;\n"
    "#else\n"
)

RSA_HEAD = "bool WiFiClientSecureCtx::_connectSSLServerRSA("
RSA_CAW = (
    "#ifdef MINI_DISPLAY_FEATURE_CAW\n"
    "  // CAW serves an EC certificate only; the RSA server is not linked.\n"
    "  (void)chain;\n"
    "  (void)sk;\n"
    "  (void)cache;\n"
    "  (void)client_CA_ta;\n"
    "  _freeSSL();\n"
    "  return false;\n"
    "#else\n"
)

BEGIN = "/* CAW_BEARSSL_SERVER {} */\n"
END = "/* CAW_BEARSSL_SERVER_END {} */\n"


def function_body(text, head):
    """Return (body_start, body_end) of the function whose signature starts with head."""
    start = text.index(head)
    open_brace = text.index("{\n", start) + 2
    close = text.index("\n}\n", open_brace) + 1
    return open_brace, close


def unwrap(text):
    """Remove previously applied regions so the patch is idempotent and reversible."""
    while BEGIN.format("server_init") in text:
        b = text.index(BEGIN.format("server_init"))
        e = text.index(END.format("server_init"), b) + len(END.format("server_init"))
        text = text[:b] + SERVER_ORIGINAL + text[e:]
    for name in ("validator", "rsa"):
        tag_b, tag_e = BEGIN.format(name), END.format(name)
        while tag_b in text:
            b = text.index(tag_b)
            e = text.index(tag_e, b)
            block = text[b + len(tag_b):e]
            original = block.split("#else\n", 1)[1]
            original = original[: original.rindex("#endif\n")]
            text = text[:b] + original + text[e + len(tag_e):]
    tag_b, tag_e = BEGIN.format("hashes"), END.format("hashes")
    while tag_b in text:
        b = text.index(tag_b)
        e = text.index(tag_e, b)
        block = text[b + len(tag_b):e]
        original = block[len(HASHES_GUARD):-len("#endif\n")]
        text = text[:b] + original + text[e + len(tag_e):]
    return text


# Both callers of this helper sit on the non-CAW side of the regions above.
# Compile it out for CAW so the build stays free of unused-function warnings.
HASHES_GUARD = "#ifndef MINI_DISPLAY_FEATURE_CAW\n"


def hashes_span(text):
    start = text.index("  static void br_ssl_client_install_hashes(br_ssl_engine_context *eng) {\n")
    end = text.index("\n  }\n", start) + len("\n  }\n")
    return start, end


def apply(text, trim):
    text = unwrap(text)
    if trim <= 0:
        return text
    if "cawDexGenerator" not in text:
        raise RuntimeError("server trim needs CAW_BEARSSL_TRIM >= 5 (cawDex* helpers)")
    if SERVER_ORIGINAL not in text:
        raise RuntimeError("BearSSL server init no longer matches the expected core code")
    server = (
        BEGIN.format("server_init")
        + "#ifdef MINI_DISPLAY_FEATURE_CAW\n"
        + SERVER_CAW
        + "\n".join(SERVER_ORIGINAL.splitlines()[1:-1])
        + "\n#endif\n  }\n"
        + END.format("server_init")
    )
    text = text.replace(SERVER_ORIGINAL, server, 1)
    for name, head, caw in (("validator", VALIDATOR_HEAD, VALIDATOR_CAW),
                            ("rsa", RSA_HEAD, RSA_CAW)):
        b, e = function_body(text, head)
        text = (text[:b] + BEGIN.format(name) + caw + text[b:e] + "#endif\n"
                + END.format(name) + text[e:])
    b, e = hashes_span(text)
    text = (text[:b] + BEGIN.format("hashes") + HASHES_GUARD + text[b:e]
            + "#endif\n" + END.format("hashes") + text[e:])

    caw = server.split("#else", 1)[0]
    for token in ("BR_TLS12, BR_TLS12", "ECDHE_ECDSA_WITH_CHACHA20_POLY1305",
                  "ECDHE_ECDSA_WITH_AES_128_GCM", "br_ec_caw_server"):
        if token not in caw:
            raise RuntimeError(f"CAW server profile lost {token}")
    for token in ("BR_TLS10", "des_cbc", "aes_cbc", "aes_ccm", "prf10",
                  "set_default_ec", "install_hashes"):
        if token in caw:
            raise RuntimeError(f"CAW server profile still references {token}")
    return text


VERIFY_ORIGINAL = (
    "    return vrfy(br_ec_get_default(), hash->hash(), hash->len(), _pubKey->getEC(), (const unsigned char *)signature, signatureLen);\n"
)
VERIFY_CAW = (
    BEGIN.format("verifier_ec")
    + "#ifdef MINI_DISPLAY_FEATURE_CAW\n"
    + "    return vrfy(&br_ec_prime_i15, hash->hash(), hash->len(), _pubKey->getEC(), (const unsigned char *)signature, signatureLen);\n"
    + "#else\n"
    + VERIFY_ORIGINAL
    + "#endif\n"
    + END.format("verifier_ec")
)


def apply_helpers(text, trim):
    if VERIFY_CAW in text:
        text = text.replace(VERIFY_CAW, VERIFY_ORIGINAL, 1)
    if trim <= 0:
        return text
    if text.count(VERIFY_ORIGINAL) != 1:
        raise RuntimeError("SigningVerifier EC call no longer matches the expected core code")
    return text.replace(VERIFY_ORIGINAL, VERIFY_CAW, 1)


if env.PioPlatform().name == "espressif8266":  # noqa: F821
    trim = int(os.environ.get("CAW_BEARSSL_SERVER_TRIM", "1"))
    framework = env.PioPlatform().get_package_dir("framework-arduinoespressif8266")  # noqa: F821
    path = Path(framework) / "libraries/ESP8266WiFi/src/WiFiClientSecureBearSSL.cpp"
    source = path.read_text()
    updated = apply(source, trim)
    if updated != source:
        path.write_text(updated)
    helpers = Path(framework) / "libraries/ESP8266WiFi/src/BearSSLHelpers.cpp"
    helpers_source = helpers.read_text()
    helpers_updated = apply_helpers(helpers_source, trim)
    if helpers_updated != helpers_source:
        helpers.write_text(helpers_updated)
    changed = updated != source or helpers_updated != helpers_source
    print(f"BearSSL server: CAW trim {trim}"
          + (" (rewritten)" if changed else " (unchanged)"))
