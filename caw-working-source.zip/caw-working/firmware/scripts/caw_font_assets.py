"""CAW-only font assets, generated into the build directory.

Runs as a pre-script of env:sdpro_caw only. The shared font sources in
src/fonts, src/CoverageFonts.generated.cpp and the sdpro build are not
modified; the CAW sources include the generated copies instead.

1. Glyph set. The 1-bit InterTight GFX fonts cover U+0020..U+017F. The smooth
   and coverage fonts that draw final-quality text contain only ASCII,
   Latin-1, Polish letters and a few symbols, so other Latin Extended-A
   letters already render as a missing-glyph box in finished frames. The CAW
   GFX copies empty those glyphs (width/height 0, advance kept).

2. Subscript digits. DexScreener-style prices such as $0.0₈5191 use
   U+2080..U+2089. GFX fonts need a contiguous range, so these digits are
   stored in the unused C1 control slots U+0080..U+0089 of every built-in
   font, and the CAW UTF-8 decoders (CoverageFont.h and TFT_eSPI) map
   U+208x to U+008x. Strings stay ordinary Unicode, so the web UI and API
   show the same text. Each subscript is the font's own digit from the
   8-bit smooth sources, scaled to 55 % and dropped below the baseline, so
   the anti-aliased renderers draw it like any other glyph.

3. Icons. Slots U+008A..U+008C hold a Wi-Fi icon (mapped from U+E000), a
   Wi-Fi-off icon (U+E001) and a play marker (U+25B6) for the CAW screen,
   drawn as anti-aliased shapes at cap height.

No renderer gains a decode step or allocation: the glyphs use the existing
VLW v12, RLE coverage and GFX formats.
"""

import importlib.util
import re
import struct
from pathlib import Path

Import("env")  # noqa: F821 - PlatformIO/SCons build environment

POLISH = "ĄĆĘŁŃÓŚŹŻąćęłńóśźż"
SYMBOLS = "€–—…←↑→↓•✓✕"
KEEP = set(range(32, 127)) | set(range(160, 256)) | {ord(c) for c in POLISH + SYMBOLS}
SUBSCRIPT_SLOT = 0x80          # U+2080 + d is stored at U+0080 + d
SUBSCRIPT_SCALE = 0.55         # subscript digit height / regular digit height
SUBSCRIPT_DROP = 0.08          # baseline drop as a fraction of the font size
ICONS = {0x8A: "wifi", 0x8B: "wifi-off", 0x8C: "play"}
GFX_FONTS = {13: 13, 18: 13, 24: 18, 36: 24}   # GFX size -> smooth source size
SMOOTH_SOURCES = {13: 13, 18: 13, 24: 18}
COVERAGE_SOURCES = {36: 24, 48: 24}

GFX_GLYPH = re.compile(
    r"\{\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(-?\d+),\s*(-?\d+)\s*\}, // U\+([0-9A-F]+)"
)


def hex_bytes(text):
    return bytes(int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", text))


def byte_rows(data, prefix="  ", width=16, lower=False):
    fmt = "0x{:02x}" if lower else "0x{:02X}"
    return "\n".join(
        prefix + ", ".join(fmt.format(b) for b in data[i:i + width]) + ","
        for i in range(0, len(data), width)
    )


# ---------------------------------------------------------------- VLW v12 ---

def parse_vlw(data):
    count, version, size, zero, ascent, descent = struct.unpack_from(">6I", data)
    if version != 12:
        raise RuntimeError(f"expected compact VLW v12, found {version}")
    glyphs, position = [], 24 + 7 * count
    for index in range(count):
        code, h, w, adv, dy, dx = struct.unpack_from(">HBBBbb", data, 24 + 7 * index)
        glyphs.append([code, h, w, adv, dy, dx, data[position:position + w * h]])
        position += w * h
    if position != len(data):
        raise RuntimeError("VLW bitmap size mismatch")
    return [size, zero, ascent, descent], glyphs


def build_vlw(header, glyphs):
    size, zero, ascent, descent = header
    out = bytearray(struct.pack(">6I", len(glyphs), 12, size, zero, ascent, descent))
    for code, h, w, adv, dy, dx, _ in glyphs:
        out += struct.pack(">HBBBbb", code, h, w, adv, dy, dx)
    for *_, alpha in glyphs:
        out += alpha
    return bytes(out)


# ------------------------------------------------------------- subscripts ---

def subscript(source_glyph, scale, font_size):
    """Scale an 8-bit digit glyph; return (w, h, advance, dx, top, alpha)."""
    code, h, w, adv, dy, dx, alpha = source_glyph
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    drop = max(1, round(font_size * SUBSCRIPT_DROP))
    advance = max(nw + 1, round(adv * scale))
    return nw, nh, advance, round(dx * scale), nh - drop, resample(alpha, w, h, nw, nh)


def resample(alpha, w, h, nw, nh):
    """Area-average resampling of an 8-bit coverage bitmap (no dependencies)."""
    def spans(size, new_size):
        step = size / new_size
        result = []
        for index in range(new_size):
            start, end = index * step, (index + 1) * step
            cells, position = [], int(start)
            while position < end and position < size:
                weight = min(end, position + 1) - max(start, position)
                if weight > 0:
                    cells.append((position, weight))
                position += 1
            result.append(cells)
        return result
    columns, rows = spans(w, nw), spans(h, nh)
    out = bytearray()
    for row_cells in rows:
        for column_cells in columns:
            total = area = 0.0
            for y, wy in row_cells:
                for x, wx in column_cells:
                    total += alpha[y * w + x] * wx * wy
                    area += wx * wy
            out.append(min(255, int(total / area + 0.5)))
    return bytes(out)


def icon(kind, font_size):
    """Rasterise an icon with 4x4 supersampling; return (w, h, adv, dx, top, alpha)."""
    import math
    h = max(7, round(font_size * 0.72))
    if kind.startswith("wifi"):
        # Wide enough for the outer arc's 45-degree ends (see wifi_geometry).
        _, outer, stroke = wifi_geometry(h)
        w = math.ceil(2 * outer * math.sin(math.radians(45)) + stroke + 2)
    else:
        w = max(5, round(h * 0.8))
    samples = 4
    out = bytearray()
    for y in range(h):
        for x in range(w):
            hits = 0
            for sy in range(samples):
                for sx in range(samples):
                    px = x + (sx + 0.5) / samples
                    py = y + (sy + 0.5) / samples
                    hits += inside(kind, px, py, w, h, math)
            out.append(round(255 * hits / samples ** 2))
    return w, h, w + max(1, round(font_size * 0.12)), 0, h, bytes(out)


def wifi_geometry(h):
    """Centre height, outer arc radius and stroke so every arc fits in h rows."""
    stroke = max(1.15, h * 0.12)
    cy = h - max(1.1, h * 0.11) - 0.3
    outer = cy - stroke / 2 - 0.3
    return cy, outer, stroke


def inside(kind, px, py, w, h, math):
    if kind == "play":
        # Right-pointing triangle filling the box.
        return px >= 0 and py >= h * (px / w) / 2 and py <= h - h * (px / w) / 2
    cy, outer, stroke = wifi_geometry(h)
    cx = w / 2
    dx, dy = px - cx, cy - py
    distance = math.hypot(dx, dy)
    angle = math.degrees(math.atan2(abs(dx), dy)) if distance else 0
    dot = distance <= max(1.1, h * 0.11)
    arcs = any(abs(distance - outer * r) <= stroke / 2 for r in (0.4, 0.7, 1.0))
    hit = dot or (arcs and angle <= 45 and dy > 0)
    if kind == "wifi-off":
        # Diagonal bar from top-left to bottom-right.
        bar = abs((py / h) - (px / w)) * min(w, h) <= stroke * 0.6
        hit = (hit and not abs((py / h) - (px / w)) * min(w, h) <= stroke * 1.4) or bar
    return hit


def digits(glyphs):
    table = {g[0]: g for g in glyphs}
    return [table[ord("0") + d] for d in range(10)]


def target_scale(source_digits, target_digit_height):
    return SUBSCRIPT_SCALE * target_digit_height / source_digits[0][1]


# ----------------------------------------------------------- smooth fonts ---

def smooth_assets(source_text):
    fonts = {}
    for name, body in re.findall(r"const uint8_t (InterTightSmooth\d+)\[\] PROGMEM = \{(.*?)\};", source_text, re.S):
        fonts[int(name[16:])] = parse_vlw(hex_bytes(body))
    out_text = source_text
    for size, src_size in SMOOTH_SOURCES.items():
        header, glyphs = fonts[size]
        src = digits(fonts[src_size][1])
        scale = target_scale(src, digits(glyphs)[0][1])
        glyphs = [g for g in glyphs if not SUBSCRIPT_SLOT <= g[0] < SUBSCRIPT_SLOT + 10]
        for d in range(10):
            w, h, adv, dx, top, alpha = subscript(src[d], scale, size)
            glyphs.append([SUBSCRIPT_SLOT + d, h, w, adv, top, dx, alpha])
        glyphs = [g for g in glyphs if g[0] not in ICONS]
        for code, kind in ICONS.items():
            w, h, adv, dx, top, alpha = icon(kind, size)
            glyphs.append([code, h, w, adv, top, dx, alpha])
        glyphs.sort(key=lambda g: g[0])
        data = build_vlw(header, glyphs)
        if parse_vlw(data)[1] != glyphs:
            raise RuntimeError(f"smooth {size}: VLW round trip failed")
        name = f"InterTightSmooth{size}"
        out_text = re.sub(
            rf"(const uint8_t {name}\[\] PROGMEM = \{{)(.*?)(\}};)",
            lambda m: m[1] + "\n" + byte_rows(data) + "\n" + m[3], out_text, count=1, flags=re.S)
        fonts[size] = (header, glyphs)
    return out_text, fonts


# --------------------------------------------------------- coverage fonts ---

def encode_coverage(alpha):
    levels = [round(a / 85) for a in alpha]  # same as generate_coverage_fonts.py
    out, index = bytearray(), 0
    while index < len(levels):
        value, run = levels[index], 1
        while index + run < len(levels) and run < 64 and levels[index + run] == value:
            run += 1
        out.append(value << 6 | (run - 1))
        index += run
    return bytes(out)


def coverage_assets(source_text, smooth):
    text = source_text
    for size, src_size in COVERAGE_SOURCES.items():
        pixels_m = re.search(rf"const uint8_t coveragePixels{size}\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
        glyphs_m = re.search(rf"const CoverageGlyph coverageGlyphs{size}\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
        pixels = bytearray(hex_bytes(pixels_m[1]))
        records = [list(map(int, r.split(","))) for r in re.findall(r"\{([^{}]+)\}", glyphs_m[1])]
        records = [r for r in records if not SUBSCRIPT_SLOT <= r[1] < SUBSCRIPT_SLOT + 10]
        zero = next(r for r in records if r[1] == ord("0"))
        src = digits(smooth[src_size][1])
        scale = target_scale(src, zero[3])
        for d in range(10):
            w, h, adv, dx, top, alpha = subscript(src[d], scale, size)
            records.append([len(pixels), SUBSCRIPT_SLOT + d, w, h, adv, dx, -top])
            pixels += encode_coverage(alpha)
        records.sort(key=lambda r: r[1])
        table = "\n".join("  {" + ", ".join(map(str, r)) + "}," for r in records)
        text = text[:pixels_m.start(1)] + "\n" + byte_rows(pixels, lower=True) + "\n" + text[pixels_m.end(1):]
        glyphs_m = re.search(rf"const CoverageGlyph coverageGlyphs{size}\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
        text = text[:glyphs_m.start(1)] + "\n" + table + "\n" + text[glyphs_m.end(1):]
        text, n = re.subn(rf"(coverageFont{size} = \{{coveragePixels{size}, coverageGlyphs{size}, )\d+",
                          lambda m: m[1] + str(len(records)), text)
        if n != 1:
            raise RuntimeError(f"coverage {size}: font object not found")
    # Strip the guard that keeps this generated file out of CAW builds.
    text = text.replace('#include "CoverageFont.h"\n', "", 1)
    text = text.replace("#if !MINI_DISPLAY_FEATURE_CAW\n", "", 1)
    text = text[:text.rindex("#endif  // !MINI_DISPLAY_FEATURE_CAW")]
    return text


# -------------------------------------------------------------- GFX fonts ---

def gfx_assets(source_text, name, size, smooth):
    bitmap_m = re.search(rf"const uint8_t {name}Bitmaps\[\] PROGMEM = \{{(.*?)\}};", source_text, re.S)
    table_m = re.search(rf"const GFXglyph {name}Glyphs\[\] PROGMEM = \{{(.*?)\}};", source_text, re.S)
    bitmap = hex_bytes(bitmap_m[1])
    glyphs = [list(m.groups()) for m in GFX_GLYPH.finditer(table_m[1])]
    if len(glyphs) != 352 or int(glyphs[0][6], 16) != 0x20:
        raise RuntimeError(f"{name}: expected 352 glyphs from U+0020")
    zero_height = int(glyphs[ord("0") - 0x20][2])
    src = digits(smooth[GFX_FONTS[size]][1])
    scale = target_scale(src, zero_height)
    out_bitmap, out_table, before = bytearray(), [], len(bitmap)
    for offset, width, height, advance, dx, dy, code in glyphs:
        code_value = int(code, 16)
        start = len(out_bitmap)
        if SUBSCRIPT_SLOT <= code_value < SUBSCRIPT_SLOT + 10 or code_value in ICONS:
            if code_value in ICONS:
                w, h, adv, sdx, top, alpha = icon(ICONS[code_value], size)
            else:
                w, h, adv, sdx, top, alpha = subscript(src[code_value - SUBSCRIPT_SLOT], scale, size)
            bits = [1 if a >= 128 else 0 for a in alpha]
            for i in range(0, len(bits), 8):
                chunk = bits[i:i + 8] + [0] * (8 - len(bits[i:i + 8]))
                out_bitmap.append(int("".join(map(str, chunk)), 2))
            out_table.append(f"  {{ {start}, {w}, {h}, {adv}, {sdx}, {-top} }}, // U+{code}")
            continue
        offset, width, height = int(offset), int(width), int(height)
        if code_value not in KEEP:
            width = height = 0
            dx = dy = "0"
        out_bitmap += bitmap[offset:offset + (width * height + 7) // 8]
        out_table.append(f"  {{ {start}, {width}, {height}, {advance}, {dx}, {dy} }}, // U+{code}")
    if len(out_bitmap) > 0xFFFF:
        raise RuntimeError(f"{name}: bitmap exceeds 16-bit GFX offsets")
    text = source_text[:bitmap_m.start(1)] + "\n" + byte_rows(out_bitmap) + "\n" + source_text[bitmap_m.end(1):]
    table_m = re.search(rf"const GFXglyph {name}Glyphs\[\] PROGMEM = \{{(.*?)\}};", text, re.S)
    text = text[:table_m.start(1)] + "\n" + "\n".join(out_table) + "\n" + text[table_m.end(1):]
    return text, before, len(out_bitmap)


# ------------------------------------------------------- TFT_eSPI decoder ---

DECODER_PATCHES = (
    (
        "      decoderBuffer |= (c & 0x3F);\n"
        "      decoderState = 0;\n"
        "      return decoderBuffer;\n",
        "      decoderBuffer |= (c & 0x3F);\n"
        "      decoderState = 0;\n"
        "#if MINI_DISPLAY_FEATURE_CAW || CAW_STANDALONE\n"
        "      // Subscript digits are stored in the C1 slots of the CAW fonts.\n"
        "      if (decoderBuffer >= 0x2080 && decoderBuffer <= 0x2089) return decoderBuffer - 0x2000;\n"
        "      if (decoderBuffer == 0xE000 || decoderBuffer == 0xE001) return decoderBuffer - 0xDF76;\n"
        "      if (decoderBuffer == 0x25B6) return 0x8C;\n"
        "#endif\n"
        "      return decoderBuffer;\n",
    ),
    (
        "    c = ((c & 0x0F)<<12) | ((buf[(*index)++]&0x3F)<<6);\n"
        "    return  c | ((buf[(*index)++]&0x3F));\n",
        "    c = ((c & 0x0F)<<12) | ((buf[(*index)++]&0x3F)<<6);\n"
        "    c |= (buf[(*index)++]&0x3F);\n"
        "#if MINI_DISPLAY_FEATURE_CAW || CAW_STANDALONE\n"
        "    // Subscript digits are stored in the C1 slots of the CAW fonts.\n"
        "    if (c >= 0x2080 && c <= 0x2089) c -= 0x2000;\n"
        "    if (c == 0xE000 || c == 0xE001) c -= 0xDF76;\n"
        "    if (c == 0x25B6) c = 0x8C;\n"
        "#endif\n"
        "    return c;\n",
    ),
)


def patch_decoder(path):
    # Always patch from the library's own text so changes to this script
    # apply cleanly to an already patched dependency.
    pristine = path.with_name(path.name + ".caw-orig")
    if not pristine.exists():
        source = path.read_text()
        if "MINI_DISPLAY_FEATURE_CAW" in source:
            raise RuntimeError("TFT_eSPI.cpp is patched but its pristine copy is missing; "
                               "delete .pio/libdeps/sdpro_caw/TFT_eSPI and rebuild")
        pristine.write_text(source)
    updated = pristine.read_text()
    for original, replacement in DECODER_PATCHES:
        if updated.count(original) != 1:
            raise RuntimeError("TFT_eSPI UTF-8 decoder changed; review caw_font_assets.py")
        updated = updated.replace(original, replacement, 1)
    if path.read_text() != updated:
        path.write_text(updated)


def write_if_changed(path, text):
    if not path.exists() or path.read_text() != text:
        path.write_text(text)


def load_index_module(project):
    spec = importlib.util.spec_from_file_location(
        "index_smooth_fonts", project / "scripts" / "index_smooth_fonts.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


if env.PioPlatform().name == "espressif8266":  # noqa: F821
    project = Path(env.subst("$PROJECT_DIR"))  # noqa: F821
    src = Path(env.subst("$PROJECT_SRC_DIR"))  # noqa: F821
    out_root = Path(env.subst("$BUILD_DIR")) / "caw_generated"  # noqa: F821
    out_dir = out_root / "fonts_caw"
    out_dir.mkdir(parents=True, exist_ok=True)

    smooth_text, smooth = smooth_assets((src / "fonts/InterTightSmooth.h").read_text())
    write_if_changed(out_dir / "InterTightSmooth.h", smooth_text)
    index = load_index_module(project)
    write_if_changed(out_dir / "StaticSmoothFonts.inc", index.render_index(smooth_text, guarded=False, sizes=(13, 18, 24)))

    coverage_text = coverage_assets((src / "CoverageFonts.generated.cpp").read_text(), smooth)
    write_if_changed(out_dir / "CoverageFonts.inc", coverage_text)

    report = []
    for size in GFX_FONTS:
        name = "InterTightCompact13" if size == 13 else f"InterTightBold{size}"
        text, before, after = gfx_assets((src / f"fonts/{name}.h").read_text(), name, size, smooth)
        write_if_changed(out_dir / f"{name}.h", text)
        report.append(f"{size}px {before}->{after}")

    library = Path(env.subst("$PROJECT_LIBDEPS_DIR")) / env.subst("$PIOENV") / "TFT_eSPI"  # noqa: F821
    patch_decoder(library / "TFT_eSPI.cpp")
    env.Prepend(CPPPATH=[str(out_root)])  # noqa: F821
    print("CAW fonts: subscripts U+2080-2089 in C1 slots; GFX bitmap bytes " + ", ".join(report))
