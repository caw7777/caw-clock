"""Generate the built-in CAW dashboard embedded in firmware/src/main.cpp.

Usage: python3 firmware/scripts/caw_dashboard.py --write
  Rewrites the R"CAWDASH(...)CAWDASH" literal in main.cpp. Bump
  kCawLayoutVersion there so clocks reinstall the new layout.

Constraints checked here: at most 18 cards (kMaxSceneCards) and a page of at
most 6 KiB (DashboardPageLoader::kMaximumPageBytes). Free-layout font sizes
come from frame size (FreeTextSizing.h): 18 px needs 23-29 px of height,
13 px (compact) results below 23 px, and size 3 is drawn with the 48 px
coverage font. Preview with scripts/preview_caw_layout.py.
"""
import json, re, sys
from pathlib import Path
W, G, R, GRAY, DIV, BOX, BG = "#F5F5F5", "#2FD655", "#FF4D4D", "#9AA0A6", "#3A3F47", "#D0D0D0", "#000000"
def f(x, y, w, h): return {"x": x, "y": y, "width": w, "height": h}
def vs(align="left", fg=None, title=False, **k):
    # Firmware defaults: white text; values centre vertically, titles do not.
    d = {"horizontalAlign": align, "marquee": False}
    if fg: d["foreground"] = fg
    if title: d["verticalAlign"] = "middle"
    d.update(k); return d
sign = [{"operator": "starts_with", "match": "-", "foreground": R}, {"operator": "starts_with", "match": "+", "foreground": G}]
T = {"transparentBackground": True}
opaque = {"style": {"background": BG}}
def box(i, x, title, src):
    return {"id": i, "type": "text", "source": src, "title": title, "frame": f(x, 72.1, 32, 17.5),
            "titleFrame": f(x + .5, 72.5, 31, 7.5), "valueFrame": f(x + .5, 80.2, 31, 9.6),
            "style": {"background": BG, "border": BOX, "borderStyle": "solid", "radius": "medium"},
            "titleStyle": vs("center", GRAY, True), "valueStyle": vs("center")}
def change(label, x, labelw, src):
    # Separate label card: a colour mapping would also recolour a card title.
    return [{"type": "text", "text": label, "frame": f(x, 47.3, labelw, 7.9), **T, "valueStyle": vs("left", GRAY)},
            {"type": "text", "source": src, "frame": f(x + labelw, 45.85, 31, 10.8), **T, "valueStyle": vs(),
             "colorMappings": sign}]
cards = [
    {"id": "logo", "type": "image", "image": "LOGO_ID", "imageFit": "contain", "frame": f(2, 2, 20, 20)},
    # Title/value pairs keep the header within the 18-card page limit.
    {"type": "text", "title": "crow with", "text": "caw / wcro", "frame": f(22, 2, 44, 21.5),
     "titleFrame": f(22, 2, 39, 11), "valueFrame": f(22, 12.5, 44, 11), **T,
     "titleStyle": vs("left", W, True), "valueStyle": vs()},
    # "knife" is always red, so the Wi-Fi mapping (red when offline) cannot change it.
    {"type": "text", "title": "knife", "source": "sensor.caw_wifi_status_display", "frame": f(58.4, 2, 41.6, 21.5),
     "titleFrame": f(58.4, 2, 21, 11), "valueFrame": f(88.5, 12.5, 11, 11), **T,
     "titleStyle": vs("left", R, True), "valueStyle": vs("right"),
     "colorMappings": [{"operator": "equals", "match": "\ue001", "foreground": R}]},
    {"id": "clock", "type": "clock", "format": "24h", "showDate": False, "frame": f(76.5, 2, 23, 11), **T, "valueStyle": vs("right")},
    {"id": "rule1", "type": "text", "text": " ", "frame": f(2, 24.2, 96, 2), "style": {"background": DIV}},
    # Size 3 in the CAW build is measured with the 36 px GFX font but drawn with
    # the 48 px coverage font; bottom alignment in 51 px fits its digits and subscript.
    {"id": "price", "type": "text", "source": "sensor.caw_usd_price_display", "frame": f(1, 24.6, 98, 21.3), **opaque,
     "valueStyle": vs(verticalAlign="bottom")},
    *change("1H", 1, 9, "sensor.caw_change_1h_display"),
    *change("24H", 42, 14, "sensor.caw_change_24h_display"),
    # Drawn before the chart, which covers all but its bottom row (no gaps show
    # between the boxes below).
    {"id": "rule2", "type": "text", "text": " ", "frame": f(2, 70, 96, 2), "style": {"background": DIV}},
    {"id": "chart", "type": "chart", "source": "sensor.caw_usd_price_display", "frame": f(1, 57, 98, 14.6), **opaque,
     "graph": {"source": "sensor.caw_usd_price_display", "colorSource": "sensor.caw_change_24h_display", "type": "line",
               "aggregation": "mean", "points": 48, "intervalSeconds": 1800, "color": G, "opacity": 100, "lineWidth": 2,
               "fillOpacity": 30, "gridLines": 0, "scale": "fit", "scalePadding": 8},
     "colorMappings": [sign[0]]},
    box("liq", 1, "liq", "sensor.caw_liquidity_display"),
    box("vol", 34, "vol", "sensor.caw_volume_24h_display"),
    box("mcap", 67, "mcap", "sensor.caw_market_cap_display"),
    {"id": "ring", "type": "text", "source": "sensor.caw_trend_display", "valueMappings": [{"operator": "contains", "match": "", "value": " "}] if False else None,
     "frame": f(1, 90, 98, 10), "style": {"background": G, "foreground": G, "radius": "medium"},
     "valueStyle": vs(),
     "colorMappings": [{"operator": "equals", "match": "down", "background": R, "foreground": R},
                       {"operator": "equals", "match": "stale", "background": GRAY, "foreground": GRAY}]},
    {"id": "ticker", "type": "text", "source": "sensor.caw_ticker_display", "frame": f(1.85, 90.85, 96.3, 8.4),
     "style": {"background": BG, "radius": "medium"}, "valueStyle": vs()},
    {"id": "moves", "type": "text", "source": "sensor.caw_ticker_changes_display", "frame": f(55, 90.85, 42.5, 8.4), **T,
     "valueStyle": vs("right"), "colorMappings": sign},
]
for c in cards:
    if c.get("valueMappings", 1) is None: del c["valueMappings"]
    c.pop("id", None)  # optional; saves page bytes
page = {"id": "caw", "title": "crow with knife", "showTitle": False, "layout": "free", "style": {"background": BG},
        "rows": [{"cards": cards}]}
dash = {"version": 1, "pages": [page]}
text = json.dumps(dash, separators=(",", ":"), ensure_ascii=False)
page_text = json.dumps(page, separators=(",", ":"), ensure_ascii=False)
print("cards", len(cards), "dashboard bytes", len(text.encode()), "page bytes", len(page_text.encode()), file=sys.stderr)
assert len(cards) <= 18 and len(page_text.encode()) <= 6144
if sys.argv[1:] == ["--write"]:
    main = Path(__file__).resolve().parents[1] / "src/main.cpp"
    source = main.read_text()
    updated, count = re.subn(r'R"CAWDASH\((.*?)\)CAWDASH"', lambda m: 'R"CAWDASH(' + text + ')CAWDASH"', source, flags=re.S)
    assert count == 1
    main.write_text(updated)
elif sys.argv[1:]:
    Path(sys.argv[1]).write_text(text)
else:
    print(text)
