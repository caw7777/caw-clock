declare const __MINI_DISPLAY_FEATURE_TLS__: boolean;
declare const __MINI_DISPLAY_FEATURE_CAW__: boolean;

export const features = {
  tls: __MINI_DISPLAY_FEATURE_TLS__,
  caw: __MINI_DISPLAY_FEATURE_CAW__,
} as const;
