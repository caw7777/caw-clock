# JUZIPi SD PRO, ESP32-C2 board ("SDC2") pinout

Found 2026-11-22 by disassembling the factory firmware (SDC2 V1.2.0,
Arduino + TFT_eSPI) and confirmed on the owner's clock with caw-probe-c2.

| Function | Value |
| --- | --- |
| MCU | ESP32-C2 (ESP8684) rev v2.0, 26 MHz crystal |
| Flash | 4 MB (64 KB MMU pages) |
| Display | ST7789, 240 x 240, SPI mode 3, colour inversion on, RGB |
| SPI SCLK | GPIO1 (FSPICLK, signal 63) |
| SPI MOSI | GPIO2 (FSPID, signal 65) |
| MISO / CS | not connected (CS tied low) |
| Display DC | GPIO0 |
| Display reset | GPIO3 (high, low 20 ms, high, 150 ms: TFT_eSPI's pattern) |
| Backlight | GPIO5, **active LOW** (factory firmware holds it high, i.e. off, during init) |
| Visible rows | panel rows 3-242: picture scrolled up 3 rows (VSCRSADD 3), else the last 3 drawn rows hide under the glass |
| Button | GPIO18, INPUT_PULLUP |
| Other output | GPIO7 written low once (unknown) |
| USB | power only (no USB-serial bridge) |

Factory partition table (before CAW Clock re-lays it): nvs 0x9000 (20 KB), otadata 0xe000 (8 KB),
app0 0x10000 (768 KB), app1 0xd0000 (768 KB), spiffs 0x190000 (2496 KB).
Factory OTA: POST /update_ota, field "update", file name must start with
SDC2, image checked by Update (ESP32-C2 chip id, 4 MB / 64 KB pages); app
descriptor of the factory image is zeroed. /config returns the Wi-Fi password
without authentication.

Not the GeekMagic SmallTV ESP32-C2 wiring (pinout-geekmagic-smalltv-esp32c2.md).

CAW Clock layout (after the one-time re-layout, caw-c2): nvs and otadata unchanged,
app0 0x10000 and app1 0x190000 (1536 KB each), spiffs 0x310000 (960 KB).
