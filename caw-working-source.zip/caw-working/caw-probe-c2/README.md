# CAW probe for the ESP32-C2 clocks ("SDC2")

Newer JUZIPi SD PRO clocks have an ESP32-C2 (router name `esp32c2-XXXXXX`)
and a factory updater that only takes files named `SDC2...`. CAW Clock is
ESP8266 firmware and does not run on them. This probe finds out what the
port needs, and keeps the way back to the factory firmware open.

Install: factory web page -> Firmware Update (OTA) -> `SDC2_V1.0.bin` (probe 4: 4 MB flash layout, 64 KB pages).

Then join the open Wi-Fi `CAW-Probe-XXXX` and open http://192.168.4.1 (or
the clock's address on the home Wi-Fi, if the factory firmware had saved it):

- chip, crystal check, flash size, partition table;
- display test: wirings 1-4 (1 = GeekMagic SmallTV ESP32-C2: MOSI 6, SCLK 4,
  DC 5, reset 1, no CS, backlight 18 active low, SPI mode 3, inverted) and
  any other wiring;
- backup downloads: the factory firmware's partition and the whole flash;
- "Return to the factory firmware" (it stays in its own partition);
- install another firmware (into the factory firmware's partition).

History: probes 1-2 (2 MB, 32 KB pages) were refused by the factory
updater ("Firmware checksum/validation failed"). Probe 3 (4 MB) installed but
never started: built for a 40 MHz crystal, it stopped at ESP-IDF's start-up
assert that the bootloader's crystal equals CONFIG_XTAL_FREQ (the clock's is
most likely 26 MHz), before any of its own safety code ran. That clock needs a
USB-serial adapter to switch back (its USB port has no data).

Safety in probe 4:
- assertions off and the clocks follow the bootloader's stored crystal, so the
  build's crystal setting cannot stop it (built for 26 MHz anyway);
- a restart counter in its own partition: 3 starts in a row without running
  Wi-Fi and it switches back to the factory firmware;
- switching back writes the boot choice directly if esp_ota_set_boot_partition
  refuses;
- Wi-Fi and the page start first, no error aborts, the display comes last;
- task watchdog resets a hang (which then counts as a failed start);
- if nobody opens the page within 15 minutes it switches back;
- nothing of the factory firmware is erased.
Not covered: a crash before app_main (nothing of ours runs there).

Build: ESP-IDF 5.5 through pioarduino's platform (the official PlatformIO
platform has no ESP32-C2), which needs PlatformIO Core 6.2 (develop):
`pip install git+https://github.com/platformio/platformio-core@develop`, then
`pio run` here. Output: `.pio/build/sdc2_probe/firmware.bin`.
