idf_component_register(SRCS "main.c" INCLUDE_DIRS "."
  REQUIRES esp_wifi esp_netif esp_event nvs_flash esp_http_server app_update
           spi_flash esp_lcd esp_driver_gpio esp_driver_spi esp_timer esp_partition
           bootloader_support esp_hw_support esp_app_format)
