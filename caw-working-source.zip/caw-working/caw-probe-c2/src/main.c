// CAW Clock probe for the ESP32-C2 clocks (factory updater asks for "SDC2"
// file names). Installed through the factory updater, it finds out what the
// CAW Clock port needs to know, and keeps the way back open:
//
//   - an open Wi-Fi network "CAW-Probe-XXXX" with a page at 192.168.4.1
//     (and the home Wi-Fi the factory firmware saved, if it can join it);
//   - chip, crystal, flash and partition report;
//   - a display test with the likely wirings (and any other) to choose from;
//   - download of the factory firmware and of the whole flash, as a backup;
//   - "Return to the factory firmware" (it stays in its own partition);
//   - upload of the next firmware.
//
// Safety: the probe never erases anything of the factory firmware. It writes
// only the boot choice (otadata), a restart counter in its own partition
// and, on request, an upload. The clock goes back to the factory firmware by
// itself after 3 starts that did not reach a running Wi-Fi, or when nobody
// opens the page within 15 minutes.
//
// Crystal: ESP-IDF asserts at start-up that the crystal frequency stored by
// the bootloader equals CONFIG_XTAL_FREQ. Probe 3 was built for 40 MHz and
// never started (the clock's bootloader says otherwise: 26 MHz, most likely).
// Assertions are off in this build, and the clocks follow the bootloader's
// stored value at run time, so the probe runs whatever the crystal is.

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_app_desc.h"
#include "esp_chip_info.h"
#include "esp_event.h"
#include "esp_flash.h"
#include "esp_flash_encrypt.h"
#include "esp_http_server.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_st7789.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_secure_boot.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_rom_crc.h"
#include "nvs_flash.h"
#include "sdkconfig.h"
#include "soc/rtc.h"

static const char *TAG = "probe";
#define PROBE_VERSION "4"

// ------------------------------------------------------------------ state ---

typedef struct {
  int mosi, sclk, dc, rst, cs, bl;
  int bl_high;   // backlight on = high level
  int mode;      // SPI mode 0..3
  int invert;    // colour inversion
  int bgr;       // BGR element order
  int x_gap, y_gap;
  int mhz;
} wiring_t;

// Likely wirings. 1: the GeekMagic SmallTV ESP32-C2 (ST7789V, no CS, mode 3).
static const wiring_t kPresets[] = {
    {6, 4, 5, 1, -1, 18, 0, 3, 1, 0, 0, 0, 20},
    {6, 4, 5, 1, -1, 18, 1, 3, 1, 0, 0, 0, 20},
    {6, 4, 5, 1, -1, 18, 0, 0, 1, 0, 0, 0, 20},
    {6, 4, 5, 1, -1, 18, 0, 3, 0, 1, 0, 0, 20},
};
#define PRESET_COUNT (sizeof(kPresets) / sizeof(kPresets[0]))

static wiring_t g_wiring;
static int g_preset = 1;  // 1-based; 0 = custom
static char g_display_note[96] = "not started";
static bool g_backlight_on = true;

static esp_lcd_panel_io_handle_t g_io;
static esp_lcd_panel_handle_t g_panel;
static bool g_bus_ready;

static char g_ap_ssid[24];
static char g_sta_ssid[33];
static char g_sta_ip[16] = "";
static uint32_t g_slow_hz;
static uint32_t g_boot_xtal_mhz;
static bool g_xtal_ok = true;
static uint32_t g_restarts;  // starts in a row that did not get Wi-Fi running
static volatile bool g_page_seen;
static const esp_partition_t *g_factory;  // the app partition we did not boot from

// --------------------------------------------------------------- the font ---
// 5 x 7, columns, bit 0 = top. Enough for the probe's lines.

typedef struct { char c; uint8_t col[5]; } glyph_t;
static const glyph_t kFont[] = {
    {' ', {0, 0, 0, 0, 0}},           {'.', {0, 0x60, 0x60, 0, 0}},
    {'-', {8, 8, 8, 8, 8}},           {':', {0, 0x36, 0x36, 0, 0}},
    {'/', {0x20, 0x10, 8, 4, 2}},     {'0', {0x3E, 0x51, 0x49, 0x45, 0x3E}},
    {'1', {0, 0x42, 0x7F, 0x40, 0}},  {'2', {0x42, 0x61, 0x51, 0x49, 0x46}},
    {'3', {0x21, 0x41, 0x45, 0x4B, 0x31}}, {'4', {0x18, 0x14, 0x12, 0x7F, 0x10}},
    {'5', {0x27, 0x45, 0x45, 0x45, 0x39}}, {'6', {0x3C, 0x4A, 0x49, 0x49, 0x30}},
    {'7', {1, 0x71, 9, 5, 3}},        {'8', {0x36, 0x49, 0x49, 0x49, 0x36}},
    {'9', {6, 0x49, 0x49, 0x29, 0x1E}}, {'A', {0x7E, 0x11, 0x11, 0x11, 0x7E}},
    {'B', {0x7F, 0x49, 0x49, 0x49, 0x36}}, {'C', {0x3E, 0x41, 0x41, 0x41, 0x22}},
    {'D', {0x7F, 0x41, 0x41, 0x22, 0x1C}}, {'E', {0x7F, 0x49, 0x49, 0x49, 0x41}},
    {'F', {0x7F, 9, 9, 9, 1}},        {'G', {0x3E, 0x41, 0x49, 0x49, 0x7A}},
    {'H', {0x7F, 8, 8, 8, 0x7F}},     {'I', {0, 0x41, 0x7F, 0x41, 0}},
    {'J', {0x20, 0x40, 0x41, 0x3F, 1}}, {'K', {0x7F, 8, 0x14, 0x22, 0x41}},
    {'L', {0x7F, 0x40, 0x40, 0x40, 0x40}}, {'M', {0x7F, 2, 0xC, 2, 0x7F}},
    {'N', {0x7F, 4, 8, 0x10, 0x7F}},  {'O', {0x3E, 0x41, 0x41, 0x41, 0x3E}},
    {'P', {0x7F, 9, 9, 9, 6}},        {'Q', {0x3E, 0x41, 0x51, 0x21, 0x5E}},
    {'R', {0x7F, 9, 0x19, 0x29, 0x46}}, {'S', {0x46, 0x49, 0x49, 0x49, 0x31}},
    {'T', {1, 1, 0x7F, 1, 1}},        {'U', {0x3F, 0x40, 0x40, 0x40, 0x3F}},
    {'V', {0x1F, 0x20, 0x40, 0x20, 0x1F}}, {'W', {0x3F, 0x40, 0x38, 0x40, 0x3F}},
    {'X', {0x63, 0x14, 8, 0x14, 0x63}}, {'Y', {7, 8, 0x70, 8, 7}},
    {'Z', {0x61, 0x51, 0x49, 0x45, 0x43}},
};

static const uint8_t *glyph(char c) {
  if (c >= 'a' && c <= 'z') c -= 32;
  for (size_t i = 0; i < sizeof(kFont) / sizeof(kFont[0]); ++i)
    if (kFont[i].c == c) return kFont[i].col;
  return kFont[0].col;
}

// ---------------------------------------------------------------- drawing ---

typedef struct { int x, y, scale; uint16_t color; char text[24]; } line_t;
static line_t g_lines[8];
static int g_line_count;

static uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

static void add_line(int x, int y, int scale, uint16_t color, const char *text) {
  if (g_line_count >= (int)(sizeof(g_lines) / sizeof(g_lines[0]))) return;
  line_t *l = &g_lines[g_line_count++];
  l->x = x; l->y = y; l->scale = scale; l->color = color;
  snprintf(l->text, sizeof(l->text), "%s", text);
}

static uint16_t pixel(int x, int y) {
  const uint16_t white = rgb(255, 255, 255);
  if (x < 3 || y < 3 || x > 236 || y > 236) return white;        // frame
  if ((x < 14 && y < 14) || (x > 225 && y > 225)) return rgb(255, 200, 0);  // corners
  for (int i = 0; i < g_line_count; ++i) {
    const line_t *l = &g_lines[i];
    const int cw = 6 * l->scale, len = (int)strlen(l->text);
    if (y < l->y || y >= l->y + 7 * l->scale || x < l->x || x >= l->x + cw * len) continue;
    const int index = (x - l->x) / cw, cx = ((x - l->x) % cw) / l->scale;
    const int cy = (y - l->y) / l->scale;
    if (cx < 5 && (glyph(l->text[index])[cx] >> cy) & 1) return l->color;
  }
  if (y >= 150 && y < 180) return rgb(255, 0, 0);
  if (y >= 180 && y < 205) return rgb(0, 255, 0);
  if (y >= 205 && y < 230) return rgb(0, 0, 255);
  return 0;
}

static void draw_screen(void) {
  if (!g_panel) return;
  enum { STRIP = 20 };
  uint16_t *buf = heap_caps_malloc(240 * STRIP * 2, MALLOC_CAP_DMA);
  if (!buf) return;
  for (int y0 = 0; y0 < 240; y0 += STRIP) {
    for (int y = 0; y < STRIP; ++y)
      for (int x = 0; x < 240; ++x) {
        const uint16_t c = pixel(x, y0 + y);
        buf[y * 240 + x] = (uint16_t)((c >> 8) | (c << 8));  // the panel wants MSB first
      }
    esp_lcd_panel_draw_bitmap(g_panel, 0, y0, 240, y0 + STRIP, buf);
  }
  heap_caps_free(buf);
}

static void compose_and_draw(void) {
  g_line_count = 0;
  char text[24];
  add_line(12, 12, 3, rgb(255, 255, 255), "CAW PROBE");
  add_line(12, 44, 2, rgb(255, 200, 0), "WI-FI:");
  add_line(12, 62, 2, rgb(255, 255, 255), g_ap_ssid);
  add_line(12, 84, 2, rgb(255, 200, 0), "OPEN:");
  add_line(12, 102, 2, rgb(255, 255, 255), g_sta_ip[0] ? g_sta_ip : "192.168.4.1");
  if (g_preset) snprintf(text, sizeof(text), "WIRING %d", g_preset);
  else snprintf(text, sizeof(text), "WIRING CUSTOM");
  add_line(12, 126, 2, rgb(150, 150, 150), text);
  add_line(160, 158, 2, rgb(255, 255, 255), "RED");
  add_line(148, 184, 2, rgb(0, 0, 0), "GREEN");
  add_line(154, 210, 2, rgb(255, 255, 255), "BLUE");
  draw_screen();
}

static bool pin_ok(int pin) {
  // ESP32-C2: GPIO 0..20; 11 to 17 belong to the flash.
  return pin == -1 || (pin >= 0 && pin <= 20 && !(pin >= 11 && pin <= 17));
}

static void set_backlight(bool on) {
  g_backlight_on = on;
  if (g_wiring.bl < 0) return;
  gpio_set_level(g_wiring.bl, on ? g_wiring.bl_high : !g_wiring.bl_high);
}

static void display_stop(void) {
  if (g_panel) { esp_lcd_panel_del(g_panel); g_panel = NULL; }
  if (g_io) { esp_lcd_panel_io_del(g_io); g_io = NULL; }
  if (g_bus_ready) { spi_bus_free(SPI2_HOST); g_bus_ready = false; }
}

static void display_start(const wiring_t *w) {
  display_stop();
  const int pins[] = {w->mosi, w->sclk, w->dc, w->rst, w->cs, w->bl};
  for (size_t i = 0; i < sizeof(pins) / sizeof(pins[0]); ++i)
    if (!pin_ok(pins[i]) || (i < 3 && pins[i] < 0)) {
      snprintf(g_display_note, sizeof(g_display_note), "pin %d not allowed", pins[i]);
      return;
    }
  g_wiring = *w;
  if (w->bl >= 0) {
    gpio_reset_pin(w->bl);
    gpio_set_direction(w->bl, GPIO_MODE_OUTPUT);
    set_backlight(g_backlight_on);
  }
  spi_bus_config_t bus = {
      .mosi_io_num = w->mosi, .miso_io_num = -1, .sclk_io_num = w->sclk,
      .quadwp_io_num = -1, .quadhd_io_num = -1, .max_transfer_sz = 240 * 20 * 2,
  };
  esp_err_t err = spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO);
  if (err != ESP_OK) {
    snprintf(g_display_note, sizeof(g_display_note), "SPI bus: %s", esp_err_to_name(err));
    return;
  }
  g_bus_ready = true;
  esp_lcd_panel_io_spi_config_t io = {
      .dc_gpio_num = w->dc, .cs_gpio_num = w->cs,
      .pclk_hz = (uint32_t)(w->mhz > 0 && w->mhz <= 80 ? w->mhz : 20) * 1000 * 1000,
      .lcd_cmd_bits = 8, .lcd_param_bits = 8, .spi_mode = w->mode & 3,
      .trans_queue_depth = 4,
  };
  err = esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)SPI2_HOST, &io, &g_io);
  if (err == ESP_OK) {
    esp_lcd_panel_dev_config_t dev = {
        .reset_gpio_num = w->rst,
        .rgb_ele_order = w->bgr ? LCD_RGB_ELEMENT_ORDER_BGR : LCD_RGB_ELEMENT_ORDER_RGB,
        .bits_per_pixel = 16,
    };
    err = esp_lcd_new_panel_st7789(g_io, &dev, &g_panel);
  }
  if (err == ESP_OK) err = esp_lcd_panel_reset(g_panel);
  if (err == ESP_OK) err = esp_lcd_panel_init(g_panel);
  if (err == ESP_OK) err = esp_lcd_panel_invert_color(g_panel, w->invert);
  if (err == ESP_OK) err = esp_lcd_panel_set_gap(g_panel, w->x_gap, w->y_gap);
  if (err == ESP_OK) err = esp_lcd_panel_disp_on_off(g_panel, true);
  if (err != ESP_OK) {
    snprintf(g_display_note, sizeof(g_display_note), "panel: %s", esp_err_to_name(err));
    display_stop();
    return;
  }
  snprintf(g_display_note, sizeof(g_display_note), "drawn");
  compose_and_draw();
}

// ------------------------------------------------------------------ chip ---

// The bootloader stores the crystal frequency; the clocks follow it. The RC
// slow clock (about 136 kHz) measured against it is a cross-check.
static void check_crystal(void) {
  g_boot_xtal_mhz = (uint32_t)rtc_clk_xtal_freq_get();
  const uint32_t period = rtc_clk_cal(RTC_CAL_RTC_MUX, 1024);  // us, Q13.19
  g_slow_hz = period ? (uint32_t)((1000000ULL << 19) / period) : 0;
  g_xtal_ok = g_slow_hz > 90000 && g_slow_hz < 200000;
}

static void find_factory(void) {
  const esp_partition_t *running = esp_ota_get_running_partition();
  esp_partition_iterator_t it =
      esp_partition_find(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_ANY, NULL);
  for (; it; it = esp_partition_next(it)) {
    const esp_partition_t *p = esp_partition_get(it);
    esp_app_desc_t desc;
    if (p->address != running->address && esp_ota_get_partition_description(p, &desc) == ESP_OK) {
      g_factory = p;
      break;
    }
  }
  if (it) esp_partition_iterator_release(it);
}

// Writes the boot choice directly, the way the bootloader reads it, without
// the image check esp_ota_set_boot_partition does first (in case that check
// disagrees with the factory firmware's image).
static esp_err_t select_directly(const esp_partition_t *app) {
  const esp_partition_t *otadata =
      esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, NULL);
  if (!otadata || otadata->size < 0x2000) return ESP_FAIL;
  if (app->subtype == ESP_PARTITION_SUBTYPE_APP_FACTORY)  // no otadata = factory app
    return esp_partition_erase_range(otadata, 0, 0x2000);
  if (app->subtype < ESP_PARTITION_SUBTYPE_APP_OTA_MIN || app->subtype > ESP_PARTITION_SUBTYPE_APP_OTA_MAX)
    return ESP_FAIL;
  uint32_t slots = 0;
  esp_partition_iterator_t it =
      esp_partition_find(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_ANY, NULL);
  for (; it; it = esp_partition_next(it))
    if (esp_partition_get(it)->subtype >= ESP_PARTITION_SUBTYPE_APP_OTA_MIN &&
        esp_partition_get(it)->subtype <= ESP_PARTITION_SUBTYPE_APP_OTA_MAX) ++slots;
  if (it) esp_partition_iterator_release(it);
  if (!slots) return ESP_FAIL;
  esp_ota_select_entry_t entries[2];
  uint32_t newest = 0;
  int older = 0;
  for (int i = 0; i < 2; ++i) {
    esp_partition_read(otadata, i * 0x1000, &entries[i], sizeof(entries[i]));
    const bool valid = entries[i].ota_seq != 0xFFFFFFFF &&
                       entries[i].crc == esp_rom_crc32_le(UINT32_MAX, (const uint8_t *)&entries[i].ota_seq, 4);
    if (valid && entries[i].ota_seq > newest) { newest = entries[i].ota_seq; older = 1 - i; }
  }
  const uint32_t wanted = app->subtype - ESP_PARTITION_SUBTYPE_APP_OTA_MIN;
  uint32_t seq = newest + 1;
  while ((seq - 1) % slots != wanted) ++seq;
  esp_ota_select_entry_t entry;
  memset(&entry, 0xFF, sizeof(entry));
  entry.ota_seq = seq;
  entry.ota_state = ESP_OTA_IMG_VALID;
  entry.crc = esp_rom_crc32_le(UINT32_MAX, (const uint8_t *)&entry.ota_seq, 4);
  esp_err_t err = esp_partition_erase_range(otadata, older * 0x1000, 0x1000);
  if (err == ESP_OK) err = esp_partition_write(otadata, older * 0x1000, &entry, sizeof(entry));
  return err;
}

static void return_to_factory(const char *why) {
  ESP_LOGW(TAG, "back to the factory firmware: %s", why);
  if (!g_factory) return;
  if (esp_ota_set_boot_partition(g_factory) != ESP_OK && select_directly(g_factory) != ESP_OK) return;
  vTaskDelay(pdMS_TO_TICKS(1500));
  esp_restart();
}

// Restart counter in the last 4 KB of the probe's own partition (the probe is
// far smaller than the partition). Counts starts until Wi-Fi runs.
#define COUNTER_MAGIC 0x43415750u  // "CAWP"
typedef struct { uint32_t magic, count; } counter_t;

static const esp_partition_t *counter_partition(void) {
  const esp_partition_t *p = esp_ota_get_running_partition();
  return p && p->size >= 0x100000 ? p : NULL;  // only with room to spare
}

static uint32_t counter_bump(void) {
  const esp_partition_t *p = counter_partition();
  if (!p) return 0;
  counter_t c = {0};
  esp_partition_read(p, p->size - 0x1000, &c, sizeof(c));
  c.count = c.magic == COUNTER_MAGIC && c.count < 100 ? c.count + 1 : 1;
  c.magic = COUNTER_MAGIC;
  if (esp_partition_erase_range(p, p->size - 0x1000, 0x1000) == ESP_OK)
    esp_partition_write(p, p->size - 0x1000, &c, sizeof(c));
  return c.count;
}

static void counter_clear(void) {
  const esp_partition_t *p = counter_partition();
  if (p) esp_partition_erase_range(p, p->size - 0x1000, 0x1000);
}

// ------------------------------------------------------------------- wifi ---

static void on_event(void *arg, esp_event_base_t base, int32_t id, void *data) {
  if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
    g_sta_ip[0] = 0;
    vTaskDelay(pdMS_TO_TICKS(5000));
    esp_wifi_connect();
  } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
    const ip_event_got_ip_t *e = data;
    snprintf(g_sta_ip, sizeof(g_sta_ip), IPSTR, IP2STR(&e->ip_info.ip));
    compose_and_draw();
  }
}

static void wifi_start(void) {
  esp_netif_init();
  esp_event_loop_create_default();
  esp_netif_create_default_wifi_ap();
  esp_netif_create_default_wifi_sta();
  // NVS: read only what is there (the factory firmware's saved Wi-Fi);
  // never erase it. Without NVS, Wi-Fi runs without it.
  const bool nvs = nvs_flash_init() == ESP_OK;
  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  cfg.nvs_enable = nvs;
  if (esp_wifi_init(&cfg) != ESP_OK) {
    cfg.nvs_enable = 0;  // e.g. NVS written by another ESP-IDF version
    if (esp_wifi_init(&cfg) != ESP_OK) return;
  }
  wifi_config_t sta = {0};
  if (nvs && esp_wifi_get_config(WIFI_IF_STA, &sta) == ESP_OK)
    snprintf(g_sta_ssid, sizeof(g_sta_ssid), "%s", (const char *)sta.sta.ssid);
  esp_wifi_set_storage(WIFI_STORAGE_RAM);  // nothing the probe sets is saved
  esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, on_event, NULL);
  esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, on_event, NULL);
  uint8_t mac[6];
  esp_read_mac(mac, ESP_MAC_WIFI_SOFTAP);
  snprintf(g_ap_ssid, sizeof(g_ap_ssid), "CAW-Probe-%02X%02X", mac[4], mac[5]);
  wifi_config_t ap = {0};
  memcpy(ap.ap.ssid, g_ap_ssid, strlen(g_ap_ssid));
  ap.ap.ssid_len = strlen(g_ap_ssid);
  ap.ap.channel = 1;
  ap.ap.max_connection = 4;
  ap.ap.authmode = WIFI_AUTH_OPEN;
  esp_wifi_set_mode(g_sta_ssid[0] ? WIFI_MODE_APSTA : WIFI_MODE_AP);
  esp_wifi_set_config(WIFI_IF_AP, &ap);
  if (g_sta_ssid[0]) esp_wifi_set_config(WIFI_IF_STA, &sta);
  if (esp_wifi_start() != ESP_OK) return;
  if (g_sta_ssid[0]) esp_wifi_connect();
}

// ------------------------------------------------------------------- page ---

static void seen(void) {
  if (!g_page_seen) {
    g_page_seen = true;
    esp_ota_mark_app_valid_cancel_rollback();  // someone reached the probe
  }
}

static esp_err_t send_page(httpd_req_t *req) {
  seen();
  char *p = malloc(9000);
  if (!p) return httpd_resp_send_500(req);
  size_t n = 0;
#define OUT(...) n += snprintf(p + n, n < 9000 ? 9000 - n : 0, __VA_ARGS__)
  esp_chip_info_t chip;
  esp_chip_info(&chip);
  uint32_t flash_size = 0, physical = 0;
  esp_flash_get_size(NULL, &flash_size);
  esp_flash_get_physical_size(NULL, &physical);
  uint8_t mac[6];
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  const esp_partition_t *running = esp_ota_get_running_partition();
  esp_app_desc_t fdesc = {0};
  const bool fvalid = g_factory && esp_ota_get_partition_description(g_factory, &fdesc) == ESP_OK;
  OUT("<!doctype html><meta name=viewport content='width=device-width'><title>CAW Probe</title>"
      "<style>body{font:15px sans-serif;background:#0a0d12;color:#eee;max-width:640px;margin:auto;padding:12px}"
      "h2{color:#b79cff;font-size:17px;margin-top:22px}td{padding:2px 8px 2px 0;vertical-align:top}"
      "input{width:46px}button{padding:8px 12px;margin:4px 4px 4px 0}.w{color:#ff9500}</style>"
      "<h1>CAW Probe " PROBE_VERSION "</h1>");
  OUT("<h2>Chip</h2><table>"
      "<tr><td>Chip<td>ESP32-C2 rev v%d.%d, %d core(s)"
      "<tr><td>Crystal<td>%" PRIu32 " MHz (from the bootloader; probe built for %d MHz); slow clock %" PRIu32 " Hz (%s)"
      "<tr><td>Starts before Wi-Fi ran<td>%" PRIu32
      "<tr><td>Flash<td>%" PRIu32 " KB configured, %" PRIu32 " KB detected"
      "<tr><td>MAC<td>%02X:%02X:%02X:%02X:%02X:%02X"
      "<tr><td>Free memory<td>%" PRIu32 " bytes"
      "<tr><td>Secure boot / flash encryption<td>%s / %s"
      "<tr><td>Home Wi-Fi saved by the factory firmware<td>%s %s</table>",
      chip.revision / 100, chip.revision % 100, chip.cores, g_boot_xtal_mhz, CONFIG_XTAL_FREQ, g_slow_hz,
      g_xtal_ok ? "plausible" : "odd", g_restarts, flash_size / 1024, physical / 1024,
      mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], esp_get_free_heap_size(),
      esp_secure_boot_enabled() ? "ON" : "off", esp_flash_encryption_enabled() ? "ON" : "off",
      g_sta_ssid[0] ? g_sta_ssid : "(none)", g_sta_ip[0] ? g_sta_ip : "");
  OUT("<h2>Partitions</h2><table><tr><td><b>Name</b><td><b>Type</b><td><b>Address</b><td><b>Size</b><td>");
  esp_partition_iterator_t it = esp_partition_find(ESP_PARTITION_TYPE_ANY, ESP_PARTITION_SUBTYPE_ANY, NULL);
  for (; it && n < 7000; it = esp_partition_next(it)) {
    const esp_partition_t *q = esp_partition_get(it);
    esp_app_desc_t d;
    const bool app = q->type == ESP_PARTITION_TYPE_APP;
    const bool has = app && esp_ota_get_partition_description(q, &d) == ESP_OK;
    OUT("<tr><td>%s<td>%d/0x%02x<td>0x%06" PRIx32 "<td>%" PRIu32 " KB<td>%s%s%s%s", q->label, q->type, q->subtype,
        q->address, q->size / 1024, q == running || q->address == running->address ? "running: " : "",
        has ? d.project_name : "", has ? " " : "", has ? d.version : "");
  }
  if (it) esp_partition_iterator_release(it);
  OUT("</table>");
  OUT("<h2>Display test</h2><p>The screen should show <b>CAW PROBE</b>, the Wi-Fi name, a white frame with "
      "yellow corners top-left and bottom-right, and three bars: <b>red, green, blue</b> from top to bottom. "
      "Result: <b>%s</b>. Try the wirings until it looks right, then note the number.</p>", g_display_note);
  for (size_t i = 0; i < PRESET_COUNT; ++i)
    OUT("<form method=post action=/display style=display:inline><input type=hidden name=preset value=%u>"
        "<button%s>Wiring %u</button></form>", (unsigned)(i + 1), g_preset == (int)(i + 1) ? " style='outline:2px solid #b79cff'" : "",
        (unsigned)(i + 1));
  OUT("<form method=post action=/backlight style=display:inline><button>Backlight %s</button></form>",
      g_backlight_on ? "off" : "on");
  OUT("<details><summary>Other wiring</summary><form method=post action=/display><table>"
      "<tr><td>MOSI<td><input name=mosi value=%d><td>SCLK<td><input name=sclk value=%d>"
      "<tr><td>DC<td><input name=dc value=%d><td>Reset<td><input name=rst value=%d>"
      "<tr><td>CS<td><input name=cs value=%d><td>Backlight<td><input name=bl value=%d>"
      "<tr><td>Backlight on = high (1/0)<td><input name=blhigh value=%d><td>SPI mode<td><input name=mode value=%d>"
      "<tr><td>Invert (1/0)<td><input name=inv value=%d><td>BGR (1/0)<td><input name=bgr value=%d>"
      "<tr><td>X / Y offset<td><input name=xgap value=%d> <input name=ygap value=%d><td>MHz<td><input name=mhz value=%d>"
      "</table><button>Try this wiring</button></form><p>-1 = not connected. GPIO 11 to 17 are the flash.</p></details>",
      g_wiring.mosi, g_wiring.sclk, g_wiring.dc, g_wiring.rst, g_wiring.cs, g_wiring.bl, g_wiring.bl_high,
      g_wiring.mode, g_wiring.invert, g_wiring.bgr, g_wiring.x_gap, g_wiring.y_gap, g_wiring.mhz);
  OUT("<h2>Back up the factory firmware</h2><p>Do this first and keep the files.</p>"
      "<p><a href=/backup/factory><button>Factory firmware (%s %s)</button></a> "
      "<a href=/backup/flash><button>Whole flash (%" PRIu32 " KB)</button></a></p>",
      fvalid ? fdesc.project_name : "not found", fvalid ? fdesc.version : "", flash_size / 1024);
  OUT("<h2>Factory firmware</h2>"
      "<form method=post action=/factory onsubmit=\"return confirm('Restart into the factory firmware?')\">"
      "<button %s>Return to the factory firmware</button></form>"
      "<p>If nobody opens this page within 15 minutes of a start, the clock returns to it by itself.</p>",
      fvalid ? "" : "disabled");
  OUT("<h2>Install a firmware</h2><p class=w>This replaces the factory firmware's copy on the clock "
      "(partition %s). Back it up first.</p>"
      "<input type=file id=f accept=.bin> <label><input type=checkbox id=ok style=width:auto> I have the backup</label>"
      "<br><button onclick=up()>Install</button> <span id=s></span>"
      "<script>function up(){var f=document.getElementById('f').files[0],s=document.getElementById('s');"
      "if(!f||!document.getElementById('ok').checked){s.textContent='Choose a file and tick the box.';return}"
      "var x=new XMLHttpRequest();x.open('POST','/update');x.upload.onprogress=function(e){s.textContent=Math.round(e.loaded*100/e.total)+'%%'};"
      "x.onload=function(){s.textContent=x.responseText};x.onerror=function(){s.textContent='Upload failed'};x.send(f)}</script>",
      esp_ota_get_next_update_partition(NULL) ? esp_ota_get_next_update_partition(NULL)->label : "?");
#undef OUT
  httpd_resp_set_type(req, "text/html");
  const esp_err_t r = httpd_resp_send(req, p, n < 9000 ? n : 8999);
  free(p);
  return r;
}

static int form_int(const char *body, const char *key, int fallback) {
  char v[12];
  if (httpd_query_key_value(body, key, v, sizeof(v)) != ESP_OK) return fallback;
  return atoi(v);
}

static esp_err_t redirect_home(httpd_req_t *req) {
  httpd_resp_set_status(req, "303 See Other");
  httpd_resp_set_hdr(req, "Location", "/");
  return httpd_resp_send(req, NULL, 0);
}

static esp_err_t post_display(httpd_req_t *req) {
  seen();
  char body[256] = {0};
  const int len = httpd_req_recv(req, body, sizeof(body) - 1);
  if (len <= 0) return httpd_resp_send_500(req);
  const int preset = form_int(body, "preset", 0);
  wiring_t w = g_wiring;
  if (preset >= 1 && preset <= (int)PRESET_COUNT) {
    w = kPresets[preset - 1];
    g_preset = preset;
  } else {
    w.mosi = form_int(body, "mosi", w.mosi); w.sclk = form_int(body, "sclk", w.sclk);
    w.dc = form_int(body, "dc", w.dc); w.rst = form_int(body, "rst", w.rst);
    w.cs = form_int(body, "cs", w.cs); w.bl = form_int(body, "bl", w.bl);
    w.bl_high = form_int(body, "blhigh", w.bl_high); w.mode = form_int(body, "mode", w.mode);
    w.invert = form_int(body, "inv", w.invert); w.bgr = form_int(body, "bgr", w.bgr);
    w.x_gap = form_int(body, "xgap", w.x_gap); w.y_gap = form_int(body, "ygap", w.y_gap);
    w.mhz = form_int(body, "mhz", w.mhz);
    g_preset = 0;
  }
  display_start(&w);
  return redirect_home(req);
}

static esp_err_t post_backlight(httpd_req_t *req) {
  seen();
  set_backlight(!g_backlight_on);
  return redirect_home(req);
}

static esp_err_t stream_flash(httpd_req_t *req, uint32_t start, uint32_t size, const char *name) {
  seen();
  char header[96];
  snprintf(header, sizeof(header), "attachment; filename=\"%s\"", name);
  httpd_resp_set_type(req, "application/octet-stream");
  httpd_resp_set_hdr(req, "Content-Disposition", header);
  uint8_t *buf = malloc(4096);
  if (!buf) return httpd_resp_send_500(req);
  for (uint32_t off = 0; off < size; off += 4096) {
    const uint32_t chunk = size - off < 4096 ? size - off : 4096;
    if (esp_flash_read(NULL, buf, start + off, chunk) != ESP_OK ||
        httpd_resp_send_chunk(req, (const char *)buf, chunk) != ESP_OK) {
      free(buf);
      return ESP_FAIL;
    }
  }
  free(buf);
  return httpd_resp_send_chunk(req, NULL, 0);
}

static esp_err_t get_backup_factory(httpd_req_t *req) {
  if (!g_factory) return httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "No factory firmware found");
  char name[48];
  snprintf(name, sizeof(name), "SDC2-factory-%s.bin", g_factory->label);
  return stream_flash(req, g_factory->address, g_factory->size, name);
}

static esp_err_t get_backup_flash(httpd_req_t *req) {
  uint32_t size = 0;
  esp_flash_get_physical_size(NULL, &size);
  if (!size) esp_flash_get_size(NULL, &size);
  return stream_flash(req, 0, size, "SDC2-whole-flash.bin");
}

static esp_err_t post_factory(httpd_req_t *req) {
  seen();
  if (!g_factory) return httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "No factory firmware found");
  httpd_resp_sendstr(req, "Restarting into the factory firmware.");
  return_to_factory("asked on the page");
  return ESP_OK;
}

static esp_err_t post_update(httpd_req_t *req) {
  seen();
  const esp_partition_t *target = esp_ota_get_next_update_partition(NULL);
  if (!target) return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "No partition to write");
  if (req->content_len > target->size)
    return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "The file is larger than the partition");
  esp_ota_handle_t ota;
  esp_err_t err = esp_ota_begin(target, OTA_SIZE_UNKNOWN, &ota);
  if (err != ESP_OK) return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, esp_err_to_name(err));
  char *buf = malloc(4096);
  int left = req->content_len;
  while (buf && left > 0) {
    const int got = httpd_req_recv(req, buf, left < 4096 ? left : 4096);
    if (got == HTTPD_SOCK_ERR_TIMEOUT) continue;
    if (got <= 0 || esp_ota_write(ota, buf, got) != ESP_OK) { err = ESP_FAIL; break; }
    left -= got;
  }
  free(buf);
  if (err != ESP_OK || left) {
    esp_ota_abort(ota);
    return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Upload failed; nothing changed");
  }
  err = esp_ota_end(ota);  // checks the image (ESP32-C2, checksum)
  if (err == ESP_OK) err = esp_ota_set_boot_partition(target);
  if (err != ESP_OK)
    return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Not a valid ESP32-C2 firmware; not installed");
  httpd_resp_sendstr(req, "Installed. Restarting.");
  vTaskDelay(pdMS_TO_TICKS(1500));
  esp_restart();
  return ESP_OK;
}

static void web_start(void) {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.stack_size = 8192;
  config.max_uri_handlers = 12;
  config.recv_wait_timeout = 20;
  config.send_wait_timeout = 20;
  httpd_handle_t server;
  if (httpd_start(&server, &config) != ESP_OK) return;
  const httpd_uri_t uris[] = {
      {"/", HTTP_GET, send_page, NULL},
      {"/display", HTTP_POST, post_display, NULL},
      {"/backlight", HTTP_POST, post_backlight, NULL},
      {"/backup/factory", HTTP_GET, get_backup_factory, NULL},
      {"/backup/flash", HTTP_GET, get_backup_flash, NULL},
      {"/factory", HTTP_POST, post_factory, NULL},
      {"/update", HTTP_POST, post_update, NULL},
  };
  for (size_t i = 0; i < sizeof(uris) / sizeof(uris[0]); ++i) httpd_register_uri_handler(server, &uris[i]);
}

// ------------------------------------------------------------------- main ---

void app_main(void) {
  find_factory();
  // A start that does not get as far as running Wi-Fi counts; three in a row
  // and the clock goes back to the factory firmware.
  g_restarts = counter_bump();
  if (g_restarts >= 3) return_to_factory("3 starts without Wi-Fi");
  check_crystal();
  snprintf(g_ap_ssid, sizeof(g_ap_ssid), "CAW-Probe");
  wifi_start();
  web_start();
  // Wi-Fi is up; the display comes last (a wrong wiring cannot stop the rest).
  vTaskDelay(pdMS_TO_TICKS(20000));
  counter_clear();
  display_start(&kPresets[0]);
  const int64_t started = esp_timer_get_time();
  while (true) {
    vTaskDelay(pdMS_TO_TICKS(5000));
    if (!g_page_seen && esp_timer_get_time() - started > 15LL * 60 * 1000 * 1000)
      return_to_factory("nobody opened the page within 15 minutes");
  }
}
