// CAW Clock installer for the JUZIPi SD PRO.
//
// A small image that the clock's stock firmware accepts (its update page
// wants a file name starting with "SDP"). It opens a WPA2 setup network whose
// key is shown on the screen; on that network's page the owner picks the
// home Wi-Fi, a clock password and the time zone. The installer then
// downloads one CAW Clock release from GitHub, checks it against the SHA-256
// built into this image, prepares the storage (Wi-Fi, password and time zone
// in the format CAW Clock reads) and installs it. The image is activated only
// after every check passed: its last byte is written last.
//
// Adapted from the Home Assistant Mini Display bootstrap
// (firmware-bootstrap/, MIT, Copyright (c) 2026 Piotr Kochan).

#include <Arduino.h>
#include <DNSServer.h>
#include <EEPROM.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <LittleFS.h>
#include <TFT_eSPI.h>
#include <Updater.h>
#include <WiFiClientSecureBearSSL.h>
#include <bearssl/bearssl_hash.h>

#include <functional>
#include <memory>
#include <new>

#include "CawTimeZones.h"

namespace {

#ifndef CAW_INSTALLER_VERSION
#error "CAW_INSTALLER_VERSION is required"
#endif
#ifndef CAW_INSTALLER_SHA256
#error "CAW_INSTALLER_SHA256 is required"
#endif

constexpr char kVersion[] = CAW_INSTALLER_VERSION;
constexpr char kFirmwareSha256[] = CAW_INSTALLER_SHA256;
static_assert(sizeof(kFirmwareSha256) == 65, "CAW_INSTALLER_SHA256 must be 64 hex characters");
static_assert(sizeof(kVersion) > 1, "CAW_INSTALLER_VERSION must not be empty");
constexpr char kReleaseUrl[] = "https://github.com/caw7777/caw-clock/releases/download/v";

// The same EEPROM layout, magic and checksum as CAW Clock (DeviceSettings).
constexpr uint32_t kConfigMagic = 0x53445034;
constexpr size_t kEepromSize = 512;
constexpr uint32_t kConnectTimeoutMs = 30000;
constexpr uint32_t kDownloadTimeoutMs = 20000;
constexpr uint16_t kDnsPort = 53;
constexpr char kSettingsPath[] = "/caw-settings.json";

struct DeviceConfig {
  uint32_t magic;
  char ssid[33];
  char wifiPassword[65];
  char apiPassword[33];
  char otaPassword[33];
  char hostname[33];
  char username[33];
  uint8_t apiAuthEnabled;
  uint8_t otaAuthEnabled;
  uint8_t wifiRetryLimit;
  uint8_t resetApiAuthOnRecovery;
  uint8_t directOtaEnabled;
  uint8_t reserved[3];
  uint32_t checksum;
};
static_assert(sizeof(DeviceConfig) == 248, "DeviceConfig must match CAW Clock");

enum class Phase : uint8_t { Setup, Connecting, Ready, Downloading, Verifying, Preparing, Failed };

TFT_eSPI display;
ESP8266WebServer server(80);
DNSServer dns;
DeviceConfig config{};
char timezoneRule[64] = "UTC0";
Phase phase = Phase::Setup;
String statusMessage = "Join the setup network";
char networkName[32]{};
char networkKey[11]{};  // 10 characters, as CAW Clock's setup network
uint32_t connectStartedAt = 0;
int progressPercent = -1;
bool installRequested = false;
bool portalRunning = false;

// ------------------------------------------------------------------- screen

constexpr uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  return static_cast<uint16_t>(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}
constexpr uint16_t kBackground = rgb(10, 13, 18);
constexpr uint16_t kPanel = rgb(22, 27, 34);
constexpr uint16_t kPurple = rgb(0x6A, 0x35, 0xD6);
constexpr uint16_t kLilac = rgb(0xB7, 0x9C, 0xFF);
constexpr uint16_t kYellow = rgb(0xFF, 0xD1, 0x66);

String clipped(const String &value, size_t limit = 26) {
  return value.length() <= limit ? value : value.substring(0, limit);
}

void drawFrame(uint16_t accent) {
  display.fillScreen(kBackground);
  display.fillRoundRect(12, 12, 216, 216, 12, kPanel);
  display.fillRoundRect(12, 12, 216, 6, 3, accent);
  display.setTextDatum(MC_DATUM);
  display.setTextColor(TFT_WHITE, kPanel);
  display.drawString("CAW CLOCK", 120, 40, 4);
  display.setTextColor(kLilac, kPanel);
  display.drawString(String("Installer for v") + kVersion, 120, 66, 2);
}

void drawStatus() {
  const uint16_t accent = phase == Phase::Failed ? TFT_RED : kPurple;
  drawFrame(accent);
  display.setTextColor(TFT_WHITE, kPanel);
  if (phase == Phase::Setup || phase == Phase::Ready) {
    display.drawString("Join Wi-Fi network", 120, 96, 2);
    display.drawString(networkName, 120, 118, 2);
    display.setTextColor(kYellow, kPanel);
    display.drawString("Key:", 120, 142, 2);
    display.drawString(networkKey, 120, 162, 4);
    display.setTextColor(TFT_WHITE, kPanel);
    display.drawString("then open 192.168.4.1", 120, 196, 2);
    return;
  }
  display.drawString(clipped(statusMessage), 120, 106, 2);
  if (phase == Phase::Downloading && progressPercent >= 0) {
    display.drawRoundRect(30, 136, 180, 16, 6, TFT_WHITE);
    if (progressPercent > 0)
      display.fillRoundRect(32, 138, progressPercent * 176 / 100, 12, 4, accent);
    display.drawString(String(progressPercent) + "%", 120, 176, 4);
  } else if (phase == Phase::Failed) {
    display.drawString("Open 192.168.4.1", 120, 150, 2);
    display.drawString("on the setup network", 120, 172, 2);
  }
  if (phase != Phase::Failed) {
    display.setTextColor(kYellow, kPanel);
    display.drawString("Do not power off", 120, 206, 2);
  }
}

const char *phaseName() {
  switch (phase) {
    case Phase::Setup: return "setup";
    case Phase::Connecting: return "connecting";
    case Phase::Ready: return "ready";
    case Phase::Downloading: return "downloading";
    case Phase::Verifying: return "verifying";
    case Phase::Preparing: return "preparing";
    case Phase::Failed: return "failed";
  }
  return "failed";
}

void setStatus(Phase next, const String &message, int progress = -1) {
  const bool redraw = next != phase || message != statusMessage || progress != progressPercent;
  phase = next;
  statusMessage = message;
  progressPercent = progress;
  Serial.printf("[installer] %s: %s\n", phaseName(), message.c_str());
  if (redraw) drawStatus();
}

// ------------------------------------------------------------------- config

uint32_t configChecksum(const DeviceConfig &value) {
  const auto *bytes = reinterpret_cast<const uint8_t *>(&value);
  uint32_t hash = 2166136261UL;
  for (size_t index = 0; index < offsetof(DeviceConfig, checksum); ++index) {
    hash ^= bytes[index];
    hash *= 16777619UL;
  }
  return hash;
}

bool saveConfig() {
  config.magic = kConfigMagic;
  config.checksum = configChecksum(config);
  EEPROM.put(0, config);
  return EEPROM.commit();
}

bool timezoneKnown(const char *rule) {
  for (uint8_t index = 0; index < kCawTimeZoneCount; ++index)
    if (strcmp_P(rule, cawTimeZone(index).rule) == 0) return true;
  return false;
}

// CAW Clock's settings file with just the time zone; everything else starts
// at CAW Clock's defaults.
bool writeTimezone() {
  File file = LittleFS.open(kSettingsPath, "w");
  if (!file) return false;
  file.print(F("{\"schemaVersion\":1,\"timezone\":\""));
  file.print(timezoneRule);  // from the list: no quotes or backslashes
  file.print(F("\"}"));
  const bool ok = !file.getWriteError();
  file.close();
  return ok;
}

// --------------------------------------------------------------------- page

const char kPageHead[] PROGMEM = R"HTML(<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CAW Clock installer</title><style>
:root{color-scheme:dark}body{margin:0;background:#0a0d12;color:#eef0f2;font:15px system-ui,sans-serif}
main{max-width:460px;margin:auto;padding:16px}h1{font-size:22px;margin:4px 0 12px}
section{background:#161b22;border:1px solid #2b333d;border-radius:12px;padding:14px;margin:12px 0}
label{display:block;margin:10px 0 4px;color:#aab4c1;font-size:13px}
input,select,button{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #3a444f;background:#0c1117;color:#fff;font-size:15px}
button{margin-top:12px;background:#6a35d6;border:0;font-weight:700}button:disabled{opacity:.45}
.ghost{background:#2b333d}small{color:#8d97a3}.hidden{display:none}#status{color:#ffd166;min-height:20px}
.brand{color:#b79cff;font-weight:800;letter-spacing:.12em;font-size:12px}.warn{color:#ff9a9a}
</style></head><body><main><div class=brand>CAW CLOCK</div><h1>Installer</h1>
<form id=wifi><section><label>Wi-Fi network</label><select name=ssid required><option value="">Tap Scan to list networks</option></select>
<button id=scan type=button class=ghost>Scan Wi-Fi networks</button>
<label>Wi-Fi password</label><input name=wifiPassword type=password maxlength=64>
<label>Clock password (8-32 characters)</label><input name=password type=password minlength=8 maxlength=32 required autocomplete=new-password>
<label>Repeat clock password</label><input name=repeat type=password minlength=8 maxlength=32 required autocomplete=new-password>
<label>Time zone</label><select name=timezone>)HTML";

const char kPageTail[] PROGMEM = R"HTML(</select>
<p id=formError class=warn></p><button>Connect</button>
<small>Sign in to the clock later as <b>admin</b> with this password.</small></section></form>
<section id=release class=hidden><h2 id=title></h2><p>Downloaded from GitHub and checked against its SHA-256 before it is installed.</p>
<p class=warn>The clock's original firmware and its data are replaced. Keep the clock plugged in.</p>
<button id=install type=button></button></section>
<p id=status>Loading...</p><button id=retry type=button class="ghost hidden">Try again</button>
<script>
const f=document.querySelector('#wifi'),rel=document.querySelector('#release'),st=document.querySelector('#status'),
err=document.querySelector('#formError'),inst=document.querySelector('#install'),retry=document.querySelector('#retry'),
scan=document.querySelector('#scan'),ssid=f.elements.ssid;let scanning=false,ver='';
async function post(p,b=''){const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:b});const t=await r.text();if(!r.ok)throw new Error(t);return t}
async function readScan(){try{const r=await fetch('/networks',{cache:'no-store'});if(r.status===202){setTimeout(readScan,700);return}
if(!r.ok)throw 0;const n=await r.json();ssid.replaceChildren(Object.assign(document.createElement('option'),{value:'',textContent:n.length?'Select Wi-Fi':'No networks found'}),
...n.map(x=>Object.assign(document.createElement('option'),{value:x,textContent:x})));st.textContent=n.length?'Select your network':'No networks found'}
catch(e){st.textContent='Scan failed'}scanning=false;scan.disabled=false}
scan.onclick=async()=>{scanning=true;scan.disabled=true;st.textContent='Scanning...';try{await post('/scan');setTimeout(readScan,700)}catch(e){scanning=false;scan.disabled=false;st.textContent='Scan failed'}};
f.onsubmit=async e=>{e.preventDefault();if(f.elements.password.value!==f.elements.repeat.value){err.textContent='The passwords do not match';return}
err.textContent='';st.textContent='Connecting...';try{await post('/connect',new URLSearchParams(new FormData(f)))}catch(x){err.textContent=x.message}};
inst.onclick=async()=>{inst.disabled=true;st.textContent='Starting...';try{await post('/install','version='+encodeURIComponent(ver))}catch(x){st.textContent=x.message;inst.disabled=false}};
retry.onclick=()=>location.reload();
async function poll(){try{const s=await fetch('/status',{cache:'no-store'}).then(r=>r.json());ver=s.version;
document.querySelector('#title').textContent='CAW Clock v'+ver;inst.textContent='Install CAW Clock v'+ver;
if(!scanning)st.textContent=s.message+(s.progress>=0?' ('+s.progress+'%)':'');const ready=s.phase==='ready';
rel.classList.toggle('hidden',!ready);f.classList.toggle('hidden',ready||s.phase==='downloading'||s.phase==='verifying'||s.phase==='preparing');
retry.classList.toggle('hidden',s.phase!=='failed')}catch(e){}setTimeout(poll,1000)}poll();
(function(){var s=document.querySelector('select[name=timezone]');var z;try{z=Intl.DateTimeFormat().resolvedOptions().timeZone}catch(e){return}if(!z)return;
function o(t,m){var d=new Date(Date.UTC(2026,m,15,12));try{return Math.round((new Date(d.toLocaleString('en-US',{timeZone:t}))-new Date(d.toLocaleString('en-US',{timeZone:'UTC'})))/6e4)}catch(e){return NaN}}
var a=o(z,0),b=o(z,6),best=null;for(var i=0;i<s.options.length;i++){var p=s.options[i],q=p.getAttribute('data-z');if(!q)continue;if(q===z){best=p;break}
if(!best&&q!=='Etc/UTC'&&o(q,0)===a&&o(q,6)===b)best=p}if(best)best.selected=true})();
</script></main></body></html>)HTML";

void sendPage() {
  String page;
  page.reserve(9000);
  page += FPSTR(kPageHead);
  const char *region = nullptr;
  for (uint8_t index = 0; index < kCawTimeZoneCount; ++index) {
    const CawTimeZone zone = cawTimeZone(index);
    if (zone.region != region) {
      if (region) page += F("</optgroup>");
      region = zone.region;
      page += F("<optgroup label='");
      page += FPSTR(zone.region);
      page += F("'>");
    }
    page += F("<option value='");
    page += FPSTR(zone.rule);
    page += F("' data-z='");
    page += FPSTR(zone.iana);
    page += F("'>");
    page += FPSTR(zone.label);
    page += F("</option>");
  }
  if (region) page += F("</optgroup>");
  page += FPSTR(kPageTail);
  server.sendHeader(F("Cache-Control"), F("no-store"));
  server.send(200, F("text/html"), page);
}

String jsonEscape(const String &value) {
  String escaped;
  escaped.reserve(value.length() + 8);
  for (size_t index = 0; index < value.length(); ++index) {
    const char c = value[index];
    if (c == '"' || c == '\\') escaped += '\\';
    escaped += (c == '\n' || c == '\r') ? ' ' : c;
  }
  return escaped;
}

void sendStatus() {
  String body;
  body.reserve(200);
  body += F("{\"phase\":\"");
  body += phaseName();
  body += F("\",\"message\":\"");
  body += jsonEscape(statusMessage);
  body += F("\",\"progress\":");
  body += progressPercent;
  body += F(",\"version\":\"");
  body += kVersion;
  body += F("\"}");
  server.sendHeader(F("Cache-Control"), F("no-store"));
  server.send(200, F("application/json"), body);
}

void sendNetworks() {
  const int count = WiFi.scanComplete();
  if (count == WIFI_SCAN_RUNNING) {
    server.send(202, F("application/json"), F("[]"));
    return;
  }
  if (count < 0) {
    server.send(503, F("text/plain"), F("Wi-Fi scan failed"));
    return;
  }
  String body = "[";
  bool first = true;
  for (int index = 0; index < count; ++index) {
    const String name = WiFi.SSID(index);
    if (name.isEmpty()) continue;
    bool duplicate = false;
    for (int previous = 0; previous < index && !duplicate; ++previous)
      duplicate = WiFi.SSID(previous) == name;
    if (duplicate) continue;
    if (!first) body += ',';
    body += '"';
    body += jsonEscape(name);
    body += '"';
    first = false;
  }
  body += ']';
  WiFi.scanDelete();
  server.sendHeader(F("Cache-Control"), F("no-store"));
  server.send(200, F("application/json"), body);
}

void startNetworkScan() {
  if (WiFi.scanComplete() == WIFI_SCAN_RUNNING) {
    server.send(202, F("text/plain"), F("Scan already running"));
    return;
  }
  WiFi.scanDelete();
  if (WiFi.scanNetworks(true, true) == WIFI_SCAN_FAILED) {
    server.send(503, F("text/plain"), F("Cannot start a Wi-Fi scan"));
    return;
  }
  server.send(202, F("text/plain"), F("Scan started"));
}

void handleConnect() {
  const String ssid = server.arg("ssid");
  const String wifiPassword = server.arg("wifiPassword");
  const String password = server.arg("password");
  const String zone = server.arg("timezone");
  if (ssid.isEmpty() || ssid.length() > 32 || wifiPassword.length() > 64) {
    server.send(400, F("text/plain"), F("Choose a Wi-Fi network"));
    return;
  }
  if (password.length() < 8 || password.length() > 32 || password != server.arg("repeat")) {
    server.send(400, F("text/plain"), F("The clock password needs 8-32 characters, typed twice"));
    return;
  }
  if (!timezoneKnown(zone.c_str())) {
    server.send(400, F("text/plain"), F("Choose a time zone"));
    return;
  }
  memset(&config, 0, sizeof(config));
  strlcpy(config.ssid, ssid.c_str(), sizeof(config.ssid));
  strlcpy(config.wifiPassword, wifiPassword.c_str(), sizeof(config.wifiPassword));
  strlcpy(config.apiPassword, password.c_str(), sizeof(config.apiPassword));
  strlcpy(config.otaPassword, password.c_str(), sizeof(config.otaPassword));
  strlcpy(config.username, "admin", sizeof(config.username));
  // As CAW Clock's own setup page: the clock shows up as "caw-clock" on the
  // router (an empty name would fall back to "mini-display-XXXXXX").
  strlcpy(config.hostname, "caw-clock", sizeof(config.hostname));
  config.apiAuthEnabled = 1;
  config.otaAuthEnabled = 1;
  config.wifiRetryLimit = 3;
  config.directOtaEnabled = 1;
  strlcpy(timezoneRule, zone.c_str(), sizeof(timezoneRule));
  server.send(202, F("text/plain"), F("Connecting"));
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.hostname("caw-clock-installer");
  WiFi.begin(config.ssid, config.wifiPassword);
  connectStartedAt = millis();
  setStatus(Phase::Connecting, "Connecting to " + clipped(config.ssid, 18));
}

void handleInstall() {
  if (phase != Phase::Ready || WiFi.status() != WL_CONNECTED) {
    server.send(409, F("text/plain"), F("Wi-Fi is not connected"));
    return;
  }
  if (server.arg("version") != kVersion) {
    server.send(400, F("text/plain"), F("Unexpected version"));
    return;
  }
  installRequested = true;
  server.send(202, F("text/plain"), F("Installation started"));
}

// Requests are answered only on the setup network, whose key is on the
// screen. Once the installer has joined the home Wi-Fi its server is also
// reachable there, where anyone could otherwise set the clock's password.
template <typename Handler>
std::function<void()> setupNetworkOnly(Handler handler) {
  return [handler] {
    if (server.client().localIP() != WiFi.softAPIP()) {
      server.send(403, F("text/plain"), F("Use the clock's setup network"));
      return;
    }
    handler();
  };
}

void startPortal() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(networkName, networkKey);
  dns.start(kDnsPort, "*", WiFi.softAPIP());
  server.begin();
  portalRunning = true;
}

void stopPortal() {
  dns.stop();
  server.stop();
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  portalRunning = false;
  delay(100);
}

// ------------------------------------------------------------------ install

bool sha256Matches(const uint8_t actual[32]) {
  for (size_t index = 0; index < 32; ++index) {
    auto nibble = [](char c) -> int {
      if (c >= '0' && c <= '9') return c - '0';
      if (c >= 'a' && c <= 'f') return c - 'a' + 10;
      if (c >= 'A' && c <= 'F') return c - 'A' + 10;
      return -1;
    };
    const int high = nibble(kFirmwareSha256[index * 2]), low = nibble(kFirmwareSha256[index * 2 + 1]);
    if (high < 0 || low < 0 || actual[index] != static_cast<uint8_t>((high << 4) | low)) return false;
  }
  return true;
}

void failInstall(const String &message) {
  if (Update.isRunning()) Update.end(false);  // nothing activated
  startPortal();
  setStatus(Phase::Failed, message);
}

void downloadAndInstall() {
  stopPortal();  // more memory for the download
  const String downloading = String("Downloading v") + kVersion;
  setStatus(Phase::Downloading, downloading, 0);

  // Authenticity comes from the SHA-256 built into this image: a different
  // download is never activated, so certificate checks would only add the
  // risk of a missing root certificate.
  BearSSL::WiFiClientSecure client;
  client.setInsecure();
  client.setTimeout(kDownloadTimeoutMs);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(kDownloadTimeoutMs);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setRedirectLimit(5);
  http.setUserAgent(F("CAW-Clock-Installer"));
  const String url = String(kReleaseUrl) + kVersion + "/caw-clock-" + kVersion + ".bin";
  if (!http.begin(client, url)) {
    failInstall("Cannot open the GitHub address");
    return;
  }
  const int status = http.GET();
  if (status != HTTP_CODE_OK) {
    http.end();
    failInstall("GitHub answered " + String(status));
    return;
  }
  const int length = http.getSize();
  if (length <= 0) {
    http.end();
    failInstall("Unknown firmware size");
    return;
  }
  const size_t size = static_cast<size_t>(length);
  if (!Update.begin(size, U_FLASH)) {
    http.end();
    failInstall("No room: " + Update.getErrorString());
    return;
  }
  std::unique_ptr<uint8_t[]> buffer(new (std::nothrow) uint8_t[1024]);
  if (!buffer) {
    http.end();
    failInstall("Not enough memory");
    return;
  }
  br_sha256_context hash;
  br_sha256_init(&hash);
  WiFiClient *stream = http.getStreamPtr();
  uint8_t finalByte = 0;
  size_t received = 0;
  uint32_t lastData = millis();
  int shown = 0;
  while (received < size) {
    const size_t available = stream->available();
    if (!available) {
      if (!http.connected() || millis() - lastData > kDownloadTimeoutMs) {
        http.end();
        failInstall("The download stopped");
        return;
      }
      delay(1);
      continue;
    }
    const size_t wanted = std::min(std::min(available, size_t{1024}), size - received);
    const int count = stream->read(buffer.get(), wanted);
    if (count <= 0) {
      delay(1);
      continue;
    }
    lastData = millis();
    br_sha256_update(&hash, buffer.get(), count);
    // The last byte is held back: the image is complete, and so activated,
    // only after every check below passed.
    size_t writable = count;
    if (received + count == size) {
      finalByte = buffer[count - 1];
      --writable;
    }
    if (writable && Update.write(buffer.get(), writable) != writable) {
      http.end();
      failInstall("Flash write: " + Update.getErrorString());
      return;
    }
    received += count;
    const int percent = static_cast<int>(static_cast<uint64_t>(received) * 100 / size);
    if (percent >= shown + 5) {
      shown = percent;
      setStatus(Phase::Downloading, downloading, shown);
    }
    yield();
  }
  http.end();

  setStatus(Phase::Verifying, "Checking SHA-256");
  uint8_t digest[32];
  br_sha256_out(&hash, digest);
  if (!sha256Matches(digest)) {
    failInstall("Checksum mismatch: not installed");
    return;
  }

  setStatus(Phase::Preparing, "Preparing storage");
  // The stock firmware's files are of no use to CAW Clock: start clean, with
  // the time zone CAW Clock reads.
  if (!LittleFS.format() || !LittleFS.begin() || !writeTimezone()) {
    failInstall("Storage could not be prepared");
    return;
  }
  LittleFS.end();
  if (!saveConfig()) {
    failInstall("Settings could not be saved");
    return;
  }
  if (Update.write(&finalByte, 1) != 1 || !Update.end()) {
    failInstall("Firmware check failed");
    return;
  }
  setStatus(Phase::Preparing, "Installed. Restarting...");
  delay(1500);
  ESP.restart();
}

}  // namespace

void setup() {
  Serial.begin(115200);
  Serial.printf("\nCAW Clock installer for v%s\n", kVersion);
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, TFT_BACKLIGHT_ON);
  display.init();
  display.setRotation(0);
  display.setTextWrap(false, false);

  // Setup network: "CAW-Installer-" + the last 6 MAC digits, WPA2 with a
  // random 10-character key shown only on this screen (~50 bits). The radio
  // goes on first: the core notes (Esp.cpp) that with Wi-Fi off the hardware
  // generator behind ESP.random() is likely pseudo-random, and since core 3.0
  // Wi-Fi is off at boot.
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  delay(20);
  uint8_t mac[6];
  WiFi.softAPmacAddress(mac);
  snprintf(networkName, sizeof(networkName), "CAW-Installer-%02X%02X%02X", mac[3], mac[4], mac[5]);
  static const char kAlphabet[] = "abcdefghjkmnpqrstuvwxyz23456789";
  for (uint8_t index = 0; index < sizeof(networkKey) - 1; ++index)
    networkKey[index] = kAlphabet[ESP.random() % (sizeof(kAlphabet) - 1)];
  networkKey[sizeof(networkKey) - 1] = '\0';

  EEPROM.begin(kEepromSize);
  server.on("/", HTTP_GET, setupNetworkOnly(sendPage));
  server.on("/status", HTTP_GET, setupNetworkOnly(sendStatus));
  server.on("/scan", HTTP_POST, setupNetworkOnly(startNetworkScan));
  server.on("/networks", HTTP_GET, setupNetworkOnly(sendNetworks));
  server.on("/connect", HTTP_POST, setupNetworkOnly(handleConnect));
  server.on("/install", HTTP_POST, setupNetworkOnly(handleInstall));
  server.onNotFound(setupNetworkOnly([] {
    server.sendHeader(F("Location"), F("http://192.168.4.1/"), true);
    server.send(302, F("text/plain"), F("Open the installer"));
  }));
  startPortal();
  drawStatus();
}

void loop() {
  if (portalRunning) {
    dns.processNextRequest();
    server.handleClient();
  }
  if (phase == Phase::Connecting) {
    if (WiFi.status() == WL_CONNECTED) {
      setStatus(Phase::Ready, "Wi-Fi connected. Install when ready.");
    } else if (millis() - connectStartedAt >= kConnectTimeoutMs) {
      WiFi.disconnect();
      setStatus(Phase::Failed, "Could not join that Wi-Fi. Check the password.");
    }
  }
  if (installRequested) {
    installRequested = false;
    downloadAndInstall();
  }
  delay(2);
}
