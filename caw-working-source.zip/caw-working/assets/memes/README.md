# Bundled CAW memes

Pictures in this folder are built into the CAW firmware and rotate in the
56 x 56 slot at the top left of the screen (with the original crow).

* PNG, JPG, WebP or GIF (first frame). Anything not square is cropped to the
  centre square, then scaled to 56 x 56.
* Order on the clock follows the file names when rotation is "in order".
* After adding or removing pictures run, from the repository root:

      python3 firmware/scripts/caw_memes.py --preview /tmp/memes.png

  which regenerates `firmware/src/CawStandalone/CawMemes.h` (commit it) and
  writes a preview sheet at the clock's real size.
* Budget: about 6.3 KB each; the script stops at 30 pictures / 200 KB so the
  firmware keeps room under the OTA limit.
